#!/usr/bin/env python3
"""
CARET firm export reader for the Law Offices of Charles A. Ray, P.C.
Version 2, November 2026. One copy of this file ships in each CARET skill
(day notes, hearing prep, calendar conflicts, playbook). Keep them identical.

CARET Legal has no API. Its firm export (Firm Settings, Your CARET Legal
Account, Export, Download Data) saves a zip named FirmExport-<n>.zip to
Downloads, holding one CSV per record type: Notes, Calendar, Matter, Task,
Hours, Contact(Person), Contact(Company), Invoice, and the Check files.

    from caret_export import find_export, read_table, read_calendar
    exp = find_export()                     # newest FirmExport in Downloads or Claude AI Reports
    notes = read_table(exp, "Notes")        # list of dicts, headers normalized
    evs, unread, info = read_calendar(exp, start, end, outlook=outlook_items)

What version 2 changes

    CARET writes email HTML into its text fields without escaping it for CSV:
    quotes inside a field are not doubled, and line breaks and commas can sit
    inside a field. A standard CSV reader loses its place at the first one and
    every row after it comes apart. The reader here does not trust CARET's
    quoting. A quote closes a field only where a comma or a line end follows
    it. A row that comes out short is joined to the piece that follows it. A
    row that comes out long has its extra pieces folded back into the text
    column they broke out of, chosen by what the rest of the row then looks
    like. Every repair is counted, and a row that cannot be put back together
    is set aside by line number, never guessed at. table_health() reports it.

    read_calendar() is the one way the skills read Calendar.csv. It drops rows
    outside the date window before it touches their HTML, so a 58,000-row
    calendar reads in seconds. It folds one item filed under two matters into
    one event that names both. It reads CARET's times against Outlook (below).

CARET times

    CARET labels its times UTC (+00:00). Charles found they are not: an item at
    10:00 a.m. in Outlook is stored in CARET as 11:00 "UTC". So the time as
    written is the starting point, and the offset between CARET and Outlook is
    measured on items that appear in both, separately for daylight and
    standard time. The measurement is saved to CARET Time Calibration.json in
    the Claude AI Reports folder, so a run without Outlook still uses it. With
    no measurement anywhere, the time is read as written and every CARET time
    on the page says so. An all-day item always keeps the date as written.

Every row keeps its line number in the CSV as "_row", so anything built from it
can cite the line it came from. Columns are looked up by meaning, not exact
spelling: CARET spells some headers its own way ("Descrption"). A column that
cannot be found is reported, never guessed.
"""

import html
import json
import os
import re
import zipfile
from collections import Counter
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path

READER_VERSION = 2

# ------------------------------------------------------------------ finding it

SEARCH_DIRS = [
    "~/Downloads",
    "~/OneDrive/Claude AI Reports", "~/OneDrive/ClaudeAIReports",
    "~/Claude AI Reports", "~/Documents/Claude AI Reports",
]


def _roots():
    """The home folder and every folder connected to this session (Claude's
    desktop app mounts each under ~/mnt/<name>)."""
    home = Path(os.path.expanduser("~"))
    roots = [home]
    mnt = home / "mnt"
    if mnt.is_dir():
        roots += [d for d in sorted(mnt.iterdir()) if d.is_dir()]
    return roots


def _candidates(dirs):
    out = []
    for d in dirs:
        base = Path(os.path.expanduser(d))
        if not base.exists():
            continue
        for p in base.glob("FirmExport*"):
            if p.suffix.lower() == ".zip" or p.is_dir():
                out.append(p)
    # OneDrive business folders carry the firm name: look one level under each
    # OneDrive*, under home and under every connected folder
    for root in _roots():
        places = [root, root / "Downloads"] + list(root.glob("OneDrive*"))
        for od in places:
            if not od.is_dir():
                continue
            for sub in list(od.glob("*Claude*")) + [od]:
                for p in sub.glob("FirmExport*"):
                    if (p.suffix.lower() == ".zip" or p.is_dir()) and p not in out:
                        out.append(p)
    return out


def find_export(path=None, dirs=None):
    """The export to read: the path given, or the newest FirmExport zip or
    folder in Downloads or Claude AI Reports. None if there is none."""
    if path:
        p = Path(os.path.expanduser(str(path)))
        if not p.exists():
            raise FileNotFoundError(f"No export at {p}")
        if p.is_dir() and not any(p.glob("*.csv")):
            inner = sorted([q for q in p.glob("FirmExport*") if q.suffix.lower() == ".zip" or q.is_dir()],
                           key=lambda q: q.stat().st_mtime)
            if inner:
                return inner[-1]
        return p
    cands = _candidates(dirs or SEARCH_DIRS)
    if not cands:
        return None
    return max(cands, key=lambda q: q.stat().st_mtime)


def reports_dir(create=False):
    """The Claude AI Reports folder on OneDrive, where everything that must
    survive between sessions is kept: the alert log, the conversion tracker,
    the playbook standard, the time calibration. A skill's own folder does not
    persist between sessions, so nothing is saved there.

    CRLAW_REPORTS overrides it. Otherwise the first that exists of OneDrive
    (any OneDrive* folder, business ones included), then the home folder. With
    create=True and none existing, it is made under OneDrive if there is one,
    else under the home folder."""
    env = os.environ.get("CRLAW_REPORTS")
    if env:
        p = Path(os.path.expanduser(env))
        if create:
            p.mkdir(parents=True, exist_ok=True)
        return p
    tries = []
    for root in _roots():
        if _norm(root.name) in ("claudeaireports",):
            tries.append(root)          # the folder itself, connected to the chat
        for od in sorted(root.glob("OneDrive*")):
            tries += [od / "Claude AI Reports", od / "ClaudeAIReports"]
        tries += [root / "Claude AI Reports"]
    home = Path(os.path.expanduser("~"))
    tries += [home / "Documents" / "Claude AI Reports"]
    for t in tries:
        if t.is_dir():
            return t
    if not create:
        return None
    for root in _roots():
        ods = sorted(root.glob("OneDrive*"))
        if ods:
            p = ods[0] / "Claude AI Reports"
            p.mkdir(parents=True, exist_ok=True)
            return p
    p = home / "Claude AI Reports"
    p.mkdir(parents=True, exist_ok=True)
    return p


def persist_warning():
    """A line to show Charles when the Claude AI Reports folder in use is not
    on his OneDrive, so anything saved there may not be there next session.
    None when it is fine."""
    d = reports_dir()
    if d is None:
        return ("No Claude AI Reports folder is connected. Nothing this run saves "
                "will be there next time. Connect the OneDrive folder Claude AI "
                "Reports to this chat and run again.")
    mnt = Path(os.path.expanduser("~")) / "mnt"
    connected = mnt in Path(d).parents
    if "onedrive" not in str(d).lower() and not connected and not os.environ.get("CRLAW_REPORTS"):
        return (f"The Claude AI Reports folder in use ({d}) is not on OneDrive, so "
                "what this run saves may not be there next session. Connect the "
                "OneDrive folder Claude AI Reports to this chat.")
    return None


def export_taken(exp):
    """When the export was taken: the newest file time inside it."""
    p = Path(exp)
    if p.suffix.lower() == ".zip":
        with zipfile.ZipFile(p) as z:
            times = [datetime(*i.date_time) for i in z.infolist() if i.filename.lower().endswith(".csv")]
        return max(times) if times else datetime.fromtimestamp(p.stat().st_mtime)
    files = list(p.glob("*.csv"))
    return datetime.fromtimestamp(max(f.stat().st_mtime for f in files)) if files else \
        datetime.fromtimestamp(p.stat().st_mtime)


def export_age_days(exp, today=None):
    today = today or date.today()
    return (today - export_taken(exp).date()).days


def list_tables(exp):
    p = Path(exp)
    if p.suffix.lower() == ".zip":
        with zipfile.ZipFile(p) as z:
            return sorted(Path(n).stem for n in z.namelist() if n.lower().endswith(".csv"))
    return sorted(f.stem for f in p.glob("*.csv"))


# ------------------------------------------------------------------ reading it

def _norm(h):
    return re.sub(r"[^a-z0-9]", "", str(h or "").lower())


def _decode(b):
    for enc in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            return b.decode(enc)
        except UnicodeDecodeError:
            continue
    return b.decode("utf-8", "replace")


def _raw(exp, name):
    p = Path(exp)
    want = _norm(name)
    if p.suffix.lower() == ".zip":
        with zipfile.ZipFile(p) as z:
            for n in z.namelist():
                if n.lower().endswith(".csv") and _norm(Path(n).stem) == want:
                    return _decode(z.read(n)), n
    else:
        for f in p.glob("*.csv"):
            if _norm(f.stem) == want:
                return _decode(f.read_bytes()), f.name
    return None, None


# A quoted field ends at the first quote that a comma or a line end follows.
# A quote anywhere else inside it is text, which is how CARET's unescaped HTML
# attributes (href="...") stay inside their field.
_QUOTED = re.compile(r'"(.*?)"(?=,|\r?\n|\Z)', re.S)
_UNQUOTED = re.compile(r'[^,\r\n]*')
_SEP = re.compile(r',|\r?\n|\Z')


def _records(text):
    """Split CSV text into records without trusting the quoting. Yields
    (line, fields), line being where the record starts, the header being 1."""
    pos, n, line = 0, len(text), 1
    while pos < n:
        start_line = line
        fields = []
        while True:
            if pos < n and text[pos] == '"':
                m = _QUOTED.match(text, pos)
                if m:
                    val = m.group(1).replace('""', '"')
                    line += text.count("\n", pos, m.end())
                    pos = m.end()
                else:
                    # an opening quote that never closes before the end: read to the line end
                    m = _UNQUOTED.match(text, pos + 1)
                    val = m.group(0)
                    pos = m.end()
            else:
                m = _UNQUOTED.match(text, pos)
                val = m.group(0)
                pos = m.end()
            # anything between a closing quote and the separator stays with the field
            if pos < n and text[pos] not in ",\r\n":
                m = _UNQUOTED.match(text, pos)
                val += m.group(0)
                pos = m.end()
            fields.append(val)
            if pos >= n:
                break
            if text[pos] == ",":
                pos += 1
                continue
            # a line end closes the record
            if text[pos] == "\r":
                pos += 1
            if pos < n and text[pos] == "\n":
                pos += 1
            line += 1
            break
        yield start_line, fields


_DATE = re.compile(r"^\s*(\d{4}-\d{2}-\d{2}([T ]\d{1,2}:\d{2}(:\d{2})?(\.\d+)?)?\s*(Z|[+-]\d{2}:?\d{2})?"
                   r"|\d{1,2}/\d{1,2}/\d{2,4}( \d{1,2}:\d{2}(:\d{2})?( ?[AP]M)?)?)\s*$", re.I)
_BOOL = re.compile(r"^\s*(true|false|yes|no)\s*$", re.I)
_INT = re.compile(r"^\s*-?\d+(\.\d+)?\s*$")


def _kind(v):
    if not v or not v.strip():
        return "empty"
    if len(v) > 80:
        return "text"
    if _DATE.match(v):
        return "date"
    if _BOOL.match(v):
        return "bool"
    if _INT.match(v):
        return "num"
    return "text"


def _hint_kinds(header):
    """What a column should hold, from its name alone, for when there are too
    few clean rows to learn it from."""
    h = _norm(header)
    if h.endswith("by") or h.endswith("name") or h in ("owner", "subject"):
        return None
    if re.search(r"(date|time)$|^(created|modified|lastedited|due|completed|from|to|start|end)$", h):
        return {"date", "empty"}
    if h.startswith("is") or h in ("allday", "recurring", "private", "closed", "billable"):
        return {"bool", "empty"}
    return None   # anything


class _Profile:
    """What each column holds, learned from the rows that came out whole."""

    def __init__(self, header, clean_rows):
        self.n = len(header)
        self.expect = []
        learned = len(clean_rows) >= 20
        for i, h in enumerate(header):
            hint = _hint_kinds(h)
            if learned:
                c = Counter(_kind(r[i]) for r in clean_rows)
                filled = {k: v for k, v in c.items() if k != "empty"}
                tot = sum(filled.values())
                # Only dates and TRUE/FALSE are held to their kind: they are the
                # anchors that keep a row in line. Anything else, including a
                # column that happened to be blank in the sample, takes any value.
                ks = None
                if tot:
                    top, n_top = max(filled.items(), key=lambda kv: kv[1])
                    if top in ("date", "bool") and n_top / tot >= 0.99:
                        ks = {top, "empty"}
                elif hint:
                    ks = hint
                self.expect.append(ks)
            else:
                self.expect.append(hint)
        # the columns text can spill out of: free text, widest first
        self.text_cols = [i for i, e in enumerate(self.expect) if e is None]

    def score(self, fields):
        """How many columns hold what they should."""
        s = 0
        for i, v in enumerate(fields[:self.n]):
            e = self.expect[i]
            if e is None or _kind(v) in e:
                s += 1
        return s

    def fits(self, fields):
        return len(fields) == self.n and self.score(fields) >= self.n - 1


_ATOM = re.compile(r"([^,\n]*)(,|\n|\Z)")


def _atoms(text):
    """Every piece between commas and line ends, with the separator after it
    and the line it starts on."""
    out = []
    line = 1
    pos, n = 0, len(text)
    while pos <= n:
        m = _ATOM.match(text, pos)
        val, sep = m.group(1), m.group(2)
        out.append((val, sep, line))
        if sep == "\n":
            line += 1
        if m.end() == pos:          # end of text
            break
        pos = m.end()
        if pos >= n and sep != "":
            break
    return out


def _unq(v):
    v = v.rstrip("\r")
    s = v.strip()
    if len(s) >= 2 and s[0] == '"' and s[-1] == '"':
        return s[1:-1].replace('""', '"')
    return v


class _Fitter:
    """Fits the pieces of a CSV that CARET wrote without escaping back into
    rows of the header's width. A typed column (dates, TRUE/FALSE, numbers)
    takes exactly one piece and it must read as its kind. A free-text column
    takes as many pieces as it needs; when it opens with a quote it closes on
    a piece that ends with one. The first fit that reaches a line end with
    every column placed is the row."""

    MAX_SPAN = 600

    def __init__(self, atoms, prof):
        self.a = atoms
        self.p = prof
        self.n = prof.n
        self._rowstart = {}

    def _line(self, k):
        """The pieces of the physical line starting at piece k."""
        out = []
        while k < len(self.a):
            out.append(self.a[k])
            if self.a[k][1] != ",":
                break
            k += 1
        return out

    def _is_row_start(self, k):
        """True when the physical line at piece k is a whole row on its own."""
        if k not in self._rowstart:
            ln = self._line(k)
            ok = len(ln) == self.n and self.p.score([_unq(x[0]) for x in ln]) >= self.n
            if ok:
                for v, _, _ in ln:
                    t = v.rstrip("\r")
                    # a field starts right after its comma, and a quoted one
                    # closes on the same piece; email prose does neither
                    if t[:1].isspace() or (t.lstrip().startswith('"') != t.endswith('"')) or t.strip() == '"':
                        ok = False
                        break
            self._rowstart[k] = ok
        return self._rowstart[k]

    def _ok_typed(self, i, c):
        raw = self.a[i][0]
        if raw[:1].isspace():
            return False                # a date or TRUE/FALSE never follows ", "
        v = _unq(raw)
        return _kind(v) in self.p.expect[c]

    def _ends(self, i, c):
        """Where column c may end when it starts at piece i, shortest first."""
        a = self.a
        last = len(a) - 1
        if self.p.expect[c] is not None:
            return [i] if self._ok_typed(i, c) else []
        first = a[i][0].lstrip()
        if first.startswith('"'):
            return self._quoted_ends(i, c)
        ends = [i]
        for k in range(i + 1, min(last, i + 40) + 1):
            if a[k - 1][1] != ",":      # unquoted text never runs past a line end
                break
            ends.append(k)
        return ends

    def _quoted_ends(self, i, c):
        """Ends for a field that opens with a quote, lazily, so the usual case
        (the first plausible end) costs one short scan.

        An end the next field can plausibly start after comes first: a line
        end, or a next piece that starts right after the comma. A quote, a
        comma, and a space ("we can extend", then hung up) is a sentence going
        on, and those ends are tried last. A quoted field never runs into a
        line that is a whole row on its own."""
        a = self.a
        last = len(a) - 1

        def good(k):
            # a field starts right after its comma; words after a comma and a
            # space are the same sentence going on
            if a[k][1] != ",":
                return True
            nx = a[k + 1][0] if k + 1 < len(a) else ""
            return not nx[:1].isspace()
        later = []
        first = a[i][0].lstrip().rstrip("\r")
        if len(first) >= 2 and first.endswith('"'):
            if good(i):
                yield i
            else:
                later.append(i)
        for k in range(i + 1, min(last, i + self.MAX_SPAN) + 1):
            if a[k - 1][1] == "":
                break
            # a quoted field never runs into a line that is a whole row itself
            if a[k - 1][1] == "\n" and self._is_row_start(k):
                break
            if a[k][0].rstrip("\r").endswith('"'):
                if good(k):
                    yield k
                else:
                    later.append(k)
        yield from later

    def fit(self, i):
        """(fields, next piece index) for the row starting at piece i, or None."""
        a, n = self.a, self.n
        fail = set()
        cuts = []

        def go(c, j):
            if (c, j) in fail or j >= len(a):
                return False
            for k in self._ends(j, c):
                sep = a[k][1]
                if c == n - 1:
                    if sep in ("\n", ""):
                        cuts.append((j, k))
                        return True
                    continue
                if sep != ",":
                    continue
                cuts.append((j, k))
                if go(c + 1, k + 1):
                    return True
                cuts.pop()
            fail.add((c, j))
            return False

        if not go(0, i):
            return None
        fields, damaged = [], False
        for j, k in cuts:
            raw = "".join(a[x][0] + (a[x][1] if x < k else "") for x in range(j, k + 1))
            fields.append(_unq(raw))
            t = raw.rstrip("\r").strip()
            if t.startswith('"') and t.endswith('"') and len(t) >= 2:
                # a standard reader loses its place on a quote that is not doubled
                if '"' in t[1:-1].replace('""', ""):
                    damaged = True
            elif k > j:
                damaged = True          # unquoted text that carried commas
        self.damaged = damaged
        return fields, cuts[-1][1] + 1


def _fold_long(fields, prof):
    """A row with too many pieces: a comma broke a text field. Fold the extra
    pieces back into the text column that leaves the rest of the row reading
    right."""
    extra = len(fields) - prof.n
    best, best_s = None, -1
    cols = prof.text_cols or range(prof.n)
    for j in cols:
        cand = fields[:j] + [",".join(fields[j:j + extra + 1])] + fields[j + extra + 1:]
        s = prof.score(cand)
        if s > best_s:
            best, best_s = cand, s
    if best is not None and best_s >= prof.n - 1:
        return best
    return None


_HEALTH = {}


def table_health(name):
    """How the last read of this table went: rows in the file, rows read
    whole, rows put back together, and rows set aside with their lines."""
    return _HEALTH.get(_norm(name))


def health_line(name):
    """One plain line for the page: "Calendar.csv: 58,181 rows read, 412 with
    email text CARET did not escape, read around it; 3 set aside (rows 1022,
    5310, 9071)". None if unread."""
    h = table_health(name)
    if not h:
        return None
    s = f"{h['file']}: {h['read']:,} rows read"
    if h["repaired"]:
        s += f" ({h['repaired']:,} with email text CARET did not escape, read around it)"
    if h["set_aside"]:
        lines = ", ".join(str(x) for x in h["set_aside_rows"][:8])
        more = f" and {len(h['set_aside_rows']) - 8:,} more" if len(h["set_aside_rows"]) > 8 else ""
        s += f", {h['set_aside']:,} set aside (line {lines}{more})" if h["set_aside"] == 1 else \
            f", {h['set_aside']:,} set aside (lines {lines}{more})"
    if h.get("kept") is not None and h["kept"] != h["read"]:
        s += f"; {h['kept']:,} in the window"
    return s


def read_table(exp, name, keep=None):
    """Rows of one CSV as dicts keyed by normalized header, each with _row (the
    line in the file where the record starts, header is 1), _file, and
    _repaired when CARET's unescaped text had to be fitted back into place. []
    if the table is not in the export.

    keep, if given, is called on each row before it is stored; a row it
    rejects is dropped there, so a large table filtered by date costs little.
    table_health(name) reports the read afterwards."""
    text, fname = _raw(exp, name)
    if text is None:
        return []
    first = next(_records(text), None)
    if not first:
        return []
    head = first[1]
    keys = [_norm(h) for h in head]
    n = len(head)
    # learn what each column holds from rows that come out whole and whose
    # date and yes/no columns, by their names, read right
    hints = [_hint_kinds(h) for h in head]
    clean = []
    for k, (_, f) in enumerate(_records(text)):
        if k == 0:
            continue
        if len(f) == n and all(h is None or _kind(v) in h for h, v in zip(hints, f)):
            clean.append(f)
            if len(clean) >= 3000:
                break
        if k > 40000:
            break
    prof = _Profile(head, clean)
    atoms = _atoms(text)
    i = 0
    while i < len(atoms) and atoms[i][1] not in ("\n", ""):
        i += 1
    i += 1
    fitter = _Fitter(atoms, prof)
    out, repaired, set_aside, read_rows = [], 0, [], 0
    while i < len(atoms):
        val, sep, line = atoms[i]
        if not val.strip() and sep in ("\n", ""):
            i += 1
            continue
        res = fitter.fit(i)
        if res is None:
            set_aside.append(line)
            while i < len(atoms) and atoms[i][1] not in ("\n", ""):
                i += 1
            i += 1
            continue
        fields, nxt = res
        broken = fitter.damaged
        i = nxt
        read_rows += 1
        d = {k: (fields[x] if x < len(fields) else "") for x, k in enumerate(keys) if k}
        d["_row"] = line
        d["_file"] = fname
        if broken:
            d["_repaired"] = True
            repaired += 1
        if keep is not None and not keep(d):
            continue
        out.append(d)
    _HEALTH[_norm(name)] = {"file": Path(fname).name, "records": read_rows + len(set_aside),
                            "read": read_rows, "repaired": repaired, "set_aside": len(set_aside),
                            "set_aside_rows": set_aside, "kept": len(out) if keep else None}
    return out


def headers(exp, name):
    text, _ = _raw(exp, name)
    if text is None:
        return []
    for _, f in _records(text):
        return f
    return []


def col(row, *names, default=""):
    """The first of these columns the row has, matched by meaning. A name ending
    in * matches any header that starts with it."""
    for n in names:
        k = _norm(n)
        if n.endswith("*"):
            k = _norm(n[:-1])
            for rk, v in row.items():
                if not rk.startswith("_") and rk.startswith(k):
                    return v
        elif k in row:
            return row[k]
    return default


def has_col(rows, *names):
    if not rows:
        return False
    return any(col(rows[0], n, default=None) is not None for n in names)


# ------------------------------------------------------------------ cleaning

_STYLE = re.compile(r"(?is)<\s*(style|script|head)[^>]*>.*?<\s*/\s*\1\s*>")


def clean_text(s, limit=None):
    """CARET stores notes as HTML. Plain text, paragraphs kept as line breaks.
    limit cuts the HTML before cleaning, for fields that only feed a preview."""
    s = str(s or "")
    if limit and len(s) > limit * 6:
        s = s[:limit * 6]
    s = _STYLE.sub(" ", s)
    s = re.sub(r"(?i)<\s*(br|/p|/div|/li|/tr|/h\d)\s*/?>", "\n", s)
    s = re.sub(r"(?i)<\s*li[^>]*>", "\n- ", s)
    s = re.sub(r"<[^>]+>", " ", s)
    s = html.unescape(s).replace("\xa0", " ")
    lines = [" ".join(l.split()) for l in s.split("\n")]
    out = "\n".join(l for l in lines if l).strip()
    return out[:limit] if limit else out


def _nth_sunday(y, m, n):
    d = date(y, m, 1)
    d += timedelta(days=(6 - d.weekday()) % 7)
    return d + timedelta(weeks=n - 1)


def is_dst(d):
    """True when US Eastern is on daylight time on this date."""
    d = d.date() if isinstance(d, datetime) else d
    return _nth_sunday(d.year, 3, 2) <= d < _nth_sunday(d.year, 11, 1)


def eastern(dt):
    """US Eastern without a time zone database: daylight time from 2 a.m. on the
    second Sunday of March to 2 a.m. on the first Sunday of November."""
    if dt.tzinfo is None:
        return dt
    u = dt.astimezone(timezone.utc).replace(tzinfo=None)
    start = datetime.combine(_nth_sunday(u.year, 3, 2), datetime.min.time()) + timedelta(hours=7)
    end = datetime.combine(_nth_sunday(u.year, 11, 1), datetime.min.time()) + timedelta(hours=6)
    return u + timedelta(hours=-4 if start <= u < end else -5)


def parse_dt(s):
    """A date or date-time. Returns (datetime in Eastern, has_time) or
    (None, False). Offsets and Z are converted; a bare time is taken as
    Eastern; a bare date has no time. For CARET's own times use
    read_calendar, which does not trust CARET's +00:00."""
    s = str(s or "").strip()
    if not s:
        return None, False
    t = s.replace("Z", "+00:00")
    m = re.match(r"^(\d{4}-\d{2}-\d{2})[T ](\d{1,2}:\d{2}(?::\d{2})?(?:\.\d+)?)\s*([+-]\d{2}:?\d{2})?$", t)
    if m:
        d, tm, off = m.groups()
        tm = tm.split(".")[0]
        if len(tm.split(":")[0]) == 1:
            tm = "0" + tm
        if len(tm) <= 5:
            tm += ":00"
        dt = datetime.fromisoformat(f"{d}T{tm}")
        if off:
            off = off if ":" in off else off[:3] + ":" + off[3:]
            dt = datetime.fromisoformat(f"{d}T{tm}{off}")
            return eastern(dt), True
        return dt, True
    m = re.match(r"^(\d{4}-\d{2}-\d{2})$", t)
    if m:
        return datetime.fromisoformat(m.group(1)), False
    for fmt in ("%m/%d/%Y %I:%M:%S %p", "%m/%d/%Y %I:%M %p", "%m/%d/%Y %H:%M:%S", "%m/%d/%Y %H:%M"):
        try:
            return datetime.strptime(t, fmt), True
        except ValueError:
            pass
    for fmt in ("%m/%d/%Y", "%m/%d/%y"):
        try:
            return datetime.strptime(t, fmt), False
        except ValueError:
            pass
    return None, False


def wall_dt(s):
    """The date and time exactly as written, any offset ignored. Returns
    (naive datetime, has_time) or (None, False)."""
    s = str(s or "").strip()
    m = re.match(r"^(\d{4}-\d{2}-\d{2})(?:[T ](\d{1,2}):(\d{2})(?::(\d{2}))?)?", s)
    if m:
        d = date.fromisoformat(m.group(1))
        if m.group(2) is None:
            return datetime.combine(d, time()), False
        return datetime.combine(d, time(int(m.group(2)), int(m.group(3)), int(m.group(4) or 0))), True
    dt, has_t = parse_dt(s)
    return dt, has_t


def written_date(s):
    """The date as written, before anything else is done to it."""
    dt, _ = wall_dt(s)
    return dt.date() if dt else None


def truthy(s):
    return str(s or "").strip().lower() in ("true", "yes", "1", "y")


def split_matter(number_field, name_field=""):
    """CARET writes the matter number with the client after it, "01231-James
    Archie". The number alone, for keys and file names."""
    s = str(number_field or "").strip()
    m = re.match(r"^([A-Za-z]*\d[\w]*)(?:\s*-\s*.*)?$", s)
    return (m.group(1) if m else s), str(name_field or "").strip()


def is_lead(row):
    """CARET files a prospect's notes under the matter name "lead"."""
    return str(col(row, "MatterName")).strip().lower() == "lead"


# ------------------------------------------------------------------ same item, two places

_STOP = {"the", "a", "an", "and", "or", "of", "for", "to", "in", "on", "at", "by", "with", "re",
         "fw", "fwd", "mr", "ms", "mrs", "call", "meeting", "mtg", "w", "v", "vs"}


def subject_words(s):
    s = re.sub(r"\b\d{4,6}\b", " ", str(s or "").lower())       # matter numbers
    return {w for w in re.findall(r"[a-z0-9]+", s) if w not in _STOP and len(w) > 1}


def same_subject(a, b):
    """Two subjects name the same item: equal once case and punctuation are set
    aside, or most of the shorter one's words are in the longer one."""
    if _norm(a) and _norm(a) == _norm(b):
        return True
    A, B = subject_words(a), subject_words(b)
    if not A or not B:
        return False
    common = len(A & B)
    return common >= 2 and common / min(len(A), len(B)) >= 0.6


# ------------------------------------------------------------------ CARET times

CALIBRATION_FILE = "CARET Time Calibration.json"


def _season(d):
    return "daylight" if is_dst(d) else "standard"


def load_calibration(path=None):
    p = Path(path) if path else (reports_dir() / CALIBRATION_FILE if reports_dir() else None)
    if p and p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except (ValueError, OSError):
            return {}
    return {}


def save_calibration(cal, path=None):
    p = Path(path) if path else reports_dir(create=True) / CALIBRATION_FILE
    p.write_text(json.dumps(cal, indent=2), encoding="utf-8")
    return p


def measure_offsets(caret_items, outlook_items):
    """The offset from CARET's written time to Outlook's Eastern time, measured
    on timed items that are in both: same date (as written, a day either way),
    same subject. caret_items: (subject, naive written datetime). outlook_items:
    (subject, naive Eastern datetime). Returns {season: {"hours": h, "pairs": n,
    "agree": k, "examples": [...]}} for each season with a match."""
    by_day = {}
    for s, dt in outlook_items:
        if dt is None:
            continue
        by_day.setdefault(dt.date(), []).append((s, dt))
    # one CARET item filed under two matters is one item, measured once; and
    # each Outlook event is matched to one CARET item at most
    # A subject that repeats on one day ("Phone hold - IRS PPS" at 11, 12, and
    # 1) cannot be paired with certainty, so it is not used to measure.
    o_rep = Counter((odt.date(), _norm(s)) for s, odt in outlook_items if odt is not None)
    c_rep = Counter((w.date(), _norm(s)) for s, w in {(s, w) for s, w in caret_items if w is not None})
    seen_caret, cands = set(), []
    for ci, (s, wdt) in enumerate(caret_items):
        if wdt is None:
            continue
        key = (_norm(s), wdt)
        if key in seen_caret:
            continue
        seen_caret.add(key)
        if c_rep[(wdt.date(), _norm(s))] > 1:
            continue
        for dd in (0, -1, 1):
            for oi, (os_, odt) in enumerate(by_day.get(wdt.date() + timedelta(days=dd), [])):
                if o_rep[(odt.date(), _norm(os_))] > 1:
                    continue
                if same_subject(s, os_):
                    cands.append((abs((odt - wdt).total_seconds()), ci, (os_, odt), wdt))
    # closest pairs first; each CARET item and each Outlook event used once
    used_c, used_o, found = set(), set(), {}
    for gap, ci, (os_, odt), wdt in sorted(cands, key=lambda x: x[0]):
        if ci in used_c or (os_, odt) in used_o:
            continue
        used_c.add(ci)
        used_o.add((os_, odt))
        h = round((odt - wdt).total_seconds() / 1800) / 2     # to the half hour
        if abs(h) <= 14:
            found.setdefault(_season(odt), []).append((h, os_, odt))
    out = {}
    for season, xs in found.items():
        c = Counter(h for h, _, _ in xs)
        h, k = c.most_common(1)[0]
        ex = [f"{o} on {odt:%b %d}" for hh, o, odt in xs if hh == h][:3]
        out[season] = {"hours": h, "pairs": len(xs), "agree": k, "examples": ex}
    return out


def _trusted(m):
    """A measurement is trusted when at least two items agree on it and they
    are most of the matches. One item alone could be an item that moved."""
    return m["agree"] >= 2 and m["agree"] / m["pairs"] >= 0.6


def _calibration_for(day, measured, saved):
    """(hours, how) for a date: a trusted measurement this run, else saved
    from an earlier run, else the other season's trusted or saved value, else
    a single-item measurement (said so), else 0 with a note."""
    season = _season(day)
    other = "standard" if season == "daylight" else "daylight"
    m = measured.get(season)
    if m and _trusted(m):
        return m["hours"], f"measured on {m['agree']} of {m['pairs']} items also in Outlook"
    if season in saved:
        return saved[season]["hours"], f"measured {saved[season].get('measured', 'earlier')}"
    mo = measured.get(other)
    if mo and _trusted(mo):
        return mo["hours"], f"measured in {other} time; none in {season} time yet"
    if other in saved:
        return saved[other]["hours"], f"measured in {other} time; none in {season} time yet"
    if m:
        return 0, ("read as written: only one item is in both calendars, too few to "
                   "measure CARET's offset")
    return 0, "not yet checked against Outlook, read as written"


ALL_DAY_COLS = ("IsAllday", "IsAllDay", "AllDay", "AllDayEvent", "All Day Event", "IsAllDayEvent")


def _all_day(r):
    """All day by its flag, or, when no flag column is there, a start and end
    both at midnight as written, a day or more apart."""
    flag = col(r, *ALL_DAY_COLS, default=None)
    if flag is not None and str(flag).strip():
        return truthy(flag)
    s0, ts = wall_dt(col(r, "FromDate", "StartDate", "Start*", "From*"))
    e0, te = wall_dt(col(r, "ToDate", "EndDate", "End*", "To*"))
    return bool(s0 and e0 and ts and te and s0.time() == time() and e0.time() == time()
                and e0 > s0)


def calendar_rows(exp, start=None, end=None, margin_days=1):
    """Calendar.csv rows whose start, as written, falls in the window (a day of
    margin each side for the time offset). Nothing outside it is cleaned."""
    lo = start - timedelta(days=margin_days) if start else None
    hi = end + timedelta(days=margin_days) if end else None

    def keep(r):
        if lo is None and hi is None:
            return True
        d = written_date(col(r, "FromDate", "StartDate", "Start*", "From*"))
        if d is None:
            return True                      # unreadable rows are reported, never dropped
        return (lo is None or d >= lo) and (hi is None or d <= hi)
    return read_table(exp, "Calendar", keep=keep)


def read_calendar(exp, start=None, end=None, outlook=None, calibration_path=None,
                  save=True, body_chars=400):
    """Calendar.csv as events, Eastern, one per item.

    start, end: dates; rows outside [start, end] by their written date are
    dropped before anything else is done to them (end inclusive).
    outlook: [(subject, naive Eastern datetime or None)] for timed Outlook
    events, used to measure CARET's time offset. A measurement is saved to the
    Claude AI Reports folder unless save is False.

    Each event: subject, day, time (None when all day), all_day, start
    (datetime or None), end, location, body, categories, matters [numbers],
    matter_names, recurring, refs ["Calendar.csv row 12", ...], where (refs
    joined), time_note (how the time was read), raw_start, raw_end (as
    written). A season's offset is applied and saved only when two or more
    items agree on it; one item alone is used only when nothing else is
    known, and its note says so.
    Returns (events, unread, info). unread rows carry subject, start, where.
    info: health line, calibration used, items folded."""
    rows = calendar_rows(exp, start, end)
    saved = load_calibration(calibration_path)
    caret_timed = []
    for r in rows:
        if _all_day(r):
            continue
        w, has_t = wall_dt(col(r, "FromDate", "StartDate", "Start*", "From*"))
        if has_t:
            caret_timed.append((clean_text(col(r, "Subject", "Title"), limit=300), w))
    measured = measure_offsets(caret_timed, outlook) if outlook else {}
    if any(_trusted(v) for v in measured.values()) and save:
        stamp = date.today().isoformat()
        cal = dict(saved)
        for k, v in measured.items():
            if _trusted(v):
                cal[k] = {"hours": v["hours"], "measured": stamp, "pairs": v["pairs"], "agree": v["agree"]}
        try:
            save_calibration(cal, calibration_path)
        except OSError:
            pass

    evs, unread = [], []
    for r in rows:
        ref = f"Calendar.csv line {r['_row']}"
        subject = clean_text(col(r, "Subject", "Title"), limit=300).replace("\n", " ")
        raw_s = col(r, "FromDate", "StartDate", "Start*", "From*")
        raw_e = col(r, "ToDate", "EndDate", "End*", "To*")
        w, has_t = wall_dt(raw_s)
        if w is None:
            unread.append({"subject": subject, "start": raw_s, "where": ref})
            continue
        all_day = _all_day(r) or not has_t
        we, he = wall_dt(raw_e) if str(raw_e).strip() else (None, False)
        if all_day:
            day, tm, st, en, note = w.date(), None, None, None, "all day, date as written"
        else:
            hrs, how = _calibration_for(w.date(), measured, saved)
            st = w + timedelta(hours=hrs)
            en = (we + timedelta(hours=hrs)) if (we and he) else None
            day, tm = st.date(), st.time().replace(second=0, microsecond=0)
            note = f"CARET time {'moved ' + _fmt_h(hrs) if hrs else 'as written'} ({how})"
        if start and day < start or end and day > end:
            continue
        number, mname = split_matter(col(r, "MatterNumber", "Matter Number", "MatterNo"),
                                     col(r, "MatterName", "Matter Name"))
        cat = str(col(r, "CategoryName", "Category")).strip()
        evs.append({
            "subject": subject, "day": day, "time": tm, "all_day": all_day,
            "start": st, "end": en,
            "location": clean_text(col(r, "Location"), limit=200).replace("\n", ", "),
            "body": clean_text(col(r, "Descrption", "Description", "Notes"), limit=body_chars),
            "categories": [cat] if cat and cat.lower() != "none" else [],
            "matters": [number] if number else [], "matter_names": [mname] if mname else [],
            "recurring": truthy(col(r, "IsRecurring", "Recurring")),
            "refs": [ref], "where": ref, "time_note": note, "raw_start": raw_s, "raw_end": raw_e,
            "repaired": bool(r.get("_repaired")),
        })
    evs, folded = fold_duplicates(evs)
    h = table_health("Calendar") or {}
    if h.get("set_aside"):
        lines = h["set_aside_rows"]
        shown = ", ".join(str(x) for x in lines[:20]) + (f" and {len(lines) - 20} more" if len(lines) > 20 else "")
        unread.append({"subject": f"{len(lines)} calendar row(s) that could not be read",
                       "start": "", "where": f"Calendar.csv line(s) {shown}"})
    notes = []
    if rows and col(rows[0], *ALL_DAY_COLS, default=None) is None:
        notes.append("Calendar.csv has no all-day column; an entry from midnight to midnight is read as all day")
    info = {"health": health_line("Calendar"), "measured": measured, "saved": saved,
            "folded": folded, "rows_in_window": len(rows), "notes": notes}
    return evs, unread, info


def _fmt_h(h):
    sign = "back" if h < 0 else "forward"
    h = abs(h)
    return f"{sign} {int(h) if h == int(h) else h} hour{'s' if h != 1 else ''}"


def fold_duplicates(evs):
    """One item CARET files under two matters is one event naming both.
    Same day, same time (or both all day), same subject. Returns (events,
    folded) where folded counts the rows merged away."""
    out, folded = [], 0
    for e in sorted(evs, key=lambda x: (x["day"], x["time"] or time.min, x["subject"])):
        hit = None
        for o in reversed(out):
            if o["day"] != e["day"]:
                break
            if o["all_day"] == e["all_day"] and o["time"] == e["time"] and same_subject(o["subject"], e["subject"]):
                hit = o
                break
        if hit is None:
            out.append(e)
            continue
        folded += 1
        for k in ("matters", "matter_names", "refs"):
            for v in e[k]:
                if v not in hit[k]:
                    hit[k].append(v)
        hit["matters"].sort()
        hit["where"] = ", ".join(hit["refs"])
        if len(e["body"]) > len(hit["body"]):
            hit["body"] = e["body"]
    return out, folded


# ------------------------------------------------------------------ IRS contacts

CONTACTS_FILE = "IRS Contacts.txt"
_TITLE_KIND = [
    (re.compile(r"^(RA|revenue agent|examiner)\b", re.I), "Examination"),
    (re.compile(r"^(RO|revenue officer|ACS)\b", re.I), "Collection"),
    (re.compile(r"^(SO|AO|settlement officer|appeals officer)\b", re.I), "Appeals"),
]
_CONTACT = re.compile(r"^\s*(?:(RA|RO|SO|AO|ACS|PPS|(?i:revenue agent|revenue officer|settlement officer|"
                      r"appeals officer|examiner))\s+)?([A-Z][a-z][A-Za-z'\-]+(?:\s+[A-Z][a-z][A-Za-z'\-]+)?)\s*$")


def contacts_path(create=False):
    d = reports_dir(create=create)
    return d / CONTACTS_FILE if d else None


def load_contacts(path=None):
    """The IRS employees on Charles's matters, from IRS Contacts.txt in Claude
    AI Reports: one per line, as written, "RA Delgado" or "Settlement Officer
    Park" or "Delgado". Lines starting with # are notes. Returns
    [{"as_written", "surname", "kind"}]."""
    p = Path(path) if path else contacts_path()
    out = []
    if not p or not p.exists():
        return out
    for line in p.read_text(encoding="utf-8").splitlines():
        m = _CONTACT.match(line)
        if not m or line.lstrip().startswith("#"):
            continue
        title, name = m.group(1) or "", m.group(2)
        kind = next((k for rx, k in _TITLE_KIND if title and rx.match(title)), "Meeting")
        out.append({"as_written": line.strip(), "surname": name.split()[-1], "kind": kind})
    return out


NOT_A_NAME = {w.lower() for w in """
Monday Tuesday Wednesday Thursday Friday Saturday Sunday January February March April May
June July August September October November December Notice Notices Report Reports Letter
Letters Office Case Cases Call Calls Meeting Phone Fax Faxed Agent Officer Group Unit Team
Manager Request Response Received Sent Today Tomorrow Yesterday Status Update Follow Hold
Levy Lien Summons Exam Audit Appeal Appeals Hearing Transcript Transcripts Form Forms Package
Attached Attachment Email Voicemail Message Contact Confirmed Agreed Asked Said Needs Left
Gave Wants Will Would Should Called Spoke Again Back Office Memphis Ogden Philadelphia Kansas
Austin Fresno Atlanta Andover Cincinnati Covington Holtsville Chamblee Brookhaven Liaison
Penalty Penalties Installment Installments Abatement Agreement Agreements Offer Compromise
Collection Collections Balance Balances Payment Payments Plan Plans Account Accounts Return
Returns Refund Refunds Credit Credits Interest Assessment Assessments Determination
Conference Conferences Assigned Requested Request Requests Approved Denied Pending Granted
Closed Open Opened Review Reviewed Revenue Agent Officer Settlement Examination Appraisal
Withholding Garnishment Seizure Bank Wage Wages Statement Statements Financial Information
Document Documents Records Record Schedule Schedules Extension Deadline Due Filing Filed
Amended Final Initial Second Third Next Last New Prior Current Annual Quarterly Monthly
Trust Fund Recovery Business Personal Individual Corporate Partnership Estate Gift Payroll
Employment Excise Income Tax Taxes Taxpayer Taxpayers Client Clients Counsel Attorney Power
Representative Representation Signed Unsigned Original Copy Copies Fax Faxes Mail Mailed
Certified Letter Determination Substitute Proposed Deficiency Adjustment Adjustments Exam
Hardship Currently Collectible Status Reasonable Cause First Time Abate Waiver Lien Release
""".split()}

_NOT_NAME_SUFFIX = re.compile(r"(?:ed|tion|sion|ment|ance|ence|ity|ness|ure|ings|ies|ive|able|ible|ary|ory)$", re.I)


def looks_like_surname(w):
    """A capitalized word that reads as a name, not a tax word or a verb."""
    w = str(w or "")
    return (bool(re.fullmatch(r"[A-Z][a-z][A-Za-z'\-]+", w)) and w.lower() not in NOT_A_NAME
            and not _NOT_NAME_SUFFIX.search(w))


def add_contacts(officials, path=None, exclude=(), min_seen=2):
    """Adds officials found in his notes ("RA Delgado") to IRS Contacts.txt.
    Only a title followed by a capitalized name is added; a bare title is not.
    Returns the lines added."""
    p = Path(path) if path else contacts_path(create=True)
    have = {c["surname"].lower() for c in load_contacts(p)}
    if p.exists():
        # a line struck as "# Delgado" stays struck
        for line in p.read_text(encoding="utf-8").splitlines():
            m = re.match(r"^\s*#\s*(?:\S+\s+)*?([A-Z][a-z][A-Za-z'\-]+)\s*$", line)
            if m:
                have.add(m.group(1).lower())
    new = []
    # a name is learned once it is seen in min_seen notes (officials lists one
    # entry per note); one mention could be a word that only looks like a name
    seen = Counter()
    for o in officials or []:
        m0 = _CONTACT.match(" ".join(str(o).split()))
        if m0 and m0.group(1):
            seen[m0.group(2).split()[-1].lower()] += 1
    for o in officials or []:
        o = " ".join(str(o).split())
        m = _CONTACT.match(o)
        if not m or not m.group(1):
            continue
        sur = m.group(2).split()[-1]
        words = [w.lower() for w in m.group(2).split()]
        if (sur.lower() in have or len(sur) < 3 or any(w in NOT_A_NAME for w in words)
                or not all(looks_like_surname(w) for w in m.group(2).split())
                or seen[sur.lower()] < min_seen
                or sur.lower() in {str(x).lower() for x in exclude}):
            continue
        have.add(sur.lower())
        new.append(o)
    if new:
        head = "" if p.exists() else ("# IRS employees on your matters. One per line, as written: \"RA Delgado\".\n"
                                      "# Day notes adds the ones it finds in your notes. Add or strike any.\n")
        with p.open("a", encoding="utf-8") as f:
            f.write(head + "\n".join(new) + "\n")
    return new


def contact_in(text, contacts, exclude=()):
    """The first contact whose surname appears in the text as a capitalized
    whole word, or None. A surname in exclude (a client's, from the matter
    list) never counts: "Call client - Brooks" is not RO Brooks."""
    ex = {str(x).lower() for x in exclude}
    for c in contacts or []:
        if c["surname"].lower() in ex or not looks_like_surname(c["surname"]):
            continue
        if re.search(r"(?<![A-Za-z])" + re.escape(c["surname"]) + r"(?![A-Za-z])", str(text or "")):
            return c
    return None

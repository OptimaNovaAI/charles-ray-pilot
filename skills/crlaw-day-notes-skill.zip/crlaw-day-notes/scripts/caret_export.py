#!/usr/bin/env python3
"""
CARET firm export reader for the Law Offices of Charles A. Ray, P.C.

CARET Legal has no API. Its firm export (Firm Settings, Your CARET Legal
Account, Export, Download Data) saves a zip named FirmExport-<n>.zip to
Downloads, holding one CSV per record type: Notes, Calendar, Matter, Task,
Hours, Contact(Person), Contact(Company), Invoice, and the Check files.

This module finds the newest export and reads any of those CSVs straight out
of the zip, so nothing has to be unzipped or moved. It needs nothing installed.

    from caret_export import find_export, read_table, export_age_days
    exp = find_export()                    # newest FirmExport in Downloads or Claude AI Reports
    notes = read_table(exp, "Notes")       # list of dicts, headers normalized

Every row keeps its line number in the CSV as "_row", so anything built from it
can cite the line it came from. Columns are looked up by meaning, not exact
spelling: CARET spells some headers its own way ("Descrption"), and a header it
renames later still reads. A column that cannot be found is reported, never
guessed.
"""

import csv
import html
import io
import os
import re
import zipfile
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

# ------------------------------------------------------------------ finding it

SEARCH_DIRS = [
    "~/Downloads",
    "~/OneDrive/Claude AI Reports", "~/OneDrive/ClaudeAIReports",
    "~/Claude AI Reports", "~/Documents/Claude AI Reports",
]


def _candidates(dirs):
    out = []
    for d in dirs:
        base = Path(os.path.expanduser(d))
        if not base.exists():
            continue
        for p in base.glob("FirmExport*"):
            if p.suffix.lower() == ".zip" or p.is_dir():
                out.append(p)
    # OneDrive business folders carry the firm name: look one level under each OneDrive*
    home = Path(os.path.expanduser("~"))
    for od in home.glob("OneDrive*"):
        for sub in list(od.glob("*Claude*")) + [od]:
            for p in sub.glob("FirmExport*"):
                if p.suffix.lower() == ".zip" or p.is_dir():
                    out.append(p)
    return out


def find_export(path=None, dirs=None):
    """The export to read: the path given, or the newest FirmExport zip or
    folder in Downloads or Claude AI Reports. None if there is none."""
    if path:
        p = Path(os.path.expanduser(str(path)))
        if not p.exists():
            raise FileNotFoundError(f"No export at {p}")
        if p.is_dir() and not any(p.glob("*.csv")):
            inner = sorted([q for q in p.glob("FirmExport*") if q.suffix.lower() == ".zip" or q.is_dir()],
                           key=lambda q: q.stat().st_mtime)
            if inner:
                return inner[-1]
        return p
    cands = _candidates(dirs or SEARCH_DIRS)
    if not cands:
        return None
    return max(cands, key=lambda q: q.stat().st_mtime)


def export_taken(exp):
    """When the export was taken: the newest file time inside it."""
    p = Path(exp)
    if p.suffix.lower() == ".zip":
        with zipfile.ZipFile(p) as z:
            times = [datetime(*i.date_time) for i in z.infolist() if i.filename.lower().endswith(".csv")]
        return max(times) if times else datetime.fromtimestamp(p.stat().st_mtime)
    files = list(p.glob("*.csv"))
    return datetime.fromtimestamp(max(f.stat().st_mtime for f in files)) if files else \
        datetime.fromtimestamp(p.stat().st_mtime)


def export_age_days(exp, today=None):
    today = today or date.today()
    return (today - export_taken(exp).date()).days


def list_tables(exp):
    p = Path(exp)
    if p.suffix.lower() == ".zip":
        with zipfile.ZipFile(p) as z:
            return sorted(Path(n).stem for n in z.namelist() if n.lower().endswith(".csv"))
    return sorted(f.stem for f in p.glob("*.csv"))


# ------------------------------------------------------------------ reading it

def _norm(h):
    return re.sub(r"[^a-z0-9]", "", str(h or "").lower())


def _decode(b):
    for enc in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            return b.decode(enc)
        except UnicodeDecodeError:
            continue
    return b.decode("utf-8", "replace")


def _raw(exp, name):
    p = Path(exp)
    want = _norm(name)
    if p.suffix.lower() == ".zip":
        with zipfile.ZipFile(p) as z:
            for n in z.namelist():
                if n.lower().endswith(".csv") and _norm(Path(n).stem) == want:
                    return _decode(z.read(n)), n
    else:
        for f in p.glob("*.csv"):
            if _norm(f.stem) == want:
                return _decode(f.read_bytes()), f.name
    return None, None


def read_table(exp, name):
    """Rows of one CSV as dicts keyed by normalized header, each with _row (the
    line in the file, header is 1) and _file. [] if the table is not in the
    export."""
    text, fname = _raw(exp, name)
    if text is None:
        return []
    rdr = csv.reader(io.StringIO(text))
    try:
        head = next(rdr)
    except StopIteration:
        return []
    keys = [_norm(h) for h in head]
    rows = []
    line = 1
    for rec in rdr:
        line += 1
        if not any(c.strip() for c in rec):
            continue
        d = {k: (rec[i] if i < len(rec) else "") for i, k in enumerate(keys) if k}
        d["_row"] = line
        d["_file"] = fname
        rows.append(d)
    return rows


def headers(exp, name):
    text, _ = _raw(exp, name)
    if text is None:
        return []
    return next(csv.reader(io.StringIO(text)), [])


def col(row, *names, default=""):
    """The first of these columns the row has, matched by meaning. A name ending
    in * matches any header that starts with it."""
    for n in names:
        k = _norm(n)
        if n.endswith("*"):
            k = _norm(n[:-1])
            for rk, v in row.items():
                if not rk.startswith("_") and rk.startswith(k):
                    return v
        elif k in row:
            return row[k]
    return default


def has_col(rows, *names):
    if not rows:
        return False
    return any(col(rows[0], n, default=None) is not None for n in names)


# ------------------------------------------------------------------ cleaning

def clean_text(s):
    """CARET stores notes as HTML. Plain text, paragraphs kept as line breaks."""
    s = str(s or "")
    s = re.sub(r"(?i)<\s*(br|/p|/div|/li|/tr|/h\d)\s*/?>", "\n", s)
    s = re.sub(r"(?i)<\s*li[^>]*>", "\n- ", s)
    s = re.sub(r"<[^>]+>", " ", s)
    s = html.unescape(s).replace("\xa0", " ")
    lines = [" ".join(l.split()) for l in s.split("\n")]
    return "\n".join(l for l in lines if l).strip()


def _nth_sunday(y, m, n):
    d = date(y, m, 1)
    d += timedelta(days=(6 - d.weekday()) % 7)
    return d + timedelta(weeks=n - 1)


def eastern(dt):
    """US Eastern without a time zone database: daylight time from 2 a.m. on the
    second Sunday of March to 2 a.m. on the first Sunday of November."""
    if dt.tzinfo is None:
        return dt
    u = dt.astimezone(timezone.utc).replace(tzinfo=None)
    start = datetime.combine(_nth_sunday(u.year, 3, 2), datetime.min.time()) + timedelta(hours=7)
    end = datetime.combine(_nth_sunday(u.year, 11, 1), datetime.min.time()) + timedelta(hours=6)
    return u + timedelta(hours=-4 if start <= u < end else -5)


def parse_dt(s):
    """A CARET date or date-time. Returns (datetime in Eastern, has_time) or
    (None, False). Offsets and Z are converted; a bare time is taken as
    Eastern; a bare date has no time."""
    s = str(s or "").strip()
    if not s:
        return None, False
    t = s.replace("Z", "+00:00")
    m = re.match(r"^(\d{4}-\d{2}-\d{2})[T ](\d{1,2}:\d{2}(?::\d{2})?(?:\.\d+)?)\s*([+-]\d{2}:?\d{2})?$", t)
    if m:
        d, tm, off = m.groups()
        tm = tm.split(".")[0]
        if len(tm) <= 5:
            tm += ":00"
        dt = datetime.fromisoformat(f"{d}T{tm}")
        if off:
            off = off if ":" in off else off[:3] + ":" + off[3:]
            dt = datetime.fromisoformat(f"{d}T{tm}{off}")
            return eastern(dt), True
        return dt, True
    m = re.match(r"^(\d{4}-\d{2}-\d{2})$", t)
    if m:
        return datetime.fromisoformat(m.group(1)), False
    for fmt in ("%m/%d/%Y %I:%M:%S %p", "%m/%d/%Y %I:%M %p", "%m/%d/%Y %H:%M:%S", "%m/%d/%Y %H:%M"):
        try:
            return datetime.strptime(t, fmt), True
        except ValueError:
            pass
    for fmt in ("%m/%d/%Y", "%m/%d/%y"):
        try:
            return datetime.strptime(t, fmt), False
        except ValueError:
            pass
    return None, False


def truthy(s):
    return str(s or "").strip().lower() in ("true", "yes", "1", "y")


def split_matter(number_field, name_field=""):
    """CARET writes the matter number with the client after it, "01231-James
    Archie". The number alone, for keys and file names."""
    s = str(number_field or "").strip()
    m = re.match(r"^([A-Za-z]*\d[\w]*)(?:\s*-\s*.*)?$", s)
    return (m.group(1) if m else s), str(name_field or "").strip()


def is_lead(row):
    """CARET files a prospect's notes under the matter name "lead"."""
    return str(col(row, "MatterName")).strip().lower() == "lead"

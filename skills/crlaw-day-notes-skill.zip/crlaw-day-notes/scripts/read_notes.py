#!/usr/bin/env python3
"""
Day notes reader for the Law Offices of Charles A. Ray, P.C.

    python3 read_notes.py [notes.json] [--days 30 | --since 2026-10-01]
    python3 read_notes.py --caret FirmExport-NNNN.zip notes.json --days 30
    python3 read_notes.py "Day Notes.docx" notes.json --since 2026-09-01   (fallback only)

CARET Notes.csv is the source. Charles keeps his notes in CARET Legal, inside
each matter. CARET has no API; its firm export (Firm Settings, Your CARET Legal
Account, Export, Download Data) saves FirmExport-<n>.zip to Downloads. With no
file named, this reads Notes.csv straight out of the newest export in
Downloads or Claude AI Reports, and Task.csv with it, and writes notes.json.
--caret with a path reads that export instead. --days 30 is the last 30 days;
--since takes a date. --no-tasks leaves Task.csv out.

Each note becomes a numbered paragraph under its date. Each paragraph is
"Subject: description" with the HTML cleaned, and carries its matter number,
the matter name, whether it is a lead, and its row in Notes.csv. A note with no
readable date is listed as undated. A note that is a contact with the IRS also
carries what it says about it, as found in the text: the official as written,
any employee ID number, and every sentence with a date or a commitment, quoted
word for word. Nothing is paraphrased.

A Word or text file is read only when Charles hands one over and names it.

Word: reads the day notes from a Word file and splits them into days
and numbered paragraphs. It reads the file itself, with nothing installed: a
.docx is a zip of XML, and only the text is taken. A .txt or .md file is read as
text.

It does not interpret anything. It finds the date headings, numbers every
paragraph under each day, and keeps every paragraph, including the ones before
the first date, which are listed as undated. Interpreting a paragraph is the
next step, and every interpretation cites the day and the paragraph number this
file gives it.

A date heading is a paragraph that is a date and little else, in any of the
shapes Charles might type: Monday, October 12, 2026 · October 12, 2026 ·
Oct. 12, 2026 · 10/12/2026 · 10/12/26 · 2026-10-12. A paragraph that opens
with a date and a colon or a dash starts a new day and keeps its text.
"""

import json
import re
import sys
import zipfile
from datetime import date, datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import caret_export as C  # noqa: E402

W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"

MONTHS = {m: i for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}
WEEKDAY = r"(?:mon|tue|tues|wed|thu|thur|thurs|fri|sat|sun)[a-z]*\.?,?\s+"
D_LONG = re.compile(r"^(?:" + WEEKDAY + r")?([a-z]{3,9})\.?\s+(\d{1,2}),?\s+(\d{4})", re.I)
D_NUM = re.compile(r"^(?:" + WEEKDAY + r")?(\d{1,2})/(\d{1,2})/(\d{2,4})")
D_ISO = re.compile(r"^(?:" + WEEKDAY + r")?(\d{4})-(\d{2})-(\d{2})")


def read_date(text):
    """(date, rest) if the paragraph opens with a date, else (None, text)."""
    t = text.strip()
    for rx in (D_LONG, D_NUM, D_ISO):
        m = rx.match(t)
        if not m:
            continue
        try:
            if rx is D_LONG:
                mon = MONTHS.get(m.group(1)[:3].lower())
                if not mon:
                    continue
                d0 = date(int(m.group(3)), mon, int(m.group(2)))
            elif rx is D_NUM:
                y = int(m.group(3))
                y = y + 2000 if y < 100 else y
                d0 = date(y, int(m.group(1)), int(m.group(2)))
            else:
                d0 = date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except ValueError:
            return None, text
        return d0, t[m.end():]
    return None, text


def paragraphs_docx(path):
    import xml.etree.ElementTree as ET
    with zipfile.ZipFile(path) as z:
        root = ET.fromstring(z.read("word/document.xml"))
    out = []
    for p in root.iter(W + "p"):
        style = ""
        ps = p.find(f"{W}pPr/{W}pStyle")
        if ps is not None:
            style = ps.get(W + "val", "")
        parts = []
        for node in p.iter():
            if node.tag == W + "t" and node.text:
                parts.append(node.text)
            elif node.tag == W + "tab":
                parts.append("\t")
            elif node.tag in (W + "br", W + "cr"):
                parts.append("\n")
        out.append((style, "".join(parts)))
    return out


def paragraphs_text(path):
    return [("", line) for line in Path(path).read_text(encoding="utf-8-sig").splitlines()]


def split(paras, since=None):
    days, undated, cur = [], [], None
    for style, raw in paras:
        text = raw.strip()
        if not text:
            continue
        d0, rest = read_date(text)
        rest_clean = re.sub(r"^[\s:\-\u2013\u2014.]+", "", rest).strip()
        is_heading = d0 is not None and (len(rest_clean) == 0 or style.lower().startswith("heading"))
        opens_dated = d0 is not None and not is_heading and re.match(r"^\s*[:\-\u2013\u2014]", rest)
        if is_heading or opens_dated:
            cur = {"date": d0.isoformat(), "heading": text if is_heading else text[:len(text) - len(rest)].strip(),
                   "paras": []}
            days.append(cur)
            if opens_dated and rest_clean:
                cur["paras"].append({"n": 1, "text": rest_clean})
            continue
        if cur is None:
            undated.append({"n": len(undated) + 1, "text": text})
        else:
            cur["paras"].append({"n": len(cur["paras"]) + 1, "text": text})
    # a day written twice in the file stays two blocks, in file order
    if since:
        days = [d for d in days if d["date"] >= since]
    return days, undated


# ---------------------------------------------------------------- IRS contacts

# Abbreviations count only in capitals, so "so" and "ra" in a sentence do not.
IRS_ABBR = re.compile(r"\b(RA|RO|SO|AO|ACS|PPS|IRS|TAS)\b")
IRS_TITLE = re.compile(r"\b(revenue agent|revenue officer|settlement officer|appeals officer|"
                       r"appeals|examiner|collection(?:s)? (?:officer|agent|rep(?:resentative)?)|"
                       r"irs agent|irs rep(?:resentative)?|practitioner priority)\b", re.I)
NAME = r"(?:\s+(?:[A-Z][a-z][A-Za-z'\-]+|[A-Z]\.)(?:\s+[A-Z][a-z][A-Za-z'\-]+)?)?"
OFFICIAL = re.compile(r"(?:\b(?:RA|RO|SO|AO)\b|\bACS\b(?:\s+(?:agent|rep(?:resentative)?))?|"
                      r"\bPPS\b(?:\s+(?:agent|rep(?:resentative)?))?|"
                      r"\b(?i:revenue agent|revenue officer|settlement officer|appeals officer|examiner)\b)" + NAME)
EMP_ID = re.compile(r"\b(?:ID|I\.D\.|badge|employee)\s*(?:#|no\.?|number)?\s*:?\s*#?\s*(\d{5,12})\b", re.I)
EMP_ID_BARE = re.compile(r"(?<![\d/-])\b(10\d{8})\b(?![\d/-])")
DATE_TXT = re.compile(r"\b\d{1,2}/\d{1,2}(?:/\d{2,4})?\b|\b\d{4}-\d{2}-\d{2}\b|"
                      r"\b(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\.?\s+\d{1,2}\b|"
                      r"\b(?:by|on|until|before|next)\s+(?:mon|tues|wednes|thurs|fri|satur|sun)day\b|"
                      r"\b\d+\s+(?:days?|weeks?|months?)\b", re.I)
COMMIT = re.compile(r"\b(agreed|agree|will|need|needs|owe|owes|promised|hold|holds|extend|extended|"
                    r"due|deadline|send|sending|call back|callback|follow up|requested|asked for|"
                    r"waiting on|expects?|granted|approved|denied)\b", re.I)


def _sentences(text):
    out = []
    for chunk in str(text).split("\n"):
        out += [x.strip() for x in re.split(r"(?<=[.!?])\s+(?=[A-Z0-9])", chunk) if x.strip()]
    return out


def irs_contact(text):
    """What a note says about a contact with the IRS, found in its own words,
    or None when it is not one. Officials as written, ID numbers, and the
    sentences that carry a date or a commitment, each quoted whole."""
    t = str(text or "")
    if not (IRS_ABBR.search(t) or IRS_TITLE.search(t) or EMP_ID.search(t)):
        return None
    officials = []
    for m in OFFICIAL.finditer(t):
        o = " ".join(m.group(0).split())
        if o not in officials:
            officials.append(o)
    ids = []
    for rx in (EMP_ID, EMP_ID_BARE):
        for m in rx.finditer(t):
            if m.group(1) not in ids:
                ids.append(m.group(1))
    said = [x for x in _sentences(t) if DATE_TXT.search(x) or COMMIT.search(x)]
    return {"officials": officials, "ids": ids, "said": said}


# ---------------------------------------------------------------- CARET export

NOTE_COLS = {
    "date": ("Date", "NoteDate", "CreatedDate", "Created*"),
    "subject": ("Subject", "Title", "Name"),
    "description": ("Description", "Descrption", "Note", "Notes", "Body", "Text"),
    "matter": ("MatterNumber", "Matter Number", "MatterNo"),
    "matter_name": ("MatterName", "Matter Name", "Matter"),
}
TASK_COLS = {
    "subject": ("Subject", "Name", "Title", "TaskName", "Task"),
    "due": ("DueDate", "Due", "Deadline", "DueOn", "Due*"),
    "status": ("Status", "State", "TaskStatus"),
    "completed": ("CompletedDate", "DateCompleted", "CompletedOn", "Completed*", "IsCompleted"),
    "matter": ("MatterNumber", "Matter Number", "MatterNo"),
    "matter_name": ("MatterName", "Matter Name", "Matter"),
}
DONE = {"completed", "complete", "done", "closed", "finished", "cancelled", "canceled"}


def _missing(rows, heads, cols, table, needed):
    """A plain sentence for each needed column the table does not have."""
    out = []
    for key in needed:
        names = cols[key]
        if not rows or not C.has_col(rows, *names):
            looked = list(dict.fromkeys(n.rstrip("*") for n in names))
            label = {"due": "due date", "matter_name": "matter name"}.get(key, key)
            out.append(f"{table} has no {label} column (looked for "
                       f"{', '.join(looked)}). Headers found: "
                       f"{', '.join(heads) or 'none'}.")
    return out


def _day_heading(d0):
    return f"{d0.strftime('%A, %B')} {d0.day}, {d0.year}"


def read_caret_notes(exp, since=None):
    rows = C.read_table(exp, "Notes")
    heads = C.headers(exp, "Notes")
    notes_csv = Path(rows[0]["_file"]).name if rows else "Notes.csv"
    problems = []
    if not heads:
        problems.append(f"Notes.csv is not in the export. Tables found: {', '.join(C.list_tables(exp)) or 'none'}.")
    elif rows:
        problems = _missing(rows, heads, NOTE_COLS, "Notes.csv", ("date", "subject", "description"))
    dated, undated = [], []
    for r in rows:
        subj = C.clean_text(C.col(r, *NOTE_COLS["subject"]))
        body = C.clean_text(C.col(r, *NOTE_COLS["description"]))
        text = f"{subj}: {body}" if subj and body else (subj or body or "(empty note)")
        num, name = C.split_matter(C.col(r, *NOTE_COLS["matter"]), C.col(r, *NOTE_COLS["matter_name"]))
        para = {"text": text, "matter": num, "matter_name": name, "lead": C.is_lead(r),
                "src": f"{notes_csv} row {r['_row']}"}
        irs = irs_contact(text)
        if irs:
            para["irs"] = irs
        # CARET labels its times UTC but they are not; the date as written is the day
        dt, _ = C.wall_dt(C.col(r, *NOTE_COLS["date"]))
        if dt is None:
            undated.append(para)
        else:
            dated.append((dt.date(), r["_row"], para))
    dated.sort(key=lambda x: (x[0], x[1]))
    days, by = [], {}
    for d0, _, para in dated:
        k = d0.isoformat()
        if since and k < since:
            continue
        if k not in by:
            by[k] = {"date": k, "heading": _day_heading(d0), "paras": []}
            days.append(by[k])
        para["n"] = len(by[k]["paras"]) + 1
        by[k]["paras"].append(para)
    for i, p in enumerate(undated, 1):
        p["n"] = i
    return days, undated, problems, len(rows)


def read_caret_tasks(exp, as_of=None):
    rows = C.read_table(exp, "Task")
    heads = C.headers(exp, "Task")
    task_csv = Path(rows[0]["_file"]).name if rows else "Task.csv"
    if not heads:
        return [], {"rows": 0, "open": 0, "completed": 0}, [
            f"Task.csv is not in the export. Tables found: {', '.join(C.list_tables(exp)) or 'none'}."]
    problems = _missing(rows, heads, TASK_COLS, "Task.csv", ("subject", "due", "status")) if rows else []
    if rows and not C.has_col(rows, *TASK_COLS["status"]) and not C.has_col(rows, *TASK_COLS["completed"]):
        problems.append("Task.csv has neither a status nor a completed date, so every task is listed as open.")
    open_, done = [], 0
    for r in rows:
        status = C.clean_text(C.col(r, *TASK_COLS["status"]))
        comp = str(C.col(r, *TASK_COLS["completed"])).strip()
        comp_done = bool(comp) and (C.parse_dt(comp)[0] is not None or C.truthy(comp))
        if status.lower() in DONE or comp_done:
            done += 1
            continue
        raw_due = str(C.col(r, *TASK_COLS["due"])).strip()
        dt, _ = C.wall_dt(raw_due)      # the due date as written, never shifted a day
        num, name = C.split_matter(C.col(r, *TASK_COLS["matter"]), C.col(r, *TASK_COLS["matter_name"]))
        t = {"subject": C.clean_text(C.col(r, *TASK_COLS["subject"])), "due": dt.date().isoformat() if dt else "",
             "status": status, "matter": num, "matter_name": name, "src": f"{task_csv} row {r['_row']}"}
        if raw_due and not dt:
            t["due_as_written"] = raw_due
        open_.append(t)
    open_.sort(key=lambda t: (t["due"] or "9999", t["src"]))
    return open_, {"rows": len(rows), "open": len(open_), "completed": done}, problems


def _window(args, as_of=None):
    """--since DATE or --days N, removed from args. Returns the since date."""
    since = None
    if "--since" in args:
        i = args.index("--since")
        since = args[i + 1]
        del args[i:i + 2]
    if "--days" in args:
        i = args.index("--days")
        n = int(args[i + 1])
        del args[i:i + 2]
        since = ((as_of or date.today()) - timedelta(days=n)).isoformat()
    return since


def main_caret(argv):
    want_tasks = "--no-tasks" not in argv
    args = [a for a in argv if a not in ("--caret", "--tasks", "--no-tasks")]
    as_of = None
    if "--as-of" in args:
        i = args.index("--as-of")
        as_of = date.fromisoformat(args[i + 1])
        del args[i:i + 2]
    since = _window(args, as_of)
    # what is left: [export] [notes.json]
    out = Path("notes.json")
    path = None
    for x in args:
        if x.lower().endswith(".json"):
            out = Path(x)
        else:
            path = x
    exp = C.find_export(path)
    if exp is None:
        raise SystemExit("No CARET export found in Downloads or Claude AI Reports. In CARET: Firm Settings, "
                         "Your CARET Legal Account, Export, Download Data. Then run this again.")
    exp = Path(exp)
    days, undated, problems, nrows = read_caret_notes(exp, since)
    taken = C.export_taken(exp)
    doc = {"source": "CARET export", "notes_file": exp.name, "export_file": exp.name,
           "export_taken": taken.isoformat(timespec="minutes"), "export_age_days": C.export_age_days(exp),
           "read_on": datetime.now().strftime("%Y-%m-%d %H:%M"), "since": since,
           "days": days, "undated": undated,
           "counts": {"rows": nrows, "days": len(days), "paragraphs": sum(len(d["paras"]) for d in days),
                      "undated": len(undated),
                      "leads": sum(1 for d in days for p in d["paras"] if p["lead"]),
                      "irs": sum(1 for d in days for p in d["paras"] if p.get("irs"))},
           "health": {"Notes": C.health_line("Notes")},
           "problems": problems}
    if want_tasks:
        tasks, tcounts, tprob = read_caret_tasks(exp)
        doc["tasks"] = tasks
        doc["counts"]["tasks"] = tcounts
        doc["health"]["Task"] = C.health_line("Task")
        doc["problems"] = problems + tprob
    # the officials in his IRS call notes join IRS Contacts.txt, so hearing
    # prep and the playbook know a meeting with them by name
    found, clients = [], set()
    for dd in doc.get("days", []):
        for pp in dd.get("paragraphs", dd.get("paras", [])) or []:
            found += (pp.get("irs") or {}).get("officials", [])
            for w in re.findall(r"[A-Z][a-z][A-Za-z'\-]+", str(pp.get("matter_name") or "")):
                clients.add(w)
    try:
        added = C.add_contacts(found, exclude=clients)
    except OSError:
        added = []
    doc["contacts_added"] = added
    out.write_text(json.dumps(doc, indent=1, ensure_ascii=False), encoding="utf-8")
    c = doc["counts"]
    print(f"Read {exp.name} (taken {taken:%Y-%m-%d}, {doc['export_age_days']} day(s) old): "
          f"{c['days']} day(s), {c['paragraphs']} note(s), {c['irs']} IRS contact(s), "
          f"{c['leads']} lead note(s), {c['undated']} undated" + (f", since {since}" if since else ""))
    for h in doc["health"].values():
        if h:
            print(f"  {h}")
    if want_tasks:
        t = c["tasks"]
        print(f"  Task.csv: {t['open']} open, {t['completed']} completed")
    for pr in doc["problems"]:
        print(f"  Note: {pr}")
    warn = C.persist_warning()
    if warn:
        print("  " + warn)
    if doc.get("contacts_added"):
        print(f"  Added to IRS Contacts.txt: {', '.join(doc['contacts_added'])}")
    print(f"  Written: {out}")


def _is_word_file(x):
    return Path(x).suffix.lower() in (".docx", ".txt", ".md") and Path(x).exists()


def main():
    argv = sys.argv[1:]
    if argv[:1] in (["-h"], ["--help"]):
        print(__doc__)
        return
    # CARET is the default. A Word or text file is read only when one is named.
    if "--caret" in argv or not any(_is_word_file(x) for x in argv):
        main_caret(argv)
        return
    args = list(argv)
    since = _window(args)
    files = [x for x in args if not x.startswith("--")]
    src = Path(next(x for x in files if _is_word_file(x)))
    out = Path(next((x for x in files if x.lower().endswith(".json")), "notes.json"))
    paras = paragraphs_docx(src) if src.suffix.lower() == ".docx" else paragraphs_text(src)
    days, undated = split(paras, since)
    for d in days:
        for pp in d["paras"]:
            irs = irs_contact(pp["text"])
            if irs:
                pp["irs"] = irs
    doc = {"notes_file": src.name, "read_on": datetime.now().strftime("%Y-%m-%d %H:%M"),
           "since": since, "days": days, "undated": undated,
           "counts": {"days": len(days), "paragraphs": sum(len(d["paras"]) for d in days),
                      "undated": len(undated)}}
    out.write_text(json.dumps(doc, indent=1, ensure_ascii=False), encoding="utf-8")
    print(f"Read {src.name}: {doc['counts']['days']} day(s), "
          f"{doc['counts']['paragraphs']} paragraph(s), {len(undated)} undated")
    order = [d["date"] for d in days]
    if order != sorted(order):
        print("  Note: the days are not in date order in the file. Kept in file order.")


if __name__ == "__main__":
    main()

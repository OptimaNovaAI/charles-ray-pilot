#!/usr/bin/env python3
"""
Day notes reader for the Law Offices of Charles A. Ray, P.C.

    python3 read_notes.py --caret [FirmExport-NNNN.zip] notes.json [--since 2026-07-15] [--tasks]
    python3 read_notes.py "Day Notes.docx" notes.json [--since 2026-09-01]

Charles keeps his notes in CARET Legal, inside each matter. CARET has no API;
its firm export (Firm Settings, Your CARET Legal Account, Export, Download
Data) saves FirmExport-<n>.zip to Downloads. With --caret this reads Notes.csv
straight out of that zip, the newest one when no path is given, and groups the
notes by their date into days and numbered paragraphs. Each paragraph is
"Subject: description" with the HTML cleaned, and carries its matter number,
the matter name, whether it is a lead, and its row in Notes.csv. A note with no
readable date is listed as undated. With --tasks it also reads Task.csv into
the open tasks.

A Word or text file still reads the old way, below.

Word: reads the day notes from a Word file and splits them into days
and numbered paragraphs. It reads the file itself, with nothing installed: a
.docx is a zip of XML, and only the text is taken. A .txt or .md file is read as
text.

It does not interpret anything. It finds the date headings, numbers every
paragraph under each day, and keeps every paragraph, including the ones before
the first date, which are listed as undated. Interpreting a paragraph is the
next step, and every interpretation cites the day and the paragraph number this
file gives it.

A date heading is a paragraph that is a date and little else, in any of the
shapes Charles might type: Monday, October 12, 2026 · October 12, 2026 ·
Oct. 12, 2026 · 10/12/2026 · 10/12/26 · 2026-10-12. A paragraph that opens
with a date and a colon or a dash starts a new day and keeps its text.
"""

import json
import re
import sys
import zipfile
from datetime import date, datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import caret_export as C  # noqa: E402

W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"

MONTHS = {m: i for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}
WEEKDAY = r"(?:mon|tue|tues|wed|thu|thur|thurs|fri|sat|sun)[a-z]*\.?,?\s+"
D_LONG = re.compile(r"^(?:" + WEEKDAY + r")?([a-z]{3,9})\.?\s+(\d{1,2}),?\s+(\d{4})", re.I)
D_NUM = re.compile(r"^(?:" + WEEKDAY + r")?(\d{1,2})/(\d{1,2})/(\d{2,4})")
D_ISO = re.compile(r"^(?:" + WEEKDAY + r")?(\d{4})-(\d{2})-(\d{2})")


def read_date(text):
    """(date, rest) if the paragraph opens with a date, else (None, text)."""
    t = text.strip()
    for rx in (D_LONG, D_NUM, D_ISO):
        m = rx.match(t)
        if not m:
            continue
        try:
            if rx is D_LONG:
                mon = MONTHS.get(m.group(1)[:3].lower())
                if not mon:
                    continue
                d0 = date(int(m.group(3)), mon, int(m.group(2)))
            elif rx is D_NUM:
                y = int(m.group(3))
                y = y + 2000 if y < 100 else y
                d0 = date(y, int(m.group(1)), int(m.group(2)))
            else:
                d0 = date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except ValueError:
            return None, text
        return d0, t[m.end():]
    return None, text


def paragraphs_docx(path):
    import xml.etree.ElementTree as ET
    with zipfile.ZipFile(path) as z:
        root = ET.fromstring(z.read("word/document.xml"))
    out = []
    for p in root.iter(W + "p"):
        style = ""
        ps = p.find(f"{W}pPr/{W}pStyle")
        if ps is not None:
            style = ps.get(W + "val", "")
        parts = []
        for node in p.iter():
            if node.tag == W + "t" and node.text:
                parts.append(node.text)
            elif node.tag == W + "tab":
                parts.append("\t")
            elif node.tag in (W + "br", W + "cr"):
                parts.append("\n")
        out.append((style, "".join(parts)))
    return out


def paragraphs_text(path):
    return [("", line) for line in Path(path).read_text(encoding="utf-8-sig").splitlines()]


def split(paras, since=None):
    days, undated, cur = [], [], None
    for style, raw in paras:
        text = raw.strip()
        if not text:
            continue
        d0, rest = read_date(text)
        rest_clean = re.sub(r"^[\s:\-\u2013\u2014.]+", "", rest).strip()
        is_heading = d0 is not None and (len(rest_clean) == 0 or style.lower().startswith("heading"))
        opens_dated = d0 is not None and not is_heading and re.match(r"^\s*[:\-\u2013\u2014]", rest)
        if is_heading or opens_dated:
            cur = {"date": d0.isoformat(), "heading": text if is_heading else text[:len(text) - len(rest)].strip(),
                   "paras": []}
            days.append(cur)
            if opens_dated and rest_clean:
                cur["paras"].append({"n": 1, "text": rest_clean})
            continue
        if cur is None:
            undated.append({"n": len(undated) + 1, "text": text})
        else:
            cur["paras"].append({"n": len(cur["paras"]) + 1, "text": text})
    # a day written twice in the file stays two blocks, in file order
    if since:
        days = [d for d in days if d["date"] >= since]
    return days, undated


# ---------------------------------------------------------------- CARET export

NOTE_COLS = {
    "date": ("Date", "NoteDate", "CreatedDate", "Created*"),
    "subject": ("Subject", "Title", "Name"),
    "description": ("Description", "Descrption", "Note", "Notes", "Body", "Text"),
    "matter": ("MatterNumber", "Matter Number", "MatterNo"),
    "matter_name": ("MatterName", "Matter Name", "Matter"),
}
TASK_COLS = {
    "subject": ("Subject", "Name", "Title", "TaskName", "Task"),
    "due": ("DueDate", "Due", "Deadline", "DueOn", "Due*"),
    "status": ("Status", "State", "TaskStatus"),
    "completed": ("CompletedDate", "DateCompleted", "CompletedOn", "Completed*", "IsCompleted"),
    "matter": ("MatterNumber", "Matter Number", "MatterNo"),
    "matter_name": ("MatterName", "Matter Name", "Matter"),
}
DONE = {"completed", "complete", "done", "closed", "finished", "cancelled", "canceled"}


def _missing(rows, heads, cols, table, needed):
    """A plain sentence for each needed column the table does not have."""
    out = []
    for key in needed:
        names = cols[key]
        if not rows or not C.has_col(rows, *names):
            looked = list(dict.fromkeys(n.rstrip("*") for n in names))
            label = {"due": "due date", "matter_name": "matter name"}.get(key, key)
            out.append(f"{table} has no {label} column (looked for "
                       f"{', '.join(looked)}). Headers found: "
                       f"{', '.join(heads) or 'none'}.")
    return out


def _day_heading(d0):
    return f"{d0.strftime('%A, %B')} {d0.day}, {d0.year}"


def read_caret_notes(exp, since=None):
    rows = C.read_table(exp, "Notes")
    heads = C.headers(exp, "Notes")
    notes_csv = Path(rows[0]["_file"]).name if rows else "Notes.csv"
    problems = []
    if not heads:
        problems.append(f"Notes.csv is not in the export. Tables found: {', '.join(C.list_tables(exp)) or 'none'}.")
    elif rows:
        problems = _missing(rows, heads, NOTE_COLS, "Notes.csv", ("date", "subject", "description"))
    dated, undated = [], []
    for r in rows:
        subj = C.clean_text(C.col(r, *NOTE_COLS["subject"]))
        body = C.clean_text(C.col(r, *NOTE_COLS["description"]))
        text = f"{subj}: {body}" if subj and body else (subj or body or "(empty note)")
        num, name = C.split_matter(C.col(r, *NOTE_COLS["matter"]), C.col(r, *NOTE_COLS["matter_name"]))
        para = {"text": text, "matter": num, "matter_name": name, "lead": C.is_lead(r),
                "src": f"{notes_csv} row {r['_row']}"}
        dt, _ = C.parse_dt(C.col(r, *NOTE_COLS["date"]))
        if dt is None:
            undated.append(para)
        else:
            dated.append((dt.date(), r["_row"], para))
    dated.sort(key=lambda x: (x[0], x[1]))
    days, by = [], {}
    for d0, _, para in dated:
        k = d0.isoformat()
        if since and k < since:
            continue
        if k not in by:
            by[k] = {"date": k, "heading": _day_heading(d0), "paras": []}
            days.append(by[k])
        para["n"] = len(by[k]["paras"]) + 1
        by[k]["paras"].append(para)
    for i, p in enumerate(undated, 1):
        p["n"] = i
    return days, undated, problems, len(rows)


def read_caret_tasks(exp, as_of=None):
    rows = C.read_table(exp, "Task")
    heads = C.headers(exp, "Task")
    task_csv = Path(rows[0]["_file"]).name if rows else "Task.csv"
    if not heads:
        return [], {"rows": 0, "open": 0, "completed": 0}, [
            f"Task.csv is not in the export. Tables found: {', '.join(C.list_tables(exp)) or 'none'}."]
    problems = _missing(rows, heads, TASK_COLS, "Task.csv", ("subject", "due", "status")) if rows else []
    if rows and not C.has_col(rows, *TASK_COLS["status"]) and not C.has_col(rows, *TASK_COLS["completed"]):
        problems.append("Task.csv has neither a status nor a completed date, so every task is listed as open.")
    open_, done = [], 0
    for r in rows:
        status = C.clean_text(C.col(r, *TASK_COLS["status"]))
        comp = str(C.col(r, *TASK_COLS["completed"])).strip()
        comp_done = bool(comp) and (C.parse_dt(comp)[0] is not None or C.truthy(comp))
        if status.lower() in DONE or comp_done:
            done += 1
            continue
        raw_due = str(C.col(r, *TASK_COLS["due"])).strip()
        dt, _ = C.parse_dt(raw_due)
        num, name = C.split_matter(C.col(r, *TASK_COLS["matter"]), C.col(r, *TASK_COLS["matter_name"]))
        t = {"subject": C.clean_text(C.col(r, *TASK_COLS["subject"])), "due": dt.date().isoformat() if dt else "",
             "status": status, "matter": num, "matter_name": name, "src": f"{task_csv} row {r['_row']}"}
        if raw_due and not dt:
            t["due_as_written"] = raw_due
        open_.append(t)
    open_.sort(key=lambda t: (t["due"] or "9999", t["src"]))
    return open_, {"rows": len(rows), "open": len(open_), "completed": done}, problems


def main_caret(argv):
    want_tasks = "--tasks" in argv
    since = None
    args = [a for a in argv if a not in ("--caret", "--tasks")]
    if "--since" in args:
        i = args.index("--since")
        since = args[i + 1]
        del args[i:i + 2]
    if not args:
        print(__doc__)
        sys.exit(1)
    out = Path(args[-1])
    path = args[0] if len(args) > 1 else None
    exp = C.find_export(path)
    if exp is None:
        raise SystemExit("No CARET export found in Downloads or Claude AI Reports. In CARET: Firm Settings, "
                         "Your CARET Legal Account, Export, Download Data. Then run this again.")
    exp = Path(exp)
    days, undated, problems, nrows = read_caret_notes(exp, since)
    taken = C.export_taken(exp)
    doc = {"source": "CARET export", "notes_file": exp.name, "export_file": exp.name,
           "export_taken": taken.isoformat(timespec="minutes"), "export_age_days": C.export_age_days(exp),
           "read_on": datetime.now().strftime("%Y-%m-%d %H:%M"), "since": since,
           "days": days, "undated": undated,
           "counts": {"rows": nrows, "days": len(days), "paragraphs": sum(len(d["paras"]) for d in days),
                      "undated": len(undated),
                      "leads": sum(1 for d in days for p in d["paras"] if p["lead"])},
           "problems": problems}
    if want_tasks:
        tasks, tcounts, tprob = read_caret_tasks(exp)
        doc["tasks"] = tasks
        doc["counts"]["tasks"] = tcounts
        doc["problems"] = problems + tprob
    out.write_text(json.dumps(doc, indent=1, ensure_ascii=False), encoding="utf-8")
    c = doc["counts"]
    print(f"Read {exp.name} (taken {taken:%Y-%m-%d}, {doc['export_age_days']} day(s) old): "
          f"{c['days']} day(s), {c['paragraphs']} note(s), {c['leads']} lead note(s), {c['undated']} undated")
    if want_tasks:
        t = c["tasks"]
        print(f"  Task.csv: {t['open']} open, {t['completed']} completed")
    for pr in doc["problems"]:
        print(f"  Note: {pr}")


def main():
    if "--caret" in sys.argv:
        main_caret(sys.argv[1:])
        return
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    src, out = Path(sys.argv[1]), Path(sys.argv[2])
    since = None
    if "--since" in sys.argv:
        since = sys.argv[sys.argv.index("--since") + 1]
    paras = paragraphs_docx(src) if src.suffix.lower() == ".docx" else paragraphs_text(src)
    days, undated = split(paras, since)
    doc = {"notes_file": src.name, "read_on": datetime.now().strftime("%Y-%m-%d %H:%M"),
           "since": since, "days": days, "undated": undated,
           "counts": {"days": len(days), "paragraphs": sum(len(d["paras"]) for d in days),
                      "undated": len(undated)}}
    out.write_text(json.dumps(doc, indent=1, ensure_ascii=False), encoding="utf-8")
    print(f"Read {src.name}: {doc['counts']['days']} day(s), "
          f"{doc['counts']['paragraphs']} paragraph(s), {len(undated)} undated")
    order = [d["date"] for d in days]
    if order != sorted(order):
        print("  Note: the days are not in date order in the file. Kept in file order.")


if __name__ == "__main__":
    main()

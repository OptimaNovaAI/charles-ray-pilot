#!/usr/bin/env python3
"""
Day notes reader for the Law Offices of Charles A. Ray, P.C.

    python3 read_notes.py "Day Notes.docx" notes.json [--since 2026-09-01]

Reads the day notes where Charles keeps them, in Word, and splits them into days
and numbered paragraphs. It reads the file itself, with nothing installed: a
.docx is a zip of XML, and only the text is taken. A .txt or .md file is read as
text.

It does not interpret anything. It finds the date headings, numbers every
paragraph under each day, and keeps every paragraph, including the ones before
the first date, which are listed as undated. Interpreting a paragraph is the
next step, and every interpretation cites the day and the paragraph number this
file gives it.

A date heading is a paragraph that is a date and little else, in any of the
shapes Charles might type: Monday, October 12, 2026 · October 12, 2026 ·
Oct. 12, 2026 · 10/12/2026 · 10/12/26 · 2026-10-12. A paragraph that opens
with a date and a colon or a dash starts a new day and keeps its text.
"""

import json
import re
import sys
import zipfile
from datetime import date, datetime
from pathlib import Path

W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"

MONTHS = {m: i for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}
WEEKDAY = r"(?:mon|tue|tues|wed|thu|thur|thurs|fri|sat|sun)[a-z]*\.?,?\s+"
D_LONG = re.compile(r"^(?:" + WEEKDAY + r")?([a-z]{3,9})\.?\s+(\d{1,2}),?\s+(\d{4})", re.I)
D_NUM = re.compile(r"^(?:" + WEEKDAY + r")?(\d{1,2})/(\d{1,2})/(\d{2,4})")
D_ISO = re.compile(r"^(?:" + WEEKDAY + r")?(\d{4})-(\d{2})-(\d{2})")


def read_date(text):
    """(date, rest) if the paragraph opens with a date, else (None, text)."""
    t = text.strip()
    for rx in (D_LONG, D_NUM, D_ISO):
        m = rx.match(t)
        if not m:
            continue
        try:
            if rx is D_LONG:
                mon = MONTHS.get(m.group(1)[:3].lower())
                if not mon:
                    continue
                d0 = date(int(m.group(3)), mon, int(m.group(2)))
            elif rx is D_NUM:
                y = int(m.group(3))
                y = y + 2000 if y < 100 else y
                d0 = date(y, int(m.group(1)), int(m.group(2)))
            else:
                d0 = date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except ValueError:
            return None, text
        return d0, t[m.end():]
    return None, text


def paragraphs_docx(path):
    import xml.etree.ElementTree as ET
    with zipfile.ZipFile(path) as z:
        root = ET.fromstring(z.read("word/document.xml"))
    out = []
    for p in root.iter(W + "p"):
        style = ""
        ps = p.find(f"{W}pPr/{W}pStyle")
        if ps is not None:
            style = ps.get(W + "val", "")
        parts = []
        for node in p.iter():
            if node.tag == W + "t" and node.text:
                parts.append(node.text)
            elif node.tag == W + "tab":
                parts.append("\t")
            elif node.tag in (W + "br", W + "cr"):
                parts.append("\n")
        out.append((style, "".join(parts)))
    return out


def paragraphs_text(path):
    return [("", line) for line in Path(path).read_text(encoding="utf-8-sig").splitlines()]


def split(paras, since=None):
    days, undated, cur = [], [], None
    for style, raw in paras:
        text = raw.strip()
        if not text:
            continue
        d0, rest = read_date(text)
        rest_clean = re.sub(r"^[\s:\-\u2013\u2014.]+", "", rest).strip()
        is_heading = d0 is not None and (len(rest_clean) == 0 or style.lower().startswith("heading"))
        opens_dated = d0 is not None and not is_heading and re.match(r"^\s*[:\-\u2013\u2014]", rest)
        if is_heading or opens_dated:
            cur = {"date": d0.isoformat(), "heading": text if is_heading else text[:len(text) - len(rest)].strip(),
                   "paras": []}
            days.append(cur)
            if opens_dated and rest_clean:
                cur["paras"].append({"n": 1, "text": rest_clean})
            continue
        if cur is None:
            undated.append({"n": len(undated) + 1, "text": text})
        else:
            cur["paras"].append({"n": len(cur["paras"]) + 1, "text": text})
    # a day written twice in the file stays two blocks, in file order
    if since:
        days = [d for d in days if d["date"] >= since]
    return days, undated


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    src, out = Path(sys.argv[1]), Path(sys.argv[2])
    since = None
    if "--since" in sys.argv:
        since = sys.argv[sys.argv.index("--since") + 1]
    paras = paragraphs_docx(src) if src.suffix.lower() == ".docx" else paragraphs_text(src)
    days, undated = split(paras, since)
    doc = {"notes_file": src.name, "read_on": datetime.now().strftime("%Y-%m-%d %H:%M"),
           "since": since, "days": days, "undated": undated,
           "counts": {"days": len(days), "paragraphs": sum(len(d["paras"]) for d in days),
                      "undated": len(undated)}}
    out.write_text(json.dumps(doc, indent=1, ensure_ascii=False), encoding="utf-8")
    print(f"Read {src.name}: {doc['counts']['days']} day(s), "
          f"{doc['counts']['paragraphs']} paragraph(s), {len(undated)} undated")
    order = [d["date"] for d in days]
    if order != sorted(order):
        print("  Note: the days are not in date order in the file. Kept in file order.")


if __name__ == "__main__":
    main()

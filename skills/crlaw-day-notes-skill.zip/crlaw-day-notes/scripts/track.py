#!/usr/bin/env python3
"""
Day notes intelligence and conversion tracking for the Law Offices of
Charles A. Ray, P.C.

    python3 track.py --notes notes.json --entries entries.json \
                     --tracker "Conversion Tracker.csv" \
                     [--as-of 2026-10-13] [--since 2026-07-15] [--quiet-days 7] \
                     --out "Day Notes.html"

Item 15. read_notes.py splits the Word file into days and numbered paragraphs.
Claude reads them and writes entries.json: who, what kind of contact, the
source, the outcome, the fee as written, and what is owed. This file checks
every entry against the paragraph it cites, keeps the conversion tracker, and
writes the page.

Three rules, and they are the firm's.
    Every entry cites its paragraph, and its quote must be found in that
    paragraph, word for word. An entry whose quote is not there is refused and
    listed. Nothing interpreted gets in without its line.
    Nothing is dropped silently. Every paragraph read and not recorded as an
    entry is listed on the page.
    It reports. Open means the notes do not say it was done. A prospect who
    has gone quiet is listed, never concluded lost.

The tracker is one row per prospect, kept where Charles keeps it (.csv, or
.xlsx where openpyxl is present). It holds names, so it stays on his machine.
"""

import argparse
import csv
import html as H
import json
import re
import statistics
from datetime import date, timedelta
from pathlib import Path

KINDS = {"prospect", "consult", "engaged", "declined", "no_show",
         "client_work", "irs_call", "admin", "other"}
FUNNEL = {"prospect", "consult", "engaged", "declined", "no_show"}
SOURCES = {"legalmatch": "LegalMatch", "avvo": "Avvo", "martindale": "Martindale",
           "calendly": "Calendly", "friedman framme": "Friedman Framme",
           "fft": "Friedman Framme", "answering service": "Answering service",
           "answering": "Answering service", "referral": "Referral",
           "phone": "Phone", "website": "Website", "other": "Other"}
COLUMNS = ["person", "first_seen", "source", "consult_date", "outcome",
           "outcome_date", "fee", "matter", "last_seen", "refs", "note"]
OWED_BY_YOU = {"", "charles", "charles ray", "cr", "me", "i", "we", "us", "the firm"}
WORDS_NEVER_PRINTED = (" should ", "recommend", "advisable", "we suggest")


def e(s):
    return H.escape(str(s if s is not None else ""), quote=False)


def nt(s):
    """Text quoted from the notes. Marked so the word check skips it: Charles's
    own words are his, and the check is for the engine's."""
    return f"<span class=\"nt\">{e(s)}</span>"


def norm(s):
    return " ".join(re.sub(r"[^\w\s]", " ", str(s or "").lower()).split())


def squash(s):
    return " ".join(str(s or "").split()).lower()


def source_of(s):
    if not s or str(s).strip().lower() in ("not stated", "none", "null"):
        return "Not stated"
    return SOURCES.get(str(s).strip().lower(), str(s).strip())


# ---------------------------------------------------------------- tracker io

def load_tracker(path):
    p = Path(path)
    if not p.exists():
        return {}
    if p.suffix.lower() == ".xlsx":
        from openpyxl import load_workbook
        ws = load_workbook(p, read_only=True, data_only=True).active
        rows = list(ws.iter_rows(values_only=True))
        head = [str(h or "") for h in rows[0]] if rows else []
        recs = [{h: ("" if v is None else str(v)) for h, v in zip(head, r)} for r in rows[1:]]
    else:
        with p.open(newline="", encoding="utf-8-sig") as fh:
            recs = list(csv.DictReader(fh))
    return {norm(r["person"]): r for r in recs if r.get("person")}


def save_tracker(path, rows):
    p = Path(path)
    ordered = sorted(rows.values(), key=lambda r: (r.get("first_seen", ""), r["person"]))
    if p.suffix.lower() == ".xlsx":
        from openpyxl import Workbook
        from openpyxl.styles import Font
        wb = Workbook()
        ws = wb.active
        ws.title = "Conversion Tracker"
        ws.append(list(COLUMNS))
        for c in ws[1]:
            c.font = Font(bold=True)
        for r in ordered:
            ws.append([r.get(c, "") for c in COLUMNS])
        ws.freeze_panes = "A2"
        wb.save(p)
        return
    with p.open("w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=COLUMNS, extrasaction="ignore")
        w.writeheader()
        for r in ordered:
            w.writerow({c: r.get(c, "") for c in COLUMNS})


# ---------------------------------------------------------------- checking

def check_entries(notes, entries):
    """Every entry's quote must be in the paragraphs it cites. Returns
    (kept, refused, cited) where cited is the set of (date, n) used."""
    paras = {}
    for d in notes["days"]:
        for p in d["paras"]:
            paras.setdefault((d["date"], p["n"]), []).append(p["text"])
    kept, refused, cited = [], [], set()
    for i, en in enumerate(entries, 1):
        problems = []
        dd = str(en.get("date", ""))
        refs = en.get("paras") or []
        if isinstance(refs, int):
            refs = [refs]
        if en.get("kind") not in KINDS:
            problems.append(f"kind '{en.get('kind')}' is not one of {', '.join(sorted(KINDS))}")
        texts = []
        for n in refs:
            t = paras.get((dd, int(n)))
            if t is None:
                problems.append(f"no paragraph {n} on {dd}")
            else:
                texts.extend(t)
        q = squash(en.get("quote"))
        if not q:
            problems.append("no quote")
        elif texts and q not in squash(" ".join(texts)):
            problems.append(f"the quote is not in paragraph(s) {', '.join(str(n) for n in refs)} of {dd}")
        if not refs:
            problems.append("no paragraph cited")
        for o in en.get("owed", []) or []:
            if o.get("due"):
                try:
                    date.fromisoformat(str(o["due"]))
                except ValueError:
                    problems.append(f"due date '{o['due']}' is not a date")
        if problems:
            refused.append((i, en, problems))
        else:
            kept.append(en)
            for n in refs:
                cited.add((dd, int(n)))
    return kept, refused, cited


def update_tracker(rows, entries):
    changes = []
    for en in sorted(entries, key=lambda x: x["date"]):
        if not en.get("person"):
            continue
        k = norm(en["person"])
        ref = f"{en['date']} para {','.join(str(n) for n in (en['paras'] if isinstance(en['paras'], list) else [en['paras']]))}"
        r = rows.get(k)
        if en["kind"] not in FUNNEL:
            # other work for someone already on the tracker keeps them from reading as quiet
            if r is not None and en["date"] >= (r.get("last_seen") or ""):
                r["last_seen"] = en["date"]
            continue
        if r is None:
            r = {c: "" for c in COLUMNS}
            r.update(person=en["person"], first_seen=en["date"],
                     source=source_of(en.get("source")))
            rows[k] = r
            changes.append(("added", r["person"], en["date"]))
        if en["date"] < (r.get("first_seen") or en["date"]):
            r["first_seen"] = en["date"]
        if r.get("source") in ("", "Not stated") and en.get("source"):
            r["source"] = source_of(en.get("source"))
        if en.get("matter"):
            r["matter"] = en["matter"]
        if en.get("fee"):
            r["fee"] = str(en["fee"])
        if en["kind"] == "consult":
            if not r.get("consult_date") or en["date"] < r["consult_date"]:
                r["consult_date"] = en["date"]
        if en["kind"] in ("engaged", "declined", "no_show"):
            if not r.get("outcome_date") or en["date"] >= r["outcome_date"]:
                if r.get("outcome") != en["kind"]:
                    changes.append((en["kind"], r["person"], en["date"]))
                r["outcome"], r["outcome_date"] = en["kind"], en["date"]
            if en["kind"] == "engaged" and not r.get("consult_date"):
                r["note"] = "engaged with no consult in the notes"
        if en["date"] >= (r.get("last_seen") or ""):
            r["last_seen"] = en["date"]
        refs = [x for x in (r.get("refs") or "").split("; ") if x]
        if ref not in refs:
            refs.append(ref)
        r["refs"] = "; ".join(refs[-6:])
    return changes


# ---------------------------------------------------------------- page

CSS = """
body{margin:0;background:#f4f5f7;font-family:-apple-system,BlinkMacSystemFont,
"Segoe UI",Arial,sans-serif;color:#1b2a4a}
.w{max-width:900px;margin:0 auto;padding:28px 20px 70px}
.card{background:#fff;border:1px solid #e3e8ef;border-radius:12px;padding:22px 26px;margin-bottom:16px}
.k{font-size:11px;font-weight:600;letter-spacing:1.6px;text-transform:uppercase;color:#ca25b7;padding-bottom:10px}
h1{margin:0 0 6px;font-size:27px;font-weight:600;color:#0b1f3a;letter-spacing:-.5px}
.sub{color:#6a7488;font-size:14px;margin:0 0 18px;line-height:1.55}
.tally{display:flex;gap:10px;flex-wrap:wrap;margin:0 0 22px}
.t{background:#fff;border:1px solid #e3e8ef;border-radius:10px;padding:10px 16px;min-width:120px}
.t b{display:block;font-size:24px;color:#000c65}
.t span{font-size:11px;letter-spacing:1.2px;text-transform:uppercase;color:#8a93a6;font-weight:600}
table{width:100%;border-collapse:collapse;font-size:13.5px}
th{text-align:left;font-size:10.5px;letter-spacing:1.2px;text-transform:uppercase;color:#8a93a6;
font-weight:600;padding:0 8px 8px 0;border-bottom:1px solid #e3e8ef}
td{padding:8px 8px 8px 0;border-bottom:1px solid #f0f2f6;vertical-align:top}
td.n,th.n{text-align:right}
.late{color:#b4483a;font-weight:600}
.src{color:#8a93a6;font-size:11.5px;font-family:ui-monospace,Menlo,monospace}
.row{font-size:13.5px;line-height:1.55;padding:6px 0;border-bottom:1px solid #f0f2f6}
.foot{color:#8a93a6;font-size:12.5px;line-height:1.65}
@media(max-width:600px){.card{padding:18px 16px}.tbl{overflow-x:auto}}
"""


def pct(a, b):
    return f"{round(100 * a / b)}%" if b else "&mdash;"


def render(notes, kept, refused, cited, rows, as_of, since, quiet_days, out):
    owed = []
    for en in kept:
        for o in en.get("owed", []) or []:
            if (o.get("status") or "open") != "open":
                continue
            due = date.fromisoformat(o["due"]) if o.get("due") else None
            owed.append({"what": o.get("what", ""), "who": (o.get("who") or "").strip(),
                         "for": en.get("person") or en.get("matter") or "",
                         "noted": en["date"], "due": due, "as_written": o.get("due_as_written", ""),
                         "age": (as_of - date.fromisoformat(en["date"])).days,
                         "ref": f"{en['date']} para {','.join(str(n) for n in (en['paras'] if isinstance(en['paras'], list) else [en['paras']]))}"})
    mine = sorted([o for o in owed if norm(o["who"]) in OWED_BY_YOU],
                  key=lambda o: (o["due"] or date.max, o["noted"]))
    theirs = sorted([o for o in owed if o not in mine], key=lambda o: o["noted"])

    def party(o, by_you):
        if by_you:
            return e(o["for"]) if o["for"] else "&mdash;"
        extra = o["for"] if o["for"] and norm(o["for"]) != norm(o["who"]) else ""
        return e(o["who"] or "not stated") + ((" &middot; for " + e(extra)) if extra else "")

    def owed_rows(lst, by_you):
        if not lst:
            return "<tr><td colspan=5 class=src>Nothing open in the notes read.</td></tr>"
        return "".join(
            f"<tr><td>{e(o['what'])}</td><td>{party(o, by_you)}</td>"
            f"<td>{e(o['noted'])}<div class='src'>{e(o['ref'])}</div></td>"
            f"<td class='{'late' if o['due'] and o['due'] < as_of else ''}'>{e(o['due'] or 'not stated')}"
            f"{' (past due)' if o['due'] and o['due'] < as_of else ''}"
            f"{('<div class=src>' + e(o['as_written']) + '</div>') if o['as_written'] else ''}</td>"
            f"<td class='n'>{o['age']}</td></tr>" for o in lst)

    win = [r for r in rows.values() if r.get("first_seen") and r["first_seen"] >= since.isoformat()]
    by = {}
    for r in win:
        s = r.get("source") or "Not stated"
        b = by.setdefault(s, {"p": 0, "c": 0, "e": 0, "d": 0, "x": 0, "o": 0})
        b["p"] += 1
        b["c"] += 1 if r.get("consult_date") else 0
        b["e"] += 1 if r.get("outcome") == "engaged" else 0
        b["d"] += 1 if r.get("outcome") == "declined" else 0
        b["x"] += 1 if r.get("outcome") == "no_show" else 0
        b["o"] += 1 if not r.get("outcome") else 0
    tot = {k: sum(b[k] for b in by.values()) for k in ("p", "c", "e", "d", "x", "o")}
    funnel = "".join(
        f"<tr><td>{e(s)}</td><td class=n>{b['p']}</td><td class=n>{b['c']}</td><td class=n>{b['e']}</td>"
        f"<td class=n>{b['d']}</td><td class=n>{b['x']}</td><td class=n>{b['o']}</td><td class=n>{pct(b['e'], b['p'])}</td></tr>"
        for s, b in sorted(by.items(), key=lambda x: -x[1]["p"]))
    funnel += (f"<tr><td><b>All sources</b></td><td class=n><b>{tot['p']}</b></td><td class=n><b>{tot['c']}</b></td>"
               f"<td class=n><b>{tot['e']}</b></td><td class=n><b>{tot['d']}</b></td><td class=n><b>{tot['x']}</b></td><td class=n><b>{tot['o']}</b></td>"
               f"<td class=n><b>{pct(tot['e'], tot['p'])}</b></td></tr>")
    spans = [(date.fromisoformat(r["outcome_date"]) - date.fromisoformat(r["first_seen"])).days
             for r in win if r.get("outcome") == "engaged" and r.get("outcome_date")]
    median = (f"Median {statistics.median(spans):g} days from first contact to engagement, "
              f"across {len(spans)} engagement(s).") if spans else "No engagements in the window."

    quiet = sorted([r for r in rows.values() if not r.get("outcome") and r.get("last_seen")
                    and (as_of - date.fromisoformat(r["last_seen"])).days >= quiet_days],
                   key=lambda r: r["last_seen"])
    quiet_rows = "".join(
        f"<tr><td>{e(r['person'])}</td><td>{e(r.get('source'))}</td><td>{e(r['first_seen'])}</td>"
        f"<td>{e(r.get('consult_date') or 'none in the notes')}</td><td>{e(r['last_seen'])}</td>"
        f"<td class=n>{(as_of - date.fromisoformat(r['last_seen'])).days}</td></tr>" for r in quiet) \
        or "<tr><td colspan=6 class=src>No prospect has gone quiet.</td></tr>"

    engaged = sorted([r for r in rows.values() if r.get("outcome") == "engaged"
                      and r.get("outcome_date", "") >= since.isoformat()], key=lambda r: r["outcome_date"])
    engaged_rows = "".join(
        f"<div class='row'><b>{e(r['outcome_date'])}.</b> {e(r['person'])}"
        f"{(' &middot; ' + e(r['matter'])) if r.get('matter') else ''} &middot; {e(r.get('source'))}"
        f"{(' &middot; fee as written: ' + e(r['fee'])) if r.get('fee') else ''}"
        f"{(' &middot; ' + e(r['note'])) if r.get('note') else ''}</div>" for r in engaged) \
        or "<div class='foot'>None in the window.</div>"

    uncited = [(d["date"], p["n"], p["text"]) for d in notes["days"] for p in d["paras"]
               if (d["date"], p["n"]) not in cited]
    unc_rows = "".join(f"<div class='row'><span class='src'>{e(dd)} para {n}</span> {nt(t[:160])}{'&hellip;' if len(t) > 160 else ''}</div>"
                       for dd, n, t in uncited) or "<div class='foot'>Every paragraph read is recorded in an entry.</div>"
    undated = "".join(f"<div class='row'><span class='src'>undated para {p['n']}</span> {nt(p['text'][:160])}</div>"
                      for p in notes.get("undated", []))
    ref_rows = "".join(f"<div class='row'><b>Entry {i}.</b> {e('; '.join(pr))}. "
                       f"<span class='src'>{nt((en.get('quote') or '')[:120])}</span></div>"
                       for i, en, pr in refused) or "<div class='foot'>None refused.</div>"

    html = f"""<!DOCTYPE html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>Day Notes</title><style>{CSS}</style></head><body><div class="w">
<div class="k">Day Notes &middot; Item 15</div>
<h1>As of {e(as_of.strftime('%B ') + str(as_of.day) + ', ' + str(as_of.year))}</h1>
<p class="sub">Read from {e(notes.get('notes_file'))} on {e(notes.get('read_on'))}:
{notes['counts']['days']} day(s), {notes['counts']['paragraphs']} paragraph(s). Every entry
below cites its day and paragraph. Conversion counts prospects first seen since {e(since)}.</p>
<div class="tally">
<div class="t"><b>{len(mine)}</b><span>Owed by you</span></div>
<div class="t"><b>{len(theirs)}</b><span>Owed to you</span></div>
<div class="t"><b>{len(quiet)}</b><span>Gone quiet</span></div>
<div class="t"><b>{tot['e']}</b><span>Engaged</span></div>
</div>
<div class="card"><div class="k">Owed by you</div><div class="tbl"><table>
<tr><th>What</th><th>For</th><th>Noted</th><th>Due</th><th class=n>Days</th></tr>{owed_rows(mine, True)}</table></div>
<p class="foot" style="margin-top:10px">Open means the notes do not say it was done.</p></div>
<div class="card"><div class="k">Owed to you</div><div class="tbl"><table>
<tr><th>What</th><th>From</th><th>Noted</th><th>Due</th><th class=n>Days</th></tr>{owed_rows(theirs, False)}</table></div></div>
<div class="card"><div class="k">Gone quiet</div><div class="tbl"><table>
<tr><th>Prospect</th><th>Source</th><th>First seen</th><th>Consult</th><th>Last in the notes</th><th class=n>Days</th></tr>{quiet_rows}</table></div>
<p class="foot" style="margin-top:10px">No outcome in the notes and nothing for {quiet_days} days or more. Silence is an open item, never a conclusion.</p></div>
<div class="card"><div class="k">Conversion by source</div><div class="tbl"><table>
<tr><th>Source</th><th class=n>Prospects</th><th class=n>Consulted</th><th class=n>Engaged</th><th class=n>Declined</th><th class=n>No-show</th><th class=n>Open</th><th class=n>Engaged rate</th></tr>
{funnel}</table></div><p class="foot" style="margin-top:10px">{e(median)} Engaged rate is engaged over prospects first seen in the window, from the notes alone. Leads that never reached the notes are not counted here.</p></div>
<div class="card"><div class="k">Engaged in the window</div>{engaged_rows}</div>
<div class="card"><div class="k">Read, not recorded as an entry</div>{unc_rows}{undated}</div>
<div class="card"><div class="k">Entries refused</div>{ref_rows}</div>
<div class="card"><p class="foot" style="margin:0">Every entry kept was checked against the paragraph it cites, and its quote
was found there word for word. An entry that failed the check is listed above as refused. A fee is shown as written. The tracker holds names and stays on
this machine. This page reports what the notes say. The judgment is the attorney's.</p></div>
</div></body></html>"""
    own = re.sub(r'<span class="nt">.*?</span>', " ", html, flags=re.S)
    low = " " + re.sub(r"<[^>]+>", " ", own).lower() + " "
    for w in WORDS_NEVER_PRINTED:
        if w in low:
            raise SystemExit(f"Refusing to write: the page contains '{w.strip()}'.")
    Path(out).write_text(html, encoding="utf-8")
    return mine, theirs, quiet, uncited


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--notes", required=True)
    ap.add_argument("--entries", required=True)
    ap.add_argument("--tracker", required=True)
    ap.add_argument("--as-of")
    ap.add_argument("--since")
    ap.add_argument("--quiet-days", type=int, default=7)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    notes = json.loads(Path(a.notes).read_text(encoding="utf-8"))
    ents = json.loads(Path(a.entries).read_text(encoding="utf-8"))
    entries = ents.get("entries", ents if isinstance(ents, list) else [])
    as_of = date.fromisoformat(a.as_of) if a.as_of else date.today()
    since = date.fromisoformat(a.since) if a.since else as_of - timedelta(days=90)

    kept, refused, cited = check_entries(notes, entries)
    rows = load_tracker(a.tracker)
    changes = update_tracker(rows, kept)
    save_tracker(a.tracker, rows)
    mine, theirs, quiet, uncited = render(notes, kept, refused, cited, rows, as_of, since,
                                          a.quiet_days, a.out)

    print(f"Written: {a.out}   as of {as_of}")
    print(f"  {len(kept)} entr(ies) kept, {len(refused)} refused, "
          f"{len(uncited)} paragraph(s) read and not recorded")
    print(f"  tracker {a.tracker}: {len(rows)} prospect(s); "
          + (", ".join(f"{k} {p} {d}" for k, p, d in changes) or "no changes"))
    print(f"  owed by you {len(mine)}, owed to you {len(theirs)}, gone quiet {len(quiet)}")
    note_days = sorted({d["date"] for d in notes["days"]})
    entry_days = sorted({str(en.get("date")) for en in entries})
    if note_days:
        bare = [d for d in note_days if d not in entry_days]
        print(f"  entries run through {entry_days[-1] if entry_days else 'none'}; notes run through "
              f"{note_days[-1]}; {len(bare)} day(s) in the notes with no entry"
              + (f": {', '.join(bare[-5:])}" if bare else ""))
    for i, en, pr in refused:
        print(f"  REFUSED entry {i}: {'; '.join(pr)}")


if __name__ == "__main__":
    main()

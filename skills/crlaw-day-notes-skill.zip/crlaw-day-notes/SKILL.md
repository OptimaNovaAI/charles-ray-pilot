---
name: crlaw-day-notes
description: Day notes intelligence and conversion tracking for the Law Offices of Charles A. Ray, P.C. Use whenever Charles asks about his notes, his leads, or his open work, including "read my day notes", "read my CARET notes", "what's open from my notes", "what's open in CARET", "show my open tasks", "who owes me", "who do I owe a call", "who owes me documents", "who went quiet", "how are my leads converting", "how many LegalMatch leads signed", "update the conversion tracker", "what did I promise this week", or when a scheduled Monday run asks for it. It reads the notes he keeps in CARET Legal from the firm export (and a Word file when he has one), records what each note says with the note cited, keeps a conversion tracker by lead source, lists his open CARET tasks, and reports what is owed. It never says what to do.
---

# Day Notes

Item 15. Charles keeps his notes in CARET Legal, inside each matter, and files
a prospect's notes under the matter name "lead". CARET has no API. Its firm
export saves every note, task, and matter to one zip in Downloads, and this
skill reads that zip as it lands. It records who he spoke with, what kind of
contact it was, where the lead came from, the outcome, the fee as he wrote it,
and what is owed by whom. It keeps a conversion tracker, one row per prospect,
and writes one page: owed by you, owed to you, gone quiet, conversion by
source.

Three rules, and they are the firm's:

- **Every entry cites its day and note**, and carries a quote copied from that
  note. The engine checks the quote word for word. An entry whose quote is not
  in the note is refused and listed. So is an entry dated a day the notes do
  not have, or one whose matter differs from the cited note's matter.
- **Nothing is dropped.** Every note read and not recorded is listed on the
  page with its row in Notes.csv, and so is every note with no readable date.
- **It reports.** Open means the notes do not say it was done. A prospect who
  has gone quiet is listed as an open item.

---

## Run It

**1. Export from CARET.** In CARET: Firm Settings, Your CARET Legal Account,
Export, Download Data. The zip, FirmExport-<n>.zip, lands in Downloads. There
is nothing to unzip and nothing to move.

**2. Read the notes.**

```
python3 scripts/read_notes.py --caret notes.json --since 2026-07-15 --tasks
```

It finds the newest FirmExport zip in Downloads (or Claude AI Reports) on its
own and reads Notes.csv straight out of it. To read a particular export, put
its path after `--caret`. It needs nothing installed.

- Each note becomes one numbered paragraph under its date, in date order and
  then in the order of the rows in Notes.csv. A note with a time is placed on
  its Eastern day.
- The paragraph reads "Subject: description", with CARET's HTML cleaned to
  plain text. A note with no description is its subject alone.
- Each paragraph carries its matter number, the matter name, whether it is a
  lead, and its row, as "Notes.csv row 12".
- A note with no readable date is listed as undated and kept.
- `--tasks` also reads Task.csv: the open tasks, with due date, status,
  matter, and row. Completed tasks are counted and left off the list.
- Columns are found by meaning. When one it needs is missing, it says which
  headers it found and carries on with the rest.

Read the last 90 days each run. The tracker does not double count, so a day
read twice changes nothing.

From Word, in one line: `python3 scripts/read_notes.py "Day Notes.docx" notes.json --since 2026-07-15`.

**3. Write the entries.** Read `notes.json` and add to `entries.json` for every
day that has none yet, following `reference/entries.md`. Keep `entries.json`
beside the tracker. It grows run by run. When a later note says an owed item
was done, set that item's status to done and cite the note in `closed_by`.

**4. Run the engine.**

```
python3 scripts/track.py --notes notes.json --entries entries.json \
    --tracker "C:/Users/<you>/OneDrive/Conversion Tracker.xlsx" \
    --as-of 2026-10-13 --since 2026-07-15 --out "Day Notes.html"
```

- `--tracker` is .xlsx where openpyxl is present, .csv anywhere. It holds
  names, so it stays on his machine.
- `--since` sets the conversion window. It defaults to 90 days back.
- `--quiet-days` sets when a prospect with no outcome reads as quiet. It
  defaults to 7.

The run prints the export it read and its age, how many entries were kept and
refused, what changed in the tracker, and which days in the notes have no
entry yet. A refused entry is fixed and the run repeated. The usual cause is a
note Charles edited or a new note on the same day, which moves the numbers.

**5. Hand him the page.** Say what is owed by him, what is past due, and who
has gone quiet. Add no advice the page does not carry.

---

## The Page

| Section | What It Shows |
|---|---|
| Header | The export read, when it was taken, and how many days old it is. Past seven days, the header states the age as a fact. |
| Owed by You | What the notes say Charles will do, open, with the date noted, the due date if one was written, and days open. His open CARET tasks sit here too, labeled From CARET tasks, with due date, matter, and Task.csv row. Past due is marked. |
| Owed to You | What a client or prospect said they would send, open, the same way. |
| Gone Quiet | Prospects with no outcome in the notes and nothing for seven days or more. |
| Conversion by Source | Prospects, consulted, engaged, declined, no-show, and open, by source, with the engaged rate and the median days from first contact to engagement. |
| Engaged in the Window | Each engagement with its matter, source, and the fee as written. |
| Read, Not Recorded | Every note no entry cites, with its matter and Notes.csv row, and every undated note. |
| Entries Refused | Every entry that failed the check, with the reason. |
| From the Export | Any column the reader could not find, with the headers it did find. |

Notes filed under "lead" are the prospect pool. An entry on a lead note takes
its source from the note when the note names one (LegalMatch, Avvo,
Martindale, Calendly, a referral) and reads Not stated when it names none. The
conversion count comes from the notes alone. A lead that never reached the
notes is not counted, and the page says so.

---

## Monday Mornings

Built to be scheduled. Charles exports from CARET Friday afternoon or first
thing Monday. Mondays at 7:00 a.m., a scheduled task:

> Run day notes. Read my newest CARET export from Downloads with my open
> tasks, covering the last 90 days. Add entries for any day without them,
> following crlaw-day-notes, and run it with my conversion tracker. Send me the
> page with what I owe, what is past due, and who has gone quiet. If the export
> is more than seven days old, say how old it is.

---

## What It Will Not Do

- Say what to do about a prospect, a fee, a task, or an open item. The
  judgment is his.
- Conclude a prospect is lost. Quiet is an open item.
- Fill in a source, a fee, or a due date the notes do not give.
- Change CARET or the notes. It reads the export and never writes to it.
- Put a name on the hub or in a file name. The tracker and the page stay on
  his machine.

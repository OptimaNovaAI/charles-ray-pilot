---
name: crlaw-day-notes
description: Day notes intelligence and conversion tracking for the Law Offices of Charles A. Ray, P.C. Use whenever Charles asks about his day notes or his leads, including "read my day notes", "what's open from my notes", "who do I owe a call", "who owes me documents", "who went quiet", "how are my leads converting", "how many LegalMatch leads signed", "update the conversion tracker", "what did I promise this week", or when a scheduled morning run asks for it. It reads the Word file where he keeps his notes, records what each paragraph says with the paragraph cited, keeps a conversion tracker by lead source, and reports what is owed. It never says what to do.
---

# Day notes

Item 15. Charles keeps his day notes in Word, one heading per day. This skill
reads them, records who he spoke with, what kind of contact it was, where the
lead came from, the outcome, the fee as he wrote it, and what is owed by whom.
It keeps a conversion tracker, one row per prospect, and writes one page:
owed by you, owed to you, gone quiet, conversion by source.

Three rules, and they are the firm's:

- **Every entry cites its day and paragraph**, and carries a quote copied from
  that paragraph. The engine checks the quote word for word. An entry whose
  quote is not in the paragraph is refused and listed.
- **Nothing is dropped.** Every paragraph read and not recorded is listed on the
  page, and so is every paragraph before the first date.
- **It reports.** Open means the notes do not say it was done. A prospect who
  has gone quiet is listed, never concluded lost.

---

## Run it

**1. Read the notes.**

```
python3 scripts/read_notes.py "C:/Users/<you>/Documents/Day Notes.docx" notes.json --since 2026-07-15
```

It needs nothing installed. A .docx is read as the zip of XML it is. A .txt or
.md file is read as text. It finds the date headings in any shape he types:
Monday, October 12, 2026 · Oct. 12, 2026 · 10/12/2026 · 10/12/26 ·
2026-10-12. A paragraph that opens with a date and a colon or a dash starts a
new day and keeps its text. Every paragraph under a day gets a number. It
interprets nothing.

Read the last 90 days each run. The tracker does not double count, so a day
read twice changes nothing.

**2. Write the entries.** Read `notes.json` and add to `entries.json` for every
day that has none yet, following `reference/entries.md`. Keep `entries.json`
beside the tracker. It grows run by run. When a later paragraph says an owed
item was done, set that item's status to done and cite the paragraph in
`closed_by`.

**3. Run the engine.**

```
python3 scripts/track.py --notes notes.json --entries entries.json \
    --tracker "C:/Users/<you>/OneDrive/Conversion Tracker.xlsx" \
    --as-of 2026-10-13 --since 2026-07-15 --out "Day Notes.html"
```

- `--tracker` is .xlsx where openpyxl is present, .csv anywhere. It holds
  names, so it stays on his machine.
- `--since` sets the conversion window. It defaults to 90 days back.
- `--quiet-days` sets when a prospect with no outcome reads as quiet. It
  defaults to 7.

The run prints how many entries were kept and refused, what changed in the
tracker, and which days in the notes have no entry yet. A refused entry is
fixed and the run repeated. The usual cause is a paragraph Charles edited or a
paragraph inserted above it, which moves the numbers.

**4. Hand him the page.** Say what is owed by him, what is past due, and who
has gone quiet. Do not add advice the page does not carry.

---

## The page

| Section | What it shows |
|---|---|
| Owed by you | What the notes say Charles will do, open, with the date noted, the due date if one was written, and days open. Past due is marked. |
| Owed to you | What a client or prospect said they would send, open, the same way. |
| Gone quiet | Prospects with no outcome in the notes and nothing for seven days or more. |
| Conversion by source | Prospects, consulted, engaged, declined, no-show, and open, by source, with the engaged rate and the median days from first contact to engagement. |
| Engaged in the window | Each engagement with its matter, source, and the fee as written. |
| Read, not recorded | Every paragraph no entry cites, and every paragraph before the first date. |
| Entries refused | Every entry that failed the check, with the reason. |

The conversion count comes from the notes alone. A lead that never reached the
notes is not counted, and the page says so.

---

## Every morning

Built to be scheduled. Weekdays at 7:00 a.m., a scheduled task:

> Run day notes. Read my day notes from the last 90 days, add entries for any
> day without them, and run crlaw-day-notes with my conversion tracker. Send me
> the page if anything is owed by me, past due, or gone quiet.

---

## What it will not do

- Say what to do about a prospect, a fee, or an open item. The judgment is his.
- Conclude a prospect is lost. Quiet is an open item.
- Fill in a source, a fee, or a due date the notes do not give.
- Change the notes. It reads them and never writes to them.
- Put a name on the hub or in a file name. The tracker and the page stay on
  his machine.

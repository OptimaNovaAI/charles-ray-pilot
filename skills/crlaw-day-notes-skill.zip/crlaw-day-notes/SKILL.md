---
name: crlaw-day-notes
description: Day notes intelligence and conversion tracking for the Law Offices of Charles A. Ray, P.C. Use whenever Charles asks about his notes, his leads, or his open work, including "read my CARET notes from the last 30 days and show me what's open", "read my day notes", "read my CARET notes", "what IRS calls did I have", "what did the revenue officer agree to", "what's open from my notes", "what's open in CARET", "show my open tasks", "who owes me", "who do I owe a call", "who owes me documents", "who went quiet", "how are my leads converting", "how many LegalMatch leads signed", "update the conversion tracker", "what did I promise this week", or when a scheduled Monday run asks for it. It reads the notes he keeps in CARET Legal from the firm export (CARET is the source; a Word file only when he hands one over), leads with his IRS calls quoted from the notes, lists his open CARET tasks, records what each note says with the note cited, keeps a conversion tracker by lead source in OneDrive, and reports what is owed. It never says what to do.
---

# Day Notes

Item 15. Charles keeps his notes in CARET Legal, inside each matter, and files
a prospect's notes under the matter name "lead". **CARET's Notes.csv is the
source.** CARET has no API. Its firm export saves every note, task, and matter
to one zip in Downloads, and this skill reads that zip as it lands. Most of his
notes are IRS calls, so the page leads with them: every IRS contact, the
official as written, the ID number, and what the note says about dates and
commitments, quoted. Then what is owed by whom, his open CARET tasks, and lead
conversion by source.

Three rules, and they are the firm's:

- **Every entry cites its day and note**, and carries a quote copied from that
  note. The engine checks the quote word for word. An entry whose quote is not
  in the note is refused and listed. So is an entry dated a day the notes do
  not have, or one whose matter differs from the cited note's matter.
- **Nothing is dropped.** Every note read and not recorded is listed on the
  page with its row in Notes.csv, and so is every note with no readable date.
- **It reports.** Open means the notes do not say it was done. A prospect who
  has gone quiet is listed as an open item. An IRS call is quoted, never
  summarized into advice.

---

## Run It

Commands below say `python3`. On Windows, where `python3` is not found, use
`python` (or `py -3`). Run from this skill's own folder; the scripts are in
`scripts/`.

Two lines the run may print go to Charles as written, before anything else:
"No CARET export found" (the run read Outlook only; tell him how to export)
and any line saying the Claude AI Reports folder is not on OneDrive or not
connected (what the run saved will not be there next session; ask him to
connect his OneDrive folder Claude AI Reports to the chat).


When Charles says "Read my CARET notes from the last 30 days and show me
what's open," this is the whole run.

**1. Export from CARET.** In CARET: Firm Settings, Your CARET Legal Account,
Export, Download Data. The zip, FirmExport-<n>.zip, lands in Downloads. There
is nothing to unzip and nothing to move. Do not ask him for a Word file; there
is none.

**2. Read the notes.**

```
python3 scripts/read_notes.py notes.json --days 30
```

With no file named it reads Notes.csv and Task.csv straight out of the newest
FirmExport zip in Downloads (or Claude AI Reports). `--days 30` is the last 30
days; `--since 2026-07-15` takes a date instead. To read a particular export,
add `--caret` and its path. It needs nothing installed.

- Each note becomes one numbered paragraph under its date, in date order and
  then in the order of the rows in Notes.csv.
- The paragraph reads "Subject: description", with CARET's HTML cleaned to
  plain text, and carries its matter number, the matter name, whether it is a
  lead, and its row, as "Notes.csv row 12".
- A note that is an IRS contact also carries, from its own text: the official
  as written (RA, RO, SO, AO, ACS, PPS, revenue agent or officer, settlement or
  appeals officer, examiner), any employee ID number, and every sentence with
  a date or a commitment, quoted whole.
- Open tasks come from Task.csv: every task whose status is not complete,
  done, closed, or cancelled and whose completed date is blank, with due date,
  status, matter, and row. `--no-tasks` leaves them out.
- The run prints how each table read, for example "Task.csv: 2,400 rows read",
  and the page shows the same lines. A row the reader could not put back
  together is listed by line, never guessed at.
- A note with no readable date is listed as undated and kept.

A Word or text file is read only when Charles hands one over and names it:
`python3 scripts/read_notes.py "Day Notes.docx" notes.json --since 2026-07-15`.

**3. Write the entries.** Read `notes.json` and add to
`Day Notes Entries.json` for every day that has none yet, following
`reference/entries.md`. When a later note says an owed item was done, set that
item's status to done and cite the note in `closed_by`. With no entries yet,
the page still runs: IRS calls, open tasks, and every note read.

**4. Run the engine.**

```
python3 scripts/track.py --notes notes.json --out "Day Notes.html"
```

- **Where things are kept.** The conversion tracker, `Lead Conversion
  Tracker.csv`, and the entries, `Day Notes Entries.json`, live in OneDrive,
  in the Claude AI Reports folder beside the clock register. A skill's own
  folder does not persist between sessions, so nothing that must last is kept
  there. The engine finds that folder on its own and creates it when missing.
  `--tracker` and `--entries` name another place; a `.xlsx` tracker works
  where openpyxl is present. Both hold names, so both stay on his machine.
- `--since` sets the conversion window. It defaults to 90 days back.
- `--quiet-days` sets when a prospect with no outcome reads as quiet. It
  defaults to 7.

The run prints the export it read and its age, how many IRS calls, how many
entries were kept and refused, what changed in the tracker, and which days in
the notes have no entry yet. A refused entry is fixed and the run repeated.

**5. Hand him the page.** Say how many IRS calls, what is owed by him, what is
past due, and who has gone quiet. Add no advice the page does not carry.

---

## The Page

| Section | What It Shows |
|---|---|
| Header | The export read, when it was taken, and how many days old it is. Past seven days, the header states the age as a fact. |
| IRS Calls | First. Every note that is an IRS contact, newest first: date, matter, the official as written, the ID number, and each sentence of the note with a date or a commitment, quoted word for word. |
| Owed by You | What the notes say Charles will do, open, with the date noted, the due date if one was written, and days open. His open CARET tasks sit here too, labeled From CARET tasks, with due date, matter, and Task.csv row. Past due is marked. |
| Owed to You | What a client or prospect said they would send, open, the same way. |
| Lead Conversion | Gone Quiet, Conversion by Source, and Engaged in the Window, after the work above. With no lead notes and no prospects in the period, one line says so: No lead notes in this period. |
| Read, Not Recorded | Every note no entry cites, with its matter and Notes.csv row, and every undated note. |
| Entries Refused | Every entry that failed the check, with the reason. |
| From the Export | How Notes.csv and Task.csv read, and any column the reader could not find, with the headers it did find. |

Notes filed under "lead" are the prospect pool. An entry on a lead note takes
its source from the note when the note names one (LegalMatch, Avvo,
Martindale, Calendly, a referral) and reads Not stated when it names none. The
conversion count comes from the notes alone. A lead that never reached the
notes is not counted, and the page says so.

---

## IRS Contacts

Every official the notes name with a title, "RA Delgado" or "Settlement
Officer Park", in two or more notes, is added to IRS Contacts.txt in Claude AI
Reports, once. Tax words that follow a title ("RA Penalty abatement") are never
added. Hearing
prep and the playbook read that list, so a meeting he calendars by surname
alone, "Meeting with Delgado", is still caught. The run says who was added.
He can edit the file; a struck name that his notes name again comes back, so
tell him to leave a line he wants gone as "# Delgado" instead.

## Monday Mornings

Built to be scheduled. Charles exports from CARET Friday afternoon or first
thing Monday. Mondays at 7:00 a.m., a scheduled task:

> Run day notes. Read my newest CARET export from Downloads with my open
> tasks, covering the last 30 days. Add entries for any day without them,
> following crlaw-day-notes, and run it with my conversion tracker in Claude
> AI Reports. Send me the page with my IRS calls, what I owe, what is past due,
> and who has gone quiet. If the export is more than seven days old, say how
> old it is.

---

## What It Will Not Do

- Say what to do about a prospect, a fee, a task, or an open item. The
  judgment is his.
- Conclude a prospect is lost. Quiet is an open item.
- Fill in a source, a fee, or a due date the notes do not give.
- Change CARET or the notes. It reads the export and never writes to it.
- Put a name on the hub or in a file name. The tracker and the page stay on
  his machine.

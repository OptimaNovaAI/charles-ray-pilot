# Writing entries

`entries.json` is a list of entries, one per fact the notes state. A paragraph
that holds two facts, a consult and a document promised, is one entry with an
owed item. A paragraph about two people is two entries citing the same
paragraph.

```json
{"entries": [
  {
    "date": "2026-09-28",
    "paras": [2],
    "quote": "Quoted $3,500 flat for CNC",
    "kind": "consult",
    "person": "the name as the notes write it",
    "matter": "M-0917",
    "source": "Friedman Framme",
    "fee": "$3,500 flat for CNC",
    "owed": [
      {"what": "433-A", "who": "the client's name", "due": "2026-10-02", "status": "open"}
    ]
  }
]}
```

## The fields

| Field | Rule |
|---|---|
| `date` | The day heading the paragraph sits under, as `notes.json` gives it. |
| `paras` | The paragraph number or numbers under that day. |
| `quote` | Copied from the cited paragraph, word for word. A short phrase is enough. The engine checks it, ignoring spacing and case. |
| `kind` | One of the kinds below. |
| `person` | The name as the notes write it. The tracker keys on it, so the same person is written the same way each time. |
| `matter` | The matter number, when the notes give one. |
| `source` | Where the lead came from, only when the notes say. Otherwise leave it out. The tracker shows Not stated. |
| `fee` | As written, with its words: "$3,500 flat for CNC". Never computed. |
| `owed` | What someone said they would do. See below. |

## Kinds

| Kind | Use for |
|---|---|
| `prospect` | A new lead, an inquiry, a callback, a consult set. |
| `consult` | The consult held. |
| `engaged` | Signed, retained, matter opened. |
| `declined` | Declined, by either side. |
| `no_show` | A consult missed. |
| `client_work` | Work on an engaged matter. |
| `irs_call` | A call with the IRS or a state agency. |
| `admin` | The practice itself: CAF, CLE, billing, the office. |
| `other` | Anything else. Still cited. |

The first five feed the conversion tracker. The rest keep a person's last date
current, so a prospect with work in the notes does not read as quiet.

## Sources

Written the way the tracker groups them: LegalMatch, Avvo, Martindale,
Calendly, Friedman Framme, Answering service, Referral, Phone, Website, Other.
A referral from a named person or firm is that name when the notes give it.

## Owed items

| Field | Rule |
|---|---|
| `what` | The thing owed, in a few words, in the notes' terms. |
| `who` | Charles for what he owes. The person's name for what they owe him. |
| `due` | A date, `YYYY-MM-DD`, only when the notes give one. "By 10/2" is the 2nd of October in the year of the note. "By Friday" is the first Friday on or after the note's date, with `due_as_written` set to "by Friday". No date in the notes, no `due`. |
| `status` | `open`, or `done` when a later paragraph says it was done. |
| `closed_by` | With `done`: the day and paragraph that says so, as "2026-10-05 para 1". |

## Words never written

An entry is a record. The engine refuses to write the page when its own text
contains should, recommend, advisable, or we suggest. Charles's own words,
quoted from the notes, are his and pass.

# Writing Entries

`Day Notes Entries.json` (in OneDrive, Claude AI Reports) is a list of entries, one per fact the notes state. A note that
holds two facts, a consult and a document promised, is one entry with an owed
item. A note about two people is two entries citing the same note.

```json
{"entries": [
  {
    "date": "2026-10-08",
    "paras": [1],
    "quote": "Dana Whitfield, wage levy",
    "kind": "consult",
    "person": "the name as the notes write it",
    "fee": "$3,500 flat",
    "owed": [
      {"what": "433-A", "who": "the client's name", "due": "2026-10-14", "status": "open"}
    ]
  },
  {
    "date": "2026-10-12",
    "paras": [1],
    "quote": "I will send the 433-F by 10/20",
    "kind": "client_work",
    "person": "Avery Lane",
    "matter": "01901",
    "owed": [{"what": "433-F", "who": "Charles", "due": "2026-10-20", "status": "open"}]
  }
]}
```

## The Fields

| Field | Rule |
|---|---|
| `date` | The day the note sits under, as `notes.json` gives it. It must be a day in `notes.json`, or the entry is refused. |
| `paras` | The note's number or numbers under that day. An IRS call note also shows its `irs` block in notes.json; an `irs_call` entry cites the same note. Each CARET paragraph also shows its row as `src`, "Notes.csv row 12", for finding it. |
| `quote` | Copied from the cited note, word for word. A short phrase is enough. The engine checks it, ignoring spacing and case. |
| `kind` | One of the kinds below. |
| `person` | The name as the notes write it. The tracker keys on it, so the same person is written the same way each time. |
| `matter` | The matter number, when the note has one. It must match the cited note's `matter`, or the entry is refused with the reason. "01901" and "01901-Avery Lane" both match. Leave it out for a lead note. |
| `source` | Where the lead came from, only when the notes say. Otherwise leave it out. |
| `fee` | As written, with its words: "$3,500 flat for CNC". Never computed. |
| `owed` | What someone said they would do. See below. |

## Kinds

| Kind | Use For |
|---|---|
| `prospect` | A new lead, an inquiry, a callback, a consult set. |
| `consult` | The consult held. |
| `engaged` | Signed, retained, matter opened. |
| `declined` | Declined, by either side. |
| `no_show` | A consult missed. |
| `client_work` | Work on an engaged matter. |
| `irs_call` | A call with the IRS or a state agency. |
| `admin` | The practice itself: CAF, CLE, billing, the office. |
| `other` | Anything else. Still cited. |

The first five feed the conversion tracker. The rest keep a person's last date
current, so a prospect with work in the notes does not read as quiet.

## Leads

CARET files a prospect's notes under the matter name "lead", and `notes.json`
marks those paragraphs `"lead": true`. They are the prospect pool. Write a
`prospect`, `consult`, `no_show`, or `declined` entry for each person a lead
note names. When the entry carries no `source`, the engine reads the cited
note: a note that names LegalMatch, Avvo, Martindale, Calendly, Friedman
Framme, the answering service, a referral, or the website gives that source,
and a note that names none reads Not stated. Once the client signs and CARET
opens a matter, the `engaged` entry cites the note filed under that matter.

## Sources

Written the way the tracker groups them: LegalMatch, Avvo, Martindale,
Calendly, Friedman Framme, Answering service, Referral, Phone, Website, Other.
A referral from a named person or firm is that name when the notes give it.

## Owed Items

| Field | Rule |
|---|---|
| `what` | The thing owed, in a few words, in the notes' terms. |
| `who` | Charles for what he owes. The person's name for what they owe him. |
| `due` | A date, `YYYY-MM-DD`, only when the notes give one. "By 10/2" is the 2nd of October in the year of the note. "By Friday" is the first Friday on or after the note's date, with `due_as_written` set to "by Friday". No date in the notes, no `due`. |
| `status` | `open`, or `done` when a later note says it was done. |
| `closed_by` | With `done`: the day and note that says so, as "2026-10-05 para 1". |

Open tasks from Task.csv need no entry. They reach the page on their own,
labeled From CARET tasks. When a note promises the same thing a task holds,
both show, each with its own source.

## Words Never Written

An entry is a record. The engine refuses to write the page when its own text
contains should, recommend, advisable, or we suggest. Charles's own words,
quoted from the notes, and his CARET task names are his and pass.

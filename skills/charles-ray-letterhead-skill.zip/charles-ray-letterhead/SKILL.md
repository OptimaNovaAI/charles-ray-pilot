---
name: charles-ray-letterhead
description: Produce letters, memoranda, client agreements, and complete matter opening packages on the Law Offices of Charles A. Ray, P.C. letterhead. Use whenever Charles needs something that goes out on firm paper — a client letter, a transmittal, an internal memo, a services agreement, an engagement letter, a letter to the IRS or a state taxing authority, or anything he describes as "put this on my letterhead". Triggers include "draft a letter to", "put this on letterhead", "write a memo about", "send this to the client", "draft the transmittal", "engagement letter for", "services agreement for", or pasting draft text and asking for it to be formatted properly. Also use when he says "open a matter for", "send the agreement", "get the engagement letter out", or when a document he was sent needs to be rebuilt on his letterhead.
---

# Letterhead and memoranda

Every document that leaves the firm carries the letterhead, the running
header, and the badge at the correct proportion. None of that is retyped and
none of it drifts.

---

## Build from the corrected master, never from a prior document

`templates/CRLaw_Letterhead_Master.docx`

Copying an old letter forward is how another client's matter ends up in a
running header. It has already happened once in this firm's templates, and the
correction is in `reference/corrections.md`.

---

## Two kinds of placeholder

**«Guillemets» are filled by the system.** Nine of them:

```
ClientName            ClientEmail          ClientAddressLine1
ClientCityStateZip    ClientSalutation     LetterDate
MatterDescription     TaxFormAndYear       FeeAmount
```

**[Square brackets] are drafting Charles owns.** Never fill them, never remove
them, never guess at them. They mark the places where his judgment goes.

When a bracket remains at the end, say so plainly and name what it is waiting
for. Do not describe the document as finished while a bracket is open.

---

## Build it

Assemble the nine fields into JSON, then:

```
python3 scripts/build_letter.py fields.json out.docx
```

The script refuses to write a file when any of the nine is empty. A document
that reaches a client with `«ClientName»` in it is worse than no document, so
ask for the missing field instead of filling it with something plausible.

`MatterDescription` and `TaxFormAndYear` appear in the running header on every
page after the first, and `MatterDescription` is also written to the document
title property. Both are read by anyone who opens the file, so they carry the
matter and never a placeholder.

---

## What the master already handles

Do not rebuild any of this by hand.

- Badge at 3.125 by 0.9167 inches, the native 3.409 to 1 proportion
- Letterhead block in Georgia, the firm's own setting
- Letter, one-inch margins, header half an inch from the edge
- Four-line running header on page two onward: matter, form and year, date,
  and a live page number
- First-page header declared and deliberately blank
- No footers anywhere; the header carries the page number
- Website and email hyperlinks pointing where they display

---

## Opening a matter

For a complete package rather than a single letter:

```
python3 scripts/open_matter.py matter.json outdir/
```

It writes the agreement on letterhead, names the POA master that travels with
it, and drafts the transmittal email. Three agreement types:

| Type | When |
|---|---|
| `investigative` | Investigatory work only. Administrative Fee, credited toward the later engagement. |
| `representation` | Representation before a named forum. Fixed Fee, prior credit applied. |
| `full` | The long-form agreement, sections 1 through 12. |

The JSON needs the nine letterhead fields plus `Jurisdiction` and
`AgreementType`. Jurisdiction picks the POA: federal to Form 2848, dc to
D-2848, md to Form 548, va to PAR 101.

The LawPay link is written in. It is the firm's payment link and it does not
come from any practice management system.

Every type ships with bracketed passages open. Those are the matter-specific
paragraphs and they are his to write. Say how many remain and what each is
waiting for. Never describe the package as ready to send while a bracket is
open.

---

## Drafting the body

Charles writes short. Short sentences, no corporate padding, no throat
clearing, no closing flourish. He states the matter, sets out what he will do,
and names the next step.

**Service clauses use manually typed numbers,** (1), (2), (3), never Word
auto-numbering. Fee paragraphs cross-reference those numbers by hand, and
auto-numbering renumbers silently when a clause moves. That breaks the
cross-reference without warning anyone.

**No clause may name a party from another matter.** Read every exclusion and
every recital against the client in front of you before the document is
written.

---

## Before it goes out

Convert to PDF and look at it. It passes only with an undistorted badge, no
header on page one, the correct running header from page two, page numbers
that resolve, a document title naming this client and no other, no stray digit
before LAW OFFICES OF, and no unfilled guillemet.

---

## Confidentiality

Metadata travels with the file. The document title is visible in a PDF title
bar even when nobody opens the properties, which is why it is set explicitly on
every build. Never let a file inherit a title from the document it was copied
from.

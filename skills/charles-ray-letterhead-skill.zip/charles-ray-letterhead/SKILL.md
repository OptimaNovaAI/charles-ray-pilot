---
name: charles-ray-letterhead
description: Produce letters, memoranda, and client agreements on the Law Offices of Charles A. Ray, P.C. letterhead. Use whenever Charles needs something that goes out on firm paper — a client letter, a transmittal, an internal memo, a services agreement, an engagement letter, a letter to the IRS or a state taxing authority, or anything he describes as "put this on my letterhead". Triggers include "draft a letter to", "put this on letterhead", "write a memo about", "send this to the client", "draft the transmittal", "engagement letter for", "letter to the Service", or pasting draft text and asking for it to be formatted properly. Also use when a document he was sent needs to be rebuilt on his letterhead.
---

# Letters and memoranda

Built on the firm's own masters. Two variants, and the difference is not
cosmetic.

| Variant | Contact line |
|---|---|
| `client` | Tel, Mobile, Fax |
| `agency` | Tel, Fax |

**The mobile number is on the client sheet and not the agency sheet.** Anything
going to the Service or a state taxing authority uses `agency`. If you are
unsure which one a letter needs, ask.

---

## Build it

```
python3 scripts/build_letter.py fields.json out.docx
```

`fields.json` carries the eleven tokens, a `Variant`, and a `Body` as a list of
paragraphs. The token list and what each one does is in
`reference/tokens.md`.

---

## Opening a matter

For the full package rather than a single letter:

```
python3 scripts/open_matter.py matter.json outdir/
```

It writes the agreement into the letterhead, names the power of attorney that
travels with it, and drafts the transmittal. Three types:

| Type | When |
|---|---|
| `investigative` | Investigatory work only. Administrative Fee, credited toward the later engagement. |
| `representation` | Representation before a named forum. Fixed Fee, prior credit applied. |
| `full` | The long-form agreement, sections 1 through 11. |

The JSON carries the eleven letterhead tokens plus `FeeAmount`,
`Jurisdiction`, `AgreementType`, and a `Variant`. Jurisdiction picks the power
of attorney: federal to Form 2848, dc to D-2848, md to Form 548, va to
PAR 101.

The LawPay link is the firm's own and is written in. Every type ships with
bracketed passages open. Those are the matter-specific paragraphs and they are
his to write. Say how many remain. Never call a package finished while one is
unwritten.

---

## The rule that governs this skill

**Nothing is written unless the finished file can prove it worked.**

Every supplied value is read back out of the document after it is written. For
an agreement that includes the fee and the payment link. If any of it is not in
the file, the file is deleted and the reason is printed.

This replaces an earlier check that asked whether any token had been left
behind. That check passed on a document containing no client information at
all, because the tokens were never in that template to begin with, so nothing
was left behind. Absence of a failure is not presence of a result. The full
list is in `reference/acceptance.md`.

**A letter with no body is refused.** So is a build missing any of the ten
required fields. Ask for what is missing rather than filling it with something
plausible.

---

## Drafting the body

Charles writes short. Short sentences, no throat clearing, no closing flourish.
He states the matter, sets out what he will do, and names the next step.

Pass the body as separate paragraphs. The skeleton already carries the date,
the address block, the Re: line, the salutation, and the sign-off, so the body
is only the letter itself.

**Service clauses use manually typed numbers**, (1), (2), (3), never Word
auto-numbering. Fee paragraphs cross-reference those numbers by hand, and
auto-numbering renumbers silently when a clause moves.

**No clause may name a party from another matter.** Read every exclusion and
recital against the client in front of you before the document is written.

---

## Before it goes out

Convert to PDF from Word on Charles's machine, not from this pipeline.

The build host has no licence for Georgia, so a Georgia request there resolves
to Gelasio. Gelasio is metrically identical, which means line breaks, page
counts, and pagination are faithful and layout can be trusted. The letterforms
are not Georgia. For anything a client or an agency will read, the conversion
happens in Word.

---

## Confidentiality

Metadata travels with the file. The document title is visible in a PDF title
bar without anyone opening the properties panel, so it is set to the matter on
every build and never inherited from the document it was copied from.

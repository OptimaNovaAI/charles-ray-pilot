# The eleven tokens

Ten appear in the body, four in the running header, and `ClientHeader` is the
only one that lives in the header alone.

| Token | Where | Notes |
|---|---|---|
| `ClientHeader` | header | The short name that repeats on page two onward |
| `ClientName` | body | First addressee |
| `ClientNameSecond` | body | Optional. Blank removes the line rather than leaving it empty. |
| `ClientStreet` | body | Was `ClientAddressLine1` in the earlier build |
| `ClientCityStateZip` | body | |
| `ClientEmail` | body | Under VIA ELECTRONIC MAIL |
| `ClientSalutation` | body | The name after Dear |
| `LetterDate` | body, header | |
| `MatterCaption` | body, header | The first line after Re: |
| `MatterDescription` | body, header | |
| `TaxFormAndYear` | body, header | |

`FeeAmount` is not here. The fee belongs in an agreement body, which
`open_matter.py` writes, not on the letterhead.

## Two things Word does that break naive filling

**It splits tokens across runs.** In the header, `«ClientHeader»` is stored as
three separate text nodes: `«`, `ClientHeader`, `»`. A plain string replace
never matches it and never errors. The fill engine joins the paragraph before
substituting, which is why a split token fills the same as a contiguous one.

**Tabs sit between runs.** The `Re:` line is `Re:` then a tab to a stop at half
an inch then the caption. Collapsing the runs to reach a split token moves the
text past the tab. So the engine replaces in place first and only collapses a
paragraph when a guillemet actually survives, which is the only case that
needs it.

# What was corrected in the master

Five defects were live in the letterhead file the firm was using as of
August 2026. All five are fixed in `templates/CRLaw_Letterhead_Master.docx`.
They are recorded here so none is reintroduced by copying an older document
forward.

## 1. The badge was stretched 34 percent

The AV Preeminent badge is 300 by 88 pixels, a proportion of 3.409 to 1. In
the master it was placed at 3.125 by 1.229 inches, a proportion of 2.542 to 1.
It had been resized on one axis.

Corrected to 3.125 by 0.9167 inches. **Never resize one axis alone.**

## 2. The running header carried another client's matter

The header read `DCPS MEMORANDUM OF AGREEMENT`, dated September 22, 2025.
Every document generated from that master carried a different client's matter
name on every page after the first until someone noticed and retyped it.

Replaced with tokens that are filled per document.

## 3. The website link went to the wrong domain

Displayed text read `www.charlesraylaw.com`. The link target was
`http://www.charlesray.com/`. Anyone clicking the address in the letterhead
went somewhere other than the firm.

Target corrected to `https://www.charlesraylaw.com/`.

## 4. A hidden field printed a stray digit

The letterhead contained a `SEQ CHAPTER` field. Word hides it. Headless PDF
converters print it as a `1` immediately before LAW OFFICES OF.

The field is removed.

## 5. The document title property was empty

The title is visible in a PDF title bar without anyone opening the properties
panel. An empty title is better than a stale one, but neither is right.

Now set explicitly to the matter description on every build.

## Also added

The first-page header is now declared and deliberately blank, rather than
relying on its absence. Word treats a missing first-page header differently
across versions and converters, and relying on absence is how a letterhead
ends up doubled on page one.

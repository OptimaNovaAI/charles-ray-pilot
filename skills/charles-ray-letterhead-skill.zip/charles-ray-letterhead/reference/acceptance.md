# What a build has to prove

The old checklist asked whether any token was left behind. That is the wrong
question, and it is how an empty letterhead shipped reporting success. A token
that was never in the template leaves nothing behind and passes a check it
should have failed.

Every check below asks whether the result is present, never whether a failure
is absent.

1. **Each of the ten required values is read back out of the written file.**
   Name, street, city and state, email, salutation, date, caption, matter
   description, form and years, and the header name.
2. **The body is in the document.** A letterhead with no letter on it is the
   specific failure this replaces.
3. **A supplied optional value is present.** A second addressee that was given
   and then vanished is a silent loss.
4. **An omitted optional value removed its line.** No blank row in the address
   block.
5. **No guillemet survives anywhere.** The old check, kept, because it still
   catches a template that changed under the script.
6. **Nothing is written when any check fails.** The file is deleted and the
   reason is printed. A partial document on disk is worse than none, because
   it will eventually be sent.

## Awaiting the firm's audit

Charles ran an eleven-finding audit against the files. Four were blocking.
Only the first was described in the covering email, the empty letterhead, and
it is addressed above. The audit document did not arrive with the masters.

When it does, its six acceptance checks replace this list rather than sitting
beside it.

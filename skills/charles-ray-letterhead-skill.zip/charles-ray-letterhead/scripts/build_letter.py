#!/usr/bin/env python3
"""
Letterhead and memo generator for the Law Offices of Charles A. Ray, P.C.

    python3 build_letter.py fields.json out.docx

Fills the nine guillemet tokens in the corrected master. Square-bracket
drafting is never touched; it is the attorney's to write.

Refuses to write a file with an unfilled guillemet, because a document that
reaches a client with «ClientName» in it is worse than no document.
"""

import json
import re
import shutil
import sys
import zipfile
from pathlib import Path

TEMPLATE = Path(__file__).resolve().parent.parent / "templates" / "CRLaw_Letterhead_Master.docx"

TOKENS = [
    "ClientName", "ClientEmail", "ClientAddressLine1", "ClientCityStateZip",
    "ClientSalutation", "LetterDate", "MatterDescription", "TaxFormAndYear",
    "FeeAmount",
]

PARTS = [
    "word/document.xml",
    "word/header1.xml",
    "word/header2.xml",
    "docProps/core.xml",
]


def xml_escape(s):
    return (str(s).replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;"))


def split_safe(xml, token, value):
    """
    Replace a token even when Word has split it across runs.

    Word breaks text at spell-check and formatting boundaries, so
    «MatterDescription» can live as three separate <w:t> elements. Collapse
    the guillemet span first, then substitute.
    """
    needle = f"\u00ab{token}\u00bb"
    if needle in xml:
        return xml.replace(needle, xml_escape(value))

    # token split across runs: find the guillemet pair and rebuild
    pattern = re.compile(
        r"\u00ab((?:</w:t>.*?<w:t[^>]*>|[^\u00ab\u00bb])*?)\u00bb", re.S)

    def repl(m):
        inner = re.sub(r"<[^>]+>", "", m.group(1))
        if inner.strip() == token:
            return xml_escape(value)
        return m.group(0)

    return pattern.sub(repl, xml)


def build(fields, out_path):
    missing = [t for t in TOKENS if t not in fields or fields[t] == ""]
    if missing:
        raise SystemExit(
            "Refusing to build. These fields are empty: "
            + ", ".join(missing)
            + "\nA document that reaches a client with an unfilled token in it "
              "is worse than no document. Fill them and run again."
        )

    out_path = Path(out_path)
    shutil.copy(TEMPLATE, out_path)

    zin = zipfile.ZipFile(TEMPLATE, "r")
    tmp = out_path.with_suffix(".tmp.docx")
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename in PARTS:
                xml = data.decode("utf-8")
                for tok in TOKENS:
                    xml = split_safe(xml, tok, fields[tok])
                data = xml.encode("utf-8")
            zout.writestr(item, data)
    zin.close()
    tmp.replace(out_path)

    # verify nothing slipped through
    leftovers = []
    with zipfile.ZipFile(out_path) as z:
        for part in PARTS:
            try:
                x = z.read(part).decode("utf-8")
            except KeyError:
                continue
            plain = re.sub(r"<[^>]+>", "", x)
            leftovers += re.findall(r"\u00ab[^\u00bb]{0,60}\u00bb", plain)

    if leftovers:
        out_path.unlink(missing_ok=True)
        raise SystemExit(
            "Build failed. Unfilled tokens remained: "
            + ", ".join(sorted(set(leftovers)))
        )

    brackets = 0
    with zipfile.ZipFile(out_path) as z:
        plain = re.sub(r"<[^>]+>", "", z.read("word/document.xml").decode("utf-8"))
        brackets = len(re.findall(r"\[[^\]]{3,}\]", plain))

    print(f"Written: {out_path}")
    print(f"  Matter: {fields['MatterDescription']}")
    print(f"  Client: {fields['ClientName']}")
    if brackets:
        print(f"  {brackets} bracketed passage(s) awaiting your drafting.")


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    fields = json.loads(Path(sys.argv[1]).read_text())
    build(fields, sys.argv[2])


if __name__ == "__main__":
    main()

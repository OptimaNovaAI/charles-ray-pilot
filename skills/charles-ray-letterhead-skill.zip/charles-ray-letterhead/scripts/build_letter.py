#!/usr/bin/env python3
"""
Letters and memoranda on the Law Offices of Charles A. Ray, P.C. letterhead.

    python3 build_letter.py fields.json out.docx

Fills the eleven tokens in the firm's master and writes the body in place of
the drafting placeholder. Two variants:

    client   Tel, Mobile, Fax
    agency   Tel, Fax only

The mobile number is on the client sheet and not the agency sheet. That is
deliberate and it is not a formatting choice.

Nothing is written unless every supplied value can be read back out of the
finished file.
"""

import json
import sys
from pathlib import Path

from docx import Document
from docx.shared import Pt

sys.path.insert(0, str(Path(__file__).resolve().parent))
from fill import fill_document, verify  # noqa: E402

HERE = Path(__file__).resolve().parent
TEMPLATES = {
    "client": HERE.parent / "templates" / "CRLaw_Letterhead_Client_2026.docx",
    "agency": HERE.parent / "templates" / "CRLaw_Letterhead_Agency_2026.docx",
}

BODY_PLACEHOLDER = "[body of the letter. Delete this line.]"

REQUIRED = [
    "ClientHeader", "ClientName", "ClientStreet", "ClientCityStateZip",
    "ClientEmail", "ClientSalutation", "LetterDate", "MatterCaption",
    "MatterDescription", "TaxFormAndYear",
]
OPTIONAL = ["ClientNameSecond"]


def write_body(path, paragraphs):
    """Replace the drafting placeholder with the letter body."""
    doc = Document(str(path))
    target = None
    for p in doc.paragraphs:
        if BODY_PLACEHOLDER in p.text:
            target = p
            break
    if target is None:
        raise SystemExit(
            "The master no longer contains its body placeholder. Nothing was "
            "written. Check the template before running again."
        )

    style_src = target.runs[0] if target.runs else None
    anchor = target

    for i, text in enumerate(paragraphs):
        if i == 0:
            for r in list(target.runs):
                r._element.getparent().remove(r._element)
            run = target.add_run(text)
            new_p = target
            # the placeholder carries a half-inch indent; the body does not
            new_p.paragraph_format.left_indent = Pt(0)
            new_p.paragraph_format.first_line_indent = Pt(0)
        else:
            new_p = anchor.insert_paragraph_before(text) if False else None
            # insert after the anchor so order is preserved
            new_el = anchor._p.makeelement(anchor._p.tag, {})
            anchor._p.addnext(new_el)
            from docx.text.paragraph import Paragraph
            new_p = Paragraph(new_el, anchor._parent)
            run = new_p.add_run(text)
        run.font.name = "Georgia"
        run.font.size = Pt(12)
        new_p.paragraph_format.space_after = Pt(10)
        new_p.paragraph_format.line_spacing = 1.15
        anchor = new_p

    doc.save(str(path))


def build(fields, out_path):
    variant = str(fields.get("Variant", "client")).lower()
    if variant not in TEMPLATES:
        raise SystemExit(f"Unknown variant '{variant}'. Use client or agency.")

    missing = [k for k in REQUIRED if not str(fields.get(k, "")).strip()]
    if missing:
        raise SystemExit(
            "Refusing to build. These fields are empty: " + ", ".join(missing)
            + "\nAsk for them rather than filling them with something plausible."
        )

    body = fields.get("Body") or []
    if isinstance(body, str):
        body = [b.strip() for b in body.split("\n\n") if b.strip()]
    if not body:
        raise SystemExit(
            "Refusing to build. There is no body. A letterhead with no letter "
            "on it is the failure this script exists to prevent."
        )

    out_path = Path(out_path)
    fill_document(TEMPLATES[variant], out_path, fields,
                  drop_if_empty=("ClientNameSecond",))
    write_body(out_path, body)

    ok, problems = verify(out_path, fields, REQUIRED, OPTIONAL)
    body_ok = all(_present(out_path, b) for b in body[:1])
    if not body_ok:
        problems.append("the body is not in the written document")
        ok = False

    if not ok:
        out_path.unlink(missing_ok=True)
        raise SystemExit(
            "Build failed and nothing was written:\n  - "
            + "\n  - ".join(problems)
        )

    print(f"Written: {out_path}")
    print(f"  Variant: {variant}")
    print(f"  Verified in the file: {', '.join(REQUIRED)}")
    if str(fields.get('ClientNameSecond', '')).strip():
        print("  Second addressee present.")
    else:
        print("  No second addressee. That line was removed, not left blank.")


def _present(path, needle):
    from fill import read_text
    return needle[:60] in read_text(path)


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    build(json.loads(Path(sys.argv[1]).read_text()), sys.argv[2])


if __name__ == "__main__":
    main()

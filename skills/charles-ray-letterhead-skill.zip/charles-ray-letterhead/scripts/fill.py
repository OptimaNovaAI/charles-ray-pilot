#!/usr/bin/env python3
"""
Token fill and verification for the Law Offices of Charles A. Ray, P.C.

Shared by build_letter.py and open_matter.py. Two jobs, and the second one
matters more than the first.

**Fill.** Word splits a token across runs at spell-check and formatting
boundaries, so a master authored in Word stores «ClientHeader» as three
separate text nodes: «, ClientHeader, ». A plain string replace never matches
it and never errors. This fills at the paragraph level, joining the text nodes
before substituting, so a split token fills the same as a contiguous one.

**Verify.** Every supplied value is then read back out of the written file.
A build that cannot prove the client's name is in the document does not get
written. Checking that no token was left behind is not the same test: a token
that was never in the template leaves nothing behind and passes a check it
should have failed.
"""

import re
import zipfile
from pathlib import Path

from lxml import etree

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
XML = "http://www.w3.org/XML/1998/namespace"


def _q(tag):
    return f"{{{W}}}{tag}"


FILLABLE_PARTS = ("word/document.xml", "word/header1.xml", "word/header2.xml")


def fill_part(xml_bytes, fields, drop_if_empty=()):
    """
    Substitute tokens in one XML part.

    Works paragraph by paragraph. A paragraph with no guillemet is untouched,
    which is what keeps the PAGE and NUMPAGES field runs intact: they carry no
    token, so they are never rewritten.

    A token named in drop_if_empty whose value is blank removes its whole
    paragraph, so an absent second addressee leaves no empty line in the
    address block.
    """
    root = etree.fromstring(xml_bytes)

    for para in list(root.iter(_q("p"))):
        nodes = list(para.iter(_q("t")))
        if not nodes:
            continue
        joined = "".join(n.text or "" for n in nodes)
        if "\u00ab" not in joined:
            continue

        # a paragraph that is only an empty optional token goes away entirely
        dropped = False
        for tok in drop_if_empty:
            if not fields.get(tok, "").strip():
                if joined.strip() == f"\u00ab{tok}\u00bb":
                    parent = para.getparent()
                    if parent is not None:
                        parent.remove(para)
                    dropped = True
                    break
        if dropped:
            continue

        # Pass one: a token wholly inside a single text node is replaced in
        # place. No restructuring, so tabs, breaks, and run formatting survive.
        for node in nodes:
            if not node.text or "\u00ab" not in node.text:
                continue
            txt = node.text
            for tok, val in fields.items():
                txt = txt.replace(f"\u00ab{tok}\u00bb", str(val))
            node.text = txt

        # Pass two, only if a guillemet survives, which means Word split a
        # token across runs. Collapsing is the only way to reach it, and it is
        # confined to paragraphs that genuinely need it.
        joined = "".join(n.text or "" for n in nodes)
        if "\u00ab" not in joined:
            continue
        filled = joined
        for tok, val in fields.items():
            filled = filled.replace(f"\u00ab{tok}\u00bb", str(val))
        if filled == joined:
            continue
        nodes[0].text = filled
        nodes[0].set(f"{{{XML}}}space", "preserve")
        for n in nodes[1:]:
            n.text = ""

    return etree.tostring(root, xml_declaration=True,
                          encoding="UTF-8", standalone=True)


def fill_document(template, out_path, fields, drop_if_empty=()):
    """Copy the template to out_path with every token filled."""
    out_path = Path(out_path)
    zin = zipfile.ZipFile(template)
    tmp = out_path.with_suffix(".tmp")
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename in FILLABLE_PARTS:
                data = fill_part(data, fields, drop_if_empty)
            zout.writestr(item, data)
    zin.close()
    tmp.replace(out_path)
    return out_path


def read_text(path):
    """All visible text from the parts that carry tokens."""
    out = []
    with zipfile.ZipFile(path) as z:
        for part in FILLABLE_PARTS:
            try:
                root = etree.fromstring(z.read(part))
            except KeyError:
                continue
            out.append("".join(n.text or "" for n in root.iter(_q("t"))))
    return "\n".join(out)


def verify(path, fields, required, optional=()):
    """
    Read the written file and confirm each value is actually in it.

    Returns (ok, problems). This is the check Charles asked for: presence of
    the result, never absence of a failure.
    """
    text = read_text(path)
    problems = []

    for field in required:
        val = str(fields.get(field, "")).strip()
        if not val:
            problems.append(f"{field} was empty")
        elif val not in text:
            problems.append(f"{field} is not in the written document")

    for field in optional:
        val = str(fields.get(field, "")).strip()
        if val and val not in text:
            problems.append(f"{field} was supplied but is not in the document")

    leftover = sorted(set(re.findall(r"\u00ab[^\u00bb\n]{0,40}\u00bb", text)))
    if leftover:
        problems.append("unfilled tokens remain: " + ", ".join(leftover))

    return (not problems), problems

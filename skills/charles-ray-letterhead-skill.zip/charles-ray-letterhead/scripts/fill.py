#!/usr/bin/env python3
"""
Token fill and verification for the Law Offices of Charles A. Ray, P.C.

Shared by build_letter.py and open_matter.py. Two jobs, and the second one
matters more than the first.

**Fill.** Word splits a token across runs at spell-check and formatting
boundaries, so a master authored in Word stores «ClientHeader» as three
separate text nodes: «, ClientHeader, ». A plain string replace never matches
it and never errors. This fills at the paragraph level, joining the text nodes
before substituting, so a split token fills the same as a contiguous one.

**Verify.** Every supplied value is then read back out of the written file.
A build that cannot prove the client's name is in the document does not get
written. Checking that no token was left behind is not the same test: a token
that was never in the template leaves nothing behind and passes a check it
should have failed.
"""

import re
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from xml.sax.saxutils import escape

from lxml import etree

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
XML = "http://www.w3.org/XML/1998/namespace"
CP = "http://schemas.openxmlformats.org/package/2006/metadata/core-properties"
DC = "http://purl.org/dc/elements/1.1/"

FIRM = "Law Offices of Charles A. Ray, P.C."


def _q(tag):
    return f"{{{W}}}{tag}"


FILLABLE_PARTS = ("word/document.xml", "word/header1.xml", "word/header2.xml")

PAGE_FIELDS = ("PAGE", "NUMPAGES")


def _is_page_field(instr):
    words = (instr or "").split()
    return bool(words) and words[0].upper() in PAGE_FIELDS


def mark_page_fields_dirty(root):
    """
    Flag every PAGE and NUMPAGES field so Word recalculates it on open.

    The cached result in the master is right only for the page the header
    first appears on. Anything that prints from the cache instead of
    recalculating would show that number on every page.
    """
    for fs in root.iter(_q("fldSimple")):
        if _is_page_field(fs.get(_q("instr"))):
            fs.set(_q("dirty"), "true")
    begin = None
    for el in root.iter(_q("fldChar"), _q("instrText")):
        if el.tag == _q("fldChar"):
            if el.get(_q("fldCharType")) == "begin":
                begin = el
        elif begin is not None:
            if _is_page_field(el.text):
                begin.set(_q("dirty"), "true")
            begin = None


def fill_part(xml_bytes, fields, drop_if_empty=()):
    """
    Substitute tokens in one XML part.

    Works paragraph by paragraph. A paragraph with no guillemet is untouched,
    which is what keeps the PAGE and NUMPAGES field runs intact: they carry no
    token, so they are never rewritten.

    A token named in drop_if_empty whose value is blank removes its whole
    paragraph, so an absent second addressee leaves no empty line in the
    address block.
    """
    root = etree.fromstring(xml_bytes)

    for para in list(root.iter(_q("p"))):
        nodes = list(para.iter(_q("t")))
        if not nodes:
            continue
        joined = "".join(n.text or "" for n in nodes)
        if "\u00ab" not in joined:
            continue

        # a paragraph that is only an empty optional token goes away entirely
        dropped = False
        for tok in drop_if_empty:
            if not fields.get(tok, "").strip():
                if joined.strip() == f"\u00ab{tok}\u00bb":
                    parent = para.getparent()
                    if parent is not None:
                        parent.remove(para)
                    dropped = True
                    break
        if dropped:
            continue

        # Pass one: a token wholly inside a single text node is replaced in
        # place. No restructuring, so tabs, breaks, and run formatting survive.
        for node in nodes:
            if not node.text or "\u00ab" not in node.text:
                continue
            txt = node.text
            for tok, val in fields.items():
                txt = txt.replace(f"\u00ab{tok}\u00bb", str(val))
            node.text = txt

        # Pass two, only if a guillemet survives, which means Word split a
        # token across runs. Collapsing is the only way to reach it, and it is
        # confined to paragraphs that genuinely need it.
        joined = "".join(n.text or "" for n in nodes)
        if "\u00ab" not in joined:
            continue
        filled = joined
        for tok, val in fields.items():
            filled = filled.replace(f"\u00ab{tok}\u00bb", str(val))
        if filled == joined:
            continue
        nodes[0].text = filled
        nodes[0].set(f"{{{XML}}}space", "preserve")
        for n in nodes[1:]:
            n.text = ""

    mark_page_fields_dirty(root)

    return etree.tostring(root, xml_declaration=True,
                          encoding="UTF-8", standalone=True)


def fill_document(template, out_path, fields, drop_if_empty=()):
    """Copy the template to out_path with every token filled."""
    out_path = Path(out_path)
    zin = zipfile.ZipFile(template)
    tmp = out_path.with_suffix(".tmp")
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename in FILLABLE_PARTS:
                data = fill_part(data, fields, drop_if_empty)
            zout.writestr(item, data)
    zin.close()
    tmp.replace(out_path)
    return out_path


def set_properties(path, title):
    """
    Write the document properties explicitly. Nothing is inherited.

    The title is set to the matter. Author and last saved by are the firm.
    Subject, keywords, and comments carried by the master are not copied,
    because a template's notes have no place in a letter that leaves the
    firm, and the title shows in a PDF title bar without anyone opening the
    properties panel.
    """
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    core = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
        f'<cp:coreProperties xmlns:cp="{CP}" xmlns:dc="{DC}" '
        'xmlns:dcterms="http://purl.org/dc/terms/" '
        'xmlns:dcmitype="http://purl.org/dc/dcmitype/" '
        'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
        f"<dc:title>{escape(str(title))}</dc:title>"
        f"<dc:creator>{escape(FIRM)}</dc:creator>"
        f"<cp:lastModifiedBy>{escape(FIRM)}</cp:lastModifiedBy>"
        "<cp:revision>1</cp:revision>"
        f'<dcterms:created xsi:type="dcterms:W3CDTF">{now}</dcterms:created>'
        f'<dcterms:modified xsi:type="dcterms:W3CDTF">{now}</dcterms:modified>'
        "</cp:coreProperties>"
    ).encode("utf-8")

    path = Path(path)
    tmp = path.with_suffix(".props.tmp")
    with zipfile.ZipFile(path) as zin, \
            zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename == "docProps/core.xml":
                data = core
            elif item.filename == "docProps/app.xml":
                app = data.decode("utf-8")
                app = re.sub(r"<Manager>[^<]*</Manager>", "", app)
                app = re.sub(r"<Company>[^<]*</Company>",
                             f"<Company>{escape(FIRM)}</Company>", app)
                data = app.encode("utf-8")
            zout.writestr(item, data)
    tmp.replace(path)


def verify_properties(path, title):
    """Read the properties back out of the written file. Returns problems."""
    problems = []
    with zipfile.ZipFile(path) as z:
        core = etree.fromstring(z.read("docProps/core.xml"))
        app = z.read("docProps/app.xml").decode("utf-8")

    def value(ns, tag):
        el = core.find(f"{{{ns}}}{tag}")
        return (el.text or "") if el is not None else None

    if value(DC, "title") != str(title):
        problems.append("the document title is not set to this matter")
    for ns, tag, label in ((DC, "creator", "author"),
                           (CP, "lastModifiedBy", "last saved by")):
        if value(ns, tag) != FIRM:
            problems.append(f"the {label} property is not the firm")
    for ns, tag in ((DC, "subject"), (CP, "keywords"), (DC, "description")):
        if value(ns, tag):
            problems.append(f"the {tag} property was carried over from the master")
    company = re.search(r"<Company>([^<]*)</Company>", app)
    if company and company.group(1) != FIRM:
        problems.append("the company property is not the firm")
    if "<Manager>" in app:
        problems.append("a manager property is present")
    return problems


def read_text(path):
    """All visible text from the parts that carry tokens."""
    out = []
    with zipfile.ZipFile(path) as z:
        for part in FILLABLE_PARTS:
            try:
                root = etree.fromstring(z.read(part))
            except KeyError:
                continue
            out.append("".join(n.text or "" for n in root.iter(_q("t"))))
    return "\n".join(out)


def verify(path, fields, required, optional=()):
    """
    Read the written file and confirm each value is actually in it.

    Returns (ok, problems). This is the check Charles asked for: presence of
    the result, never absence of a failure.
    """
    text = read_text(path)
    problems = []

    for field in required:
        val = str(fields.get(field, "")).strip()
        if not val:
            problems.append(f"{field} was empty")
        elif val not in text:
            problems.append(f"{field} is not in the written document")

    for field in optional:
        val = str(fields.get(field, "")).strip()
        if val and val not in text:
            problems.append(f"{field} was supplied but is not in the document")

    leftover = sorted(set(re.findall(r"\u00ab[^\u00bb\n]{0,40}\u00bb", text)))
    if leftover:
        problems.append("unfilled tokens remain: " + ", ".join(leftover))

    return (not problems), problems

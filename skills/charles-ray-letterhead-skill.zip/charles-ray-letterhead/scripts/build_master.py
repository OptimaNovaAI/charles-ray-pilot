#!/usr/bin/env python3
"""
Builds the letterhead master for the Law Offices of Charles A. Ray, P.C.

    python3 build_master.py badge.png out.docx

Layout is a borderless table, never tab stops. Tab stops are what caused the
email address to wrap under the website line in the previous master; they
resolve differently in Word, LibreOffice, and every PDF pipeline in between.
A table holds.
"""

import sys
from pathlib import Path

from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import qn, nsdecls

INK = RGBColor(0x1A, 0x1A, 0x1A)
GREY = RGBColor(0x5F, 0x5F, 0x5F)

FIRM_ADDRESS = ("The Capital Hilton Hotel, Lobby Level",
                "1001 16th Street, N.W.",
                "Washington, D.C. 20036-5701")

CONTACT_1 = [("Tel (202) 824-8123", None),
             ("Mobile (202) 525-9356", None),
             ("Fax (202) 217-3462 / (202) 824-0640", None)]
CONTACT_2 = [("www.charlesraylaw.com", None),
             ("cray@charlesraylaw.com", None)]
OF_COUNSEL = "Of Counsel: Alvin B. Sherron, Esq."


def run(p, text, size=12, bold=False, color=INK, spacing=None):
    r = p.add_run(text)
    r.font.name = "Georgia"
    r.font.size = Pt(size)
    r.bold = bold
    r.font.color.rgb = color
    if spacing:
        rPr = r._element.get_or_add_rPr()
        sp = OxmlElement("w:spacing")
        sp.set(qn("w:val"), str(spacing))
        rPr.append(sp)
    return r


def tight(p, before=0, after=0):
    p.paragraph_format.space_before = Pt(before)
    p.paragraph_format.space_after = Pt(after)
    p.paragraph_format.line_spacing = 1.0
    return p


def zero_margins(cell):
    tcPr = cell._tc.get_or_add_tcPr()
    mar = OxmlElement("w:tcMar")
    for side in ("top", "start", "bottom", "end"):
        e = OxmlElement(f"w:{side}")
        e.set(qn("w:w"), "0")
        e.set(qn("w:type"), "dxa")
        mar.append(e)
    tcPr.append(mar)
    v = OxmlElement("w:vAlign")
    v.set(qn("w:val"), "center")
    tcPr.append(v)


def build(badge, out):
    doc = Document()

    s = doc.sections[0]
    s.page_width, s.page_height = Inches(8.5), Inches(11)
    s.left_margin = s.right_margin = Inches(1)
    s.top_margin = Inches(0.7)
    s.bottom_margin = Inches(1)
    s.header_distance = Inches(0.5)
    s.different_first_page_header_footer = True

    n = doc.styles["Normal"]
    n.font.name = "Georgia"
    n.font.size = Pt(12)
    n.element.rPr.rFonts.set(qn("w:eastAsia"), "Georgia")
    n.paragraph_format.space_after = Pt(6)

    # ---------------- letterhead ----------------
    t = doc.add_table(rows=1, cols=2)
    t.alignment = WD_TABLE_ALIGNMENT.LEFT
    t.autofit = False
    for cell, w in zip(t.rows[0].cells, (Inches(3.9), Inches(2.6))):
        cell.width = w
        zero_margins(cell)
    t.columns[0].width = Inches(3.9)
    t.columns[1].width = Inches(2.6)

    left, right = t.rows[0].cells

    p = tight(left.paragraphs[0], 0, 3)
    run(p, "LAW OFFICES OF", 11, True, INK, spacing=64)
    p = tight(left.add_paragraph(), 0, 6)
    run(p, "CHARLES A. RAY, P.C.", 17, True, INK, spacing=10)
    for line in FIRM_ADDRESS:
        p = tight(left.add_paragraph(), 0, 1)
        run(p, line, 10.5, False, GREY)

    p = right.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    tight(p, 0, 0)
    p.add_run().add_picture(str(badge), width=Inches(2.3))

    # ---------------- rule ----------------
    p = tight(doc.add_paragraph(), 9, 0)
    pPr = p._p.get_or_add_pPr()
    bd = OxmlElement("w:pBdr")
    b = OxmlElement("w:bottom")
    for k, v in (("w:val", "single"), ("w:sz", "6"),
                 ("w:space", "1"), ("w:color", "1A1A1A")):
        b.set(qn(k), v)
    bd.append(b)
    pPr.append(bd)

    # ---------------- contact ----------------
    def dot(p):
        run(p, "   \u00b7   ", 9, False, GREY)

    p = tight(doc.add_paragraph(), 8, 2)
    for i, (txt, _) in enumerate(CONTACT_1):
        if i:
            dot(p)
        run(p, txt, 9, False, GREY)

    p = tight(doc.add_paragraph(), 0, 2)
    for i, (txt, _) in enumerate(CONTACT_2):
        if i:
            dot(p)
        run(p, txt, 9, False, GREY)

    p = tight(doc.add_paragraph(), 0, 0)
    run(p, OF_COUNSEL, 8.5, False, GREY)

    doc.add_paragraph()

    # ---------------- running header ----------------
    RPR = ('<w:rPr><w:rFonts w:ascii="Georgia" w:hAnsi="Georgia"/>'
           '<w:sz w:val="19"/><w:color w:val="5F5F5F"/></w:rPr>')
    PPR = f'<w:pPr><w:pStyle w:val="Header"/>{RPR}</w:pPr>'

    def line_xml(txt):
        return (f'<w:p {nsdecls("w")}>{PPR}<w:r>{RPR}'
                f'<w:t xml:space="preserve">{txt}</w:t></w:r></w:p>')

    def fld(instr, cached):
        return (f'<w:r>{RPR}<w:fldChar w:fldCharType="begin"/></w:r>'
                f'<w:r>{RPR}<w:instrText xml:space="preserve"> {instr} </w:instrText></w:r>'
                f'<w:r>{RPR}<w:fldChar w:fldCharType="separate"/></w:r>'
                f'<w:r>{RPR}<w:t>{cached}</w:t></w:r>'
                f'<w:r>{RPR}<w:fldChar w:fldCharType="end"/></w:r>')

    hdr = s.header
    hdr.paragraphs[0].text = ""
    for x in (line_xml("\u00abMatterDescription\u00bb"),
              line_xml("\u00abTaxFormAndYear\u00bb"),
              line_xml("\u00abLetterDate\u00bb"),
              f'<w:p {nsdecls("w")}>{PPR}<w:r>{RPR}'
              f'<w:t xml:space="preserve">Page </w:t></w:r>'
              + fld("PAGE", "2")
              + f'<w:r>{RPR}<w:t xml:space="preserve"> of </w:t></w:r>'
              + fld("NUMPAGES", "3") + "</w:p>"):
        hdr._element.append(parse_xml(x))
    # breathing room between the running header and the first body line
    hdr.paragraphs[-1].paragraph_format.space_after = Pt(16)
    for p0 in hdr.paragraphs:
        if p0.text == "":
            p0._element.getparent().remove(p0._element)
            break

    s.first_page_header.paragraphs[0].text = ""

    doc.core_properties.title = "\u00abMatterDescription\u00bb"
    doc.core_properties.author = "Law Offices of Charles A. Ray, P.C."

    doc.save(str(out))
    print(f"Master written: {out}")


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    build(Path(sys.argv[1]), Path(sys.argv[2]))

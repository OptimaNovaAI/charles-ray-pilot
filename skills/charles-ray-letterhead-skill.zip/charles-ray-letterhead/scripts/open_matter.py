#!/usr/bin/env python3
"""
Matter opening package for the Law Offices of Charles A. Ray, P.C.

    python3 open_matter.py matter.json outdir/

Writes the services agreement on the firm's letterhead, names the power of
attorney that travels with it, and drafts the transmittal.

The agreement is built into the firm master, so the date, address block, Re:
line, salutation, and sign-off come from the letterhead itself. This script
writes only the agreement body.

Three types:
    investigative   investigatory work only, Administrative Fee credited forward
    representation  representation before a named forum, Fixed Fee
    full            the long-form agreement, sections 1 through 11

Nothing is written unless every supplied value can be read back out of the
finished file.
"""

import json
import re
import sys
from pathlib import Path

from docx import Document
from docx.shared import Pt, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH

sys.path.insert(0, str(Path(__file__).resolve().parent))
from fill import fill_document, verify, read_text  # noqa: E402

HERE = Path(__file__).resolve().parent
TEMPLATES = {
    "client": HERE.parent / "templates" / "CRLaw_Letterhead_Client_2026.docx",
    "agency": HERE.parent / "templates" / "CRLaw_Letterhead_Agency_2026.docx",
}
BODY_PLACEHOLDER = "[body of the letter. Delete this line."

LAWPAY = "https://secure.lawpay.com/pages/charlesraylaw/operating"

POA_BY_JURISDICTION = {
    "federal": ("IRS Form 2848", "MASTER_IRS_2848.pdf"),
    "irs": ("IRS Form 2848", "MASTER_IRS_2848.pdf"),
    "dc": ("DC Form D-2848", "MASTER_DC_D-2848.pdf"),
    "md": ("Maryland Form 548", "MASTER_MD_548.pdf"),
    "maryland": ("Maryland Form 548", "MASTER_MD_548.pdf"),
    "va": ("Virginia Form PAR 101", "MASTER_VA_PAR-101.pdf"),
    "virginia": ("Virginia Form PAR 101", "MASTER_VA_PAR-101.pdf"),
}

REQUIRED = [
    "ClientHeader", "ClientName", "ClientStreet", "ClientCityStateZip",
    "ClientEmail", "ClientSalutation", "LetterDate", "MatterCaption",
    "MatterDescription", "TaxFormAndYear",
]
EXTRA = ["FeeAmount", "Jurisdiction", "AgreementType"]
OPTIONAL = ["ClientNameSecond"]

# kind: (space_before, space_after, hanging indent in inches)
SPACING = {
    "p":    (0, 10, 0),
    "h":    (16, 6, 0),
    "num":  (0, 9, 0.35),
    "link": (4, 12, 0.35),
    "b":    (12, 4, 0),
    "sig":  (0, 0, 0),
}


# ------------------------------------------------------------------ bodies

def investigative(f):
    return [
        ("p", "This follows up our recent conversations about your tax matter."),
        ("p", "[State the issue as the client described it, and the problem to "
              "be solved.]"),
        ("h", "1.  Investigatory Services"),
        ("p", "To assist in resolving this matter I will:"),
        ("num", "(1)\tObtain and review the account records for the periods at "
                "issue, including account and wage-and-income transcripts, and "
                "investigate how the account has been administered."),
        ("num", "(2)\t[State the second investigatory step.]"),
        ("num", "(3)\tIdentify the steps required to resolve the matter based "
                "on what that investigation shows."),
        ("num", "(4)\tIf the relief sought proves unavailable, identify the "
                "options for resolving a verified and agreed tax debt, "
                "including an installment agreement, an offer in compromise, "
                "or currently not collectible status."),
        ("p", "[Scope limitation paragraph. State that these services are "
              "investigatory only. Identify the specific relief this engagement "
              "does not include and that is reserved for a separate engagement, "
              "and confirm that the fee paid now is credited toward that later "
              "engagement. Then state the standing exclusions: any other tax "
              "year, any state or local tax matter, litigation in the United "
              "States Tax Court or any other court, any claim against a third "
              "party, the preparation of tax returns, and any criminal matter, "
              "unless agreed otherwise in writing.]"),
        ("h", "2.  Your part"),
        ("p", "You agree to provide complete and accurate information and "
              "documents, to forward promptly any notices you receive, and to "
              "keep me informed of anything that may bear on this matter."),
        ("p", "So that I can speak with the taxing authority about your "
              "account, please complete the Power of Attorney attached. On page "
              "one, enter your name as it appears on your returns, your "
              "address, and your taxpayer identification number. On page two, "
              "sign and date with an original signature, not an electronic one. "
              "Once I have your completed form, I will sign, date, and return a "
              "copy for your records."),
        ("h", "3.  Administrative Fee"),
        ("p", f"The fee for this investigative work is fixed at "
              f"{f['FeeAmount']} (the \u201cAdministrative Fee\u201d). [State "
              f"the circumstances in which additional services would be "
              f"required, and that such work would be a separate engagement "
              f"with its own fee.] If you retain my firm for those additional "
              f"services, I will credit the Administrative Fee you now pay in "
              f"full against that later fee. The Administrative Fee is due upon "
              f"your signing this letter and may be paid at the following link:"),
        ("link", LAWPAY),
        ("p", "Please return the signed Agreement and the completed Power of "
              "Attorney by email at cray@charlesraylaw.com or by fax at "
              "202-217-3462 at your earliest opportunity."),
        ("p", "I look forward to representing you. If you have any questions at "
              "any time, please do not hesitate to contact me."),
    ]


def representation(f):
    return [
        ("p", "This letter states my proposal for this firm to represent you "
              "before [name the forum] in [state the matter, the background "
              "facts, and the notices that led to the need for representation, "
              "identifying the years at issue parenthetically as the "
              "\u201cPeriod at Issue\u201d]."),
        ("p", "In representing you in this matter, we will:"),
        ("num", "(1)\tReview [the specific notice] and related correspondence "
                "to identify the basis for [the enforcement action available to "
                "the agency]."),
        ("num", "(2)\tReview your return for the Period at Issue and the "
                "supporting documentation, if necessary or appropriate."),
        ("num", "(3)\tCoordinate with [name the third parties and their "
                "connection to the matter] for the Period at Issue, if "
                "necessary or appropriate."),
        ("num", "(4)\tPrepare and timely file [the action that is a "
                "precondition to resolving the matter]."),
        ("num", "(5)\tRepresent you before [the unit to which the request for "
                "relief is made], including all conferences and negotiations."),
        ("num", "(6)\tCoordinate with the agency\u2019s processing units to "
                "[the action required to resolve the matter]."),
        ("num", "(7)\tPrepare or review all documents, correspondence, forms, "
                "and other communications related to items (1) through (6) "
                "above."),
        ("p", "This engagement does not include any suit for refund in a United "
              "States district court or the United States Court of Federal "
              "Claims, or any other judicial proceeding. If a judicial filing "
              "becomes advisable, I will tell you promptly. That work would be "
              "the subject of a separate agreement."),
        ("p", f"The fee for the services described in paragraphs (1) through "
              f"(7) is fixed at {f['FeeAmount']} (the \u201cFixed Fee\u201d). "
              f"[State any credit applied and the agreement under which it was "
              f"paid.] The balance is due upon execution of this Agreement. You "
              f"will not incur any additional fees, charges, or expenses in "
              f"connection with the services described above."),
        ("p", "During my representation, you agree to make your best efforts to "
              "obtain and provide the documents and records I request. You "
              "agree that all documents and records you provide will be true, "
              "accurate, and complete."),
        ("p", "I personally will be responsible for managing all phases of this "
              "matter. I will apprise you of its status as events develop, and "
              "no less frequently than once per month. You may contact me "
              "directly as often as you deem appropriate."),
        ("p", "If this letter correctly states our agreement, please sign and "
              "date it in the space provided below and return it to me. I will "
              "execute and return one fully executed Agreement for your "
              "records. For your convenience, the Fixed Fee may be paid at the "
              "following link:"),
        ("link", LAWPAY),
        ("p", "I appreciate the trust and confidence you have placed in me to "
              "handle this matter. I pledge my best efforts to achieve a prompt "
              "and favorable result for you."),
    ]


def full(f):
    return [
        ("p", "This letter proposes an arrangement for this firm to represent "
              "you before [the agency] to [state the resolution sought]."),
        ("h", "1.  Parties"),
        ("p", f"This Agreement is between {f['ClientName']} (the "
              f"\u201cClient\u201d) and the Law Offices of Charles A. Ray, P.C. "
              f"(the \u201cFirm\u201d). It takes effect on the date the Client "
              f"signs it."),
        ("h", "2.  The matter"),
        ("p", "[Statement of background facts, the issue, and the nature of the "
              "relief sought.]"),
        ("h", "3.  Scope of representation"),
        ("p", f"The Firm will represent the Client with respect to "
              f"{f['TaxFormAndYear']}. [Enumerate the services using manually "
              f"typed numbers, (1), (2), (3), so that an inserted or deleted "
              f"clause does not silently renumber and break the "
              f"cross-reference in Section 5.]"),
        ("h", "4.  What this Agreement does not cover"),
        ("p", "The following are outside the scope of this Agreement. The Firm "
              "will undertake any of them only under a separate written "
              "agreement: any tax year other than those named above; any "
              "examination or audit; any collection proceeding, including "
              "collection due process hearings, installment agreements, offers "
              "in compromise, liens, and levies; an appeal of a claim denied in "
              "whole or in part; litigation of any kind, including proceedings "
              "in the United States Tax Court and any suit for refund; "
              "preparation or amendment of any tax return; and any state or "
              "local tax matter."),
        ("p", "[Confirm that no exclusion names a party, employer, or third "
              "party from a different matter before this document is sent.]"),
        ("h", "5.  Fee"),
        ("p", f"The fee for the representation described in Section 3 is fixed "
              f"at {f['FeeAmount']} (the \u201cFixed Fee\u201d). The Fixed Fee "
              f"is not an estimate and will not increase if the matter requires "
              f"more time than expected, so long as the work remains within "
              f"Section 3. The fee is payable in full upon execution of this "
              f"Agreement and may be paid at the following link:"),
        ("link", LAWPAY),
        ("p", "The Fixed Fee is earned as the Firm performs the work described "
              "in Section 3. The Client consents to the Firm\u2019s deposit of "
              "the Fixed Fee into the Firm\u2019s operating account upon "
              "receipt rather than into a trust account. If the representation "
              "ends before the work described in Section 3 is complete, the "
              "Firm will refund the portion of the Fixed Fee that has not then "
              "been earned."),
        ("h", "6.  Costs"),
        ("p", "The fee in Section 5 includes ordinary costs of the "
              "representation, such as transcript access, postage, facsimile, "
              "and copying. Any unusual cost will be discussed with the Client "
              "and approved in advance."),
        ("h", "7.  The Client\u2019s responsibilities"),
        ("p", "The Client agrees to provide the documents and information the "
              "Firm requests, promptly and in full, and to tell the Firm of any "
              "fact that bears on the matter, including facts the Client "
              "believes are unhelpful. The Firm will rely on what the Client "
              "provides."),
        ("p", "The Client agrees to forward to the Firm, without delay, every "
              "notice received from the taxing authority."),
        ("h", "8.  No guarantee of outcome"),
        ("p", "The Firm will pursue this matter diligently and will give the "
              "Client its honest assessment at every stage. The Firm cannot and "
              "does not guarantee any particular result, including the timing "
              "of any correction by the agency or the abatement of any penalty "
              "or interest."),
        ("h", "9.  The file"),
        ("p", "The Client\u2019s papers and property belong to the Client and "
              "will be returned on request. The Firm will retain the file for "
              "the period provided by its record retention practice, after "
              "which it may be destroyed without further notice."),
        ("h", "10.  Governing law"),
        ("p", "This Agreement is governed by the law of the District of "
              "Columbia."),
        ("h", "11.  Acceptance"),
        ("p", "This Agreement states the entire understanding between the "
              "Client and the Firm. It may be changed only in writing signed by "
              "both. If this Agreement is acceptable, please sign below and "
              "return one copy to the Firm with payment of the fee and the "
              "signed Power of Attorney."),
    ]


BUILDERS = {"investigative": investigative,
            "representation": representation,
            "full": full}


# ------------------------------------------------------------------ render

def _style(p, kind):
    before, after, indent = SPACING.get(kind, SPACING["p"])
    pf = p.paragraph_format
    pf.space_before = Pt(before)
    pf.space_after = Pt(after)
    pf.line_spacing = 1.15
    pf.left_indent = Inches(indent) if indent else Pt(0)
    pf.first_line_indent = Inches(-indent) if indent else Pt(0)


def _run(p, text, bold=False):
    r = p.add_run(text)
    r.font.name = "Georgia"
    r.font.size = Pt(12)
    r.bold = bold
    return r


def write_body(path, blocks, client_name):
    """Replace the drafting placeholder with the agreement body."""
    doc = Document(str(path))
    target = None
    for p in doc.paragraphs:
        if BODY_PLACEHOLDER in p.text:
            target = p
            break
    if target is None:
        raise SystemExit(
            "The master no longer contains its body placeholder. Nothing was "
            "written. Check the template before running again."
        )

    from docx.text.paragraph import Paragraph
    anchor = target
    first = True

    for kind, text in blocks:
        if first:
            for r in list(target.runs):
                r._element.getparent().remove(r._element)
            para = target
            first = False
        else:
            el = anchor._p.makeelement(anchor._p.tag, {})
            anchor._p.addnext(el)
            para = Paragraph(el, anchor._parent)
        _style(para, kind)
        _run(para, text, bold=(kind in ("h", "b")))
        anchor = para

    # The acceptance block sits after the sign-off the master already carries.
    # It needs a clear break from "Principal" and real room to sign, so the
    # spacing here is deliberate and not the body spacing.
    from docx.enum.text import WD_TAB_ALIGNMENT

    def _accept_para(text, bold=False, size=12, before=0, after=0, tabs=False):
        para = doc.add_paragraph()
        pf = para.paragraph_format
        pf.space_before = Pt(before)
        pf.space_after = Pt(after)
        pf.line_spacing = 1.0
        pf.left_indent = Pt(0)
        pf.first_line_indent = Pt(0)
        if tabs:
            # one stop for the date column, so the rules never wrap
            pf.tab_stops.add_tab_stop(Inches(4.3), WD_TAB_ALIGNMENT.LEFT)
        r = para.add_run(text)
        r.font.name = "Georgia"
        r.font.size = Pt(size)
        r.bold = bold
        return para

    _accept_para("AGREED TO AND ACCEPTED:", bold=True, before=40, after=10)
    _accept_para(client_name.upper(), bold=True, before=12, after=44)
    # 34 rules end at 3.97in, the stop is 4.3in, 18 more end at 6.23in.
    # The right margin is 6.5in, so neither rule can wrap.
    _accept_para("By:  " + "_" * 34 + "\t" + "_" * 18, before=0, after=2,
                 tabs=True)
    _accept_para("       " + client_name + "\tDate", size=10, before=0,
                 after=0, tabs=True)

    doc.save(str(path))


def build(fields, outdir):
    missing = [k for k in REQUIRED + EXTRA if not str(fields.get(k, "")).strip()]
    if missing:
        raise SystemExit(
            "Refusing to build. Missing: " + ", ".join(missing)
            + "\nAsk for these rather than filling them with something plausible."
        )

    kind = str(fields["AgreementType"]).lower()
    if kind not in BUILDERS:
        raise SystemExit(f"Unknown agreement type: {kind}. "
                         f"Use one of: {', '.join(BUILDERS)}")

    variant = str(fields.get("Variant", "client")).lower()
    if variant not in TEMPLATES:
        raise SystemExit(f"Unknown variant '{variant}'. Use client or agency.")

    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    stem = re.sub(r"[^A-Za-z0-9]+", "_", fields["ClientName"]).strip("_")
    agreement = outdir / f"Agreement_{stem}.docx"

    fill_document(TEMPLATES[variant], agreement, fields,
                  drop_if_empty=("ClientNameSecond",))
    write_body(agreement, BUILDERS[kind](fields), fields["ClientName"])

    ok, problems = verify(agreement, fields, REQUIRED, OPTIONAL)

    text = read_text(agreement)
    if fields["FeeAmount"] not in text:
        problems.append("FeeAmount is not in the written document")
        ok = False
    if LAWPAY not in text:
        problems.append("the payment link is not in the written document")
        ok = False

    if not ok:
        agreement.unlink(missing_ok=True)
        raise SystemExit(
            "Build failed and nothing was written:\n  - " + "\n  - ".join(problems)
        )

    j = str(fields["Jurisdiction"]).strip().lower()
    poa = POA_BY_JURISDICTION.get(j)
    poa_line = (f"{poa[0]}  ({poa[1]})" if poa
                else f"No POA master matches jurisdiction "
                     f"'{fields['Jurisdiction']}'. Confirm the forum before sending.")

    transmittal = outdir / "transmittal.txt"
    transmittal.write_text(f"""To: {fields['ClientEmail']}
Subject: {fields['MatterCaption']}

Dear {fields['ClientSalutation']},

Attached are two documents.

The services agreement for {fields['TaxFormAndYear']}. Please review it, sign
where indicated, and return it to me.

The power of attorney. On page one, enter your name as it appears on your
returns, your address, and your taxpayer identification number. On page two,
sign and date with an original signature, not an electronic one. I will sign
and return a copy for your records.

The fee may be paid at {LAWPAY}.

Return both by email or by fax at 202-217-3462. Once I have them I can speak
with the agency about your account directly.

Charles A. Ray, Jr.
""", encoding="utf-8")

    brackets = len(re.findall(r"\[[^\]]{5,}\]", text))

    print(f"Agreement:   {agreement}")
    print(f"Variant:     {variant}")
    print(f"POA:         {poa_line}")
    print(f"Transmittal: {transmittal}")
    print(f"Verified in the file: client, address, caption, fee, payment link.")
    if brackets:
        print(f"\n{brackets} bracketed passage(s) await your drafting. "
              f"Read every exclusion against this client before sending.")


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    build(json.loads(Path(sys.argv[1]).read_text()), sys.argv[2])


if __name__ == "__main__":
    main()

---
name: crlaw-blind-spot-flags
description: Read the compliance check and the resolution path together and flag the conditions where the attorney's judgment changes the answer, with every flag citing its line. Use whenever the question is what could be missed on a matter — "run the blind-spot flags", "what am I missing on this one", "pressure test this matter", "has the statute run on the older years", "where's the statute and why hasn't it run", "was the notice mailed to the last known address", "check the assessment window", "is there trust fund exposure", "any innocent spouse issues", "update the clock register", "what's in the register for this matter", or after the compliance check and the resolution path have both run. Also keeps the clock register. It computes and never recommends.
---

# Blind-spot flags

Item 7. It sits on top of the compliance check (item 5) and the resolution
path (item 6), reads what they read, and fires where the record reaches a
condition on which Charles's judgment changes the answer.

Every flag carries three things:

1. **What the record shows**, each statement with the transcript line, the
   resolution input, the facts file entry, or the register row behind it.
2. **What turns on it**, stated as a condition. Never a course of action.
3. **What is not on the page**, the fact that would settle it.

It computes. It never recommends. The page is refused, and nothing is
written, if it contains *should*, *recommend*, or *advisable*.

---

## Run it

```
python3 scripts/flag.py --periods 2016.json 2019.json \
                        --matter matter.json --facts facts.json \
                        --register register.csv \
                        --out flags.html --propose proposed.csv

python3 scripts/register.py merge register.csv proposed.csv
```

`--periods` are files the compliance check reader wrote, one per transcript.
Only `--periods` and `--out` are required. Each input left out narrows what
can be checked, and every check that could not run is listed on the page as
**not checked** with what it needed. Nothing is skipped in silence.

| Input | Where it comes from | Shape |
|---|---|---|
| `--periods` | `read_transcript.py` in the compliance check | its contract |
| `--matter` | the resolution path input | its `reference/input.md` |
| `--facts` | the file, the client, the notices | `reference/facts.md` |
| `--register` | the clock register | `reference/register.md` |

---

## What it flags

The full catalog, with what fires each flag, is in `reference/flags.md`.
Charles named the first two on September 8. The rest are the conditions
proposed on September 9, where the arithmetic from items 5 and 6 meets
something only judgment settles.

- **Statute.** A balance remains on an assessment whose statute has run.
  A statute runs inside twenty-four months.
- **Assessment.** An additional assessment posts after the three-year
  window, or inside the ninety days after a notice of deficiency.
- **Notice.** A notice of deficiency went somewhere other than the last
  known address, or its address has not been checked.
- **Timing.** The arithmetic permits an offer while the statute is close.
  Less is collectible before the statute runs than is owed. The offer's
  future income period outlasts the statute.
- **Equity.** The arithmetic that closes an offer rests on one asset.
- **Compliance.** Unfiled years close an offer the arithmetic opens. A
  return reads as a substitute.
- **Trust fund.** An employment tax period carries a balance.
- **Joint return.** A joint year carries a balance.

---

## The clock register

One file, kept where Charles keeps it. The proposal is Excel in his
OneDrive; `.xlsx` and `.csv` both work. It is the record, so a date in it is
never re-derived.

**Derived and controlling are enforced by the file, not by instruction.**
`register.py` refuses a row with no kind, a controlling row that does not
name who gave it and when, and a derived row with no basis. A derived date
never replaces a controlling one. Two controlling dates that disagree are
both reported and the register is left as it was.

`flag.py --propose` writes the dates it derived as rows for the register. It
never writes into the register itself. `register.py merge` folds them in
under the rules above and says what it added, replaced, kept, and refused.

To record a date the Service gave:

```
python3 scripts/register.py add register.csv --matter M-0142 --year 2016 \
  --clock CSED --date 2027-04-15 --kind controlling \
  --given-by "Revenue Officer, by phone" --given-on 2026-09-20 \
  --assessment-ref 2017-05-22 --basis "Confirmed in the follow-up letter"
```

The register holds client names. It stays on Charles's machine. It is never
attached to anything shared and never named in a file title.

---

## Each assessment has its own clock

The collection statute runs ten years from each assessment, not from the
year. A 150 in 2017 and a 300 in 2020 on the same year are two clocks. The
clocks table on the page shows every one: derived, printed, register, and
the one in use, controlling first.

Suspension codes on the transcript (an offer, a bankruptcy, a deferment) are
named and never computed with. Where they appear, a derived date is the
earliest the statute could run, and the flag says so.

---

## The open question

The lines beneath TC 166 and TC 170 can carry a date exactly ten years from
the assessment. Charles has been asked whether that is the Service's stated
collection statute date. Until he answers, the date is shown as **printed,
meaning unconfirmed**, and never used.

One setting at the top of `flag.py` changes when he does:

```
PRINTED_TEN_YEAR_DATE_IS_CSED = None   # unconfirmed
PRINTED_TEN_YEAR_DATE_IS_CSED = True   # controlling, sourced to the line
```

Set to `True`, the date becomes controlling, sourced to the transcript line
and the Response Date the transcript prints. A transcript with no Response
Date cannot source it, so its date stays unused.

---

## What it will not do

- State a state deadline. The federal rules here are not carried over to
  DC, Maryland, or Virginia. That belongs to the state tax skill.
- Compute a suspension. It names the event and leaves the arithmetic to the
  attorney with the register in front of him.
- Look up a figure. Values, quick sale percentages, and allowable expenses
  come from the resolution inputs, as in item 6.
- Decide. Every flag ends at what turns on it.

#!/usr/bin/env python3
"""
The clock register for the Law Offices of Charles A. Ray, P.C.

    python3 register.py check  register.csv
    python3 register.py merge  register.csv proposed.csv
    python3 register.py add    register.csv --matter M-0142 --year 2016 \
        --clock CSED --date 2027-04-15 --kind controlling \
        --given-by "Revenue Officer, by phone" --given-on 2026-09-20 \
        --basis "Stated on the call, confirmed in the follow-up letter"

One file, kept where Charles keeps it (the proposal is Excel in his OneDrive).
The register is the record. Nothing here re-derives a date that is already in
it, and nothing here lets a date in without saying what kind of date it is.

The derived and controlling rule is enforced by the validator, not by
instruction:

    A row with no kind is refused.
    A controlling row with no one who gave it, or no date it was given, is
    refused.
    A derived row with no basis is refused.

And by the merge:

    A derived date never replaces a controlling one.
    A controlling date replaces a derived one for the same clock.
    Two controlling dates that disagree are both reported and neither is
    written over. That disagreement is a finding for the attorney.

Reads and writes .csv, and .xlsx where openpyxl is present. Excel re-saves
dates in its own format, so dates are accepted as 2027-04-15, 4/15/2027, or
04-15-2027, and always written back as 2027-04-15.
"""

import argparse
import csv
import sys
from datetime import date, datetime
from pathlib import Path

COLUMNS = ["matter", "client", "year", "clock", "date", "kind", "basis",
           "given_by", "given_on", "assessment_ref", "recorded_on", "note"]

CLOCKS = {
    "CSED": "Collection statute expiration",
    "ASED": "Assessment statute expiration",
    "RSED": "Refund statute expiration",
    "TOLL_START": "A suspension of a statute begins",
    "TOLL_END": "A suspension of a statute ends",
    "CDP_WINDOW": "Last day to request a collection due process hearing",
    "PETITION_WINDOW": "Last day to petition the Tax Court",
}
KINDS = ("derived", "controlling")


class Refused(Exception):
    pass


# ---------------------------------------------------------------- dates

def parse_date(s):
    """Accept the three shapes Excel and the transcript produce. None if blank."""
    if s is None:
        return None
    if isinstance(s, datetime):
        return s.date()
    if isinstance(s, date):
        return s
    s = str(s).strip()
    if not s:
        return None
    for f in ("%Y-%m-%d", "%m/%d/%Y", "%m-%d-%Y", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(s, f).date()
        except ValueError:
            pass
    raise ValueError(f"'{s}' is not a date this register reads")


# ---------------------------------------------------------------- io

def load(path):
    p = Path(path)
    if not p.exists():
        return []
    if p.suffix.lower() == ".xlsx":
        from openpyxl import load_workbook
        ws = load_workbook(p, read_only=True, data_only=True).active
        rows = list(ws.iter_rows(values_only=True))
        if not rows:
            return []
        head = [str(h or "").strip() for h in rows[0]]
        return [{h: ("" if v is None else v) for h, v in zip(head, r)}
                for r in rows[1:] if any(v not in (None, "") for v in r)]
    with p.open(newline="", encoding="utf-8-sig") as fh:
        return [dict(r) for r in csv.DictReader(fh)]


def save(path, rows):
    p = Path(path)
    if p.suffix.lower() == ".xlsx":
        from openpyxl import Workbook
        from openpyxl.styles import Font
        wb = Workbook()
        ws = wb.active
        ws.title = "Clock register"
        ws.append(COLUMNS)
        for c in ws[1]:
            c.font = Font(bold=True)
        for r in rows:
            ws.append([r.get(c, "") for c in COLUMNS])
        ws.freeze_panes = "A2"
        wb.save(p)
        return
    with p.open("w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=COLUMNS, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow({c: r.get(c, "") for c in COLUMNS})


# ---------------------------------------------------------------- the rule

def normalise(row, where):
    """
    Validate one row and return it in canonical form. Raises Refused with every
    problem on the row, not only the first, so a bad row is fixed in one pass.
    """
    r = {c: ("" if row.get(c) is None else str(row.get(c)).strip())
         for c in COLUMNS}
    # dates may arrive as date objects from Excel; keep them parseable
    for c in ("date", "given_on", "recorded_on"):
        if isinstance(row.get(c), (date, datetime)):
            r[c] = parse_date(row.get(c)).isoformat()

    problems = []
    if not r["matter"]:
        problems.append("no matter")
    try:
        r["year"] = str(int(float(r["year"])))
    except ValueError:
        problems.append(f"year '{r['year']}' is not a year")

    r["clock"] = r["clock"].upper()
    if r["clock"] not in CLOCKS:
        problems.append(f"clock '{r['clock']}' is not one of "
                        f"{', '.join(CLOCKS)}")

    try:
        dd = parse_date(r["date"])
        if dd is None:
            problems.append("no date")
        else:
            r["date"] = dd.isoformat()
    except ValueError as e:
        problems.append(str(e))

    r["kind"] = r["kind"].lower()
    if r["kind"] not in KINDS:
        problems.append("no kind. Every date is derived or controlling, and "
                        "the register does not take one that is neither")
    elif r["kind"] == "controlling":
        if not r["given_by"]:
            problems.append("controlling with no one named who gave it")
        try:
            g = parse_date(r["given_on"])
            if g is None:
                problems.append("controlling with no date it was given")
            else:
                r["given_on"] = g.isoformat()
        except ValueError as e:
            problems.append(str(e))
    elif r["kind"] == "derived":
        if not r["basis"]:
            problems.append("derived with no basis. A computed date carries "
                            "the line or the arithmetic it came from")

    if r["assessment_ref"]:
        try:
            r["assessment_ref"] = parse_date(r["assessment_ref"]).isoformat()
        except ValueError as e:
            problems.append(f"assessment_ref: {e}")

    if not r["recorded_on"]:
        r["recorded_on"] = date.today().isoformat()

    if problems:
        raise Refused(f"{where}: " + "; ".join(problems))
    return r


def validate(rows, label="row"):
    good, errors = [], []
    for i, row in enumerate(rows, start=2):   # row 1 is the header
        try:
            good.append(normalise(row, f"{label} {i}"))
        except Refused as e:
            errors.append(str(e))
    return good, errors


def key(r):
    return (r["matter"], r["year"], r["clock"], r["assessment_ref"])


def merge(existing, proposed):
    """
    Fold proposed rows into the register. Returns (rows, report).

    Only one clock per key is live. The rules, in order:
      derived over controlling      kept, the proposal is not written
      controlling over derived      replaced
      derived over derived          replaced when the date differs
      controlling over controlling  same date: kept; different date: conflict,
                                    both reported, register unchanged
    """
    by_key = {key(r): r for r in existing}
    report = {"added": [], "replaced": [], "kept": [], "conflicts": []}

    for p in proposed:
        k = key(p)
        cur = by_key.get(k)
        if cur is None:
            by_key[k] = p
            report["added"].append(p)
            continue
        if cur["kind"] == "controlling" and p["kind"] == "derived":
            report["kept"].append((cur, p, "a derived date does not replace "
                                   "a controlling one"))
        elif cur["kind"] == "derived" and p["kind"] == "controlling":
            by_key[k] = p
            report["replaced"].append((cur, p))
        elif cur["kind"] == "derived":
            if cur["date"] != p["date"]:
                by_key[k] = p
                report["replaced"].append((cur, p))
            else:
                report["kept"].append((cur, p, "same date"))
        else:
            if cur["date"] == p["date"]:
                report["kept"].append((cur, p, "same date"))
            else:
                report["conflicts"].append((cur, p))

    rows = sorted(by_key.values(),
                  key=lambda r: (r["matter"], r["year"], r["clock"],
                                 r["assessment_ref"]))
    return rows, report


# ---------------------------------------------------------------- lookups

def lookup(rows, matter, year, clock, assessment_ref=None):
    """
    The live row for a clock, controlling first. assessment_ref narrows to one
    assessment; a row with a blank assessment_ref speaks for the year.
    """
    hits = [r for r in rows
            if r["matter"] == str(matter) and r["year"] == str(year)
            and r["clock"] == clock]
    if assessment_ref:
        exact = [r for r in hits if r["assessment_ref"] == assessment_ref]
        if exact:
            hits = exact
        else:
            hits = [r for r in hits if not r["assessment_ref"]]
    hits.sort(key=lambda r: (r["kind"] != "controlling", r["date"]))
    return hits[0] if hits else None


# ---------------------------------------------------------------- cli

def cmd_check(a):
    rows = load(a.register)
    good, errors = validate(rows)
    print(f"{a.register}: {len(good)} row(s) valid, {len(errors)} refused")
    for e in errors:
        print("  REFUSED " + e)
    return 1 if errors else 0


def write_merge(a, proposed_rows, label):
    existing = load(a.register)
    ex_good, ex_err = validate(existing, "register row")
    pr_good, pr_err = validate(proposed_rows, label)
    if ex_err or pr_err:
        print("Nothing written. Fix these first:")
        for e in ex_err + pr_err:
            print("  REFUSED " + e)
        return 1
    rows, rep = merge(ex_good, pr_good)
    save(a.out or a.register, rows)
    print(f"Written: {a.out or a.register}   {len(rows)} row(s)")
    print(f"  added {len(rep['added'])}, replaced {len(rep['replaced'])}, "
          f"kept {len(rep['kept'])}, conflicts {len(rep['conflicts'])}")
    for old, new in rep["replaced"]:
        print(f"  replaced {old['year']} {old['clock']} {old['date']} "
              f"({old['kind']}) with {new['date']} ({new['kind']})")
    for old, new, why in rep["kept"]:
        if why != "same date":
            print(f"  kept {old['year']} {old['clock']} {old['date']} "
                  f"({old['kind']}): {why}")
    for old, new in rep["conflicts"]:
        print(f"  CONFLICT {old['year']} {old['clock']}: controlling "
              f"{old['date']} (given by {old['given_by']}, {old['given_on']}) "
              f"against controlling {new['date']} (given by {new['given_by']}, "
              f"{new['given_on']}). Register left as it was.")
    return 2 if rep["conflicts"] else 0


def cmd_merge(a):
    return write_merge(a, load(a.proposed), "proposed row")


def cmd_add(a):
    row = {"matter": a.matter, "client": a.client or "", "year": a.year,
           "clock": a.clock, "date": a.date, "kind": a.kind,
           "basis": a.basis or "", "given_by": a.given_by or "",
           "given_on": a.given_on or "", "assessment_ref": a.assessment_ref or "",
           "note": a.note or ""}
    return write_merge(a, [row], "new row")


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)

    c = sub.add_parser("check")
    c.add_argument("register")
    c.set_defaults(fn=cmd_check)

    m = sub.add_parser("merge")
    m.add_argument("register")
    m.add_argument("proposed")
    m.add_argument("--out")
    m.set_defaults(fn=cmd_merge)

    d = sub.add_parser("add")
    d.add_argument("register")
    for f in ("matter", "year", "clock", "date", "kind"):
        d.add_argument(f"--{f}", required=True)
    for f in ("client", "basis", "given-by", "given-on", "assessment-ref",
              "note", "out"):
        d.add_argument(f"--{f}")
    d.set_defaults(fn=cmd_add)

    a = ap.parse_args()
    sys.exit(a.fn(a))


if __name__ == "__main__":
    main()

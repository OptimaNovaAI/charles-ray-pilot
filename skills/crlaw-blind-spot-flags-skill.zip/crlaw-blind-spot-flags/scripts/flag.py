#!/usr/bin/env python3
"""
Blind-spot flags for the Law Offices of Charles A. Ray, P.C.

    python3 flag.py --periods 2016.json 2019.json [...]
                    [--matter matter.json] [--facts facts.json]
                    [--register register.csv] [--as-of 2026-09-27]
                    --out flags.html [--propose proposed.csv]

Sits on top of the compliance check (item 5) and the resolution path (item 6).
Reads what they read, and fires where the record reaches a condition on which
the attorney's judgment changes the answer. Every flag says what the record
shows, with the line or input behind it, what turns on it, and what is not on
the page.

It computes. It never recommends. A flag names a condition. What to do about
it is the attorney's.

Inputs
    --periods   one or more files written by the item 5 reader
    --matter    the item 6 input (assets, income, expenses, years)
    --facts     what no transcript carries: notices and where they went,
                returns and their addresses, where the client lived, joint
                years, business matters. Shape in reference/facts.md
    --register  the clock register. Controlling dates in it outrank anything
                derived here
    --propose   writes the dates this run derived, as register rows, for
                register.py merge. Nothing is written into the register itself

Three rules carried from items 5 and 6, and they are the firm's.
    Nothing is dropped silently. A check that could not run is listed as not
    checked, with what it needed.
    Every claim cites its line or its input.
    Derived is not controlling. Every date carries its kind.
"""

import argparse
import csv
import html as H
import json
import re
import sys
from datetime import date, datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from codes import look_up, STATUTE_FLAGS, ASSESSING, REDUCING  # noqa: E402
import register as REG  # noqa: E402

# Charles's answer, October 9, 2026. A date printed beneath a transaction line,
# apart from that line's own date, is the IRS-printed collection statute date
# for the assessment that line belongs to. It is the Service's computed figure:
# not ours, so not derived, and not controlling, because the Service qualifies
# it and invites it to be verified. Display order: controlling, then
# IRS-printed, then derived. Only a controlling date is the CSED without
# qualification. Any difference of one day or more is a mismatch; no tolerance
# is built in until the firm confirms the Service's day-count convention.
IRS_PRINTED = "IRS-printed"
KIND_LABEL = {"derived": "derived", "irs_printed": IRS_PRINTED,
              "controlling": "controlling"}

# Tolling indicators for the reconciliation flags (C1, C2): an offer, a
# bankruptcy or litigation hold, a hearing request, an installment request.
TOLL_CODES = {"480", "520"}
TOLL_971 = re.compile(r"collection due process|\bCDP\b|due process hearing|"
                      r"installment", re.I)
# The assessments the firm counts for C4: each TC 150, 290, and 300 carries its
# own collection statute.
TAX_ASSESSMENTS = {"150", "290", "300"}

# Codes that are assessments for the collection statute. Each assessment
# carries its own ten years from its own date.
ASSESSMENT_CODES = {"150", "160", "166", "170", "176", "196", "234", "238",
                    "270", "276", "290", "300", "310", "320", "350"}
ADDITIONAL_ASSESSMENT = {"290", "300", "310", "320", "350"}
TRUST_FUND_FORMS = {"941", "943", "944", "945", "CT-1"}

# Notices that are collection activity under the section 6015 regulation: a
# section 6330 levy notice. An offset of the requesting spouse's refund also
# counts, and posts as a credit from another period.
LEVY_NOTICE = re.compile(r"\b(LT\s*0*11|LT\s*0*1058|L\s*1058|CP\s*0*90|CP\s*0*297)\b",
                         re.I)
SNOD_TEXT = re.compile(r"3219|notice of deficiency|statutory notice", re.I)
OFFSET_IN = {"706", "716"}

WORDS_NEVER_PRINTED = (" should ", "recommend", "advisable", "we suggest")

MONEY = "${:,.2f}"


# ---------------------------------------------------------------- helpers

def d(s):
    if s in (None, ""):
        return None
    if isinstance(s, date):
        return s
    return REG.parse_date(s)


def add_years(dt, n):
    try:
        return dt.replace(year=dt.year + n)
    except ValueError:              # February 29 into a common year
        return dt.replace(year=dt.year + n, day=28)


def months_between(a, b):
    if a is None or b is None:
        return None
    return (b.year - a.year) * 12 + (b.month - a.month) - (1 if b.day < a.day else 0)


def fmt(v):
    if isinstance(v, (int, float)):
        if abs(v) < 0.005:
            v = 0.0
        return MONEY.format(v)
    return str(v)


def e(s):
    return H.escape(str(s), quote=False)


ABBR = {"street": "st", "avenue": "ave", "road": "rd", "drive": "dr",
        "court": "ct", "lane": "ln", "boulevard": "blvd", "place": "pl",
        "terrace": "ter", "circle": "cir", "parkway": "pkwy", "highway": "hwy",
        "apartment": "apt", "suite": "ste", "unit": "apt", "north": "n",
        "south": "s", "east": "e", "west": "w", "northwest": "nw",
        "northeast": "ne", "southwest": "sw", "southeast": "se"}


def addr_key(a):
    """Compare addresses as a person would: case, punctuation, and the usual
    abbreviations do not make two addresses different."""
    s = re.sub(r"[#]", " apt ", str(a or "").lower())
    s = re.sub(r"[^\w\s]", " ", s)
    return " ".join(ABBR.get(w, w) for w in s.split())


# ---------------------------------------------------------------- one period

def read_period(p, source):
    txns = []
    for t in p.get("transactions", []):
        code = str(t.get("code", "")).strip()
        amt = t.get("amount")
        amt = float(amt) if amt not in (None, "") else None
        desc, eff, known = look_up(code)
        txns.append({"code": code, "date": d(t.get("date")), "amount": amt,
                     "line": t.get("line", ""), "desc": desc, "eff": eff,
                     "known": known, "cont": t.get("continuations", [])})

    assessed = reduced = refunded = 0.0
    for t in txns:
        if not t["known"] or t["amount"] is None:
            continue
        if t["eff"] in ASSESSING:
            assessed += abs(t["amount"])
        elif t["eff"] in REDUCING:
            reduced += abs(t["amount"])
        elif t["eff"] == "refund":
            refunded += abs(t["amount"])
    balance = assessed - reduced + refunded

    groups = {}
    for t in txns:
        if (t["code"] in ASSESSMENT_CODES and t["date"]
                and t["amount"] not in (None, 0.0) and t["amount"] > 0):
            g = groups.setdefault(t["date"], {"date": t["date"], "amount": 0.0,
                                              "txns": []})
            g["amount"] += t["amount"]
            g["txns"].append(t)

    printed, other_dates = [], []
    for t in txns:
        for c in t["cont"]:
            if c.get("kind") != "date" or not t["date"]:
                continue
            try:
                cd = d(c.get("value"))
            except ValueError:
                cd = None
            if cd:
                printed.append({"txn": t, "date": cd})
            else:
                other_dates.append({"txn": t, "value": c.get("value")})

    def notices(t):
        return " ".join(str(c.get("value", "")) for c in t["cont"]
                        if c.get("kind") == "notice")

    tolling = [t for t in txns if t["code"] in TOLL_CODES
               or (t["code"] == "971"
                   and TOLL_971.search(notices(t) + " " + t["line"]))]

    filing = next((t for t in txns if t["code"] == "150"), None)
    sfr = bool(filing and (filing["amount"] in (0.0, None))
               and re.search(r"sfr|substitute", filing["line"], re.I))

    return {
        "year": p.get("year"), "form": str(p.get("form", "")),
        "period_ending": d(p.get("period_ending")),
        "filing_status": p.get("filing_status", ""),
        "return_date_basis": d(p.get("return_date_basis")),
        "stated": p.get("stated_balance"),
        "txns": txns, "balance": balance,
        "groups": sorted(groups.values(), key=lambda g: g["date"]),
        "printed": printed, "other_dates": other_dates, "tolling": tolling,
        "suspensions": [t for t in txns if t["code"] in STATUTE_FLAGS],
        "snods": [t for t in txns if t["code"] == "494"
                  or (t["code"] == "971" and SNOD_TEXT.search(notices(t)))],
        "additional": [t for t in txns if t["code"] in ADDITIONAL_ASSESSMENT
                       and t["amount"] and t["amount"] > 0 and t["date"]],
        "levy_notices": [t for t in txns if t["code"] == "971"
                         and LEVY_NOTICE.search(notices(t))],
        "offsets": [t for t in txns if t["code"] in OFFSET_IN],
        "has_560": [t for t in txns if t["code"] == "560"],
        "has_608": [t for t in txns if t["code"] == "608"],
        "filing": filing, "sfr": sfr,
        "pulled": source.get("pulled", ""),
        "label": source.get("_label", ""),
    }


# ---------------------------------------------------------------- the clocks

def csed_for(group, P, reg_rows, matter_id):
    """
    The collection statute for one assessment, with its kind and its source.
    In use reads controlling first, then IRS-printed, then derived. The three
    are kept side by side and never substituted for one another.
    """
    derived = add_years(group["date"], 10)
    codes = ", ".join(t["code"] for t in group["txns"])
    out = {"derived": derived,
           "derived_basis": f"assessment dated {group['date']} (TC {codes}), "
                            f"plus ten years",
           "printed": None, "register": None}

    for pr in P["printed"]:
        if pr["txn"]["date"] == group["date"]:
            out["printed"] = pr
            break

    found = REG.lookup_all(reg_rows, matter_id, P["year"], "CSED",
                           group["date"].isoformat()) if reg_rows else {}
    ctrl, regp, regd = (found.get("controlling"), found.get("irs_printed"),
                        found.get("derived"))
    out["register"] = ctrl or regp or regd

    newer_on_page = (out["printed"] and (not regp or (P["pulled"] and
                     P["pulled"] >= regp["given_on"])))
    if ctrl:
        out.update(date=d(ctrl["date"]), kind="controlling",
                   source=f"given by {ctrl['given_by']} on {ctrl['given_on']}")
    elif newer_on_page:
        t = out["printed"]["txn"]
        out.update(date=out["printed"]["date"], kind=IRS_PRINTED,
                   source=f"printed beneath TC {t['code']} on the account "
                          f"transcript generated "
                          f"{P['pulled'] or 'on a date it does not print'}")
    elif regp:
        out.update(date=d(regp["date"]), kind=IRS_PRINTED,
                   source=f"register: {regp['given_by']}, transcript generated "
                          f"{regp['given_on']}")
    elif regd:
        out.update(date=d(regd["date"]), kind="derived",
                   source=f"register: {regd['basis']}")
    else:
        out.update(date=derived, kind="derived", source=out["derived_basis"])
    return out


# ---------------------------------------------------------------- flags

RANK = {"Statute": 1, "CSED": 2, "Assessment": 3, "Notice": 4, "Timing": 5,
        "Equity": 6, "Compliance": 7, "Trust fund": 8, "Joint return": 9,
        "Verification": 10}


class Run:
    def __init__(self, as_of):
        self.as_of = as_of
        self.flags = []
        self.clear = []
        self.unchecked = []
        self.proposed = []
        self.clock_rows = []

    def flag(self, cls, title, shows, turns, missing=None, year=None):
        self.flags.append({"cls": cls, "title": title, "shows": shows,
                           "turns": turns, "missing": missing, "year": year})

    def ok(self, check, text):
        self.clear.append((check, text))

    def skip(self, check, text):
        self.unchecked.append((check, text))


def cite(t):
    return f"TC {t['code']} dated {t['date'] or 'undated'}: <span class='src'>{e(t['line'])}</span>"


def statute_checks(R, periods, reg_rows, matter_id):
    """Charles, Sept 8: where is the statute on the older years, and why has
    it not run?"""
    for P in periods:
        yr = P["year"]
        if not P["groups"]:
            R.skip(f"{yr} collection statute",
                   "No dated assessment on the transcript to run ten years from.")
            continue

        floor_note = ""
        if P["suspensions"]:
            floor_note = (" The transcript carries suspension events ("
                          + "; ".join(f"TC {t['code']} {t['date']}" for t in P["suspensions"])
                          + "). They move a derived date later by an amount this "
                          "engine does not compute, so a derived date here is the "
                          "earliest the statute could run, not when it runs.")

        expired, near = [], []
        for g in P["groups"]:
            c = csed_for(g, P, reg_rows, matter_id)
            ml = months_between(R.as_of, c["date"])
            R.clock_rows.append({"year": yr, "form": P["form"], "group": g,
                                 "c": c, "months": ml})
            R.proposed.append({
                "matter": matter_id, "year": yr, "clock": "CSED",
                "date": c["derived"].isoformat(), "kind": "derived",
                "basis": c["derived_basis"], "assessment_ref": g["date"].isoformat(),
                "note": "suspension events on the transcript, not computed"
                        if P["suspensions"] else ""})
            if c["printed"]:
                t = c["printed"]["txn"]
                if P["pulled"]:
                    R.proposed.append({
                        "matter": matter_id, "year": yr, "clock": "CSED",
                        "date": c["printed"]["date"].isoformat(),
                        "kind": "irs_printed", "basis": t["line"],
                        "given_by": f"IRS account transcript, printed beneath "
                                    f"TC {t['code']}",
                        "given_on": P["pulled"],
                        "assessment_ref": g["date"].isoformat()})
                else:
                    R.skip(f"{yr} IRS-printed date to the register",
                           f"The date printed beneath TC {t['code']} is shown "
                           f"and not proposed to the register: the transcript "
                           f"prints no Response Date, so the date it was "
                           f"generated is not on the page.")
            if P["balance"] > 0.009:
                if c["date"] < R.as_of:
                    expired.append((g, c))
                elif ml is not None and ml <= 24:
                    near.append((g, c, ml))

        if P["balance"] <= 0.009:
            R.ok(f"{yr} collection statute",
                 f"No balance computed from the lines, so no running statute "
                 f"bears on collection for {yr}.")
            continue

        if expired:
            shows = [f"The lines compute a balance of {fmt(P['balance'])}."]
            for g, c in expired:
                shows.append(
                    f"Assessment of {fmt(g['amount'])} dated {g['date']} "
                    f"({', '.join(cite(t) for t in g['txns'])}). Statute "
                    f"{c['date']}, <b>{c['kind']}</b>: {e(c['source'])}."
                    + (f" Derived {c['derived']}." if c['kind'] != 'derived'
                       and c['derived'] != c['date'] else ""))
            if P["has_608"]:
                shows.append("TC 608 posts on this transcript: "
                             + "; ".join(cite(t) for t in P["has_608"]) + ".")
            kinds = {c["kind"] for _, c in expired}
            lead = ("On derived arithmetic the statute on " if kinds == {"derived"}
                    else "On the IRS-printed date, which the Service qualifies "
                         "and which is not controlling, the statute on "
                    if "controlling" not in kinds
                    else "The statute on ")
            R.flag("Statute", f"{yr}: the statute appears to have run and a balance remains",
                   shows,
                   lead + f"{len(expired)} assessment(s) for {yr} ran before "
                   f"{R.as_of}, and the account still carries a balance. What "
                   f"sits on an expired assessment is not collectible, and how "
                   f"much of the balance sits there is not on the page."
                   + (floor_note if "derived" in kinds else ""),
                   "Which assessments the payments were applied to, and any "
                   "suspension the transcript does not show, such as a hearing "
                   "request, a pending installment request, or time outside the "
                   "United States.", yr)

        if near:
            shows = [f"The lines compute a balance of {fmt(P['balance'])}."]
            for g, c, ml in near:
                shows.append(
                    f"Assessment dated {g['date']} ({', '.join(cite(t) for t in g['txns'])}). "
                    f"Statute {c['date']}, <b>{c['kind']}</b>, {ml} months from "
                    f"{R.as_of}.")
            R.flag("Statute", f"{yr}: the statute runs inside twenty-four months",
                   shows,
                   "A hearing request, an offer, and an installment request each "
                   "suspend the statute while pending, and each suspension extends "
                   "the time the Service has to collect this year. Clearing the "
                   "matter and letting the clock run is the other side of that "
                   "trade." + (floor_note if any(c["kind"] == "derived"
                                                 for _, c, _ in near) else ""),
                   None if all(c["kind"] == "controlling" for _, c, _ in near) else
                   "A statute date stated by the Service on a call, in an "
                   "account review, or in writing. The dates above are not "
                   "controlling.", yr)

        if not expired and not near:
            soon = min((c for c in [csed_for(g, P, reg_rows, matter_id)
                                    for g in P["groups"]]), key=lambda c: c["date"])
            R.ok(f"{yr} collection statute",
                 f"Earliest statute {soon['date']} ({soon['kind']}), more than "
                 f"twenty-four months out.")

    csed_reconciliation(R, periods)


def csed_reconciliation(R, periods):
    """
    Charles's reconciliation flags, October 9, 2026. Compare the IRS-printed
    date with the derived date for the same assessment. Derived here is the
    assessment date plus ten years; suspensions are named and not computed.
    Any difference of one day or more is a mismatch.
    """
    for P in periods:
        yr = P["year"]
        groups = P["groups"]
        for x in P["other_dates"]:
            R.flag("Verification",
                   f"{yr}: a date beneath TC {x['txn']['code']} does not read as a date",
                   [f"{cite(x['txn'])} carries '{e(x['value'])}' beneath it."],
                   "A printed CSED is read off the page exactly. This one could "
                   "not be read, so it is shown and not used.",
                   "The transcript page itself.", yr)
        if not P["printed"]:
            R.ok(f"{yr} CSED reconciliation",
                 "C5, no IRS-printed CSED on this transcript. The statute is "
                 "derived only, which is not by itself an anomaly.")
            continue

        matched = {}
        for pr in P["printed"]:
            g = next((g for g in groups if g["date"] == pr["txn"]["date"]), None)
            if g is None:
                R.flag("CSED",
                       f"{yr}: an IRS-printed date sits beneath a line that is "
                       f"not a dated assessment",
                       [f"{cite(pr['txn'])} carries {pr['date']} beneath it."],
                       "A printed date belongs to one assessment. This one sits "
                       "beneath a line whose date matches no dated assessment on "
                       "the transcript, so it is assigned to none.",
                       "Which assessment the Service computed it from.", yr)
                continue
            matched.setdefault(g["date"], []).append(pr)

        toll = P["tolling"]
        toll_cites = "; ".join(cite(t) for t in toll)
        gen = P["pulled"] or "on a date it does not print"

        for g in groups:
            floor = add_years(g["date"], 10)
            base = [f"Assessment dated {g['date']} "
                    f"({', '.join(cite(t) for t in g['txns'])}).",
                    f"Derived {floor}: the assessment date plus ten years."]
            for pr in matched.get(g["date"], []):
                gap = (pr["date"] - floor).days
                shows = base + [f"IRS-printed {pr['date']}, beneath "
                                f"{cite(pr['txn'])}, on the transcript "
                                f"generated {gen}."]
                if gap == 0 and toll:
                    R.flag("CSED", f"{yr}: C1, tolling not reflected",
                           shows + [f"Tolling on the transcript: {toll_cites}."],
                           "The printed date is exactly ten years from the "
                           "assessment while the transcript shows a tolling "
                           "indicator. Either the Service's computation does not "
                           "carry the suspension, or the suspension has not "
                           "posted. Which one decides when the statute runs.",
                           "The Service's computation of this CSED, and the "
                           "dates the suspension began and ended.", yr)
                elif gap == 0:
                    R.ok(f"{yr} CSED reconciliation, assessment {g['date']}",
                         f"IRS-printed {pr['date']} matches the derived date and "
                         f"no tolling indicator appears. Consistent, not "
                         f"controlling.")
                elif gap > 0 and not toll:
                    R.flag("CSED",
                           f"{yr}: C2, the IRS clock runs longer than the lines support",
                           shows + ["No tolling indicator appears on the transcript."],
                           f"The printed date runs {gap} day(s) past the "
                           f"assessment date plus ten years, and nothing on the "
                           f"transcript accounts for the added time. If no "
                           f"suspension supports it, the statute runs earlier "
                           f"than the Service shows, which favors the taxpayer.",
                           "The Service's computation of this CSED, available "
                           "through the Practitioner Priority Service, and any "
                           "suspension the transcript does not show.", yr)
                elif gap > 0:
                    R.skip(f"{yr} CSED reconciliation, assessment {g['date']}",
                           f"The IRS-printed date runs {gap} day(s) past the "
                           f"assessment date plus ten years, and the transcript "
                           f"shows tolling. Whether the added time matches the "
                           f"suspension needs the suspension arithmetic, which "
                           f"this engine names and does not compute.")
                else:
                    R.flag("CSED",
                           f"{yr}: C3, the IRS-printed date falls before the derived date",
                           shows,
                           f"The printed date falls {-gap} day(s) before the "
                           f"assessment date plus ten years. Either the derived "
                           f"arithmetic is wrong or the Service is understating "
                           f"its own clock. The derived arithmetic is the first "
                           f"to recheck, and its lines are above.",
                           "The Service's computation of this CSED.", yr)

        tax = [g for g in groups if any(t["code"] in TAX_ASSESSMENTS
                                         for t in g["txns"])]
        if len(tax) > 1:
            for g in tax:
                if matched.get(g["date"]):
                    continue
                R.flag("CSED", f"{yr}: C4, an assessment without an IRS-printed CSED",
                       [f"Assessment dated {g['date']} "
                        f"({', '.join(cite(t) for t in g['txns'])}).",
                        f"The transcript prints {len(P['printed'])} date(s) "
                        f"across {len(tax)} assessments, and none beneath a line "
                        f"dated {g['date']}."],
                       "A printed date belongs to one assessment. This assessment "
                       "has none on the page, so its statute is derived only, and "
                       "a date printed for another assessment does not stand in "
                       "for it.",
                       "The Service's computation of the CSED for this "
                       "assessment.", yr)


def assessment_checks(R, periods, facts, matter_id):
    """Was the later assessment made inside the window, and not too soon after
    a notice of deficiency."""
    fact_snods = [n for n in facts.get("notices", [])
                  if SNOD_TEXT.search(str(n.get("kind", "")))]
    for P in periods:
        yr = P["year"]
        snod_dates = sorted({t["date"] for t in P["snods"] if t["date"]}
                            | {d(n["date"]) for n in fact_snods
                               if str(n.get("year")) == str(yr) and n.get("date")})

        for sd in snod_dates:
            R.proposed.append({"matter": matter_id, "year": yr,
                               "clock": "PETITION_WINDOW",
                               "date": (sd + timedelta(days=90)).isoformat(),
                               "kind": "derived",
                               "basis": f"notice of deficiency dated {sd}, plus "
                                        f"ninety days",
                               "note": "one hundred fifty days if addressed "
                                       "outside the United States"})

        # A2: assessment inside the ninety days
        for sd in snod_dates:
            early = [t for t in P["additional"] if sd <= t["date"] < sd + timedelta(days=90)]
            if early:
                R.flag("Assessment",
                       f"{yr}: assessed inside the ninety days after the notice of deficiency",
                       [f"Notice of deficiency dated {sd}. The ninety days run to "
                        f"{sd + timedelta(days=90)} (derived)."]
                       + [cite(t) + f", {(t['date'] - sd).days} days after the notice."
                          for t in early],
                       "The Service may not assess a deficiency until the ninety "
                       "days have run, or a Tax Court decision is final if a "
                       "petition was filed, unless the taxpayer waived the "
                       "restriction. An assessment inside that period without a "
                       "waiver is premature.",
                       "Whether a waiver was signed (Form 870 or 4549), and the "
                       "date on the notice itself.", yr)
            elif P["additional"]:
                R.ok(f"{yr} assessment after notice",
                     f"Additional assessment(s) post ninety days or more after "
                     f"the {sd} notice.")

        # A1: assessment after the three-year window
        if not P["additional"]:
            continue
        if P["sfr"] or not P["filing"]:
            R.ok(f"{yr} assessment window",
                 "No return posting, or a substitute for return. The three-year "
                 "window does not begin without a return, so it is not tested.")
            continue
        base = P["return_date_basis"]
        if not base:
            R.skip(f"{yr} assessment window",
                   "The transcript header line 'Return due date or return "
                   "received date (whichever is later)' was not supplied. The "
                   "window is not guessed from the assessment date.")
            continue
        ased = add_years(base, 3)
        R.proposed.append({"matter": matter_id, "year": yr, "clock": "ASED",
                           "date": ased.isoformat(), "kind": "derived",
                           "basis": f"return due or received {base} as printed "
                                    f"on the transcript, plus three years"})
        late = [t for t in P["additional"] if t["date"] > ased]
        if not late:
            R.ok(f"{yr} assessment window",
                 f"Additional assessment(s) post inside the three years to {ased} "
                 f"(derived from the {base} date printed on the transcript).")
            continue
        before = [sd for sd in snod_dates if sd < ased]
        if before:
            suspended = ased + timedelta(days=150)
            still_late = [t for t in late if t["date"] > suspended]
            if not still_late:
                R.ok(f"{yr} assessment window",
                     f"Assessment posts after {ased} but inside {suspended}, the "
                     f"window as suspended by the {before[0]} notice of deficiency "
                     f"for the ninety days and sixty after (derived, no petition "
                     f"assumed).")
                continue
            late = still_late
        shows = [f"Return due or received {base}, as printed on the transcript. "
                 f"Three years runs to {ased} (derived)."]
        if before:
            shows.append(f"A notice of deficiency dated {before[0]} suspends that "
                         f"for the ninety days and sixty after, to {ased + timedelta(days=150)} "
                         f"(derived, no petition assumed).")
        shows += [cite(t) for t in late]
        if P["has_560"]:
            shows.append("TC 560 posts: " + "; ".join(cite(t) for t in P["has_560"]) + ".")
        R.flag("Assessment", f"{yr}: an assessment posts after the assessment window",
               shows,
               "Past the window, an assessment stands only on an agreed extension, "
               "the six-year period for an omission over twenty-five percent of "
               "gross income, a fraud or no-return exception, or a petition that "
               "held the period open. "
               + ("None of those appears on the transcript." if not P["has_560"]
                  else "The TC 560 above may be an agreed extension."),
               "Any Form 872, the date the return was actually received, and "
               "whether a petition was filed.", yr)


def address_checks(R, periods, facts):
    """Charles, Sept 8: was the statutory notice mailed to the last known
    address?"""
    notices = facts.get("notices", [])
    snods = [n for n in notices if SNOD_TEXT.search(str(n.get("kind", "")))]
    returns = facts.get("returns", [])
    homes = facts.get("addresses", [])

    covered = set()
    for n in snods:
        yr, nd, to = n.get("year"), d(n.get("date")), n.get("mailed_to")
        covered.add(str(yr))
        if not nd or not to:
            R.skip(f"{yr} last known address",
                   "A notice of deficiency is listed without its date or the "
                   "address it was mailed to.")
            continue

        shows = [f"Notice of deficiency for {yr}, dated {nd}, mailed to "
                 f"<b>{e(to)}</b>. <span class='src'>{e(n.get('source', 'source not stated'))}</span>"]
        mismatch_return = mismatch_home = mismatch_prior = False

        filed = sorted([r for r in returns if d(r.get("filed")) and d(r["filed"]) < nd],
                       key=lambda r: d(r["filed"]))
        processed = [r for r in filed if d(r["filed"]) + timedelta(days=45) <= nd]
        recent = [r for r in filed if d(r["filed"]) + timedelta(days=45) > nd]
        last = processed[-1] if processed else None
        if last:
            shows.append(f"Most recent return filed at least forty-five days "
                         f"before the notice: the {last.get('year')} return, filed "
                         f"{last['filed']}, showing <b>{e(last.get('address', 'no address given'))}</b>. "
                         f"<span class='src'>{e(last.get('source', 'source not stated'))}</span>")
            mismatch_return = addr_key(last.get("address")) != addr_key(to)
        for r in recent:
            shows.append(f"The {r.get('year')} return was filed {r['filed']}, "
                         f"inside the forty-five days before the notice, showing "
                         f"{e(r.get('address', 'no address given'))}. The regulation "
                         f"treats a return as properly processed after forty-five "
                         f"days, so this one may not count.")

        home = next((h for h in homes
                     if d(h.get("from")) and d(h["from"]) <= nd
                     and (not h.get("to") or nd <= d(h["to"]))), None)
        if home:
            shows.append(f"Where the client lived on {nd}: <b>{e(home['address'])}</b>, "
                         f"{home['from']} to {home.get('to') or 'present'}. "
                         f"<span class='src'>{e(home.get('evidence', 'evidence not stated'))}</span>")
            mismatch_home = addr_key(home["address"]) != addr_key(to)

        prior = sorted([p for p in notices if p is not n and d(p.get("date"))
                        and d(p["date"]) < nd and p.get("mailed_to")],
                       key=lambda p: d(p["date"]))
        for p in prior:
            shows.append(f"Earlier notice: {e(p.get('kind'))} dated {p['date']}, "
                         f"mailed to {e(p['mailed_to'])}. "
                         f"<span class='src'>{e(p.get('source', 'source not stated'))}</span>")
            if addr_key(p["mailed_to"]) != addr_key(to):
                mismatch_prior = True

        if not last and not home:
            R.skip(f"{yr} last known address",
                   "The notice's address is known, but neither a return filed "
                   "before it nor where the client lived at the time was supplied, "
                   "so there is nothing to compare it with.")
            continue

        if not (mismatch_return or mismatch_home or mismatch_prior):
            R.ok(f"{yr} last known address",
                 f"The {nd} notice went to the address on the last processed "
                 f"return and where the client lived.")
            continue

        if mismatch_return:
            turns = ("The notice went to an address other than the one on the "
                     "last processed return. A notice of deficiency not mailed to "
                     "the last known address does not support the assessment that "
                     "followed, unless the taxpayer received it in time to "
                     "petition.")
        else:
            turns = ("The notice matches the return on file and not where the "
                     "client lived. Whether the Service had clear and concise "
                     "notice of the move, from a later return, a Form 8822, or "
                     "correspondence, decides which address was last known.")
        if mismatch_prior:
            turns += (" The Service used a different address for an earlier "
                      "notice on this account, which bears on what it knew.")
        R.flag("Notice", f"{yr}: the notice of deficiency and the last known address",
               shows, turns,
               "Whether and when the client received the notice, and the certified "
               "mail list for it.", yr)

    for P in periods:
        if P["snods"] and str(P["year"]) not in covered:
            R.flag("Notice", f"{P['year']}: a notice of deficiency with no address check",
                   [cite(t) for t in P["snods"]],
                   "Where the notice went is not on the transcript, and whether it "
                   "went to the last known address decides whether the assessment "
                   "that followed stands.",
                   "The notice or its certified mail list, the returns filed before "
                   "it with their addresses, and where the client lived on that "
                   "date. The facts file takes all three.", P["year"])


def resolution(m, periods, reg_rows, matter_id, R):
    """
    Item 6's arithmetic, mirrored. Equity floors at zero per asset; future
    income counts twelve months on the lump sum basis and twenty-four on the
    periodic. Nothing is looked up and a missing value refuses the asset.
    """
    if not m:
        return None
    years = []
    by_year = {str(P["year"]): P for P in periods}
    for y in m.get("years", []):
        csed, kind, src = d(y.get("csed")), y.get("csed_kind", "unstated"), y.get("csed_source", "")
        P = by_year.get(str(y.get("year")))
        if not csed and P and P["groups"]:
            c = csed_for(P["groups"][0], P, reg_rows, matter_id)
            csed, kind, src = c["date"], c["kind"], c["source"]
        years.append({"year": y.get("year"), "balance": float(y.get("balance") or 0),
                      "csed": csed, "kind": kind, "source": src,
                      "months": months_between(R.as_of, csed) if csed else None})
    liab = sum(y["balance"] for y in years)

    assets, bad = [], []
    for a in m.get("assets", []):
        if a.get("fair_market_value") in (None, "") or a.get("quick_sale_pct") in (None, ""):
            bad.append(a.get("name", "unnamed"))
            continue
        fmv, pct = float(a["fair_market_value"]), float(a["quick_sale_pct"])
        enc, ex = float(a.get("encumbrance") or 0), float(a.get("exempt") or 0)
        assets.append({"name": a.get("name", "unnamed"), "fmv": fmv, "pct": pct,
                       "enc": enc, "exempt": ex,
                       "nre": max(0.0, fmv * pct / 100 - enc - ex),
                       "source": a.get("source", "not stated")})
    if bad:
        R.skip("Equity and timing", f"Asset(s) without a value or quick sale "
               f"percentage: {', '.join(bad)}. Item 6 refuses these and so does "
               f"this.")
        return None
    nre = sum(a["nre"] for a in assets)
    inc = sum(float(v or 0) for v in m.get("monthly_income", {}).values())
    exp = sum(float(v or 0) for v in m.get("monthly_allowable_expenses", {}).values())
    disp = inc - exp
    rcp = {12: nre + max(0.0, disp) * 12, 24: nre + max(0.0, disp) * 24}
    dated = [y for y in years if y["months"] is not None]
    return {"years": years, "liab": liab, "assets": assets, "nre": nre,
            "disp": disp, "rcp": rcp,
            "soonest": min(dated, key=lambda y: y["months"]) if dated else None,
            "binding": max(dated, key=lambda y: y["months"]) if dated else None,
            "unfiled": [str(u) for u in m.get("filing_compliance", {}).get("unfiled_years", [])]}


BASIS = {12: "lump sum basis (twelve months of future income)",
         24: "periodic basis (twenty-four months)"}


def equity_and_timing(R, res):
    if not res:
        R.skip("Equity and timing", "No resolution inputs (the item 6 matter file) "
               "were supplied. Offer, installment, and equity conditions need them.")
        return
    liab, rcp, nre, disp = res["liab"], res["rcp"], res["nre"], res["disp"]
    if liab <= 0:
        R.ok("Equity and timing", "The resolution inputs carry no liability.")
        return

    # E1: the foreclosure rests on one asset
    closed = [n for n in (12, 24) if rcp[n] >= liab]
    if closed and res["assets"]:
        big = max(res["assets"], key=lambda a: a["nre"])
        n = closed[-1]
        without = rcp[n] - big["nre"]
        if big["nre"] > 0 and without < liab:
            others = without
            need = liab - others
            breakeven = (need + big["enc"] + big["exempt"]) / big["fmv"] * 100 if big["fmv"] else None
            shows = [f"On the {BASIS[n]}, collection potential is {fmt(rcp[n])} "
                     f"against a liability of {fmt(liab)}.",
                     f"{e(big['name'])}: value {fmt(big['fmv'])} at {big['pct']:.0f} "
                     f"percent quick sale, less {fmt(big['enc'])} owed and "
                     f"{fmt(big['exempt'])} exempt, is {fmt(big['nre'])} of equity. "
                     f"<span class='src'>{e(big['source'])}</span>",
                     f"Without it, collection potential is {fmt(without)}."]
            if breakeven is not None and 0 < breakeven < big["pct"]:
                shows.append(f"At a quick sale figure below {breakeven:.2f} percent "
                             f"on this asset, collection potential falls below the "
                             f"liability (computed).")
            R.flag("Equity", "The arithmetic that closes an offer rests on one asset",
                   shows,
                   "Whether an offer is open or closed turns on the value of one "
                   "asset and the quick sale figure applied to it, both of which "
                   "an examiner sets with discretion.",
                   "The basis for the value: an appraisal, a comparable sale, or "
                   "the client's estimate.")
        else:
            R.ok("Equity concentration", "Collection potential exceeds the "
                 "liability without its largest asset.")
    elif not closed:
        R.ok("Equity concentration", "Offer arithmetic is open on both bases; no "
             "single asset closes it.")

    soon, bind = res["soonest"], res["binding"]
    open_bases = [n for n in (12, 24) if rcp[n] < liab]

    # T1: offer open, statute close
    if open_bases and soon and soon["months"] is not None and 0 <= soon["months"] <= 24:
        n = open_bases[0]
        R.flag("Timing", "The arithmetic permits an offer and the statute is close",
               [f"On the {BASIS[n]}, collection potential is {fmt(rcp[n])} against "
                f"a liability of {fmt(liab)}, a difference of {fmt(liab - rcp[n])}.",
                f"The {soon['year']} statute runs {soon['csed']} "
                f"(<b>{soon['kind']}</b>), {soon['months']} months out."],
               "An offer suspends the statute while it is pending, for thirty days "
               "after a rejection, and through an appeal of the rejection. The "
               "arithmetic points toward an offer and the clock points toward the "
               "year running on its own.", None, soon["year"])

    # T2: what the Service can collect before the last statute runs
    if bind and bind["months"] is not None and bind["months"] > 0:
        window = nre + max(0.0, disp) * bind["months"]
        if window < liab:
            R.flag("Timing", "Less is collectible before the statute runs than is owed",
                   [f"Equity {fmt(nre)}, plus disposable income of "
                    f"{fmt(max(0.0, disp))} a month for the {bind['months']} months "
                    f"to the {bind['year']} statute on {bind['csed']} "
                    f"(<b>{bind['kind']}</b>), is {fmt(window)} (computed).",
                    f"The liability is {fmt(liab)}. The difference, "
                    f"{fmt(liab - window)}, is not reachable on these figures before "
                    f"the last statute runs."],
                   "On the supplied figures the limit on collection is the clock. "
                   "Anything that suspends the statute moves that limit.",
                   "Whether income or expenses are expected to change inside the "
                   "window.", bind["year"])
        else:
            R.ok("Collectible inside the window",
                 f"Equity and disposable income reach {fmt(window)} before the "
                 f"{bind['year']} statute, covering the liability of {fmt(liab)}.")

    # T3: the future income period is longer than the statute left
    if bind and bind["months"] is not None and 0 < bind["months"] < 24:
        m = bind["months"]
        capped = {n: nre + max(0.0, disp) * min(n, m) for n in (12, 24)}
        R.flag("Timing", "The offer's future income period outlasts the statute",
               [f"The latest statute, {bind['year']}, runs {bind['csed']} "
                f"(<b>{bind['kind']}</b>), {m} months out.",
                f"Periodic basis at twenty-four months: {fmt(rcp[24])}. At {m} "
                f"months: {fmt(capped[24])} (computed)."]
               + ([f"Lump sum basis at twelve months: {fmt(rcp[12])}. At {m} "
                   f"months: {fmt(capped[12])} (computed)."] if m < 12 else []),
               "The Service's offer practice counts future income only for the "
               "months left on the statute where that is shorter. Item 6 counts "
               "the full period, so its figure is the higher of the two.",
               "Confirmation of the current Internal Revenue Manual provision "
               "before the lower figure is relied on.", bind["year"])

    # C1: compliance closes what the arithmetic opens
    unfiled = sorted(set(res["unfiled"]) | set(R._unfiled_from_transcripts))
    if unfiled and open_bases:
        n = open_bases[0]
        R.flag("Compliance", "The arithmetic opens an offer that filing compliance closes",
               [f"On the {BASIS[n]}, collection potential is {fmt(rcp[n])} against "
                f"{fmt(liab)}.",
                f"No return on record for {', '.join(unfiled)}."],
               "An offer is not processed while required returns are unfiled. "
               "The order of work is set by that before it is set by the "
               "arithmetic.",
               "Whether the returns were filed and have not posted, or were never "
               "filed.")
    elif unfiled:
        R.ok("Compliance against the offer", f"Unfiled {', '.join(unfiled)}, and "
             f"offer arithmetic is closed on both bases, so the two do not "
             f"conflict.")


def compliance_checks(R, periods):
    R._unfiled_from_transcripts = []
    for P in periods:
        if P["form"] == "1040" and not P["filing"]:
            R._unfiled_from_transcripts.append(str(P["year"]))
        if P["sfr"]:
            R.flag("Compliance", f"{P['year']}: the return on record reads as a substitute",
                   [cite(P["filing"])] + [cite(t) for t in P["additional"]],
                   "An assessment built on a substitute for return rests on the "
                   "Service's figures, which usually carry no deductions, "
                   "dependents, or basis. An original return from the taxpayer can "
                   "displace them.",
                   "The client's own records for the year.", P["year"])


def trust_fund_checks(R, periods, facts, matter_id):
    tf = [P for P in periods if P["form"].upper() in TRUST_FUND_FORMS]
    for P in tf:
        if P["balance"] <= 0.009:
            R.ok(f"{P['form']} {P['period_ending'] or P['year']} trust fund",
                 "No balance on this employment tax period.")
            continue
        pe = P["period_ending"]
        shows = [f"Form {P['form']}, period ending {pe or P['year']}: the lines "
                 f"compute a balance of {fmt(P['balance'])}."]
        if pe:
            deemed = date(pe.year + 1, 4, 15)
            base = max(deemed, P["return_date_basis"]) if P["return_date_basis"] else deemed
            ased = add_years(base, 3)
            ml = months_between(R.as_of, ased)
            shows.append(f"The penalty's own assessment window runs three years "
                         f"from {base}, to {ased}, {ml} months from {R.as_of} "
                         f"(derived: a quarterly return is treated as filed April 15 "
                         f"of the following year, or later if filed late).")
            R.proposed.append({"matter": matter_id, "year": pe.year, "clock": "ASED",
                               "date": ased.isoformat(), "kind": "derived",
                               "basis": f"Form {P['form']} period ending {pe}, "
                                        f"deemed filed {base}, plus three years",
                               "note": "trust fund recovery penalty"})
        R.flag("Trust fund", f"{P['form']} {pe or P['year']}: trust fund exposure",
               shows,
               "Withheld taxes a business did not pay over can be assessed "
               "personally against anyone responsible for paying them who "
               "willfully did not, under section 6672. That exposure runs outside "
               "the business's own collection path.",
               "Who signed checks and decided which creditors were paid, and "
               "whether a Letter 1153 has issued.", P["year"])
    if facts.get("business") and not tf:
        R.skip("Trust fund", "A business matter is noted in the facts and no "
               "employment tax transcript was supplied.")


def joint_checks(R, periods, facts):
    joint_years = {str(y) for y in facts.get("joint_years", [])}
    for P in periods:
        is_joint = "joint" in str(P["filing_status"]).lower() or str(P["year"]) in joint_years
        if not is_joint:
            continue
        if P["balance"] <= 0.009:
            R.ok(f"{P['year']} joint return", "Joint year with no balance.")
            continue
        src = (f"filing status printed as '{e(P['filing_status'])}'"
               if P["filing_status"] else "joint year per the facts file")
        shows = [f"{P['year']}: {src}. The lines compute a balance of {fmt(P['balance'])}."]
        if P["additional"]:
            shows.append("Additional assessment, so an understatement: "
                         + "; ".join(cite(t) for t in P["additional"]) + ".")
        else:
            shows.append("No additional assessment posts, so the balance reads as "
                         "an underpayment of tax reported on the return.")
        acts = P["levy_notices"] + P["offsets"]
        if acts:
            first = min(acts, key=lambda t: t["date"] or date.max)
            shows.append("Collection activity on the transcript: "
                         + "; ".join(cite(t) for t in acts)
                         + f". The earliest is {first['date']}; two years from it "
                           f"is {add_years(first['date'], 2) if first['date'] else 'not computable'} (derived).")
        else:
            shows.append("No section 6330 levy notice or offset appears on this "
                         "transcript.")
        if facts.get("separated_or_divorced"):
            shows.append(f"Divorced, separated, or living apart per the facts file"
                         f"{': ' + e(facts['separated_or_divorced']) if isinstance(facts['separated_or_divorced'], str) else ''}.")
        R.flag("Joint return", f"{P['year']}: a joint year carrying a balance",
               shows,
               "Relief from joint liability turns on facts the transcript does "
               "not carry. For an understatement, relief under section 6015(b) or "
               "(c) must be elected within two years of the first collection "
               "activity against the requesting spouse, and the regulation counts "
               "a section 6330 notice and an offset of that spouse's refund. "
               "Equitable relief under 6015(f) is available while the collection "
               "statute runs.",
               "Whose income produced the balance, what the requesting spouse "
               "knew, and whether any collection activity was directed at that "
               "spouse alone.", P["year"])


# ---------------------------------------------------------------- render

CSS = """
body{margin:0;background:#f4f5f7;font-family:-apple-system,BlinkMacSystemFont,
"Segoe UI",Arial,sans-serif;color:#1b2a4a}
.w{max-width:900px;margin:0 auto;padding:28px 20px 70px}
.card{background:#fff;border:1px solid #e3e8ef;border-radius:12px;
padding:22px 26px;margin-bottom:16px}
.k{font-size:11px;font-weight:600;letter-spacing:1.6px;text-transform:uppercase;
color:#ca25b7;padding-bottom:10px}
h1{margin:0 0 6px;font-size:27px;font-weight:600;color:#0b1f3a;letter-spacing:-.5px}
.sub{color:#6a7488;font-size:14px;margin:0 0 18px;line-height:1.55}
.tally{display:flex;gap:10px;flex-wrap:wrap;margin:0 0 22px}
.t{background:#fff;border:1px solid #e3e8ef;border-radius:10px;padding:10px 16px;
min-width:120px}
.t b{display:block;font-size:24px;color:#000c65}
.t span{font-size:11px;letter-spacing:1.2px;text-transform:uppercase;color:#8a93a6;
font-weight:600}
.flag{border-left:4px solid #d5dae3}
.flag h2{font-size:17px;margin:4px 0 12px;color:#0b1f3a;font-weight:600}
.tag{font-size:10px;letter-spacing:1.3px;text-transform:uppercase;font-weight:600}
.lbl{font-size:10.5px;letter-spacing:1.2px;text-transform:uppercase;color:#8a93a6;
font-weight:600;margin:12px 0 4px}
ul{margin:0;padding-left:18px}
li{font-size:14px;line-height:1.6;margin-bottom:5px}
.turn{font-size:14.5px;line-height:1.6;margin:0}
.miss{font-size:13.5px;line-height:1.55;color:#6a7488;margin:0}
.src{color:#8a93a6;font-size:11.5px;font-family:ui-monospace,Menlo,monospace}
.c-Statute{border-left-color:#ca25b7}.c-Statute .tag{color:#ca25b7}
.c-Assessment{border-left-color:#b4483a}.c-Assessment .tag{color:#b4483a}
.c-Notice{border-left-color:#b4483a}.c-Notice .tag{color:#b4483a}
.c-Timing{border-left-color:#2e75b6}.c-Timing .tag{color:#2e75b6}
.c-Equity{border-left-color:#2e75b6}.c-Equity .tag{color:#2e75b6}
.c-Compliance{border-left-color:#0b7a55}.c-Compliance .tag{color:#0b7a55}
.c-Trust{border-left-color:#9a7220}.c-Trust .tag{color:#9a7220}
.c-Joint{border-left-color:#9a7220}.c-Joint .tag{color:#9a7220}
.c-Verification{border-left-color:#d9a441}.c-Verification .tag{color:#d9a441}
table{width:100%;border-collapse:collapse;font-size:13px}
th{text-align:left;font-size:10.5px;letter-spacing:1.2px;text-transform:uppercase;
color:#8a93a6;font-weight:600;padding:0 8px 8px 0;border-bottom:1px solid #e3e8ef}
td{padding:8px 8px 8px 0;border-bottom:1px solid #f0f2f6;vertical-align:top}
td.n,th.n{text-align:right}
.kd{font-weight:600}.kd.derived{color:#9a7220}.kd.controlling{color:#0b7a55}
.kd.IRS-printed{color:#2e75b6}
.c-CSED{border-left-color:#2e75b6}.c-CSED .tag{color:#2e75b6}
.row{font-size:13.5px;line-height:1.55;padding:6px 0;border-bottom:1px solid #f0f2f6}
.row b{color:#000c65}
.foot{color:#8a93a6;font-size:12.5px;line-height:1.65}
@media(max-width:600px){.card{padding:18px 16px}.tbl{overflow-x:auto}}
"""


def render(R, label, out_path):
    flags = sorted(R.flags, key=lambda f: (RANK[f["cls"]], str(f["year"] or "")))
    cards = []
    for f in flags:
        cls = f["cls"].split()[0]
        shows = "".join(f"<li>{s}</li>" for s in f["shows"])
        miss = (f"<div class='lbl'>Not on the page</div><p class='miss'>{e(f['missing'])}</p>"
                if f["missing"] else "")
        cards.append(f"""<div class="card flag c-{cls}">
<span class="tag">{e(f['cls'])}</span><h2>{e(f['title'])}</h2>
<div class="lbl">What the record shows</div><ul>{shows}</ul>
<div class="lbl">What turns on it</div><p class="turn">{e(f['turns'])}</p>
{miss}</div>""")

    clocks = "".join(
        f"<tr><td>{r['year']}{'' if r['form'] in ('1040', '') else ' (' + e(r['form']) + ')'}</td>"
        f"<td>{r['group']['date']}</td>"
        f"<td>{', '.join(t['code'] for t in r['group']['txns'])}</td>"
        f"<td class='n'>{fmt(r['group']['amount'])}</td>"
        f"<td>{r['c']['derived']}</td>"
        f"<td>{r['c']['printed']['date'] if r['c']['printed'] else '&mdash;'}</td>"
        f"<td>{r['c']['register']['date'] + ' (' + KIND_LABEL[r['c']['register']['kind']] + ')' if r['c']['register'] else '&mdash;'}</td>"
        f"<td><b>{r['c']['date']}</b> <span class='kd {r['c']['kind']}'>{r['c']['kind']}</span></td>"
        f"<td class='n'>{r['months'] if r['months'] is not None else '&mdash;'}</td></tr>"
        for r in R.clock_rows)

    clear = "".join(f"<div class='row'><b>{e(k)}.</b> {t}</div>" for k, t in R.clear) \
        or "<div class='foot'>None.</div>"
    skipped = "".join(f"<div class='row'><b>{e(k)}.</b> {e(t)}</div>" for k, t in R.unchecked) \
        or "<div class='foot'>Every check had what it needed.</div>"

    html = f"""<!DOCTYPE html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>Blind-spot flags</title><style>{CSS}</style></head><body><div class="w">

<div class="k">Blind-spot flags &middot; items 5 and 6, read together</div>
<h1>{e(label)}</h1>
<p class="sub">As of {R.as_of}. A flag marks a condition on which the attorney's
judgment changes the answer. It says what the record shows and what turns on it.
It does not say what to do.</p>

<div class="tally">
<div class="t"><b>{len(R.flags)}</b><span>Flags</span></div>
<div class="t"><b>{len(R.clear)}</b><span>Checked, clear</span></div>
<div class="t"><b>{len(R.unchecked)}</b><span>Not checked</span></div>
</div>

{''.join(cards) or "<div class='card'><p class='foot'>No flags fired.</p></div>"}

<div class="card"><div class="k">The clocks</div>
<div class="tbl"><table><tr><th>Year</th><th>Assessed</th><th>TC</th><th class="n">Amount</th>
<th>Derived</th><th>IRS-printed</th><th>Register</th><th>In use</th><th class="n">Months</th></tr>
{clocks or "<tr><td colspan=9 class=src>No dated assessments.</td></tr>"}</table></div>
<p class="foot" style="margin-top:12px">Each assessment carries its own ten years
from its own date. Derived is computed here: the assessment date plus ten years.
IRS-printed is the date the transcript prints beneath a line, the Service's
computed figure, never controlling. Register is the clock register, where a
controlling date names who gave it and when. In use reads controlling first,
then IRS-printed, then derived. Only a controlling date is the CSED without
qualification.</p></div>

<div class="card"><div class="k">Checked and clear</div>{clear}</div>
<div class="card"><div class="k">Not checked, and what it needed</div>{skipped}</div>

<div class="card"><p class="foot">
Every statement above traces to a transcript line, a resolution input, the facts
file, or the clock register, and says which. A date marked derived was computed
here. A date marked IRS-printed is the Service's figure as a transcript prints it,
with the date the transcript was generated. A date marked controlling was stated
by the Service and names who stated it and when.
<br><br>
A check that could not run is listed as not checked with what it needed. None
are dropped to make the page read cleanly.
<br><br>
This is a reading of the record. The decision on the matter is the attorney's.
</p></div>

</div></body></html>"""

    low = re.sub(r"<[^>]+>", " ", html).lower()
    for w in WORDS_NEVER_PRINTED:
        if w in low:
            raise SystemExit(f"Refusing to write: the page contains '{w.strip()}'. "
                             f"Flags state conditions. They do not advise.")
    Path(out_path).write_text(html, encoding="utf-8")


# ---------------------------------------------------------------- main

def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--periods", nargs="+", required=True)
    ap.add_argument("--matter")
    ap.add_argument("--facts")
    ap.add_argument("--register")
    ap.add_argument("--as-of")
    ap.add_argument("--out", required=True)
    ap.add_argument("--propose")
    a = ap.parse_args()

    facts = json.loads(Path(a.facts).read_text()) if a.facts else {}
    m = json.loads(Path(a.matter).read_text()) if a.matter else None
    as_of = d(a.as_of) or d(facts.get("as_of")) or (d(m.get("as_of")) if m else None) \
        or date.today()
    matter_id = str(facts.get("matter") or (m or {}).get("matter_id") or "")

    reg_rows = []
    if a.register:
        raw = REG.load(a.register)
        reg_rows, errs = REG.validate(raw, "register row")
        if errs:
            raise SystemExit("The register has rows it refuses. Fix them first:\n  "
                             + "\n  ".join(errs))
        if reg_rows and not matter_id:
            raise SystemExit("A register was supplied with no matter to read it for. "
                             "Put the matter in the facts file.")

    periods, label = [], None
    for f in a.periods:
        data = json.loads(Path(f).read_text())
        src = dict(data.get("source", {}))
        label = label or data.get("taxpayer_label")
        for p in data.get("periods", []):
            periods.append(read_period(p, src))
    periods.sort(key=lambda P: (str(P["year"]), P["form"]))

    R = Run(as_of)
    compliance_checks(R, periods)
    statute_checks(R, periods, reg_rows, matter_id)
    assessment_checks(R, periods, facts, matter_id)
    address_checks(R, periods, facts)
    trust_fund_checks(R, periods, facts, matter_id)
    joint_checks(R, periods, facts)
    equity_and_timing(R, resolution(m, periods, reg_rows, matter_id, R))

    render(R, (m or {}).get("matter_caption") or label or "Matter", a.out)
    print(f"Written: {a.out}   as of {as_of}")
    print(f"  {len(R.flags)} flag(s), {len(R.clear)} clear, {len(R.unchecked)} not checked")
    for f in sorted(R.flags, key=lambda f: RANK[f["cls"]]):
        print(f"  [{f['cls']}] {f['title']}")
    for k, t in R.unchecked:
        print(f"  not checked: {k}")

    if a.propose:
        if not matter_id:
            raise SystemExit("Nothing proposed: the register needs a matter. "
                             "Put it in the facts file.")
        rows = [{**{c: "" for c in REG.COLUMNS}, **r,
                 "client": facts.get("client", ""), "year": str(r["year"])}
                for r in R.proposed]
        good, errs = REG.validate(rows, "proposed row")
        if errs:
            raise SystemExit("Proposed rows refused:\n  " + "\n  ".join(errs))
        with open(a.propose, "w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=REG.COLUMNS)
            w.writeheader()
            w.writerows(good)
        print(f"Proposed: {a.propose}   {len(good)} row(s) for "
              f"register.py merge")


if __name__ == "__main__":
    main()

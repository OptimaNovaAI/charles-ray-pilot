# The clock register

## Columns

| Column | Required | What it holds |
|---|---|---|
| `matter` | always | the matter number |
| `client` | no | the client's name. The register stays on Charles's machine |
| `year` | always | the tax year |
| `clock` | always | one of the clocks below |
| `date` | always | the date |
| `kind` | always | `derived` or `controlling` |
| `basis` | derived | the line or the arithmetic it came from |
| `given_by` | controlling | who at the Service stated it, and how |
| `given_on` | controlling | when they stated it |
| `assessment_ref` | no | the assessment date this clock belongs to |
| `recorded_on` | no | filled in when the row is written |
| `note` | no | anything else |

## Clocks

| Clock | Meaning |
|---|---|
| `CSED` | Collection statute expiration |
| `ASED` | Assessment statute expiration |
| `RSED` | Refund statute expiration |
| `TOLL_START` | A suspension of a statute begins |
| `TOLL_END` | A suspension of a statute ends |
| `CDP_WINDOW` | Last day to request a collection due process hearing |
| `PETITION_WINDOW` | Last day to petition the Tax Court |

## The rules

**Refused on entry.** A row with no kind. A controlling row with no one
named who gave it, or no date it was given. A derived row with no basis. A
date that does not read as a date. When any row is refused, nothing is
written.

**On merge**, one live row per matter, year, clock, and assessment:

| In the register | Arriving | Result |
|---|---|---|
| nothing | anything | added |
| controlling | derived | kept. A derived date never replaces a controlling one |
| derived | controlling | replaced |
| derived | derived, different date | replaced |
| controlling | controlling, same date | kept |
| controlling | controlling, different date | **conflict**. Both reported, register unchanged |

A conflict between two controlling dates is a finding. Two people at the
Service gave two dates, and which one holds is the attorney's call.

## Assessment reference

The collection statute runs from each assessment separately. A row with an
`assessment_ref` speaks for that assessment only. A row without one speaks
for every assessment in the year. When the Service gives a single date for a
year that carries more than one assessment, record it without a reference and
note which assessment the caller meant.

## Excel

Excel re-saves dates in its own format. The register reads 2027-04-15,
4/15/2027, and 04-15-2027, and always writes 2027-04-15.

# The clock register

## Columns

| Column | Required | What it holds |
|---|---|---|
| `matter` | always | the matter number |
| `client` | no | the client's name. The register stays on Charles's machine |
| `year` | always | the tax year |
| `clock` | always | one of the clocks below |
| `date` | always | the date |
| `kind` | always | `derived`, `irs_printed`, or `controlling` |
| `basis` | derived, irs_printed | the line or the arithmetic it came from, or the line the printed date sits beneath |
| `given_by` | controlling, irs_printed | who at the Service stated it, and how; for a printed date, the transcript type and the code it sits beneath |
| `given_on` | controlling, irs_printed | when they stated it; for a printed date, the date the transcript was generated |
| `assessment_ref` | no | the assessment date this clock belongs to |
| `recorded_on` | no | filled in when the row is written |
| `note` | no | anything else |

## Clocks

| Clock | Meaning |
|---|---|
| `CSED` | Collection statute expiration |
| `ASED` | Assessment statute expiration |
| `RSED` | Refund statute expiration |
| `TOLL_START` | A suspension of a statute begins |
| `TOLL_END` | A suspension of a statute ends |
| `CDP_WINDOW` | Last day to request a collection due process hearing |
| `PETITION_WINDOW` | Last day to petition the Tax Court |

## The kinds

| Kind | What it is |
|---|---|
| `derived` | Computed here from transcript lines, with the arithmetic shown |
| `irs_printed` | The date a transcript prints beneath a transaction line. The Service's computed figure. Not ours, and not controlling |
| `controlling` | Stated by the Service on a call, in an account review, or in writing, with who and when |

In use reads controlling first, then IRS-printed, then derived. Only a
controlling date is the CSED without qualification. A matching printed date
and derived date are consistent, not controlling.

## The rules

**Refused on entry.** A row with no kind. A derived row with no basis. An
IRS-printed row without the line it sits beneath, the transcript it came from,
or the date that transcript was generated. A controlling row with no one named
who gave it, or no date it was given. A date that does not read as a date.
When any row is refused, nothing is written.

**On merge**, one live row per matter, year, clock, assessment, and kind. The
three kinds sit side by side and never overwrite each other.

| In the register | Arriving, same kind | Result |
|---|---|---|
| nothing | anything | added |
| derived | derived, different date | replaced |
| IRS-printed | from a newer transcript | replaced |
| IRS-printed | from an older transcript | kept, the arriving date is not written |
| IRS-printed | same transcript date, different date | **conflict**. Both reported, register unchanged |
| controlling | same date | kept |
| controlling | different date | **conflict**. Both reported, register unchanged |

A conflict between two controlling dates is a finding. Two people at the
Service gave two dates, and which one holds is the attorney's call.

## Assessment reference

The collection statute runs from each assessment separately. A row with an
`assessment_ref` speaks for that assessment only. A row without one speaks
for every assessment in the year. When the Service gives a single date for a
year that carries more than one assessment, record it without a reference and
note which assessment the caller meant.

## Excel

Excel re-saves dates in its own format. The register reads 2027-04-15,
4/15/2027, and 04-15-2027, and always writes 2027-04-15.

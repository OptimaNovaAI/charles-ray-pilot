# The facts file

What no transcript carries. Every field is optional. A check that needs a
field that is absent is listed as not checked, with the field it needed.

```json
{
  "matter": "M-0142",
  "client": "stays in the register, never in a shared file",
  "as_of": "2026-09-27",

  "notices": [
    {"kind": "CP2000", "year": 2017, "date": "2019-11-18",
     "mailed_to": "44 Birchfield Lane, Takoma Park, MD 20912",
     "source": "copy in the client file"},
    {"kind": "Notice of deficiency (Letter 3219)", "year": 2017,
     "date": "2020-06-08",
     "mailed_to": "1207 Juniper Ct, Silver Spring, MD 20910",
     "source": "copy produced by the Service"}
  ],

  "returns": [
    {"year": 2018, "filed": "2019-04-12",
     "address": "44 Birchfield Ln., Takoma Park, MD 20912",
     "source": "2018 return, page 1"}
  ],

  "addresses": [
    {"address": "44 Birchfield Lane, Takoma Park, MD 20912",
     "from": "2015-03-01", "to": "2021-06-30",
     "evidence": "lease, term dates on page 1"}
  ],

  "joint_years": [2020],
  "separated_or_divorced": "Separated since March 2024, per the client",
  "business": true
}
```

## Field by field

**`matter`** keys the register. Required for `--register` and `--propose`.

**`notices`** are the notices as sent, from copies or the Service's records.
A notice whose `kind` reads as a notice of deficiency (*notice of
deficiency*, *statutory notice*, or *3219*) runs the last known address
check. Every earlier notice with a `mailed_to` is shown beside it, because
the address the Service used before bears on what it knew.

**`returns`** are the returns filed before the notice, with the address on
each. The check takes the most recent one filed at least forty-five days
before the notice, since the regulation treats a return as properly processed
after forty-five days. One filed inside that period is shown and noted.

**`addresses`** are where the client lived, with dates and the document that
proves it. A blank `to` means still there.

Addresses are compared as a person would compare them. Case, punctuation,
and the usual abbreviations (Lane and Ln, Court and Ct) do not make two
addresses different. A different street number or street does.

**`joint_years`** adds years to the joint return check beyond those whose
transcript prints a joint filing status.

**`separated_or_divorced`** is shown as given. `true` or a sentence.

**`business`** notes a business matter. With no employment tax transcript
supplied, the trust fund check is listed as not checked.

## Dates

Written 2026-09-27. The register also reads 9/27/2026 and 09-27-2026.

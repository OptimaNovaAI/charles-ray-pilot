# The flag catalog

Each entry says what fires the flag, what it reads, and what it cannot see.
This list is Charles's to strike and add to. A flag he strikes comes out of
`flag.py`. A condition he adds goes in with the same three parts every flag
carries: what the record shows, what turns on it, and what is not on the page.

## Named by Charles, September 8

**S1. The statute appears to have run and a balance remains.**
Fires when a year computes a balance and an assessment on it carries a
statute date before the as-of date. Reads each assessment's own date plus ten
years, or a controlling date from the register. Where suspension codes post,
says the derived date is the earliest the statute could run.
*Cannot see:* which assessment the payments went to, or a suspension the
transcript does not carry.

**N1. The notice of deficiency and the last known address.**
Fires when a notice of deficiency went to an address other than the one on
the last return processed before it, or other than where the client lived,
and shows every earlier notice's address beside it. Where the transcript
shows a TC 494 and the facts file has no notice for that year, fires as an
open check.
*Cannot see:* whether and when the client received it.

## Proposed September 9

**S2. The statute runs inside twenty-four months.**
Fires on a year with a balance whose earliest running statute is inside
twenty-four months.

**T1. The arithmetic permits an offer and the statute is close.**
Fires when collection potential falls below the liability on either offer
basis and the soonest statute is inside twenty-four months.

**T2. Less is collectible before the statute runs than is owed.**
Fires when equity plus disposable income through the latest statute falls
short of the liability.

**T3. The offer's future income period outlasts the statute.**
Fires when the latest statute is fewer than twenty-four months out, and
shows collection potential at the shorter period.
*For Charles to confirm:* the current manual provision on counting only the
months left on the statute.

**E1. The arithmetic that closes an offer rests on one asset.**
Fires when collection potential meets the liability and would not without
the largest asset. Shows the quick sale figure at which it tips.

**C1. The arithmetic opens an offer that filing compliance closes.**
Fires when a year has no return on record and collection potential falls
below the liability on either basis.

**B1. Trust fund exposure.**
Fires on a Form 941, 943, 944, 945, or CT-1 period that computes a balance.
Shows the penalty's own assessment window, derived.

**J1. A joint year carrying a balance.**
Fires on a joint year with a balance. Shows whether the balance reads as an
understatement or an underpayment, any section 6330 notice or offset on the
transcript, and the separation fact if supplied.

## Found in the build

**A1. An assessment posts after the assessment window.**
Fires when a TC 290, 300, 310, 320, or 350 posts more than three years after
the date the transcript prints as the return due or received date, whichever
is later. A notice of deficiency mailed inside the window extends it by the
ninety days and sixty after, derived with no petition assumed.
*Cannot see:* a Form 872, the six-year rule, or fraud.

**A2. Assessed inside the ninety days after the notice of deficiency.**
Fires when an additional assessment posts less than ninety days after a
notice of deficiency.
*Cannot see:* a signed waiver.

**C2. The return on record reads as a substitute.**
Fires when the TC 150 posts at zero and reads as a substitute for return.

**V1. A date ten years out is printed beneath the penalty lines.**
Fires until Charles confirms what the date is. Retires once he does.

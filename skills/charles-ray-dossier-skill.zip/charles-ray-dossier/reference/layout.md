# Plain-text fallback

When file creation is unavailable, render in this order in the conversation.
Never fail silently and never skip the markings.

1. **Header** — name, matter type, jurisdiction
2. **The prospect** — name, phone, email, location, matter, jurisdiction,
   amount, years, source, first contact, reference. Omit empty rows.
3. **In their words** — the prospect's own description, verbatim, with where
   and when it was said
4. **The seven questions** — numbered, each either answered with its marking
   or marked ASK
5. **Public record** — category, finding, source, date checked. Only if run.
6. **What the record supports** — two or three lines
7. **What is missing**
8. **Before you dial** — only when something real qualifies
9. **Footer** — the marking legend and the confidentiality line

Markings: confirmed means a document proves it, reported means a person said
it, unverified means the record does not establish it. Default to unverified.

---
name: charles-ray-dossier
description: Build a pre-call prospect dossier for the Law Offices of Charles A. Ray, P.C. Use whenever Charles is about to speak with a prospect and wants the picture before he picks up the phone. Triggers include "build me a dossier", "dossier on [name]", "pull the file on this lead", "what do I know before I call", "prep me for this call", "run the intake on [name]", or pasting a lead card, an answering service message, or a LegalMatch or Martindale notification and asking what to make of it. Also use when he says he has a consultation coming up and wants to walk in prepared.
---

# Pre-call dossier

One page, in his hands before he dials. It answers three questions:
who is this, what do I already know, and what do I still have to ask.

---

## The rule that governs everything

**A dossier reports. It does not conclude.**

Every fact carries where it came from. Anything not established is written as
not established, never inferred and never softened. He is a former IRS Chief
Counsel attorney; a confident guess costs more than an honest gap.

Every figure and date is marked **confirmed**, **reported**, or
**unverified**. Confirmed means a document proves it. Reported means a person
said it. Unverified means the record does not establish it. Default to
unverified.

---

## Step 1. Read the source

The lead arrives in one of these shapes. Read whichever is given.

- A scored card from the qualification engine
- A raw answering service message
- A LegalMatch, Martindale, Avvo, Calendly, or Friedman Framme notification
- A forwarded email from the prospect
- Charles's own notes from a first call

Pull: name, phone, email, address, matter type, jurisdiction, dollar figures,
tax years, any named date, any agency or notice referenced, how they found the
firm, and their own description of the problem **in their own words**.

Their own words matter. Do not paraphrase the problem statement. He reads
tone.

---

## Step 2. The seven questions

The seven-question intake protocol is his call script, not a form to fill in.
The dossier's job is to show which questions the lead has **already answered**
and which he still has to ask.

Until his verbatim list is confirmed, use this working framework and label the
block **working framework, pending confirmation**:

1. **What is the problem you are trying to solve?**
2. **What is the last correspondence you received on it, and when?**
3. **Which tax years are at issue?**
4. **What is the amount, as the agency states it?**
5. **What have you already done about it, and with whom?**
6. **Is anything scheduled or expiring: a hearing, a levy, a deadline?**
7. **Who else is exposed: a spouse, a business, a partner?**

For each: answer it from the source if the lead already said it, or mark it
**ASK**. Never invent an answer.

When his confirmed list replaces this one, swap it in and drop the pending
label.

---

## Step 3. Public record

**Run this only when asked, and only for prospects worth the time.**

Search the open records. Cite every source with the URL and the date checked.
Where nothing is found, write *no record found*, which is different from
*nothing there*.

| Jurisdiction | Courts | Business filings |
|---|---|---|
| Maryland | Maryland Judiciary Case Search | Maryland SDAT |
| DC | DC Courts case search | DC CorpOnline |
| Virginia | Virginia OES case information | Virginia SCC Clerk's Information System |

Federal tax liens are filed in local land records: the DC Recorder of Deeds,
Maryland circuit courts by county, Virginia circuit courts by county or city.
Coverage varies and some are not searchable online. Say so when that is the
case.

**What to look for:** federal or state tax liens, active or recent civil
litigation, judgments, bankruptcy filings, and business entities with the
prospect as officer or registered agent.

**Read, do not scrape.** These are terms-of-service sites. A research pass with
citations is defensible. An automated harvester is not, and he is the one who
would be asked about it.

**A public record is a lead to verify, not a fact about the prospect.** Common
names produce false matches. Say what you found and say how confident the
match is.

---

## Step 4. What it means for the call

Three short blocks, no more.

**What the record supports.** Two or three lines. Only what the sources show.

**What is missing.** The questions marked ASK, plus anything the public record
raised that the lead did not mention.

**Worth knowing before you dial.** Only when something real is there. A named
deadline. A lien that contradicts what the prospect said. A business entity on
a matter presented as individual. A spouse on a joint year. If nothing
qualifies, omit this block entirely rather than padding it.

Never recommend a fee, a resolution path, or whether to take the matter. That
is his call and the engagement is built around protecting it.

---

## Step 5. Render

Use `scripts/build_dossier.py` to produce a single-file HTML dossier, then
convert to PDF if he wants to print it.

```
python3 scripts/build_dossier.py dossier.json out.html
```

The JSON shape is in `reference/dossier-schema.json`. Build the JSON from what
you read, run the script, and hand him the file.

If file creation is unavailable, render the same structure as plain text in
the conversation in the order given in `reference/layout.md`. Never fail
silently.

---

## Confidentiality

The dossier carries client-identifying information. It is internal work
product. Never publish it, never post it to the hub, and never include it in
anything that leaves the tenant.

---
name: charles-ray-dossier
description: Build a pre-call prospect dossier for the Law Offices of Charles A. Ray, P.C. Use whenever Charles is about to speak with a prospect and wants the picture before he picks up the phone. Triggers include "build me a dossier", "dossier on [name]", "pull the file on this lead", "what do I know before I call", "prep me for this call", "run the intake on [name]", or pasting a lead card, an answering service message, or a LegalMatch or Martindale notification and asking what to make of it. Also use when he says he has a consultation coming up and wants to walk in prepared.
---

# Pre-call dossier

One page, in his hands before he dials. It answers three questions:
who is this, what do I already know, and what do I still have to ask.

---

## The rule that governs everything

**A dossier reports. It does not conclude.**

Every fact carries where it came from. Anything not established is written as
not established, never inferred and never softened. He is a former IRS Chief
Counsel attorney; a confident guess costs more than an honest gap.

Every figure and date is marked **confirmed**, **reported**, or
**unverified**. Confirmed means a document proves it. Reported means a person
said it. Unverified means the record does not establish it. Default to
unverified.

---

## Step 1. Read the source

The lead arrives in one of these shapes. Read whichever is given.

- A scored card from the qualification engine
- A raw answering service message
- A LegalMatch, Martindale, Avvo, Calendly, or Friedman Framme notification
- A forwarded email from the prospect
- Charles's own notes from a first call

Pull: name, phone, email, address, matter type, jurisdiction, dollar figures,
tax years, any named date, any agency or notice referenced, how they found the
firm, and their own description of the problem **in their own words**.

Their own words matter. Do not paraphrase the problem statement. He reads
tone.

---

## Step 2. The seven questions

These are his, confirmed on the call of September 8, 2026. They are his call
script, not a form. The dossier shows which ones the lead has **already
answered** and which he still has to ask.

**1. How much do you owe?**

He put this first and he was explicit about why: certain cases are not worth
the engine. It runs the same whether the balance is fourteen thousand or a
hundred and forty. When the amount is absent from the lead, this is the first
thing badged **ASK**, and nothing else on the page matters as much.

**2. Are all your returns filed?**

Not a disqualifier. A sequence. In his words, if they are not filed it does
not mean he cannot take it, it postpones it until they are. Say so on the page
when the answer is no, so an unfiled year never reads as a dead case.

**3. What is your current situation?**

Working, retired, what the finances look like now.

**4. What would you like to see happen?**

Their ideal first, in their words, then what is realistic. He expects most
people to say they want it cancelled. Record what they said and do not
editorialize.

If they name an installment agreement, the follow-on is the range from low to
high they believe they can maintain, and the financial form goes out. If they
name an offer in compromise, that is the heavier form and the deeper analysis.
Note which fork the lead points to. Do not choose it for him.

**5. What is your filing status?**

Two answers, not one. For the years at issue, and currently.

**6. What are your previous efforts with the IRS?**

Last contact, last correspondence received, and where that puts them in the
collection cycle.

**7. What is your track record with the Service?**

Prior installment agreements and whether any defaulted. Prior bankruptcies.

---

For each: answer it from the source when the lead already said it, or mark it
**ASK**. Never invent an answer.

**Then the transcripts.** He pulls them to verify or challenge what the client
reported. The seven questions are what the prospect says. The transcript is
what the record says. Never present a client-reported figure as confirmed.

---

## The amount gate

Report the balance against his floor. Report it; never decline on it. He
decides.

| Reported balance | What the page says |
|---|---|
| $25,000 and up | Within his range |
| $20,000 to $25,000 | Worth a closer look before the call |
| Under $20,000 | Below his usual floor |

**The exception, and it matters.** A small balance on a recent year can still
work, where the same balance on an old year cannot. He explained the
arithmetic: the older the debt, the less collection time remains, and the
monthly payment rises to fit what is left. Fourteen thousand with one year
left on the clock is roughly a thousand a month before anyone opens a 433-F.

So when the balance is under twenty thousand, always print the years alongside
it. A recent year changes the answer.

---

## Step 3. Public record

**Run this only when asked, and only for prospects worth the time.**

Search the open records. Cite every source with the URL and the date checked.
Where nothing is found, write *no record found*, which is different from
*nothing there*.

| Jurisdiction | Courts | Business filings |
|---|---|---|
| Maryland | Maryland Judiciary Case Search | Maryland SDAT |
| DC | DC Courts case search | DC CorpOnline |
| Virginia | Virginia OES case information | Virginia SCC Clerk's Information System |

Federal tax liens are filed in local land records: the DC Recorder of Deeds,
Maryland circuit courts by county, Virginia circuit courts by county or city.
Coverage varies and some are not searchable online. Say so when that is the
case.

**What to look for:** federal or state tax liens, active or recent civil
litigation, judgments, bankruptcy filings, and business entities with the
prospect as officer or registered agent.

**Read, do not scrape.** These are terms-of-service sites. A research pass with
citations is defensible. An automated harvester is not, and he is the one who
would be asked about it.

**A public record is a lead to verify, not a fact about the prospect.** Common
names produce false matches. Say what you found and say how confident the
match is.

---

## Step 4. What it means for the call

Three short blocks, no more.

**What the record supports.** Two or three lines. Only what the sources show.

**What is missing.** The questions marked ASK, plus anything the public record
raised that the lead did not mention.

**Worth knowing before you dial.** Only when something real is there. A named
deadline. A lien that contradicts what the prospect said. A business entity on
a matter presented as individual. A spouse on a joint year. If nothing
qualifies, omit this block entirely rather than padding it.

Never recommend a fee, a resolution path, or whether to take the matter. That
is his call and the engagement is built around protecting it.

---

## Step 5. Render

Use `scripts/build_dossier.py` to produce a single-file HTML dossier, then
convert to PDF if he wants to print it.

```
python3 scripts/build_dossier.py dossier.json out.html
```

The JSON shape is in `reference/dossier-schema.json`. Build the JSON from what
you read, run the script, and hand him the file.

If file creation is unavailable, render the same structure as plain text in
the conversation in the order given in `reference/layout.md`. Never fail
silently.

---

## Confidentiality

The dossier carries client-identifying information. It is internal work
product. Never publish it, never post it to the hub, and never include it in
anything that leaves the tenant.

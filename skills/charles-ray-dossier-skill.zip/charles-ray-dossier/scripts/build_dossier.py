#!/usr/bin/env python3
"""
Pre-call dossier renderer for the Law Offices of Charles A. Ray, P.C.

    python3 build_dossier.py dossier.json out.html

Prints clean on Letter. Nothing renders that is not in the JSON, so an empty
field disappears rather than showing as blank. Schema in
reference/dossier-schema.json.
"""

import json
import sys
from html import escape
from pathlib import Path

MAGENTA = "#CA25B7"
BLUE = "#2E75B6"
NAVY = "#000C65"
INK = "#1B2A4A"
GREY = "#8A8A8A"
HAIR = "#E3E8EF"


def mark(m):
    """Verification marking. Confirmed carries none."""
    if not m or m == "confirmed":
        return ""
    return (f'<span style="font-size:8.5pt;color:{GREY};'
            f'padding-left:6px">{escape(m)}</span>')


def row(label, value, marking=None):
    if not value:
        return ""
    return (
        f'<tr><td style="padding:3.5px 14px 3.5px 0;vertical-align:top;'
        f'font-weight:600;color:{BLUE};white-space:nowrap">{escape(label)}</td>'
        f'<td style="padding:3.5px 0;vertical-align:top">{escape(str(value))}'
        f'{mark(marking)}</td></tr>'
    )


def section(title, inner):
    if not inner:
        return ""
    return (
        f'<h2 style="font-size:8.5pt;font-weight:600;color:{MAGENTA};'
        f'letter-spacing:1.5px;text-transform:uppercase;margin:15px 0 7px;'
        f'padding-bottom:5px;border-bottom:1px solid {HAIR}">{title}</h2>{inner}'
    )


def build(d):
    p = d.get("prospect", {})

    # ---- identity block ----
    ident = "".join([
        row("Name", p.get("name")),
        row("Phone", p.get("phone")),
        row("Email", p.get("email")),
        row("Location", p.get("location")),
        row("Matter", p.get("matter_type")),
        row("Jurisdiction", p.get("jurisdiction")),
        row("Amount", p.get("amount"), p.get("amount_marking")),
        row("Years", p.get("years"), p.get("years_marking")),
        row("Source", p.get("source")),
        row("First contact", p.get("first_contact"), p.get("first_contact_marking")),
        row("Reference", p.get("reference")),
    ])
    ident_block = (
        f'<table style="width:100%;border-collapse:collapse;font-size:9.4pt">'
        f'{ident}</table>' if ident else ""
    )

    # ---- their words ----
    words = ""
    if p.get("their_words"):
        words = (
            f'<div style="border:1px solid {HAIR};border-left:2px solid {BLUE};'
            f'border-radius:8px;padding:11px 15px;font-size:9.4pt;color:{INK};'
            f'line-height:1.55">{escape(p["their_words"])}'
            f'<div style="font-size:8.5pt;color:{GREY};padding-top:8px">'
            f'{escape(p.get("their_words_source", "As received"))}</div></div>'
        )

    # ---- seven questions ----
    q_rows = ""
    for q in d.get("questions", []):
        answered = bool(q.get("answer"))
        badge = (f'<span style="font-size:8pt;font-weight:600;color:{MAGENTA};'
                 f'border:1px solid {MAGENTA};border-radius:4px;padding:1px 6px;'
                 f'white-space:nowrap">ASK</span>')
        val = (escape(q["answer"]) + mark(q.get("marking"))) if answered else badge
        q_rows += (
            f'<tr><td style="padding:4.5px 12px 4.5px 0;vertical-align:top;'
            f'color:{NAVY};font-weight:600;width:30px">{q.get("n","")}.</td>'
            f'<td style="padding:4.5px 14px 4.5px 0;vertical-align:top;color:{NAVY};'
            f'font-weight:600">{escape(q.get("q",""))}</td>'
            f'<td style="padding:4.5px 0;vertical-align:top">{val}</td></tr>'
        )
    q_block = ""
    if q_rows:
        note = ""
        if d.get("questions_pending"):
            note = (f'<div style="font-size:8.5pt;color:{GREY};padding-bottom:8px">'
                    f'The firm\u2019s intake questions, confirmed September 8, 2026.</div>')
        q_block = (note + f'<table style="width:100%;border-collapse:collapse;'
                   f'font-size:9.4pt">{q_rows}</table>')

    # ---- public record ----
    rec = ""
    for r in d.get("public_record", []):
        src = ""
        if r.get("source"):
            checked = f' · checked {escape(r["checked"])}' if r.get("checked") else ""
            src = (f'<div style="font-size:8.5pt;color:{GREY};padding-top:3px">'
                   f'{escape(r["source"])}{checked}</div>')
        conf = mark(r.get("confidence"))
        rec += (
            f'<tr><td style="padding:5px 14px 5px 0;vertical-align:top;'
            f'font-weight:600;color:{BLUE};white-space:nowrap">'
            f'{escape(r.get("category",""))}</td>'
            f'<td style="padding:5px 0;vertical-align:top">'
            f'{escape(r.get("finding",""))}{conf}{src}</td></tr>'
        )
    rec_block = (f'<table style="width:100%;border-collapse:collapse;'
                 f'font-size:9.4pt">{rec}</table>') if rec else ""

    # ---- read blocks ----
    def bullets(items):
        if not items:
            return ""
        li = "".join(
            f'<li style="margin-bottom:5px">{escape(i)}</li>' for i in items)
        return (f'<ul style="margin:0 0 3px;padding-left:18px;font-size:9.4pt;'
                f'color:{INK};line-height:1.55">{li}</ul>')

    supports = bullets(d.get("supported", []))
    missing = bullets(d.get("missing", []))
    flags = d.get("before_you_dial", [])
    flag_block = ""
    if flags:
        li = "".join(f'<li style="margin-bottom:5px">{escape(i)}</li>'
                     for i in flags)
        flag_block = (
            f'<div style="border:1px solid {HAIR};border-left:3px solid {MAGENTA};'
            f'border-radius:8px;padding:13px 17px">'
            f'<ul style="margin:0;padding-left:18px;font-size:9.4pt;color:{INK};'
            f'line-height:1.5">{li}</ul></div>'
        )

    title = p.get("name") or "Prospect dossier"
    sub = " · ".join(x for x in [p.get("matter_type"),
                                 p.get("jurisdiction")] if x)

    return f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<title>Dossier · {escape(title)}</title>
<style>
@page {{ size: Letter; margin: 0.5in 0.65in; }}
body {{ margin:0; background:#fff; color:{INK};
  font-family:'Segoe UI','Helvetica Neue',Arial,sans-serif;
  font-size:9.4pt; line-height:1.42;
  -webkit-print-color-adjust:exact; print-color-adjust:exact; }}
.wrap {{ max-width:7.1in; }}
h2, table, ul {{ page-break-inside:avoid; break-inside:avoid; }}
h2 {{ page-break-after:avoid; break-after:avoid; }}
h1 {{ font-size:18pt; font-weight:600; color:{NAVY}; margin:0 0 3px;
  letter-spacing:-.3px; }}
</style></head><body><div class="wrap">

<div style="border-top:3px solid {MAGENTA};padding-top:13px;margin-bottom:18px">
  <table style="width:100%;border-collapse:collapse"><tr>
    <td><div style="font-size:8pt;font-weight:600;color:{MAGENTA};
      letter-spacing:1.6px;text-transform:uppercase">Pre-call dossier</div></td>
    <td style="text-align:right;font-size:8.5pt;color:{GREY}">
      Law Offices of Charles A. Ray, P.C.<br>{escape(d.get("prepared", ""))}</td>
  </tr></table>
</div>

<h1>{escape(title)}</h1>
<div style="font-size:10pt;color:{GREY};margin-bottom:3px">{escape(sub)}</div>

{section("The prospect", ident_block)}
{section("In their words", words)}
{section("The seven questions", q_block)}
{section("Public record", rec_block)}
{section("What the record supports", supports)}
{section("What is missing", missing)}
{section("Before you dial", flag_block)}

<div style="margin-top:18px;padding-top:9px;border-top:1px solid {HAIR};
  font-size:7.5pt;color:{GREY};line-height:1.6">
Every figure and date is marked confirmed, reported, or unverified. Unmarked
values are confirmed. Public records are leads to verify, not established facts
about this prospect.<br>
Confidential internal work product. Prepared by OptimaNova AI for the Law
Offices of Charles A. Ray, P.C. Do not forward to a client, the IRS, or a state
agency.
</div>

</div></body></html>"""


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    data = json.loads(Path(sys.argv[1]).read_text())
    Path(sys.argv[2]).write_text(build(data))
    name = data.get("prospect", {}).get("name", "prospect")
    print(f"Dossier written for {name} -> {sys.argv[2]}")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
Resolution path arithmetic for the Law Offices of Charles A. Ray, P.C.

    python3 compute.py matter.json out.html

Computes. Never recommends.

It works out what the Service can collect and by when, then shows which paths
that arithmetic opens and which it closes. It does not say to file an offer, or
to request currently not collectible status, or to propose any figure. Charles
decides. The worksheet exists so he decides against numbers he can see.

Every figure in the output carries where it came from. Nothing is looked up,
nothing is assumed, and a missing input is reported as missing rather than
estimated.
"""

import json
import sys
from datetime import date, datetime
from pathlib import Path

MONEY = "${:,.2f}"


# ------------------------------------------------------------------ helpers

def d(s):
    """Parse an ISO date. Returns None for a blank."""
    if not s:
        return None
    return datetime.strptime(str(s)[:10], "%Y-%m-%d").date()


def months_between(a, b):
    """Whole months from a to b. Negative when b is in the past."""
    if a is None or b is None:
        return None
    return (b.year - a.year) * 12 + (b.month - a.month) - (1 if b.day < a.day else 0)


def fmt(v):
    return MONEY.format(v) if isinstance(v, (int, float)) else str(v)


class Missing(Exception):
    pass


def need(obj, key, where):
    v = obj.get(key)
    if v is None or v == "":
        raise Missing(f"{key} is missing from {where}")
    return v


# ------------------------------------------------------------------ the math

def collection_window(years, as_of):
    """
    How long the Service has left, year by year.

    Each year carries its own collection statute expiration date. The binding
    one for planning is the latest, because collection continues until every
    year has run.
    """
    rows = []
    for y in years:
        csed = d(y.get("csed"))
        rows.append({
            "year": y.get("year"),
            "balance": float(y.get("balance", 0) or 0),
            "csed": csed,
            "csed_kind": y.get("csed_kind", "unstated"),
            "csed_source": y.get("csed_source", "not stated"),
            "months_left": months_between(as_of, csed) if csed else None,
        })
    return rows


def net_realizable_equity(assets):
    """
    Quick sale value less encumbrances, per asset.

    The quick sale percentage is supplied, never assumed. The Service's usual
    figure is 80 percent, but it is applied by an examiner with discretion and
    is not a constant, so it belongs in the input.
    """
    out = []
    total = 0.0
    for a in assets:
        fmv = float(need(a, "fair_market_value", f"asset '{a.get('name','unnamed')}'"))
        pct = float(need(a, "quick_sale_pct", f"asset '{a.get('name','unnamed')}'"))
        enc = float(a.get("encumbrance", 0) or 0)
        exempt = float(a.get("exempt", 0) or 0)
        qsv = fmv * (pct / 100.0)
        nre = max(0.0, qsv - enc - exempt)
        total += nre
        out.append({
            "name": a.get("name", "unnamed"),
            "fmv": fmv, "pct": pct, "qsv": qsv,
            "encumbrance": enc, "exempt": exempt, "nre": nre,
            "source": a.get("source", "not stated"),
        })
    return out, total


def monthly_disposable(income, expenses):
    """
    Income less allowable expenses.

    Allowable expenses are supplied. They are not looked up. The national and
    local standards change annually and vary by county and household size, so a
    figure invented here would be a confident wrong answer about whether
    somebody qualifies for relief.
    """
    inc = sum(float(v or 0) for v in income.values())
    exp = sum(float(v or 0) for v in expenses.values())
    return inc, exp, inc - exp


def compute(m):
    as_of = d(m.get("as_of")) or date.today()
    years = collection_window(m.get("years", []), as_of)

    total_liability = sum(y["balance"] for y in years)
    dated = [y for y in years if y["months_left"] is not None]
    binding = max(dated, key=lambda y: y["months_left"]) if dated else None
    soonest = min(dated, key=lambda y: y["months_left"]) if dated else None
    undated = [y for y in years if y["months_left"] is None]

    assets, nre_total = net_realizable_equity(m.get("assets", []))
    income = m.get("monthly_income", {})
    expenses = m.get("monthly_allowable_expenses", {})
    inc, exp, disposable = monthly_disposable(income, expenses)

    # Reasonable collection potential, both statutory offer periods.
    rcp = {}
    for label, months in (("lump sum, 5 months", 5), ("periodic, 24 months", 24)):
        future = max(0.0, disposable) * months
        rcp[label] = {"months": months, "future_income": future,
                      "total": nre_total + future}

    # What an installment agreement has to clear to full-pay inside the window.
    ia = None
    if binding and binding["months_left"] and binding["months_left"] > 0:
        ia = {
            "months": binding["months_left"],
            "monthly": total_liability / binding["months_left"],
            "driven_by": binding["year"],
        }

    return {
        "as_of": as_of, "years": years, "undated": undated,
        "total_liability": total_liability,
        "binding": binding, "soonest": soonest,
        "assets": assets, "nre_total": nre_total,
        "income": income, "expenses": expenses,
        "inc": inc, "exp": exp, "disposable": disposable,
        "rcp": rcp, "ia": ia,
        "compliance": m.get("filing_compliance", {}),
    }


# ------------------------------------------------------------------ findings

def findings(r):
    """
    What the arithmetic opens and what it closes. Statements of fact about
    numbers, never advice about what to do.
    """
    out = []
    liab = r["total_liability"]

    unfiled = [str(y) for y in r["compliance"].get("unfiled_years", [])]
    if unfiled:
        out.append(("closed",
                    f"An offer cannot be processed while {', '.join(unfiled)} "
                    f"remain unfiled. Filing compliance is a condition of "
                    f"processing, so this is a sequence question before it is "
                    f"anything else."))

    for label, v in r["rcp"].items():
        if v["total"] >= liab and liab > 0:
            out.append(("closed",
                        f"On the {label} basis, collection potential of "
                        f"{fmt(v['total'])} meets or exceeds the liability of "
                        f"{fmt(liab)}. The arithmetic does not support an offer "
                        f"below the balance."))
        elif liab > 0:
            gap = liab - v["total"]
            out.append(("open",
                        f"On the {label} basis, collection potential is "
                        f"{fmt(v['total'])} against a liability of {fmt(liab)}, "
                        f"a difference of {fmt(gap)}."))

    if r["disposable"] <= 0:
        out.append(("open",
                    f"Allowable expenses of {fmt(r['exp'])} meet or exceed "
                    f"income of {fmt(r['inc'])}. There is no monthly disposable "
                    f"figure to apply to a payment."))

    if r["ia"]:
        out.append(("note",
                    f"Full payment inside the collection window requires "
                    f"{fmt(r['ia']['monthly'])} a month for "
                    f"{r['ia']['months']} months, set by the {r['ia']['driven_by']} "
                    f"statute date."))
        if r["disposable"] > 0 and r["ia"]["monthly"] > r["disposable"]:
            short = r["ia"]["monthly"] - r["disposable"]
            out.append(("closed",
                        f"That is {fmt(short)} a month above the disposable "
                        f"figure of {fmt(r['disposable'])}, so full payment "
                        f"inside the window is not reachable from the supplied "
                        f"figures."))

    if r["soonest"] and r["soonest"]["months_left"] is not None:
        ml = r["soonest"]["months_left"]
        if ml <= 24:
            out.append(("urgent",
                        f"The {r['soonest']['year']} statute runs in {ml} "
                        f"months. Any action that suspends the statute extends "
                        f"the time the Service has to collect that year."))

    derived = [y for y in r["years"] if y["csed"] and y["csed_kind"] != "controlling"]
    if derived:
        out.append(("caution",
                    f"{len(derived)} statute date(s) are derived from "
                    f"transcript lines rather than stated by the Service. They "
                    f"carry the weight of a computation, not a confirmation."))

    if r["undated"]:
        yrs = ", ".join(str(y["year"]) for y in r["undated"])
        out.append(("caution",
                    f"No statute date for {yrs}. Every figure that depends on "
                    f"the collection window excludes those years."))

    return out


# ------------------------------------------------------------------ render

CSS = """
body{margin:0;background:#f4f5f7;font-family:-apple-system,BlinkMacSystemFont,
"Segoe UI",Arial,sans-serif;color:#1b2a4a}
.w{max-width:860px;margin:0 auto;padding:28px 20px 70px}
.card{background:#fff;border:1px solid #e3e8ef;border-radius:12px;padding:22px 26px;
margin-bottom:16px}
.k{font-size:11px;font-weight:600;letter-spacing:1.6px;text-transform:uppercase;
color:#ca25b7;padding-bottom:10px}
h1{margin:0 0 6px;font-size:27px;font-weight:600;color:#0b1f3a;letter-spacing:-.5px}
.sub{color:#6a7488;font-size:14px;margin:0 0 22px}
table{width:100%;border-collapse:collapse;font-size:14px}
th{text-align:left;font-size:10.5px;letter-spacing:1.2px;text-transform:uppercase;
color:#8a93a6;font-weight:600;padding:0 8px 8px 0;border-bottom:1px solid #e3e8ef}
td{padding:9px 8px 9px 0;border-bottom:1px solid #f0f2f6;vertical-align:top}
td.n,th.n{text-align:right}
.src{color:#8a93a6;font-size:12px}
.big{font-size:22px;font-weight:600;color:#000c65}
.f{border-left:3px solid #d5dae3;padding:2px 0 2px 14px;margin-bottom:14px;
font-size:14.5px;line-height:1.6}
.f.open{border-color:#0b7a55}.f.closed{border-color:#b4483a}
.f.urgent{border-color:#ca25b7}.f.caution{border-color:#d9a441}
.f.note{border-color:#2e75b6}
.tag{font-size:10px;letter-spacing:1.3px;text-transform:uppercase;font-weight:600;
display:block;padding-bottom:3px}
.open .tag{color:#0b7a55}.closed .tag{color:#b4483a}.urgent .tag{color:#ca25b7}
.caution .tag{color:#d9a441}.note .tag{color:#2e75b6}
.foot{color:#8a93a6;font-size:12.5px;line-height:1.65;padding-top:6px}
"""

TAGS = {"open": "Arithmetic permits", "closed": "Arithmetic forecloses",
        "urgent": "Clock", "caution": "Verification", "note": "For reference"}


def render(r, m, out_path):
    y_rows = "".join(
        f"<tr><td>{y['year']}</td><td class='n'>{fmt(y['balance'])}</td>"
        f"<td>{y['csed'].isoformat() if y['csed'] else '<span class=src>not established</span>'}</td>"
        f"<td>{y['csed_kind']}</td>"
        f"<td class='n'>{y['months_left'] if y['months_left'] is not None else '&mdash;'}</td>"
        f"<td class='src'>{y['csed_source']}</td></tr>"
        for y in r["years"])

    a_rows = "".join(
        f"<tr><td>{a['name']}</td><td class='n'>{fmt(a['fmv'])}</td>"
        f"<td class='n'>{a['pct']:.0f}%</td><td class='n'>{fmt(a['qsv'])}</td>"
        f"<td class='n'>{fmt(a['encumbrance'])}</td><td class='n'>{fmt(a['exempt'])}</td>"
        f"<td class='n'><b>{fmt(a['nre'])}</b></td>"
        f"<td class='src'>{a['source']}</td></tr>"
        for a in r["assets"]) or \
        "<tr><td colspan=8 class=src>No assets supplied. "\
        "Net realizable equity is treated as zero, which is an input, not a finding.</td></tr>"

    rcp_rows = "".join(
        f"<tr><td>{k}</td><td class='n'>{fmt(r['nre_total'])}</td>"
        f"<td class='n'>{fmt(v['future_income'])}</td>"
        f"<td class='n'><b>{fmt(v['total'])}</b></td></tr>"
        for k, v in r["rcp"].items())

    f_html = "".join(
        f"<div class='f {kind}'><span class='tag'>{TAGS[kind]}</span>{text}</div>"
        for kind, text in findings(r))

    inc_rows = "".join(f"<tr><td>{k}</td><td class='n'>{fmt(float(v or 0))}</td></tr>"
                       for k, v in r["income"].items()) or \
        "<tr><td colspan=2 class=src>None supplied</td></tr>"
    exp_rows = "".join(f"<tr><td>{k}</td><td class='n'>{fmt(float(v or 0))}</td></tr>"
                       for k, v in r["expenses"].items()) or \
        "<tr><td colspan=2 class=src>None supplied</td></tr>"

    html = f"""<!DOCTYPE html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>Resolution path worksheet</title><style>{CSS}</style></head><body><div class="w">

<div class="k">Resolution path &middot; worksheet</div>
<h1>{m.get('matter_caption','Matter')}</h1>
<p class="sub">Figures as of {r['as_of'].isoformat()}. This worksheet computes.
It does not recommend.</p>

<div class="card"><div class="k">The years</div>
<table><tr><th>Year</th><th class="n">Balance</th><th>Statute date</th>
<th>Kind</th><th class="n">Months left</th><th>Source</th></tr>
{y_rows}
<tr><td><b>Total</b></td><td class="n"><b>{fmt(r['total_liability'])}</b></td>
<td colspan="4"></td></tr></table></div>

<div class="card"><div class="k">Net realizable equity</div>
<table><tr><th>Asset</th><th class="n">FMV</th><th class="n">QSV %</th>
<th class="n">Quick sale</th><th class="n">Owed</th><th class="n">Exempt</th>
<th class="n">Equity</th><th>Source</th></tr>
{a_rows}
<tr><td colspan="6"><b>Total</b></td>
<td class="n"><b>{fmt(r['nre_total'])}</b></td><td></td></tr></table></div>

<div class="card"><div class="k">Monthly</div>
<table style="width:48%;display:inline-table;vertical-align:top">
<tr><th>Income</th><th class="n"></th></tr>{inc_rows}
<tr><td><b>Total</b></td><td class="n"><b>{fmt(r['inc'])}</b></td></tr></table>
<table style="width:48%;display:inline-table;vertical-align:top;margin-left:3%">
<tr><th>Allowable expenses</th><th class="n"></th></tr>{exp_rows}
<tr><td><b>Total</b></td><td class="n"><b>{fmt(r['exp'])}</b></td></tr></table>
<p style="margin:16px 0 0"><span class="src">Disposable</span><br>
<span class="big">{fmt(r['disposable'])}</span></p>
<p class="foot">Allowable expenses are supplied, never looked up. The national
and local standards change annually and vary by county and household size, so a
figure invented here would be a confident wrong answer.</p></div>

<div class="card"><div class="k">Collection potential</div>
<table><tr><th>Basis</th><th class="n">Equity</th><th class="n">Future income</th>
<th class="n">Total</th></tr>{rcp_rows}</table></div>

<div class="card"><div class="k">What the arithmetic opens and closes</div>
{f_html}</div>

<div class="card"><p class="foot">
Every figure above traces to an input. Nothing was looked up and nothing was
assumed. A statute date marked derived was computed from a transcript line and
carries the weight of a computation. A date marked controlling was stated by
the Service.
<br><br>
This worksheet does not propose an offer amount, a payment, or a filing. It
sets out what the numbers permit and what they foreclose, and the decision on
this matter is the attorney's.
</p></div>

</div></body></html>"""
    Path(out_path).write_text(html, encoding="utf-8")


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    m = json.loads(Path(sys.argv[1]).read_text())
    try:
        r = compute(m)
    except Missing as e:
        raise SystemExit(
            f"Refusing to compute. {e}\n"
            "Ask for it rather than assuming a figure. A worksheet built on an "
            "invented number is worse than no worksheet."
        )
    render(r, m, sys.argv[2])
    print(f"Written: {sys.argv[2]}")
    print(f"  Liability {fmt(r['total_liability'])} across {len(r['years'])} year(s)")
    print(f"  Equity {fmt(r['nre_total'])}   Disposable {fmt(r['disposable'])}/mo")
    if r["ia"]:
        print(f"  Full pay inside the window: {fmt(r['ia']['monthly'])}/mo "
              f"for {r['ia']['months']} months")
    if r["undated"]:
        print(f"  {len(r['undated'])} year(s) with no statute date, excluded "
              f"from window figures")


if __name__ == "__main__":
    main()

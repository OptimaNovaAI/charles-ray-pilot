---
name: charles-ray-resolution-path
description: Work out what the Service can collect and by when, and show which resolution paths that arithmetic opens and which it closes. Use whenever the question is money against time on a collection matter — "run the numbers on this one", "what are their options", "can they do an offer", "what would an installment agreement look like", "figure the RCP", "what is reasonable collection potential here", "is an offer viable", "how much do they have to pay a month", "run the collection analysis", or when a 433-A or 433-F comes in and needs to mean something. Also runs after the transcript decode, since the statute dates and balances it produces are this skill's inputs. It computes and never recommends.
---

# Resolution path

This computes. It never recommends.

It works out reasonable collection potential and the remaining collection
window, then sets out which paths the arithmetic opens and which it closes.
It does not say to file an offer, to request currently not collectible
status, or to propose any figure. Charles decides. The worksheet exists so he
decides against numbers he can see.

---

## Run it

```
python3 scripts/compute.py matter.json out.html
```

The input shape is in `reference/input.md`. Every figure in the output traces
to something supplied.

---

## Nothing is looked up

**Allowable expenses are an input.** The national and local collection
financial standards change annually and vary by county and household size. A
figure invented here would be a confident wrong answer about whether somebody
qualifies for relief, and the client would never know where it came from. They
come off the 433 or from Charles.

**The quick sale percentage is an input.** The Service usually applies eighty
percent, but it is applied by an examiner with discretion and it is not a
constant.

**A missing figure stops the build.** The script refuses and names what it
needs. Ask for it. A worksheet resting on an invented number is worse than no
worksheet, because it looks finished.

---

## Derived against controlling

This is the firm's rule and it carries through from the transcript decode. A
statute date computed from a transcript line is **derived**. A date the Service
stated is **controlling**. They are not the same kind of thing and the
worksheet never presents them as one.

Every year shows its kind and its source on the face of the page. Where a date
is derived, the findings say so. Where there is no date at all, the findings
say which figures exclude that year, because a year with no statute date
silently drops out of every window calculation and that omission has to be
visible.

---

## What the findings may and may not say

They are statements about numbers.

**Permitted.** A gap between collection potential and the liability. A monthly
figure that exceeds disposable income. A statute inside twenty-four months. A
year that cannot be included because it has no date.

**Not permitted.** That an offer should be filed. That an amount should be
proposed. That a path is advisable, sensible, or likely to succeed. The moment
a finding uses the word *should*, it has stopped computing.

The proposal committed to this on page 7: **AI proposes and you decide.** A
calculation the attorney reviews is his analysis. A recommendation he relies on
is a different thing, and this firm does not produce the second one.

---

## The clock finding

Where a statute runs inside twenty-four months, the worksheet says so and notes
that action suspending the statute extends the Service's time to collect that
year.

It stops there. Whether to request a hearing and freeze the clock, or to clear
the matter and let it run, is a judgment with the client's whole position
behind it. The arithmetic can show the trade. It cannot make it.

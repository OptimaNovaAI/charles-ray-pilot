# The input

```json
{
  "matter_caption": "appears as the heading",
  "as_of": "2026-09-13",

  "years": [
    {"year": 2016, "balance": 41200.00,
     "csed": "2027-04-15",
     "csed_kind": "derived | controlling | unstated",
     "csed_source": "the transcript line, or who at the Service said it and when"}
  ],

  "assets": [
    {"name": "Residence",
     "fair_market_value": 480000,
     "quick_sale_pct": 80,
     "encumbrance": 402000,
     "exempt": 0,
     "source": "where the figure came from"}
  ],

  "monthly_income": {"Wages, net": 6100},
  "monthly_allowable_expenses": {"Housing and utilities": 2900},

  "filing_compliance": {"unfiled_years": [2021, 2022]}
}
```

## Required, and refused if absent

`fair_market_value` and `quick_sale_pct` on every asset. Everything else has a
defensible default: an absent encumbrance is zero, an absent exemption is zero,
an absent statute date is reported as absent rather than guessed.

## Things worth knowing

**Equity floors at zero.** An underwater asset contributes nothing. It does not
offset equity elsewhere, because the Service does not net it that way.

**Two offer bases are computed**, five months and twenty-four. Both use the
same equity figure and differ only in how many months of disposable income are
counted.

**The installment figure is full payment inside the window**, driven by the
latest statute date, since collection continues until every year has run.

**A year with no statute date is excluded** from every window figure and the
exclusion is stated in the findings. Silence there would be the dangerous kind.

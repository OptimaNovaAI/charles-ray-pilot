---
name: charles-ray-enrichment
description: Run the public record pass on a tax prospect before Charles calls them. Use whenever he asks what is on the record about a lead, a prospect, or a caller — "run the record", "what can you find on", "check the liens", "is there a judgment", "look them up", "what does the public record say", "did they file anything", "check for a business", or "run enrichment on this lead". Also runs as the second half of the dossier when he asks for a full workup. Covers DC, Maryland, and Virginia land records and courts, federal courts, state business registries, and the federal tax lien index. Reports only what a named source states and never infers a financial picture.
---

# The public record pass

This runs before a call so the man on the phone is not the only source of
information about his own matter. It reports. It never concludes.

**Run this only when asked.** The dossier's first half stands alone, and a
record pass on a person who called for help is not automatic.

---

## The line that does not move

Report what a named source states, and nothing beyond it.

A recorded lien is a recorded lien. It is not evidence of an unpaid balance,
because liens sit on the record long after the debt behind them is satisfied.
A business registration is a registration; it says nothing about revenue,
distributions, or whether the entity still trades. A deed says what was paid on
a date, and nothing about what is owed now or what equity exists today.

**Never compute a financial picture from public records.** Equity, ability to
pay, and collection exposure are Item 6's work, and they run on transcripts and
client-supplied figures. Not on this.

**Never report an absence as a finding.** No result on a name search means the
search returned nothing. It does not mean no lien, no judgment, and no
property. Most of these indexes are partial, many are name-matched only, and a
common name defeats them all.

---

## Where to look

Search only what the matter needs. A DC wage-garnishment matter does not need
a Virginia land records pass.

**Federal tax liens.** Recorded at the county or district level, not federally
searchable in one place. DC at the Recorder of Deeds. Maryland at the Circuit
Court for the county of residence. Virginia at the Circuit Court clerk for the
city or county.

**Land records.** DC Recorder of Deeds. Maryland Land Records through
mdlandrec.net. Virginia through the individual Circuit Court clerk, which is
per-jurisdiction and often not free.

**Courts.** PACER for federal civil, and for bankruptcy, which matters more
than anything else on this list. A bankruptcy filing changes what collection
action is even lawful. DC Superior Court, Maryland Judiciary Case Search, and
Virginia's General District and Circuit Court systems for state civil and
judgments.

**Business registries.** DCRA CorpOnline, Maryland SDAT, Virginia SCC. These
establish whether an entity exists, its status, and its registered agent. A
revoked or forfeited entity is worth flagging, because it bears on who is
liable.

**Professional licensure** only when the matter turns on it, such as a
practitioner with a trust fund exposure.

---

## What to do with a match

Record it with the source, the date the record shows, and the identifier.
Then mark whether the identity is confirmed or possible.

A name match is a **possible** match. It becomes confirmed only when a second
element agrees: an address the prospect gave, a business name they named, or a
middle initial. Say which element confirmed it. In DC, Maryland, and Virginia a
common name will return other people's records, and putting another person's
judgment in front of Charles before a call is worse than returning nothing.

---

## What the pass is actually for

Three things, and they are all about the call.

**A bankruptcy or a pending court matter changes the conversation** before it
starts.

**A registered business the prospect did not mention** is worth knowing about,
because entity exposure and personal exposure are different problems.

**A recorded federal tax lien tells you the account has already been through
collection**, which bears on what the prospect believes about their own timeline.

Everything else is context.

---

## How it reports

Findings go into the dossier's public record section, each with its source and
its confidence. Where nothing was found, say the search ran and returned
nothing, and name the index searched. Where an index could not be reached, say
so plainly and name it. An index that was not searched and an index that
returned nothing are different facts, and the difference matters to a man
deciding whether to take a case.

Close with what the record does not cover. Federal and state tax account
balances are not public. Neither is filing history, income, or anything else
that decides this matter. The record pass narrows uncertainty at the margin,
and the transcripts settle it.

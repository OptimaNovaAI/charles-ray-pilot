# Where the records are

Charles practices before the IRS and the DC, Maryland, and Virginia taxing
authorities. These are the indexes that matter for those jurisdictions.

## Federal

| What | Where | Notes |
|---|---|---|
| Bankruptcy | PACER | The one that changes everything. An automatic stay bars collection action. |
| Civil | PACER | Suits for refund, government suits to reduce assessment to judgment. |
| Federal tax liens | County and district recorders, not PACER | Filed where the taxpayer lives. There is no single national index. |

## District of Columbia

| What | Where |
|---|---|
| Land records, deeds, liens | DC Recorder of Deeds |
| Civil, judgments | DC Superior Court |
| Business entities | DCRA CorpOnline |

## Maryland

| What | Where |
|---|---|
| Land records | mdlandrec.net, free with registration |
| Civil, judgments, criminal | Maryland Judiciary Case Search |
| Business entities, personal property | Maryland SDAT |

Maryland liens are recorded in the Circuit Court for the county of residence,
so the county has to be established before the search runs.

## Virginia

| What | Where |
|---|---|
| Land records | Circuit Court clerk, per jurisdiction. Often paid, rarely unified. |
| Civil, judgments | General District Court and Circuit Court case systems |
| Business entities | Virginia SCC Clerk's Information System |

Virginia is the hardest of the three. Its records are per-city and
per-county, and a search that misses the right jurisdiction returns nothing
while looking like a clean result. Always name the jurisdiction searched.

---

## What none of these will tell you

Federal and state tax account balances, filing history, assessment dates,
collection statute expiration dates, penalty and interest composition, and
anything about the taxpayer's income. Those live in the transcripts and come
in only after a power of attorney is on file.

A clean public record and a six-figure liability coexist comfortably. Never
let the absence of a lien read as the absence of a problem.

# The Playbook Record

`playbook.json` is the record. The page is drawn from it and from nothing else.
`scripts/playbook.py check` reads it, and `render` refuses to draw a page from a
record that fails any check below.

## Fields

| Field | What It Holds |
|---|---|
| `kind` | One of `Examination`, `Hearing`, `Appeals`, `Collection`, `Meeting`. Sets the title: Examination Conference Playbook, Hearing Playbook, Appeals Conference Playbook, Collection Conference Playbook, Meeting Playbook |
| `revision` | Whole number, 1 or more |
| `revised_at` | When this revision was written, ISO with offset, `2026-10-13T08:00:00-04:00` |
| `trigger` | What it was revised after, written to follow "Revised October 13, 2026, 8:00 AM," |
| `setting.official` | The agent, officer, settlement officer, or opposing counsel by name |
| `setting.role` | Revenue Agent, Revenue Officer, Settlement Officer, Appeals Officer, Trial Attorney |
| `setting.pronoun` | Optional. How the revision line refers to the official ("he"). Without it, "the Revenue Agent" |
| `setting.when` | The calendar's start, ISO with its offset. Printed in Eastern |
| `setting.dial_in` | The dial-in or the place |
| `setting.direct_line` | The official's direct line, for the critical change |
| `setting.taxpayer` | The taxpayer as the record names it |
| `setting.form` | The form under examination, `1120` |
| `setting.years` | The taxable years, `[2024]` |
| `setting.matter` | The matter number |
| `governing_record.document` | The record that governs over the playbook, such as `transmittal letter` |
| `governing_record.short` | Optional. How the revision line names it the second time, `transmittal` |
| `governing_record.date` | Its date |
| `governing_record.time` | Optional. The start time it states. When it differs from `setting.when`, a critical change is required |
| `governing_record.source` | Optional. Its id in `sources` |
| `changes[]` | `{lead, detail, critical}`. The lead prints bold; a critical change prints last, in dark red |
| `issues[]` | `{id, rank, title, stated, stated_source, likely_question, answer, support[], cautions[]}` |
| `issues[].id` | Optional but kept across revisions, so the diff follows an issue whose title changes |
| `issues[].stated` | True when the official named the issue in writing. Prints the STATED ISSUE tag |
| `issues[].stated_source` | The id of the source that names it |
| `issues[].support[]` | `{figure, source}`. The figure as it reads in the record, and the source id |
| `issues[].cautions[]` | `{text, do_not}`. A do-not caution prints in dark red |
| `open_items[]` | `{what, why}`. Everything the record does not hold |
| `sources[]` | `{id, title, date, kind, short}`. `short` is optional and is what column four prints; the full title prints under Sources |

A blank line inside an answer or a likely question starts a new paragraph.

## The Checks

Each failure is listed. The render writes nothing until the list is empty.

| Check | Refused When |
|---|---|
| Kind and revision | `kind` is not one of the five, or `revision` is not a whole number of 1 or more |
| Setting | `official`, `role`, `when`, `taxpayer`, or `matter` is empty |
| Start time | `setting.when` does not read as a date and time with its offset |
| Questions and answers | An issue has no likely question or no answer |
| Support | An issue has no support row, a row has no figure, or a row names a source not in `sources` |
| Number tracing | An answer uses a dollar amount, date, time, Bates number, percentage, form number, GL account, or any other figure of two or more digits that is not in that issue's support figures, the sources those rows name, the stated source, or the setting's form, years, and matter |
| Stated issues | A stated issue names no written source, or names one not in `sources` |
| Ranks | Ranks repeat, or do not run 1 to the number of issues |
| Time mismatch | The governing record's time differs from the calendar's and no critical change names both times |
| Revision order | A prior revision is given and this revision's number is not higher |
| Sources | A source has no id or title, or two sources share an id |

A Bates number inside a range a support row names counts as traced:
HMS-000230 traces to "HMS-000219 through HMS-000247". A dollar amount matches
with or without cents. A date matches in any of its spellings: October 9, 2026;
10/9/2026; 2026-10-09. A single digit is a count and is not traced.

## The Revision Diff

With the prior revision beside it, the changes box carries one computed
paragraph, "Against Revision N-1, issue by issue.", listing issues added,
dropped, moved in rank, and revised (question, answer, support, cautions, or
stated mark changed). Issues are matched by `id`, or by title when there is no
id. `python3 scripts/playbook.py diff new.json prior.json` prints the same.

## Not Yet in the Schema

Charles's Revision 4 standard carries four sections this record has no field
for yet:

- The narrative pages
- The decided-item box
- The do-not-raise list
- Housekeeping

They are set for a later version. Until then, when the standard in use has any
of these sections, say so plainly to Charles in one line, name which, and do
not force their content into issues, changes, or open items.

## The Week File

`playbook.py week` writes `week.json`:

| Field | What It Holds |
|---|---|
| `window` | First and last day read |
| `export`, `export_age_days` | The CARET export read and how old it is |
| `caret_health` | How Calendar.csv read: rows read, rows put back together, rows set aside by line, rows in the window |
| `caret_times` | How CARET's times were read against Outlook, by season, when measured this run |
| `caret_rows_in_window`, `caret_items_folded` | CARET rows in the window, and rows folded into one item filed under two matters |
| `standard`, `standard_line` | The gold standard file in use, or where to save one |
| `counted`, `outside_window` | Every calendar entry read, and how many fell outside the window |
| `sessions[]` | `{when, day, time, kind, trigger, subject, location, body, matters, found_in, caret_time_notes, disagreements, caret_notes, open_tasks}` |
| `set_aside[]` | Every deadline and all-day entry in the window, with the reason, and how a CARET time was read |
| `not_read[]` | Every other entry in the window that was not read as a session, with the reason |

Every note and task carries its CSV row, as `Notes.csv row 2`, for the source
list. Each CARET time says how it was read: moved by the measured offset, or
as written when no measurement exists yet.

# What Reads as a Session

A session is a scheduled meeting, conference, or hearing with an official or
opposing counsel. A due date is not a session, even when it names an official.

This list is Charles's to strike and add to. A change here goes into
`TRIGGERS`, `OFFICIAL_ABBR`, `MEETING_CUE`, and `DEADLINE` at the top of
`scripts/playbook.py`, so the rules that run and the rules on this page stay
the same.

## Where the Words Are Read

The subject and the location, in Outlook and in the CARET export's
`Calendar.csv`. The notes are not read for trigger words. CARET keeps whole
email threads in its notes, and a word in a forwarded email is not a session.

## In This Order

**1. Never.** `[no prep]` in the subject never counts. Use it on prep blocks.

**2. Set aside as a deadline.** A subject that reads as a due date, deadline,
reminder, or filing is set aside, never a session: due (but not "due
process"), deadline, reminder, remind, file by, filing, a subject that opens
with "File", last day, expire, postmark. A subject that also says meeting,
conference, call with, appointment, or interview stays a session ("Meeting
with RA re IDR due dates").

| Set Aside | Why |
|---|---|
| Client documents due (RO case) | due |
| File appeal reminder | reminder |
| IDR response due, RA Marsh | due |
| IDR #2 due to examiner Okafor | due |

**3. Set aside as all day.** An all-day entry is a deadline or a day marker
(a holiday), not a session.

**4. A session, by its words.** The first match names it and sets the
playbook's kind. Case does not matter.

| Name | Matches | Playbook Kind |
|---|---|---|
| CDP hearing | CDP, collection due process | Hearing |
| Tax Court | Tax Court, calendar call, trial | Hearing |
| Appeals | Appeal, Appeals | Appeals |
| Administrative hearing | OAH, administrative hearing, hearing officer | Hearing |
| Hearing | hearing | Hearing |
| Examination | examination, exam, audit, revenue agent, examiner | Examination |
| Revenue officer | revenue officer | Collection |
| Settlement conference | settlement conference | Appeals |
| Settlement officer | settlement officer | Appeals |
| Appeals officer | appeals officer | Appeals |

**5. A session, by an official's abbreviation.** RA, RO, SO, AO, and IDR,
uppercase as whole words, count when the subject also says it is a meeting:
meeting, mtg, conference, conf, call, appointment, interview, hearing, Zoom,
Teams, sit-down. "Meeting with RA Delgado" and "Call with RO Whitfield" are
sessions. "Follow up with RO" alone is a to-do and is listed as not read.

| Abbreviation | Name | Playbook Kind |
|---|---|---|
| RA | Revenue agent | Examination |
| RO | Revenue officer | Collection |
| SO | Settlement officer | Appeals |
| AO | Appeals officer | Appeals |
| IDR | IDR meeting | Examination |

**6. A conference with the Service or opposing counsel.** Conference or
meeting, with IRS, the Service, Chief Counsel, opposing counsel, DOJ, trial
attorney, counsel for the respondent, OTR, comptroller, department of revenue,
agent, or officer. Kind: Meeting.

**7. The Hearing category.** An Outlook or CARET category named Hearing always
counts.

## By Name

An IRS employee listed in IRS Contacts.txt (Claude AI Reports), named by
surname in the subject or location, with a meeting word, is a session. The
title on the line sets the kind. Day notes fills the list from his notes;
he can edit it.

## One Session per Matter per Day

When Outlook and CARET both carry the session, the two merge into one, and both
are named under where it was found. They merge when they share a matter, or
when their subjects name the same item, even worded slightly differently. One
item CARET files under two matters is one session naming both. When their start
times differ after CARET's time is read against Outlook, the disagreement is
carried into `week.json`, and the playbook treats it as a critical change.

## Nothing Is Dropped

Every entry in the window is counted. A set-aside entry is listed under
`set_aside` with the reason. An entry that did not read as a session is listed
under `not_read` with the reason, so a session named in a way this page does
not catch is seen and the word gets added here.

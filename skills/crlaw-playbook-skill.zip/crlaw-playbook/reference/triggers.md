# What Reads as a Session

This list is Charles's to strike and add to. A change here goes into
`TRIGGERS` at the top of `scripts/playbook.py`, so the list that runs and the
list on this page stay the same. The first eight rows are the hearing prep
skill's triggers, word for word, so both skills read the calendar the same way.

The engine reads the subject, the location, and the notes, in Outlook and in
the CARET export's `Calendar.csv`. The first match names the session and sets
the playbook's kind.

| Name | Matches | Playbook Kind |
|---|---|---|
| CDP hearing | CDP, collection due process | Hearing |
| Tax Court | Tax Court, calendar call, trial | Hearing |
| Appeals | Appeal, Appeals | Appeals |
| Administrative hearing | OAH, administrative hearing, hearing officer | Hearing |
| Hearing | hearing | Hearing |
| Examination | examination, exam, audit, revenue agent | Examination |
| Revenue officer | revenue officer | Collection |
| Settlement conference | settlement conference | Appeals |
| Conference with the Service or opposing counsel | conference or meeting, with IRS, the Service, Chief Counsel, opposing counsel, DOJ, trial attorney, counsel for the respondent, OTR, comptroller, department of revenue, agent, or officer | Meeting |

## Always and Never

- An Outlook category named **Hearing** always counts.
- **[no prep]** in the subject never counts. Use it on prep blocks.
- An all-day entry is a deadline, not a session. It is listed with that reason.

## One Session per Matter per Day

When Outlook and CARET both carry the session, the two merge into one, and both
are named under where it was found. When their start times differ, the
disagreement is carried into `week.json`, and the playbook treats it as a
critical change.

## Nothing Is Dropped

Every entry in the window is counted. An entry that did not read as a session
is listed by name with the reason, so a session named in a way this list does
not catch is seen and the word gets added here.

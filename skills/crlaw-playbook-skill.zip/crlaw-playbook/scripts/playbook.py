#!/usr/bin/env python3
"""
Conference and hearing playbooks for the Law Offices of Charles A. Ray, P.C.

    python3 playbook.py week   --events events.json [--export FirmExport.zip]
                               [--matters matters.json] [--start 2026-10-12]
                               [--days 7] --out week.json
    python3 playbook.py check  playbook.json [--prior prior.json]
    python3 playbook.py render playbook.json --out playbook.html [--prior prior.json]
    python3 playbook.py diff   playbook.json prior.json

week    Finds every examination, hearing, and conference with the Service or
        opposing counsel in the window, from the Outlook calendar (events.json)
        and the CARET export's Calendar.csv, and attaches each matter's CARET
        notes and open tasks. Every event in the window is counted; the ones
        that did not read as a session are listed with the reason.
check   Runs the checks in reference/schema.md. Any failure refuses the render
        and lists every failure, not only the first.
render  Checks, then writes one self-contained HTML file: the banner, the
        title, the setting line, the revision line, the changes box, the
        ranked issues table, open items, and sources. Nothing is written when
        a check fails.
diff    Prints what changed between two revisions: issues added, dropped,
        moved, and revised.

The prior revision is found by itself when it sits beside the playbook with
the revision number one lower in its name (M-0917 Examination Playbook R1.json
beside R2.json). --prior names it outright.

Exit codes: 0 clean, 2 refused, 1 bad input. Needs nothing installed.
"""

import argparse
import copy
import html as H
import json
import re
import sys
from datetime import date, datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import caret_export as CX  # noqa: E402

KINDS = ("Examination", "Hearing", "Appeals", "Collection", "Meeting")
TITLES = {
    "Examination": "Examination Conference Playbook",
    "Hearing": "Hearing Playbook",
    "Appeals": "Appeals Conference Playbook",
    "Collection": "Collection Conference Playbook",
    "Meeting": "Meeting Playbook",
}
BANNER = ("Privileged and Confidential", "Attorney Work Product",
          "Prepared in Anticipation of Controversy", "Not to Be Produced")

# What reads as a session. The first eight are the hearing prep triggers, word
# for word, so the two skills see the same calendar. The last is a conference
# or meeting with the Service or opposing counsel. Charles strikes and adds in
# reference/triggers.md; the list here is the one that runs.
TRIGGERS = [
    ("CDP hearing", "Hearing", r"\bCDP\b|collection due process"),
    ("Tax Court", "Hearing", r"tax court|calendar call|\btrial\b"),
    ("Appeals", "Appeals", r"\bappeals?\b"),
    ("Administrative hearing", "Hearing", r"\bOAH\b|administrative hearing|hearing officer"),
    ("Hearing", "Hearing", r"\bhearing\b"),
    ("Examination", "Examination", r"\bexamination\b|\baudit\b|revenue agent|\bexam\b"),
    ("Revenue officer", "Collection", r"revenue officer"),
    ("Settlement conference", "Appeals", r"settlement conference"),
]
MEETING_WORD = re.compile(r"\bconference\b|\bmeeting\b", re.I)
COUNTERPARTY = re.compile(
    r"\bIRS\b|internal revenue|\bthe service\b|opposing counsel|chief counsel|\bDOJ\b|"
    r"department of justice|government counsel|trial attorney|counsel for (?:the )?"
    r"(?:respondent|commissioner|government)|\bOTR\b|comptroller|department of revenue|"
    r"\bDOR\b|\bagent\b|\bofficer\b", re.I)
OPT_IN_CATEGORY = "hearing"
OPT_OUT = re.compile(r"\[no prep\]", re.I)

NUMBER_WORDS = ["no", "one", "two", "three", "four", "five", "six", "seven", "eight",
                "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen",
                "sixteen", "seventeen", "eighteen", "nineteen", "twenty"]
MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August",
          "September", "October", "November", "December"]
MON_IX = {m[:3].lower(): i + 1 for i, m in enumerate(MONTHS)}


def words(n):
    return NUMBER_WORDS[n] if 0 <= n < len(NUMBER_WORDS) else str(n)


# ================================================================== numbers

RE_DATE_LONG = re.compile(
    r"\b(Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|June?|July?|Aug(?:ust)?|"
    r"Sep(?:t(?:ember)?)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\.?\s+(\d{1,2})"
    r"(?:st|nd|rd|th)?\b(?:,?\s+(\d{4})\b)?")
RE_DATE_NUM = re.compile(r"\b(\d{1,2})/(\d{1,2})/(\d{4}|\d{2})\b")
RE_DATE_ISO = re.compile(r"\b(\d{4})-(\d{2})-(\d{2})\b")
RE_TIME = re.compile(r"\b(\d{1,2}):(\d{2})(?:\s*([AaPp])\.?\s?[Mm]\.?)?")
BATES = r"[A-Z]{2,}[-_]?\d{4,}"
RE_BATES_RANGE = re.compile(rf"\b({BATES})\s*(?:through|thru|to|-|–)\s*({BATES})\b")
RE_BATES = re.compile(rf"\b({BATES})\b")
RE_MONEY = re.compile(r"\$\s?(\d[\d,]*(?:\.\d+)?)")
RE_PCT = re.compile(r"(\d+(?:\.\d+)?)\s?(?:%|percent\b)")
RE_NUM = re.compile(r"(?<![\w.])(\d[\d,]*(?:\.\d+)?)")


def canon_num(s):
    s = s.replace(",", "")
    if "." in s:
        s = s.rstrip("0").rstrip(".")
    return s


def bates_split(b):
    m = re.match(r"([A-Z]+)[-_]?(\d+)$", b)
    return m.group(1), int(m.group(2)), len(m.group(2))


def extract(text):
    """Every figure in a piece of text, by kind. Dates, times, and Bates
    numbers are taken out first so their digits are not read twice."""
    t = str(text or "")
    out = {"dates": [], "monthdays": [], "times": [], "bates": [], "ranges": [],
           "nums": [], "raw": []}

    def blank(m):
        return " " * (m.end() - m.start())

    def long_date(m):
        mon = MON_IX[m.group(1)[:3].lower()]
        day = int(m.group(2))
        if not 1 <= day <= 31:
            return m.group(0)
        if m.group(3):
            out["dates"].append(f"{int(m.group(3)):04d}-{mon:02d}-{day:02d}")
        else:
            out["monthdays"].append(f"{mon:02d}-{day:02d}")
        out["raw"].append(m.group(0))
        return blank(m)

    def num_date(m):
        mo, d, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if y < 100:
            y += 2000
        if 1 <= mo <= 12 and 1 <= d <= 31:
            out["dates"].append(f"{y:04d}-{mo:02d}-{d:02d}")
            out["raw"].append(m.group(0))
            return blank(m)
        return m.group(0)

    def iso_date(m):
        out["dates"].append(m.group(0))
        out["raw"].append(m.group(0))
        return blank(m)

    def tm(m):
        h, mi = int(m.group(1)), m.group(2)
        h12 = h % 12 or 12
        out["times"].append(f"{h12}:{mi}")
        out["raw"].append(m.group(0))
        return blank(m)

    def brange(m):
        a, b = m.group(1), m.group(2)
        out["ranges"].append((a, b))
        out["bates"].extend([a, b])
        out["raw"].append(m.group(0))
        return blank(m)

    def bates(m):
        out["bates"].append(m.group(1))
        out["raw"].append(m.group(0))
        return blank(m)

    def money(m):
        out["nums"].append(canon_num(m.group(1)))
        out["raw"].append(m.group(0))
        return blank(m)

    t = RE_DATE_LONG.sub(long_date, t)
    t = RE_DATE_ISO.sub(iso_date, t)
    t = RE_DATE_NUM.sub(num_date, t)
    t = RE_TIME.sub(tm, t)
    t = RE_BATES_RANGE.sub(brange, t)
    t = RE_BATES.sub(bates, t)
    t = RE_MONEY.sub(money, t)

    def pct(m):
        out["nums"].append(canon_num(m.group(1)))
        out["raw"].append(m.group(0))
        return blank(m)

    t = RE_PCT.sub(pct, t)
    for m in RE_NUM.finditer(t):
        v = canon_num(m.group(1))
        if not v or (len(v) == 1 and "." not in v):
            continue  # a single digit is a count, not a figure
        out["nums"].append(v)
        out["raw"].append(m.group(1))
    return out


class Haystack:
    """The figures an answer may use: its issue's support figures, the sources
    those rows name, the written source of a stated issue, and the setting."""

    def __init__(self, texts):
        self.dates, self.mds, self.times, self.bates, self.nums = set(), set(), set(), set(), set()
        self.ranges = []
        for t in texts:
            e = extract(t)
            self.dates.update(e["dates"])
            self.mds.update(e["monthdays"])
            self.mds.update(d[5:] for d in e["dates"])
            self.nums.update(d[:4] for d in e["dates"])
            self.times.update(e["times"])
            self.bates.update(e["bates"])
            self.ranges.extend(e["ranges"])
            self.nums.update(e["nums"])

    def has_bates(self, b):
        if b in self.bates:
            return True
        p, n, _ = bates_split(b)
        for a, z in self.ranges:
            pa, na, _ = bates_split(a)
            pz, nz, _ = bates_split(z)
            if p == pa == pz and na <= n <= nz:
                return True
        return any(bates_split(x)[:2] == (p, n) for x in self.bates)


def untraced(answer, hay):
    e = extract(answer)
    miss = []
    for d in e["dates"]:
        if d not in hay.dates:
            miss.append(("date", d))
    for md in e["monthdays"]:
        if md not in hay.mds:
            miss.append(("date", md))
    for t in e["times"]:
        if t not in hay.times:
            miss.append(("time", t))
    for b in e["bates"]:
        if not hay.has_bates(b):
            miss.append(("Bates number", b))
    for n in e["nums"]:
        if n not in hay.nums:
            miss.append(("figure", n))
    return miss


# ================================================================== time

def parse_when(s):
    """ISO date-time with an offset, as Eastern. None if it does not read."""
    s = str(s or "").strip()
    if not re.match(r"^\d{4}-\d{2}-\d{2}[T ]\d{1,2}:\d{2}(:\d{2})?(\.\d+)?(Z|[+-]\d{2}:?\d{2})$", s):
        return None
    dt, has_time = CX.parse_dt(s)
    return dt if has_time else None


def parse_clock(s):
    """'10:30 AM', '10:30 a.m.', '14:30', '10:30'. Returns (hour24, minute)
    or None. A bare time from 1:00 to 6:59 without a meridiem is taken as
    afternoon, the way a conference is set."""
    m = re.search(r"(\d{1,2}):(\d{2})\s*([AaPp])?\.?\s?[Mm]?\.?", str(s or ""))
    if not m:
        return None
    h, mi, ap = int(m.group(1)), int(m.group(2)), (m.group(3) or "").lower()
    if ap == "p" and h < 12:
        h += 12
    elif ap == "a" and h == 12:
        h = 0
    elif not ap and 1 <= h <= 6:
        h += 12
    return h, mi


def fmt_clock(h, mi):
    ap = "AM" if h < 12 else "PM"
    return f"{h % 12 or 12}:{mi:02d} {ap}"


def fmt_date(d):
    return f"{MONTHS[d.month - 1]} {d.day}, {d.year}"


def fmt_day(d):
    return f"{d.strftime('%A')}, {fmt_date(d)}"


def fmt_any_date(s):
    s = str(s or "").strip()
    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})$", s)
    if m:
        return fmt_date(date(int(m.group(1)), int(m.group(2)), int(m.group(3))))
    return s


def time_mismatch(pb):
    """(record time, calendar time) as text when the governing record states a
    time that differs from the calendar's, else None."""
    gr = pb.get("governing_record") or {}
    rec = parse_clock(gr.get("time"))
    when = parse_when((pb.get("setting") or {}).get("when"))
    if not rec or not when:
        return None
    cal = (when.hour, when.minute)
    if rec == cal:
        return None
    return fmt_clock(*rec), fmt_clock(*cal)


# ================================================================== diff

def issue_key(i):
    return str(i.get("id") or re.sub(r"[^a-z0-9]+", " ", str(i.get("title", "")).lower()).strip())


def diff(prior, new):
    old = {issue_key(i): i for i in prior.get("issues", [])}
    cur = {issue_key(i): i for i in new.get("issues", [])}
    added = [cur[k] for k in cur if k not in old]
    dropped = [old[k] for k in old if k not in cur]
    moved, revised = [], []
    for k in cur:
        if k in old:
            a, b = old[k], cur[k]
            if a.get("rank") != b.get("rank"):
                moved.append((b, a.get("rank"), b.get("rank")))
            if (a.get("answer") != b.get("answer") or a.get("support") != b.get("support")
                    or a.get("cautions") != b.get("cautions")
                    or a.get("likely_question") != b.get("likely_question")
                    or bool(a.get("stated")) != bool(b.get("stated"))):
                revised.append(b)
    return {"from": prior.get("revision"), "to": new.get("revision"),
            "added": sorted(added, key=lambda i: i.get("rank", 0)),
            "dropped": sorted(dropped, key=lambda i: i.get("rank", 0)),
            "moved": sorted(moved, key=lambda x: x[0].get("rank", 0)),
            "revised": sorted(revised, key=lambda i: i.get("rank", 0))}


def diff_sentences(d):
    parts = []
    if d["added"]:
        parts.append("Added: " + "; ".join(f"{i.get('title')} (rank {i.get('rank')})" for i in d["added"]) + ".")
    if d["dropped"]:
        parts.append("Dropped: " + "; ".join(f"{i.get('title')} (was rank {i.get('rank')})" for i in d["dropped"]) + ".")
    if d["moved"]:
        parts.append("Moved: " + "; ".join(f"{i.get('title')}, rank {a} to {b}" for i, a, b in d["moved"]) + ".")
    if d["revised"]:
        parts.append("Revised: " + "; ".join(f"{i.get('title')}" for i in d["revised"]) + ".")
    if not parts:
        parts.append("No issue was added, dropped, moved, or revised.")
    return " ".join(parts)


def find_prior(path, pb):
    p = Path(path)
    n = pb.get("revision")
    if not isinstance(n, int) or n < 2:
        return None
    m = list(re.finditer(r"(R|Rev(?:ision)?[ ._-]?)(\d+)", p.stem, re.I))
    if not m:
        return None
    last = m[-1]
    if int(last.group(2)) != n:
        return None
    stem = p.stem[:last.start(2)] + str(n - 1) + p.stem[last.end(2):]
    q = p.with_name(stem + p.suffix)
    return q if q.exists() else None


# ================================================================== check

def check(pb, prior=None):
    """Every failure, as a list of plain sentences. Empty means it renders."""
    errs = []
    if not isinstance(pb, dict):
        return ["The playbook is not a JSON object."]
    kind = pb.get("kind")
    if kind not in KINDS:
        errs.append(f"kind is {kind!r}; it must be one of {', '.join(KINDS)}.")
    rev = pb.get("revision")
    if not isinstance(rev, int) or rev < 1:
        errs.append("revision must be a whole number, 1 or more.")
    if not str(pb.get("trigger") or "").strip():
        errs.append("trigger is empty: say what this revision was revised after.")
    if pb.get("revised_at") and not parse_when(pb.get("revised_at")):
        errs.append(f"revised_at {pb.get('revised_at')!r} does not read as a date and time with an offset.")

    st = pb.get("setting") or {}
    for f in ("official", "role", "when", "taxpayer", "matter"):
        if not str(st.get(f) or "").strip():
            errs.append(f"setting.{f} is empty.")
    if st.get("when") and not parse_when(st.get("when")):
        errs.append(f"setting.when {st.get('when')!r} does not read as a date and time with its offset, "
                    "such as 2026-10-15T10:00:00-04:00.")

    sources = pb.get("sources") or []
    ids = [str(s.get("id") or "") for s in sources]
    for s in sources:
        if not str(s.get("id") or "").strip() or not str(s.get("title") or "").strip():
            errs.append(f"A source has no id or no title: {json.dumps(s)[:80]}.")
    dup = sorted({i for i in ids if i and ids.count(i) > 1})
    if dup:
        errs.append(f"Source ids repeat: {', '.join(dup)}.")
    by_id = {str(s.get("id")): s for s in sources}

    gr = pb.get("governing_record") or {}
    if gr and not str(gr.get("document") or "").strip():
        errs.append("governing_record names no document.")
    if gr.get("source") and str(gr["source"]) not in by_id:
        errs.append(f"governing_record.source {gr['source']} is not in sources.")
    if gr.get("time") and not parse_clock(gr.get("time")):
        errs.append(f"governing_record.time {gr.get('time')!r} does not read as a time.")

    issues = pb.get("issues") or []
    if not issues:
        errs.append("There are no issues.")
    ranks = []
    for n, i in enumerate(issues, 1):
        name = f"Issue {i.get('rank', '?')} ({str(i.get('title') or 'untitled')[:50]})"
        r = i.get("rank")
        if not isinstance(r, int):
            errs.append(f"Issue at position {n} has no whole-number rank.")
        else:
            ranks.append(r)
        if not str(i.get("title") or "").strip():
            errs.append(f"Issue at position {n} has no title.")
        if not str(i.get("likely_question") or "").strip():
            errs.append(f"{name}: no likely question.")
        if not str(i.get("answer") or "").strip():
            errs.append(f"{name}: no answer.")
        sup = i.get("support") or []
        if not sup:
            errs.append(f"{name}: no support row. Every answer needs at least one figure and its source.")
        for s in sup:
            if not str(s.get("figure") or "").strip():
                errs.append(f"{name}: a support row has no figure.")
            src = str(s.get("source") or "")
            if not src:
                errs.append(f"{name}: support row {str(s.get('figure'))[:40]!r} names no source.")
            elif src not in by_id:
                errs.append(f"{name}: support row {str(s.get('figure'))[:40]!r} names source {src}, "
                            "which is not in sources.")
        if i.get("stated"):
            ss = str(i.get("stated_source") or "")
            if not ss:
                errs.append(f"{name}: marked STATED ISSUE but names no written source.")
            elif ss not in by_id:
                errs.append(f"{name}: stated_source {ss} is not in sources.")
        for c in i.get("cautions") or []:
            if not str(c.get("text") or "").strip():
                errs.append(f"{name}: a caution is empty.")
        # number tracing
        texts = [s.get("figure", "") for s in sup]
        for s in sup:
            src = by_id.get(str(s.get("source")))
            if src:
                texts += [src.get("title", ""), src.get("short", ""), str(src.get("date", ""))]
        if i.get("stated") and str(i.get("stated_source")) in by_id:
            src = by_id[str(i.get("stated_source"))]
            texts += [src.get("title", ""), str(src.get("date", ""))]
        texts += [str(st.get("form", "")), " ".join(str(y) for y in (st.get("years") or [])),
                  str(st.get("matter", ""))]
        miss = untraced(i.get("answer", ""), Haystack(texts))
        if miss:
            listed = ", ".join(f"{k} {v}" for k, v in miss)
            errs.append(f"{name}: the answer uses {listed}, found in no support figure or source of this "
                        "issue. Add the support row that carries it, or move it to Open Items.")
    if ranks:
        dups = sorted({r for r in ranks if ranks.count(r) > 1})
        if dups:
            errs.append(f"Ranks repeat: {', '.join(map(str, dups))}.")
        want = list(range(1, len(issues) + 1))
        if sorted(ranks) != want and not dups:
            errs.append(f"Ranks must run 1 to {len(issues)} with no gap; they are {sorted(ranks)}.")

    for c in pb.get("changes") or []:
        if not str(c.get("lead") or "").strip():
            errs.append("A change has no lead sentence.")
    for o in pb.get("open_items") or []:
        if not str(o.get("what") or "").strip():
            errs.append("An open item does not say what is open.")

    mm = time_mismatch(pb)
    if mm:
        rec_t, cal_t = mm
        doc = gr.get("document", "the governing record")
        crit = [c for c in pb.get("changes") or [] if c.get("critical")]
        named = False
        for c in crit:
            ts = set(extract(f"{c.get('lead', '')} {c.get('detail', '')}")["times"])
            if rec_t.split()[0] in ts and cal_t.split()[0] in ts:
                named = True
        if not named:
            errs.append(f"Time mismatch: {doc} says {rec_t}; the calendar says {cal_t}. "
                        "No critical change states both times. Add a change with critical: true that "
                        "names both and says when to be on the line and whom to call.")

    if prior is not None and isinstance(rev, int):
        pr = prior.get("revision")
        if isinstance(pr, int) and rev <= pr:
            errs.append(f"This is Revision {rev} but the prior is Revision {pr}. A new revision "
                        "carries a higher number.")
    return errs


# ================================================================== render

CSS = """
:root{--ink:#111;--muted:#444;--rule:#222;--red:#8b1a1a;--paper:#fff;--soft:#f4f1ea}
*{box-sizing:border-box}
html,body{margin:0;padding:0;background:var(--paper);color:var(--ink)}
body{font-family:"Times New Roman",Times,"Nimbus Roman","Liberation Serif",Georgia,serif;
 font-size:16px;line-height:1.38;overflow-x:hidden}
.page{max-width:1120px;margin:0 auto;padding:28px 40px 48px}
.banner{border:1px solid var(--rule);text-align:center;font-variant:small-caps;
 letter-spacing:.04em;font-size:14.5px;padding:5px 10px;margin:0 0 14px;overflow-wrap:anywhere}
.banner span.dot{padding:0 .45em}
h1{font-size:26px;margin:0 0 6px;font-weight:bold;line-height:1.2}
.setting{font-size:17px;margin:0 0 6px;overflow-wrap:anywhere}
.revline{margin:0 0 12px;overflow-wrap:anywhere}
.tag{display:inline-block;font-variant:all-small-caps;font-size:12.5px;letter-spacing:.06em;
 border:1px solid var(--rule);color:var(--ink);padding:0 4px;line-height:1.3;vertical-align:1px;white-space:nowrap}
.changes{border:1.5px solid var(--rule);border-left:7px solid var(--red);padding:10px 16px 6px;margin:0 0 22px}
.changes h2{font-size:16px;margin:0 0 8px}
.changes p{margin:0 0 9px}
.changes .crit{color:var(--red);font-weight:bold}
.changes .computed{color:var(--muted)}
h2.sec{font-size:19px;margin:26px 0 8px;border-bottom:1px solid var(--rule);padding-bottom:3px}
.tablewrap{width:100%;overflow-x:auto;-webkit-overflow-scrolling:touch}
table.issues{border-collapse:collapse;width:100%;min-width:900px;font-size:14px;line-height:1.34}
table.issues th,table.issues td{border:1px solid var(--rule);padding:6px 7px;vertical-align:top;text-align:left}
table.issues thead th{background:var(--soft);font-size:13.5px}
table.issues td.issue{width:17%}
table.issues td.q{width:17%}
table.issues td.ans{width:26%}
table.issues td.sup{width:22%}
table.issues td.cau{width:18%}
.rank{font-weight:bold;font-size:17px;display:block}
.ititle{font-weight:bold;display:block;margin:2px 0 4px}
.named{font-size:12.5px;color:var(--muted);display:block;margin-top:4px}
.sup ul,.cau ul{list-style:none;margin:0;padding:0}
.sup li,.cau li{margin:0 0 6px}
.fig{display:block}
.src{display:block;font-size:12.5px;color:var(--muted)}
.src b{color:var(--ink);font-weight:normal;font-variant:small-caps}
.cau li.donot{color:var(--red);font-weight:bold}
.ans p,.q p{margin:0 0 6px}
table.plain{border-collapse:collapse;width:100%;font-size:14.5px}
table.plain th,table.plain td{border-bottom:1px solid #999;padding:5px 6px;text-align:left;vertical-align:top}
table.plain td.id{white-space:nowrap;font-variant:small-caps;width:4.5em}
.none{color:var(--muted)}
.foot{margin-top:26px;font-size:12px;color:var(--muted);border-top:1px solid #999;padding-top:6px}
@media (max-width:600px){
 .page{padding:16px 16px 32px}
 h1{font-size:21px}
 .setting{font-size:15.5px}
 body{font-size:15px}
 .banner{font-size:12.5px}
 .plainwrap{overflow-x:auto}
}
@page{size:letter;margin:0.55in 0.5in 0.6in}
@media print{
 body{font-size:11pt}
 .page{max-width:none;padding:0}
 .tablewrap{overflow:visible}
 table.issues{min-width:0;font-size:8.6pt}
 table.issues thead{display:table-header-group}
 table.issues tr{break-inside:auto;page-break-inside:auto}
 table.issues td,table.issues th{padding:4px 5px}
 .changes{break-inside:avoid}
 h2.sec{break-after:avoid;page-break-after:avoid}
 .banner,.tag,.changes,table.issues thead th{-webkit-print-color-adjust:exact;print-color-adjust:exact}
}
"""


def e(s):
    return H.escape(str(s if s is not None else ""))


def paras(s):
    parts = [p.strip() for p in re.split(r"\n\s*\n", str(s or "")) if p.strip()]
    return "".join(f"<p>{e(p)}</p>" for p in parts) or ""


def setting_line(pb):
    st = pb["setting"]
    when = parse_when(st["when"])
    bits = [f"{e(st.get('role'))} {e(st.get('official'))}"]
    w = f"{fmt_day(when)}, {fmt_clock(when.hour, when.minute)} Eastern"
    if st.get("dial_in"):
        w += f", dial-in {st['dial_in']}"
    bits.append(e(w))
    bits.append(e(st.get("taxpayer")))
    years = st.get("years") or []
    if st.get("form") or years:
        ys = [str(y) for y in years]
        if len(ys) == 1:
            yt = f"taxable year {ys[0]}"
        elif ys:
            yt = "taxable years " + ", ".join(ys[:-1]) + (" and " if len(ys) == 2 else ", and ") + ys[-1]
        else:
            yt = ""
        f = f"Form {st['form']}" if st.get("form") and not str(st["form"]).lower().startswith("form") else str(st.get("form") or "")
        bits.append(e(", ".join(x for x in (f, yt) if x)))
    m = str(st.get("matter"))
    bits.append(e(m if m.lower().startswith("matter") else f"Matter {m}"))
    return " · ".join(bits)


def revision_line(pb, by_id):
    issues = pb["issues"]
    st = pb["setting"]
    pron = st.get("pronoun") or f"the {st.get('role', 'agent')}"
    out = []
    ra = parse_when(pb.get("revised_at")) if pb.get("revised_at") else None
    trig = str(pb.get("trigger") or "").strip().rstrip(".")
    if ra:
        out.append(f"Revised {e(fmt_date(ra))}, {e(fmt_clock(ra.hour, ra.minute))}, {e(trig)}.")
    else:
        out.append(f"Revised {e(trig)}.")
    n = len(issues)
    out.append(f"{e(words(n).capitalize())} issue{'s' if n != 1 else ''}, ranked by the probability "
               f"{e(pron)} raises them.")
    stated = [i for i in issues if i.get("stated")]
    if stated:
        dates = []
        for i in stated:
            d = fmt_any_date(by_id.get(str(i.get("stated_source")), {}).get("date", ""))
            if d and d not in dates:
                dates.append(d)
        when = (" on " + " and ".join(dates)) if dates else ""
        if len(stated) == 1:
            out.append(f'The one marked <span class="tag">Stated Issue</span> is the one {e(pron)} named in writing{e(when)}.')
        else:
            out.append(f'The {e(words(len(stated)))} marked <span class="tag">Stated Issue</span> are the ones '
                       f"{e(pron)} named in writing{e(when)}.")
    out.append("Every figure in column four traces to the source named there.")
    rev = pb["revision"]
    if rev > 1:
        out.append(f"Where this revision and Revision {rev - 1} differ, this revision governs.")
    gr = pb.get("governing_record") or {}
    if gr.get("document"):
        short = gr.get("short") or gr["document"]
        dt = fmt_any_date(gr.get("date", ""))
        doc = f"{gr['document']}" + (f" dated {dt}" if dt and dt not in gr["document"] else "")
        out.append(f"Where this revision and the {e(doc)} differ, the {e(short)} governs, because it is the record.")
    return " ".join(out)


def changes_box(pb, d):
    rev = pb["revision"]
    head = "What changed in this revision." if rev > 1 else "What this revision rests on."
    rows = []
    ch = pb.get("changes") or []
    for c in [c for c in ch if not c.get("critical")]:
        rows.append(f"<p><b>{e(c['lead'].strip())}</b> {e(c.get('detail', ''))}</p>")
    if d is not None:
        rows.append(f'<p class="computed"><b>Against Revision {e(d["from"])}, issue by issue.</b> '
                    f"{e(diff_sentences(d))}</p>")
    for c in [c for c in ch if c.get("critical")]:
        rows.append(f'<p class="crit">{e(c["lead"].strip())} {e(c.get("detail", ""))}</p>')
    if not rows:
        return ""
    return f'<section class="changes"><h2>{head}</h2>{"".join(rows)}</section>'


def issue_row(i, by_id):
    tag = ' <span class="tag">Stated Issue</span>' if i.get("stated") else ""
    named = ""
    if i.get("stated"):
        s = by_id.get(str(i.get("stated_source")), {})
        named = (f'<span class="named">Named in writing: {e(s.get("title", ""))}'
                 f'{", " + e(fmt_any_date(s.get("date"))) if s.get("date") else ""}</span>')
    sup = []
    for s in i.get("support") or []:
        src = by_id.get(str(s.get("source")), {})
        dt = fmt_any_date(src.get("date", ""))
        sup.append(f'<li><span class="fig">{e(s.get("figure"))}</span>'
                   f'<span class="src"><b>{e(s.get("source"))}</b> {e(src.get("short") or src.get("title", ""))}'
                   f'{", " + e(dt) if dt else ""}</span></li>')
    cau = []
    for c in i.get("cautions") or []:
        cls = ' class="donot"' if c.get("do_not") else ""
        cau.append(f"<li{cls}>{e(c.get('text'))}</li>")
    return (f'<tr id="issue-{e(i["rank"])}"><td class="issue"><span class="rank">{e(i["rank"])}</span>'
            f'<span class="ititle">{e(i.get("title"))}</span>{tag}{named}</td>'
            f'<td class="q">{paras(i.get("likely_question"))}</td>'
            f'<td class="ans">{paras(i.get("answer"))}</td>'
            f'<td class="sup"><ul>{"".join(sup)}</ul></td>'
            f'<td class="cau">{"<ul>" + "".join(cau) + "</ul>" if cau else ""}</td></tr>')


def render(pb, prior=None, generated=None):
    by_id = {str(s.get("id")): s for s in pb.get("sources") or []}
    d = diff(prior, pb) if prior is not None else None
    title = f"{TITLES[pb['kind']]}, Revision {pb['revision']}"
    banner = '<span class="dot">·</span>'.join(e(b) for b in BANNER)
    issues = sorted(pb["issues"], key=lambda i: i["rank"])
    rows = "".join(issue_row(i, by_id) for i in issues)
    opens = pb.get("open_items") or []
    if opens:
        open_html = ('<div class="plainwrap"><table class="plain"><thead><tr><th>Open Item</th><th>Why It Is Open</th>'
                     "</tr></thead><tbody>" +
                     "".join(f"<tr><td>{e(o.get('what'))}</td><td>{e(o.get('why', ''))}</td></tr>" for o in opens) +
                     "</tbody></table></div>")
    else:
        open_html = '<p class="none">None. Everything above traces to the record listed under Sources.</p>'
    srcs = "".join(f'<tr><td class="id">{e(s.get("id"))}</td><td>{e(s.get("title"))}</td>'
                   f'<td>{e(fmt_any_date(s.get("date", "")))}</td><td>{e(s.get("kind", ""))}</td></tr>'
                   for s in pb.get("sources") or [])
    nsup = sum(len(i.get("support") or []) for i in issues)
    gen = generated or datetime.now().strftime("%Y-%m-%d %H:%M")
    st = pb["setting"]
    return f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{e(title)} · {e(st.get('matter'))}</title>
<style>{CSS}</style></head>
<body><div class="page">
<div class="banner">{banner}</div>
<h1>{e(title)}</h1>
<p class="setting">{setting_line(pb)}</p>
<p class="revline">{revision_line(pb, by_id)}</p>
{changes_box(pb, d)}
<h2 class="sec">The Issues, Ranked</h2>
<div class="tablewrap"><table class="issues">
<thead><tr><th>Rank and Issue</th><th>Likely Question</th><th>Answer</th><th>Support</th><th>Cautions</th></tr></thead>
<tbody>{rows}</tbody></table></div>
<h2 class="sec">Open Items</h2>
{open_html}
<h2 class="sec">Sources</h2>
<div class="plainwrap"><table class="plain"><thead><tr><th>Id</th><th>Source</th><th>Date</th><th>Kind</th></tr></thead>
<tbody>{srcs}</tbody></table></div>
<p class="foot">Attorney work product prepared at the direction of counsel. Rendered {e(gen)} from the checked record:
{len(issues)} issues, {nsup} support rows, {len(pb.get('sources') or [])} sources, {len(opens)} open items.</p>
</div></body></html>
"""


# ================================================================== week

def classify(subject, location="", body="", categories=()):
    """(trigger name, playbook kind) or (None, reason)."""
    text = f"{subject} {location} {body}"
    if OPT_OUT.search(str(subject or "")):
        return None, "marked [no prep]"
    for name, kind, pat in TRIGGERS:
        if re.search(pat, text, re.I):
            return name, kind
    if MEETING_WORD.search(text) and COUNTERPARTY.search(text):
        return "Conference with the Service or opposing counsel", "Meeting"
    if any(str(c).strip().lower() == OPT_IN_CATEGORY for c in categories or []):
        return "Hearing category", "Hearing"
    return None, "no trigger word"


def _matters(exp, matters_path):
    out = []
    if exp:
        for r in CX.read_table(exp, "Matter"):
            num, name = CX.split_matter(CX.col(r, "MatterNumber"), CX.col(r, "MatterName"))
            client = CX.col(r, "Client")
            out.append({"matter": num, "name": name, "aliases": [a for a in (name, client) if a]})
    if matters_path:
        for m in json.loads(Path(matters_path).read_text(encoding="utf-8")):
            num = str(m.get("matter", ""))
            al = [a for a in [m.get("client")] + list(m.get("aliases") or []) if a]
            hit = next((x for x in out if x["matter"] == num), None)
            if hit:
                hit["aliases"] += al
            else:
                out.append({"matter": num, "name": m.get("client", ""), "aliases": al})
    return out


def _match_matter(text, matters):
    hits = []
    for m in matters:
        num = m["matter"]
        if num and re.search(rf"(?<![\w-]){re.escape(num)}(?![\w])", text):
            hits.append(m["matter"])
            continue
        for a in m["aliases"]:
            if len(a) > 3 and re.search(rf"\b{re.escape(a)}\b", text, re.I):
                hits.append(m["matter"])
                break
    return sorted(set(hits))


def week(events_path=None, export=None, matters_path=None, start=None, days=7):
    start = start or date.today()
    end = start + timedelta(days=days)
    exp = CX.find_export(export) if export != "none" else None
    matters = _matters(exp, matters_path)
    raw = []
    if events_path:
        ev = json.loads(Path(events_path).read_text(encoding="utf-8"))
        for x in ev.get("events", ev if isinstance(ev, list) else []):
            dt, has_t = CX.parse_dt(x.get("start"))
            text = f"{x.get('subject', '')} {x.get('location', '')} {x.get('body', '')}"
            raw.append({"source": "Outlook", "ref": x.get("id", ""), "subject": x.get("subject", ""),
                        "location": x.get("location", ""), "body": x.get("body", ""),
                        "categories": x.get("categories") or [], "start": dt, "timed": has_t,
                        "matters": _match_matter(text, matters), "raw_start": x.get("start")})
    if exp:
        for r in CX.read_table(exp, "Calendar"):
            dt, has_t = CX.parse_dt(CX.col(r, "FromDate", "StartDate", "Start*"))
            allday = CX.truthy(CX.col(r, "IsAllday", "AllDay"))
            num, _ = CX.split_matter(CX.col(r, "MatterNumber"))
            subj = CX.col(r, "Subject")
            body = CX.clean_text(CX.col(r, "Descrption", "Description"))
            text = f"{subj} {CX.col(r, 'Location')} {body}"
            ms = [num] if num else _match_matter(text, matters)
            cat = CX.col(r, "CategoryName")
            raw.append({"source": "CARET", "ref": f"{r['_file']} row {r['_row']}", "subject": subj,
                        "location": CX.col(r, "Location"), "body": body,
                        "categories": [cat] if cat and cat != "None" else [],
                        "start": dt, "timed": has_t and not allday, "matters": ms,
                        "raw_start": CX.col(r, "FromDate")})
    sessions, not_read, outside = [], [], 0
    for x in raw:
        if x["start"] is None:
            not_read.append({"subject": x["subject"], "source": x["source"], "ref": x["ref"],
                             "reason": f"start {x['raw_start']!r} does not read as a date"})
            continue
        if not (start <= x["start"].date() < end):
            outside += 1
            continue
        name, kind = classify(x["subject"], x["location"], x["body"], x["categories"])
        if not name:
            not_read.append({"subject": x["subject"], "source": x["source"], "ref": x["ref"],
                             "when": x["start"].strftime("%Y-%m-%d %H:%M"), "reason": kind})
            continue
        if not x["timed"]:
            not_read.append({"subject": x["subject"], "source": x["source"], "ref": x["ref"],
                             "when": x["start"].strftime("%Y-%m-%d"),
                             "reason": "all-day entry: read as a deadline, not a session"})
            continue
        x["trigger"], x["kind"] = name, kind
        # one session per matter per day; Outlook and CARET entries merge
        key_m = x["matters"][0] if x["matters"] else None
        twin = None
        for s in sessions:
            if s["start"].date() == x["start"].date() and (
                    (key_m and key_m in s["matters"]) or
                    (not key_m and s["subject"].lower() == x["subject"].lower())):
                twin = s
                break
        if twin:
            twin["entries"].append(x)
            if (twin["start"].hour, twin["start"].minute) != (x["start"].hour, x["start"].minute):
                twin["disagreements"].append(
                    f"{twin['entries'][0]['source']} says {fmt_clock(twin['start'].hour, twin['start'].minute)}; "
                    f"{x['source']} says {fmt_clock(x['start'].hour, x['start'].minute)}")
            continue
        sessions.append(dict(x, entries=[x], disagreements=[]))

    notes = CX.read_table(exp, "Notes") if exp else []
    tasks = CX.read_table(exp, "Task") if exp else []
    out = []
    for s in sorted(sessions, key=lambda s: s["start"]):
        mset = set(s["matters"])

        def mine(r):
            return CX.split_matter(CX.col(r, "MatterNumber"))[0] in mset

        ns = [{"date": CX.col(r, "Date"), "subject": CX.col(r, "Subject"),
               "text": CX.clean_text(CX.col(r, "Description")), "ref": f"{r['_file']} row {r['_row']}"}
              for r in notes if mine(r)]
        ns.sort(key=lambda n: n["date"], reverse=True)
        ts = [{"subject": CX.col(r, "Subject"), "due": CX.col(r, "DueDate"), "status": CX.col(r, "Status"),
               "ref": f"{r['_file']} row {r['_row']}"}
              for r in tasks if mine(r) and CX.col(r, "Status").strip().lower() not in ("completed", "complete", "done")]
        out.append({"when": s["start"].strftime("%Y-%m-%d %H:%M") + " Eastern",
                    "day": fmt_day(s["start"]), "time": fmt_clock(s["start"].hour, s["start"].minute),
                    "kind": s["kind"], "trigger": s["trigger"], "subject": s["subject"],
                    "location": s["location"], "body": s["body"][:400], "matters": s["matters"],
                    "found_in": [f"{x['source']} {x['ref']}".strip() for x in s["entries"]],
                    "disagreements": s["disagreements"], "caret_notes": ns, "open_tasks": ts})
    return {"window": {"start": start.isoformat(), "end": (end - timedelta(days=1)).isoformat()},
            "export": str(exp) if exp else None,
            "export_age_days": CX.export_age_days(exp) if exp else None,
            "counted": len(raw), "outside_window": outside,
            "sessions": out, "not_read": not_read}


# ================================================================== cli

def load(p):
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except FileNotFoundError:
        sys.exit(f"No file at {p}")
    except json.JSONDecodeError as ex:
        sys.exit(f"{p} is not valid JSON: {ex}")


def _prior(args, pb):
    if getattr(args, "prior", None):
        return load(args.prior)
    q = find_prior(args.playbook, pb)
    return load(q) if q else None


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    w = sub.add_parser("week")
    w.add_argument("--events")
    w.add_argument("--export", help="FirmExport zip or folder; omitted finds the newest; 'none' skips CARET")
    w.add_argument("--matters")
    w.add_argument("--start")
    w.add_argument("--days", type=int, default=7)
    w.add_argument("--out")
    c = sub.add_parser("check")
    c.add_argument("playbook")
    c.add_argument("--prior")
    r = sub.add_parser("render")
    r.add_argument("playbook")
    r.add_argument("--out", required=True)
    r.add_argument("--prior")
    d = sub.add_parser("diff")
    d.add_argument("playbook")
    d.add_argument("prior")
    a = ap.parse_args(argv)

    if a.cmd == "week":
        st = date.fromisoformat(a.start) if a.start else None
        res = week(a.events, a.export, a.matters, st, a.days)
        txt = json.dumps(res, indent=2)
        if a.out:
            Path(a.out).write_text(txt, encoding="utf-8")
        print(f"{len(res['sessions'])} session(s) from {res['counted']} calendar entries; "
              f"{len(res['not_read'])} in the window not read as a session.")
        for s in res["sessions"]:
            flag = f"  [times disagree: {'; '.join(s['disagreements'])}]" if s["disagreements"] else ""
            print(f"  {s['day']} {s['time']}  {s['kind']:<11} {', '.join(s['matters']) or 'no matter'}  "
                  f"{s['subject']}{flag}")
        if not a.out:
            print(txt)
        return 0

    pb = load(a.playbook)
    if a.cmd == "diff":
        d = diff(load(a.prior), pb)
        print(diff_sentences(d))
        return 0
    prior = _prior(a, pb)
    errs = check(pb, prior)
    mm = time_mismatch(pb)
    if mm:
        print(f"Flag: the governing record says {mm[0]}; the calendar says {mm[1]}.")
    if errs:
        print(f"Refused. {len(errs)} problem{'s' if len(errs) != 1 else ''}:")
        for x in errs:
            print(f"  - {x}")
        return 2
    if a.cmd == "check":
        print(f"Clean: {len(pb['issues'])} issues, "
              f"{sum(len(i['support']) for i in pb['issues'])} support rows, every figure traced."
              + (f" Prior: Revision {prior.get('revision')}." if prior else ""))
        return 0
    Path(a.out).write_text(render(pb, prior), encoding="utf-8")
    print(f"Wrote {a.out}" + (f" (against Revision {prior.get('revision')})" if prior else ""))
    return 0


if __name__ == "__main__":
    sys.exit(main())

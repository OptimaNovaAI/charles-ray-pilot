---
name: crlaw-playbook
description: Conference and hearing playbooks for the Law Offices of Charles A. Ray, P.C., built to the standard of his Examination Conference Playbook. Use whenever Charles wants to walk into a session with the Service or opposing counsel prepared, including "give me the playbook", "playbook for my hearings this week", "give me the playbook for my hearings and examinations this week", "prep me for the exam conference", "examination playbook", "hearing playbook", "meeting playbook", "what will the agent ask", "prep me for the revenue officer", "playbook for Thursday", "revise the playbook", or when the Monday morning scheduled run asks for the week's playbooks. It reads his Outlook calendar and email, the CARET export's calendar, notes, and tasks, and the matter's OneDrive documents, and writes one ranked playbook per examination, hearing, or conference, every figure traced to its source.
---

# Conference and Hearing Playbook

Charles called his first playbook "the gold standard for prep, for hearing prep,
examination prep." It put him toe to toe with a Revenue Agent on the accounting
and got the agent to agree to let the books be cleaned up. This skill makes that
document for every examination, hearing, and conference with the Service or
opposing counsel on his calendar, from one sentence.

A playbook is attorney work product prepared at his direction. It ranks the
issues by the probability the other side raises them, gives the likely question,
the answer, the support with every figure tied to its source, and the cautions.
Suggested answers and cautions belong in it. Invented facts do not: every
answer and every figure traces to a named source, and anything the record does
not hold goes to Open Items.

---

## The Standard

If `reference/gold-standard.pdf` exists in this skill folder, read it before
writing any playbook, at least its first three pages and one full issue, and
match it: the banner, the title, the setting line, the revision line, the
changes box, the ranked table, the length of the cells, the plain declarative
tone, the red do-not cautions. His gold standard runs eighteen pages and
fourteen issues. Density is the point; a thin playbook is a failed one.

**On the first run**, Charles attaches his gold standard and says "use this
playbook as the standard." Save the attachment as `reference/gold-standard.pdf`
in his copy of this skill, say that it is saved, and use it on every run after.
It is privileged. It stays in his copy and is never packaged, shared, or quoted
outside his own playbooks.

---

## Run It

Ask Charles nothing mid-run. What cannot be found is listed on the page as
open, with why.

**1. Find the week's sessions.** With the Outlook connector, read his calendar
for the window (this week, Monday through Sunday, unless he names a day or a
matter) and write every event, unfiltered, to `events.json` in the shape the
hearing prep skill uses: id, subject, start with its offset, location, the
first lines of the notes, categories. Then run:

```
python3 scripts/playbook.py week --events events.json --start 2026-10-12 --days 7 --out week.json
```

The engine finds the newest CARET export (`FirmExport-<n>.zip` in Downloads or
Claude AI Reports) itself, through `scripts/caret_export.py`, reads its
`Calendar.csv`, and merges the two calendars, one session per matter per day.
It reads a session by the hearing prep triggers plus any conference or meeting
with the Service or opposing counsel; the list is in `reference/triggers.md`.
For each session `week.json` carries the kind, the matters, where it was found,
any disagreement between Outlook and CARET on the time, the matter's CARET notes
newest first, and its open CARET tasks, each with its CSV row. Every other event
in the window is listed with the reason it was not read as a session.

A time disagreement between the calendars goes to the playbook as a critical
change. Pass `--matters matters.json` when his matter list is on the machine,
so aliases match.

**2. Gather the record for each session.** Read everything; cite as you go.

| Where | What to Read |
|---|---|
| CARET export | The matter's `Notes.csv` and `Task.csv` rows, already in `week.json` |
| Outlook email | Every thread with the agent, officer, settlement officer, or opposing counsel, and every thread naming the matter: IDRs, the agent's written issues, appointment letters, transmittal letters, faxes and their receipts, the last confirmation of the time |
| OneDrive matter folder | General ledger, trial balances, bank statements, returns as filed, account transcripts, the production with its Bates ranges, workpapers, prior playbook revisions in `Playbooks/` |
| His other skills | Compliance check, resolution path, blind-spot flags, and the clock register, when present for the matter |

Every document used becomes a source with an id, a title that carries its Bates
range when it has one, its date, and its kind. The record that governs the
session is the governing record: usually the last transmittal letter, the
agent's appointment letter, the notice of hearing, or the court's order. When it
states a start time, put it in `governing_record.time`.

**3. Write `playbook.json`** per `reference/schema.md`. The writing rules are
below.

**4. Check and render.**

```
python3 scripts/playbook.py render "<matter> <Kind> Playbook R<N>.json" --out "<matter> <Kind> Playbook R<N>.html"
```

The render runs every check first and refuses with the full list of what
failed; nothing is written until the record is clean. Fix each item at its
source: add the support row that carries the figure, name the source, or move
the claim to Open Items. Never loosen an answer to make a number go away
without saying so in Open Items.

**5. Save and hand it over.** Save both files in the matter folder under
`Playbooks/`, named by matter number, kind, and revision, never by client name.
Open each page. In chat, one line per session: the day and time, the matter,
the number of issues and stated issues, the critical change if there is one,
and the open items count. Nothing more.

---

## Revisions

A new revision supersedes the old. When a playbook for the session exists in
`Playbooks/`, the next one is Revision N+1, and Revision N's json stays beside
it, named the same with the lower number. The engine finds it there by itself,
or takes `--prior`, and puts the difference in the changes box: issues added,
dropped, moved, and revised. Claude's own changes come first, each a bold lead
sentence and its specifics. The critical change comes last, in dark red.

Revise when the record moves: a production goes out, the agent writes, a time
changes, a document arrives. When nothing in the record moved since Revision N,
say Revision N stands and do not renumber. The trigger names what moved, as in
"after the IDR 1-0001 response went out and after the shareholder's own Form
2848 reached the agent."

---

## Writing the Playbook

- **Rank by probability.** The issues the other side named in writing are
  marked stated, with the letter that names them, and usually rank first. The
  rest come from the record: the largest unexplained figures, the accounts that
  look like income, the ones a careful agent asks about. Aim for every issue a
  well-prepared agent could raise; his standard carried fourteen.
- **The likely question** is written the way the agent asks it, with his
  figures.
- **The answer** is what counsel says at the table, in short declarative
  sentences. It cites the figure and where it sits in the production. It never
  enlarges, narrows, or recharacterizes what the transmittal letter said.
- **Support** is column four. One row per figure, each naming its source:
  the Bates range, the GL account, the bank statement and its month, the letter
  and its date. Every dollar amount, date, Bates number, percentage, time, and
  form number in an answer must appear in that issue's support rows or the
  sources they name. The engine checks this and refuses an untraced figure.
  A Code section, regulation, or case the answer relies on is a support row
  too, with the authority listed as a source of kind Authority.
- **Cautions** are what not to say, what not to concede, and what not to
  volunteer. A caution that begins "Do not" is marked `do_not` and prints in
  dark red, as in "Do not raise the mortgage."
- **The changes box** opens with bold lead sentences that say what moved ("The
  production is out and the record is fixed.", "Counsel appears alone.") and
  ends with the one thing that cannot go wrong, marked critical.
- **A time discrepancy is always critical.** When the governing record's time
  and the calendar's differ, the engine refuses the render until a critical
  change names both times and says when to be on the line and which direct
  line to call. His standard: be on the dial-in five minutes before the earlier
  time, and if the agent is not on the line at the start, stay on and call his
  direct line before treating it as a missed appointment.
- **Open Items** hold everything the record does not: a document not found by
  name, a figure that does not tie, an unanswered question to the agent. Each
  says why it is open.

---

## Every Monday

Built to be scheduled. Mondays at 6:30 a.m., a scheduled task:

> Give me the playbook for my hearings and examinations this week. Read my
> Outlook calendar from today through Sunday into events.json, run
> crlaw-playbook week with the newest CARET export, and write or revise the
> playbook for every session it finds, from my Outlook email, the CARET notes
> and tasks, and the matter folders on OneDrive. Save each in the matter's
> Playbooks folder and send me one line per session.

---

## What It Will Not Do

- Ask questions mid-run. What is missing is listed as open.
- State a figure the record does not hold, or a time that differs from the
  governing record without flagging it.
- Send anything to the Service, the client, or opposing counsel. The playbook
  is his and stays in the matter folder.
- Put a client name in a file name.

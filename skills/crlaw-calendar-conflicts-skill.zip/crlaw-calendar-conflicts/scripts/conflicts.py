#!/usr/bin/env python3
"""
Calendar conflicts for the Law Offices of Charles A. Ray, P.C.

    python3 conflicts.py --events outlook.json [--events more.json]
                         [--caret [FirmExport-123.zip or folder]]
                         [--ics court.ics ...] [--as-of 2026-10-13] [--days 14]
                         [--buffer 30] [--hearing-buffer 60]
                         [--out "Calendar Conflicts.html"] [--json conflicts.json]

Item 13. Reads every calendar it is given, puts every time in Eastern, and
reports what collides in the window, from the as-of date through as-of plus
--days:

    Overlaps            two busy events whose times intersect, any calendars
    Tentative overlaps  a tentative event that intersects a busy one
    Hearing collisions  anything busy within --hearing-buffer minutes of a
                        hearing, by the same words hearing prep uses
    Changes of place    back-to-back busy events at two physical places with
                        less than --buffer minutes between them
    Sync drift          the same event on two calendars at different times
    On both calendars   the same event on two calendars at the same time
    Busy all day        an all-day item marked busy or away, and what else is
                        timed that day
    Dates to see        weekends, federal holidays, DC Emancipation Day

What it reads
    --events    an events file Claude writes from the Outlook connector. One
                file may hold several calendars. Shape in reference/inputs.md
    --caret     the CARET firm export: the FirmExport zip as CARET saves it,
                or the folder it was unzipped to. Given with no path, the
                newest FirmExport in Downloads or Claude AI Reports. Its
                Calendar.csv is read as the calendar named CARET
    --ics       any .ics export: a court feed, a personal calendar. Repeat
                rules are expanded where the engine can; any it cannot are
                listed by name

Three rules, and they are the firm's.
    It computes. It never recommends. The page refuses to write if the
    engine's own words advise. Subjects and locations are the calendar's
    words and pass.
    Nothing is dropped silently. Every event read is counted, and every event
    not read is listed with the reason.
    Every line says where it came from: the calendar and the file.
"""

import argparse
import html as H
import json
import re
import sys
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import caret_export as CX  # noqa: E402

# What reads as a hearing. Copied from hearing prep (scripts/prep.py) so the
# two skills agree. A change to one list goes into both. Order matters: the
# first match names it.
TRIGGERS = [
    ("CDP hearing", r"\bCDP\b|collection due process"),
    ("Tax Court", r"tax court|calendar call|\btrial\b"),
    ("Appeals", r"\bappeals?\b"),
    ("Administrative hearing", r"\bOAH\b|administrative hearing|hearing officer"),
    ("Hearing", r"\bhearing\b"),
    ("Examination", r"\bexamination\b|\baudit\b|revenue agent|\bexam\b"),
    ("Revenue officer", r"revenue officer"),
    ("Settlement conference", r"settlement conference"),
]
# A calendar category of "Hearing" always counts. "[no prep]" in the subject
# never does.
OPT_IN_CATEGORY = "hearing"
OPT_OUT = re.compile(r"\[no prep\]", re.I)

# A location that reads as virtual is never a change of place.
VIRTUAL = re.compile(
    r"\bzoom\b|\bteams\b|\bwebex\b|\bphone\b|\btelephone\b|(?<!calendar )\bcall\b|"
    r"conference line|\bdial[- ]?in\b|https?:|\bwww\.|\bvirtual\b|google meet", re.I)

CANCEL_PREFIX = re.compile(r"^\s*(canceled|cancelled)\s*:\s*", re.I)

SHOW = {"busy": "busy", "tentative": "tentative", "free": "free", "oof": "oof",
        "outofoffice": "oof", "away": "oof", "workingelsewhere": "elsewhere"}
SHOW_LABEL = {"busy": "busy", "tentative": "tentative", "free": "free",
              "oof": "out of office", "elsewhere": "working elsewhere"}
BUSY = {"busy", "oof"}
FREE = {"free", "elsewhere"}

WD = ["MO", "TU", "WE", "TH", "FR", "SA", "SU"]
RRULE_KEYS = {"FREQ", "INTERVAL", "COUNT", "UNTIL", "BYDAY", "WKST"}
EXPAND_LIMIT = 200000

FED = "a federal holiday"
DC = "a District of Columbia holiday"

WORDS_NEVER_PRINTED = (" should ", "recommend", "advisable", "we suggest")

CARET_NOT_SEEN = "CARET entries that never reached any source given"
CARET_AFTER = "CARET entries made or changed after the export was taken"
CARET_STALE_DAYS = 7
CARET_CAL = "CARET"
RECURRING_NOTE = "recurring in CARET, listed occurrence only"

FOOT = ("Not checked by this page: travel time beyond the {buffer}-minute buffer between "
        "places, {caret}, and court rules. "
        "An entry moved to another date reads as two events, not as drift. A date is "
        "named for what it is. What that means for a filing or a hearing is not stated "
        "here.<br><br>This page reports what the calendars show. The scheduling is the "
        "attorney's.")


class Unread(Exception):
    """An entry the engine could not read, with the reason and the value."""

    def __init__(self, why, value=""):
        super().__init__(why)
        self.why, self.value = why, value


# ---------------------------------------------------------------- time

def _nth_sunday(y, m, n):
    d0 = date(y, m, 1)
    first = d0 + timedelta(days=(6 - d0.weekday()) % 7)
    return first + timedelta(weeks=n - 1)


def eastern(dt):
    """US Eastern without a time zone database, so it runs the same on
    Charles's Windows machine as anywhere else. Daylight time runs from 2 a.m.
    on the second Sunday of March to 2 a.m. on the first Sunday of November.
    Copied from hearing prep."""
    if dt.tzinfo is None:
        return dt
    u = dt.astimezone(timezone.utc).replace(tzinfo=None)
    start = datetime.combine(_nth_sunday(u.year, 3, 2), datetime.min.time()) + timedelta(hours=7)
    end = datetime.combine(_nth_sunday(u.year, 11, 1), datetime.min.time()) + timedelta(hours=6)
    off = -4 if start <= u < end else -5
    return (u + timedelta(hours=off))


def to_eastern(kind, dt):
    """kind is utc, eastern, or floating. Floating times are read as Eastern."""
    if kind == "utc":
        return eastern(dt.replace(tzinfo=timezone.utc))
    return dt


UTC_NAMES = {"utc", "etc/utc", "gmt", "etc/gmt", "z", "zulu", "coordinated universal time",
             "(utc) coordinated universal time"}


def tz_kind(name):
    n = (name or "").strip().strip('"').lower()
    if not n:
        return "floating"
    if n in UTC_NAMES:
        return "utc"
    if re.search(r"new_york|eastern|est5edt", n):
        return "eastern"
    return None


def mins(td):
    return int(round(td.total_seconds() / 60))


def plural(n, word):
    return f"{n} {word}" + ("" if n == 1 else "s")


def e(s):
    return H.escape(str(s if s is not None else ""), quote=False)


def nt(s):
    """Text quoted from a calendar. Marked so the word check skips it: the
    calendar's words are his, and the check is for the engine's."""
    return f"<span class=\"nt\">{e(s)}</span>"


def fmt_day(d0):
    return d0.strftime("%A, %B ") + str(d0.day)


def fmt_date_long(d0):
    return d0.strftime("%A, %B ") + str(d0.day) + ", " + str(d0.year)


def fmt_time(t):
    if t is None:
        return "all day"
    h = t.hour % 12 or 12
    return f"{h}:{t.minute:02d} {'AM' if t.hour < 12 else 'PM'}"


# ---------------------------------------------------------------- holidays

def _nth_weekday(y, m, wd, n):
    d0 = date(y, m, 1)
    return d0 + timedelta(days=(wd - d0.weekday()) % 7) + timedelta(weeks=n - 1)


def _last_weekday(y, m, wd):
    d = date(y + (m == 12), m % 12 + 1, 1) - timedelta(days=1)
    return d - timedelta(days=(d.weekday() - wd) % 7)


def observed(d0):
    """A holiday on a Saturday is observed the Friday before. On a Sunday, the
    Monday after."""
    if d0.weekday() == 5:
        return d0 - timedelta(days=1)
    if d0.weekday() == 6:
        return d0 + timedelta(days=1)
    return d0


def holidays(y):
    """(name, the date itself, the day observed, what kind) for year y."""
    fixed = [("New Year's Day", date(y, 1, 1)), ("Independence Day", date(y, 7, 4)),
             ("Veterans Day", date(y, 11, 11)), ("Christmas Day", date(y, 12, 25))]
    if y >= 2021:
        fixed.append(("Juneteenth", date(y, 6, 19)))
    moving = [("Martin Luther King Jr. Day", _nth_weekday(y, 1, 0, 3)),
              ("Washington's Birthday", _nth_weekday(y, 2, 0, 3)),
              ("Memorial Day", _last_weekday(y, 5, 0)),
              ("Labor Day", _nth_weekday(y, 9, 0, 1)),
              ("Columbus Day", _nth_weekday(y, 10, 0, 2)),
              ("Thanksgiving Day", _nth_weekday(y, 11, 3, 4))]
    out = [(n, d0, observed(d0), FED) for n, d0 in fixed]
    out += [(n, d0, d0, FED) for n, d0 in moving]
    if y >= 2005:
        d0 = date(y, 4, 16)
        out.append(("DC Emancipation Day", d0, observed(d0), DC))
    return sorted(out, key=lambda h: h[1])


def day_facts(d0):
    """What the day is, stated as fact. Never what it means."""
    facts = []
    if d0.weekday() >= 5:
        facts.append(f"Falls on a {d0:%A}.")
    for y in (d0.year - 1, d0.year, d0.year + 1):
        for name, actual, obs, kind in holidays(y):
            if actual == d0 and obs == d0:
                facts.append(f"Falls on {name}, {kind}.")
            elif obs == d0:
                facts.append(f"Falls on the day {name} is observed, {kind}. "
                             f"{name} itself is {fmt_date_long(actual)}.")
            elif actual == d0:
                facts.append(f"Falls on {name}, which is observed as {kind} on "
                             f"{fmt_date_long(obs)}.")
    return facts


# ---------------------------------------------------------------- hearings

def classify(ev):
    """Copied from hearing prep. Returns (name, None) or (None, why)."""
    subj = ev.get("subject", "") or ""
    if OPT_OUT.search(subj):
        return None, "marked [no prep]"
    cats = [str(c).lower() for c in ev.get("categories", []) or []]
    hay = " ".join([subj, ev.get("location", "") or "", ev.get("body", "") or ""])
    for name, pat in TRIGGERS:
        if re.search(pat, hay, re.I):
            return name, None
    if OPT_IN_CATEGORY in cats:
        return "Hearing", None
    return None, "no hearing word in the subject, location, or notes"


def read_show(v):
    if v in (None, ""):
        return "busy", None
    k = re.sub(r"[\s_-]", "", str(v)).lower()
    if k in SHOW:
        return SHOW[k], None
    return "busy", ("the show-as value is not one the engine knows, so it is read as busy", str(v))


# ---------------------------------------------------------------- events files

def json_when(v, label):
    """('date', date) or ('dt', naive Eastern datetime), or None when absent."""
    if v in (None, ""):
        return None
    tz = ""
    if isinstance(v, dict):
        tz = v.get("timeZone") or v.get("timezone") or ""
        v = v.get("dateTime") or v.get("date") or ""
    s = str(v).strip()
    bad = Unread(f"the {label} does not read as a date", s)
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", s):
        try:
            return ("date", date.fromisoformat(s))
        except ValueError:
            raise bad
    s2 = re.sub(r"(T\d{2}:\d{2}:\d{2})\.\d+", r"\1", s)
    s2 = re.sub(r"[Zz]$", "+00:00", s2)
    try:
        dt = datetime.fromisoformat(s2)
    except ValueError:
        raise bad
    if dt.tzinfo is not None:
        return ("dt", eastern(dt))
    k = tz_kind(tz)
    if k is None:
        raise Unread(f"the {label} time zone is not one the engine reads", tz)
    return ("dt", to_eastern(k, dt))


def date_as_written(v, label):
    if isinstance(v, dict):
        v = v.get("dateTime") or v.get("date") or ""
    s = str(v).strip()[:10]
    try:
        return date.fromisoformat(s)
    except ValueError:
        raise Unread(f"the {label} does not read as a date", str(v))


def read_events_file(path):
    doc = json.loads(Path(path).read_text(encoding="utf-8-sig"))
    events = doc.get("events", []) if isinstance(doc, dict) else (doc if isinstance(doc, list) else [])
    meta = doc if isinstance(doc, dict) else {}
    src = Path(path).name
    default_cal = str(meta.get("calendar") or "Calendar not named")
    listed = [str(c) for c in (meta.get("calendars") or [])]
    entries = []
    for ev in events:
        cal = str(ev.get("calendar") or default_cal) if isinstance(ev, dict) else default_cal
        subject = str(ev.get("subject") or "") if isinstance(ev, dict) else ""
        ent = {"src": src, "cal": cal, "subject": subject, "occ": [], "unread": None, "notes": []}
        try:
            ent["occ"] = [json_event(ev, src, cal, ent["notes"])]
        except Unread as u:
            ent["unread"] = (u.why, u.value)
        entries.append(ent)
    info = {"src": src, "kind": "events", "pulled": meta.get("pulled"), "window": meta.get("window"),
            "calendars": listed}
    return info, entries


def json_event(ev, src, cal, notes):
    if not isinstance(ev, dict):
        raise Unread("the entry is not an event", str(ev)[:80])
    st = json_when(ev.get("start"), "start")
    if st is None:
        raise Unread("no start")
    en = json_when(ev.get("end"), "end")
    all_day = bool(ev.get("is_all_day")) or st[0] == "date"
    show, note = read_show(ev.get("show_as"))
    if note:
        notes.append(note)
    subject = str(ev.get("subject") or "")
    o = {"subject": subject, "location": str(ev.get("location") or ""),
         "body": str(ev.get("body") or ""), "categories": list(ev.get("categories") or []),
         "uid": str(ev.get("id") or ""), "src": src, "cal": cal, "show": show,
         "cancelled": bool(ev.get("is_cancelled")) or bool(CANCEL_PREFIX.match(subject)),
         "all_day": all_day, "start": None, "end": None, "d0": None, "d1": None}
    if all_day:
        o["d0"] = date_as_written(ev.get("start"), "start")
        d1 = date_as_written(ev.get("end"), "end") if ev.get("end") not in (None, "") else None
        if d1 is not None and d1 <= o["d0"]:
            notes.append(("the all-day end is not after its start, so it is read as one day",
                          str(ev.get("end"))))
            d1 = None
        o["d1"] = d1 or o["d0"] + timedelta(days=1)
    else:
        o["start"] = st[1]
        if en is None:
            notes.append(("no end time given, so it is read at its start time only", ""))
        elif en[0] == "date":
            raise Unread("the start has a time and the end is a date alone", str(ev.get("end")))
        elif en[1] < st[1]:
            raise Unread("it ends before it starts", f"{ev.get('start')} to {ev.get('end')}")
        elif en[1] > st[1]:
            o["end"] = en[1]
    o["hearing"] = classify(o)[0]
    return o


# ---------------------------------------------------------------- .ics files

def unfold(text):
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    return re.sub(r"\n[ \t]", "", text).split("\n")


def split_prop(line):
    """NAME;PARAM=V;PARAM="V":value. Returns (NAME, {PARAM: V}, value) or None."""
    q = False
    cut = -1
    for i, ch in enumerate(line):
        if ch == '"':
            q = not q
        elif ch == ":" and not q:
            cut = i
            break
    if cut < 0:
        return None
    head, value = line[:cut], line[cut + 1:]
    parts, buf, q = [], "", False
    for ch in head:
        if ch == '"':
            q = not q
            buf += ch
        elif ch == ";" and not q:
            parts.append(buf)
            buf = ""
        else:
            buf += ch
    parts.append(buf)
    params = {}
    for p in parts[1:]:
        if "=" in p:
            k, v = p.split("=", 1)
            params[k.strip().upper()] = v.strip().strip('"')
    return parts[0].strip().upper(), params, value


def unescape(v):
    return re.sub(r"\\([\\,;nN])", lambda m: "\n" if m.group(1) in "nN" else m.group(1), v or "")


def split_list(v):
    return [unescape(x).strip() for x in re.split(r"(?<!\\),", v or "") if x.strip()]


def ics_time(value, params, label):
    """Returns (kind, value): ('date', date) or (utc|eastern|floating, naive datetime)."""
    v = (value or "").strip()
    bad = Unread(f"the {label} does not read as a date", v)
    if params.get("VALUE", "").upper() == "DATE" or re.fullmatch(r"\d{8}", v):
        m = re.fullmatch(r"(\d{4})(\d{2})(\d{2})", v)
        if not m:
            raise bad
        try:
            return ("date", date(int(m[1]), int(m[2]), int(m[3])))
        except ValueError:
            raise bad
    m = re.fullmatch(r"(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})(Z?)", v)
    if not m:
        raise bad
    try:
        dt = datetime(*(int(m[i]) for i in range(1, 7)))
    except ValueError:
        raise bad
    if m[7]:
        return ("utc", dt)
    k = tz_kind(params.get("TZID"))
    if k is None:
        raise Unread(f"the {label} time zone is not one the engine reads", params.get("TZID"))
    return (k, dt)


def ics_duration(v):
    s = (v or "").strip()
    m = re.fullmatch(r"([+-])?P(?:(\d+)W)?(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?)?", s)
    if not m or all(g is None for g in m.groups()[1:]):
        raise Unread("the duration does not read", s)
    td = timedelta(weeks=int(m[2] or 0), days=int(m[3] or 0), hours=int(m[4] or 0),
                   minutes=int(m[5] or 0), seconds=int(m[6] or 0))
    return -td if m[1] == "-" else td


def parse_rrule(v):
    bad = Unread("the repeat rule is not one the engine expands", v)
    parts = {}
    for p in (v or "").strip().split(";"):
        if not p:
            continue
        if "=" not in p:
            raise bad
        k, val = p.split("=", 1)
        parts[k.strip().upper()] = val.strip().upper()
    if parts.get("FREQ") not in ("DAILY", "WEEKLY", "MONTHLY") or set(parts) - RRULE_KEYS:
        raise bad
    if "COUNT" in parts and "UNTIL" in parts:
        raise bad
    try:
        rule = {"FREQ": parts["FREQ"], "INTERVAL": int(parts.get("INTERVAL", "1")),
                "COUNT": int(parts["COUNT"]) if "COUNT" in parts else None,
                "WKST": WD.index(parts.get("WKST", "MO")), "BYDAY": None, "UNTIL": None}
    except ValueError:
        raise bad
    if rule["INTERVAL"] < 1 or (rule["COUNT"] is not None and rule["COUNT"] < 1):
        raise bad
    if "BYDAY" in parts:
        codes = parts["BYDAY"].split(",")
        if rule["FREQ"] != "WEEKLY" or any(c not in WD for c in codes):
            raise bad
        rule["BYDAY"] = sorted({WD.index(c) for c in codes})
    if "UNTIL" in parts:
        u = parts["UNTIL"]
        if re.fullmatch(r"\d{8}", u):
            rule["UNTIL"] = ("date", ics_time(u, {}, "end of the repeat rule")[1])
        else:
            k, dt = ics_time(u, {}, "end of the repeat rule")
            rule["UNTIL"] = (k, dt)
    return rule


def _gen(rule, dt0):
    iv = rule["INTERVAL"]
    if rule["FREQ"] == "DAILY":
        k = 0
        while True:
            yield dt0 + timedelta(days=k * iv)
            k += 1
    elif rule["FREQ"] == "WEEKLY":
        days = rule["BYDAY"] or [dt0.weekday()]
        wkst = rule["WKST"]
        if dt0.weekday() not in days:
            yield dt0  # the start always counts as the first occurrence
        week0 = dt0 - timedelta(days=(dt0.weekday() - wkst) % 7)
        order = sorted(days, key=lambda d: (d - wkst) % 7)
        w = 0
        while True:
            ws = week0 + timedelta(weeks=w * iv)
            for d in order:
                occ = ws + timedelta(days=(d - wkst) % 7)
                if occ >= dt0:
                    yield occ
            w += 1
    else:
        k = 0
        while True:
            m0 = dt0.month - 1 + k * iv
            try:
                yield dt0.replace(year=dt0.year + m0 // 12, month=m0 % 12 + 1)
            except ValueError:
                pass  # a month without that day has no occurrence
            k += 1


def expand(rule, dt0, kind, hi, raw):
    """Occurrence starts in their own zone, from the first through the window's
    end. dt0 is a naive datetime in the zone named by kind."""
    hi_native = hi + timedelta(days=1)
    until = rule["UNTIL"]
    if until is not None and until[0] == "utc" and kind != "utc":
        until = ("local", to_eastern("utc", until[1]))

    def within(occ):
        if until is None:
            return True
        if until[0] == "date":
            return occ.date() <= until[1]
        return occ <= until[1]

    out, n, steps = [], 0, 0
    for occ in _gen(rule, dt0):
        steps += 1
        if steps > EXPAND_LIMIT:
            raise Unread("the repeat rule runs longer than the engine expands", raw)
        if not within(occ) or occ > hi_native:
            break
        n += 1
        out.append(occ)
        if rule["COUNT"] and n >= rule["COUNT"]:
            break
    return out


def read_ics(path):
    text = Path(path).read_text(encoding="utf-8-sig", errors="replace")
    cal_name, raw, stack, cur = None, [], [], None
    for ln in unfold(text):
        if not ln.strip():
            continue
        u = ln.strip().upper()
        if u.startswith("BEGIN:"):
            stack.append(u[6:].strip())
            if stack[-1] == "VEVENT":
                cur = []
            continue
        if u.startswith("END:"):
            comp = u[4:].strip()
            if stack:
                stack.pop()
            if comp == "VEVENT" and cur is not None:
                raw.append(cur)
                cur = None
            continue
        p = split_prop(ln)
        if p is None:
            continue
        if stack and stack[-1] == "VEVENT" and cur is not None:
            cur.append(p)
        elif stack and stack[-1] == "VCALENDAR" and p[0] == "X-WR-CALNAME":
            cal_name = unescape(p[2]).strip()
    return cal_name, raw


def _first(props, name):
    for n, params, v in props:
        if n == name:
            return params, v
    return None


def _all(props, name):
    return [(params, v) for n, params, v in props if n == name]


def read_ics_file(path, lo, hi):
    cal_name, raw = read_ics(path)
    src = Path(path).name
    cal = cal_name or Path(path).stem
    # moved or changed single occurrences of a series, by series and original start
    overrides = set()
    for props in raw:
        rid = _first(props, "RECURRENCE-ID")
        uid = (_first(props, "UID") or ({}, ""))[1].strip()
        if rid and uid:
            try:
                k, v = ics_time(rid[1], rid[0], "changed occurrence")
                overrides.add((uid, v if k == "date" else to_eastern(k, v)))
            except Unread:
                pass
    entries = []
    for props in raw:
        subject = unescape((_first(props, "SUMMARY") or ({}, ""))[1]).strip()
        ent = {"src": src, "cal": cal, "subject": subject, "occ": [], "unread": None, "notes": []}
        try:
            ent["occ"] = ics_event(props, src, cal, subject, overrides, lo, hi, ent["notes"])
        except Unread as u:
            if u.why == "outside":
                ent["occ"] = []
            else:
                ent["unread"] = (u.why, u.value)
        entries.append(ent)
    info = {"src": src, "kind": "ics", "pulled": None, "window": None, "calendars": [cal]}
    return info, entries


def ics_event(props, src, cal, subject, overrides, lo, hi, notes):
    ds = _first(props, "DTSTART")
    if ds is None:
        raise Unread("no start")
    sk, sv = ics_time(ds[1], ds[0], "start")
    uid = (_first(props, "UID") or ({}, ""))[1].strip()
    status = (_first(props, "STATUS") or ({}, ""))[1].strip().upper()
    transp = (_first(props, "TRANSP") or ({}, ""))[1].strip().upper()
    cdo = (_first(props, "X-MICROSOFT-CDO-BUSYSTATUS") or ({}, ""))[1].strip()
    if cdo:
        show, note = read_show(cdo)
        if note:
            notes.append(note)
    elif transp == "TRANSPARENT":
        show = "free"
    elif status == "TENTATIVE":
        show = "tentative"
    else:
        show = "busy"
    cats = []
    for _, v in _all(props, "CATEGORIES"):
        cats += split_list(v)
    base = {"subject": subject,
            "location": unescape((_first(props, "LOCATION") or ({}, ""))[1]).strip(),
            "body": unescape((_first(props, "DESCRIPTION") or ({}, ""))[1]).strip()[:400],
            "categories": cats, "uid": uid, "src": src, "cal": cal, "show": show,
            "cancelled": status == "CANCELLED" or bool(CANCEL_PREFIX.match(subject))}
    base["hearing"] = classify(base)[0]

    # the length of one occurrence
    de, du = _first(props, "DTEND"), _first(props, "DURATION")
    all_day = sk == "date"
    span_days, span = 1, None
    if all_day:
        if de:
            ek, ev_ = ics_time(de[1], de[0], "end")
            if ek != "date":
                raise Unread("the start is a date alone and the end has a time", de[1])
            span_days = (ev_ - sv).days
        elif du:
            span_days = ics_duration(du[1]).days
        if span_days < 1:
            notes.append(("the all-day end is not after its start, so it is read as one day",
                          (de or du)[1]))
            span_days = 1
    else:
        start_e = to_eastern(sk, sv)
        if de:
            ek, ev_ = ics_time(de[1], de[0], "end")
            if ek == "date":
                raise Unread("the start has a time and the end is a date alone", de[1])
            span = to_eastern(ek, ev_) - start_e
        elif du:
            span = to_eastern(sk, sv + ics_duration(du[1])) - start_e
        if span is not None and span < timedelta(0):
            raise Unread("it ends before it starts", (de or du)[1])
        if span is None:
            notes.append(("no end time given, so it is read at its start time only", ""))
        elif span == timedelta(0):
            span = None

    # the occurrences
    rr = _first(props, "RRULE")
    if _first(props, "RDATE"):
        raise Unread("its extra dates (RDATE) are not expanded", _first(props, "RDATE")[1])
    if _first(props, "EXRULE"):
        raise Unread("its exclusion rule (EXRULE) is not read", _first(props, "EXRULE")[1])
    dt0 = datetime.combine(sv, time()) if all_day else sv
    if rr:
        try:
            rule = parse_rrule(rr[1])
        except Unread:
            # a series that provably ends before the window, or starts after it, is outside
            first = sv if all_day else to_eastern(sk, sv).date()
            if first >= hi.date():
                raise Unread("outside")
            m = re.search(r"UNTIL=(\d{8})", rr[1].upper())
            if m and date(int(m[1][:4]), int(m[1][4:6]), int(m[1][6:])) < lo.date() - timedelta(days=1):
                raise Unread("outside")
            raise
        starts = expand(rule, dt0, sk, hi, rr[1])
    else:
        starts = [dt0]

    ex_dates, ex_dts = set(), set()
    for params, v in _all(props, "EXDATE"):
        for one in v.split(","):
            k, x = ics_time(one, params, "excluded date")
            if k == "date":
                ex_dates.add(x)
            else:
                ex_dts.add(to_eastern(k, x))
    is_override = _first(props, "RECURRENCE-ID") is not None

    out = []
    for s in starts:
        o = dict(base, all_day=all_day, start=None, end=None, d0=None, d1=None)
        if all_day:
            d0 = s.date()
            if d0 in ex_dates or (rr and not is_override and (uid, d0) in overrides):
                continue
            o["d0"], o["d1"] = d0, d0 + timedelta(days=span_days)
        else:
            se = to_eastern(sk, s)
            if se in ex_dts or se.date() in ex_dates:
                continue
            if rr and not is_override and (uid, se) in overrides:
                continue
            o["start"] = se
            o["end"] = se + span if span else None
        out.append(o)
    return out


# ---------------------------------------------------------------- CARET export

def _written_date(raw):
    """The date as CARET wrote it, before any time zone conversion."""
    m = re.match(r"^\s*(\d{4}-\d{2}-\d{2})", str(raw or ""))
    if m:
        return date.fromisoformat(m.group(1))
    dt, _ = CX.parse_dt(raw)
    return dt.date() if dt else None


def caret_info(exp, as_of):
    taken = CX.export_taken(exp)
    return {"name": Path(exp).name, "path": str(exp), "taken": taken,
            "age": (as_of - taken.date()).days}


def read_caret_file(exp, as_of):
    """Calendar.csv from a CARET firm export, as one more calendar named CARET.

    CARET writes times in UTC with an offset. They are converted to Eastern. An
    all-day row, or a row whose start is a date alone, is taken by the date as
    written. A recurring row carries no repeat rule in the export, so only the
    occurrence it lists is known, and it is read as that one event."""
    rows = CX.read_table(exp, "Calendar")
    info = caret_info(exp, as_of)
    src = f"{info['name']}, Calendar.csv"
    info.update({"src": src, "kind": "caret", "pulled": None, "window": None,
                 "calendars": [CARET_CAL], "has_calendar": bool(CX.headers(exp, "Calendar"))})
    entries = []
    for row in rows:
        subject = CX.clean_text(CX.col(row, "Subject", "Title")).replace("\n", " ")
        ent = {"src": src, "cal": CARET_CAL, "subject": subject, "occ": [], "unread": None, "notes": []}
        try:
            ent["occ"] = [caret_event(row, src, subject, ent["notes"])]
        except Unread as u:
            ref = f"Calendar.csv row {row['_row']}"
            ent["unread"] = (u.why, ref if u.value in ("", ref) else f"{u.value}, {ref}")
        entries.append(ent)
    return info, entries


def caret_event(row, src, subject, notes):
    ref = f"Calendar.csv row {row['_row']}"
    raw_s = CX.col(row, "FromDate", "StartDate", "Start*", "From*")
    raw_e = CX.col(row, "ToDate", "EndDate", "End*", "To*")
    if not str(raw_s).strip():
        raise Unread("no start", ref)
    st, st_time = CX.parse_dt(raw_s)
    if st is None:
        raise Unread("the start does not read as a date", raw_s)
    en, en_time = CX.parse_dt(raw_e) if str(raw_e).strip() else (None, False)
    if str(raw_e).strip() and en is None:
        raise Unread("the end does not read as a date", raw_e)
    all_day = CX.truthy(CX.col(row, "IsAllday", "IsAllDay", "AllDay")) or not st_time
    number, mname = CX.split_matter(CX.col(row, "MatterNumber", "Matter Number", "MatterNo"),
                                    CX.col(row, "MatterName", "Matter Name"))
    cat = str(CX.col(row, "CategoryName", "Category")).strip()
    o = {"subject": subject, "location": CX.clean_text(CX.col(row, "Location")).replace("\n", ", "),
         "body": CX.clean_text(CX.col(row, "Descrption", "Description", "Notes"))[:400],
         "categories": [cat] if cat and cat.lower() != "none" else [],
         "uid": ref, "src": src, "cal": CARET_CAL, "show": "busy",
         "cancelled": bool(CANCEL_PREFIX.match(subject)), "matter": number,
         "matter_name": mname, "row": row["_row"],
         "all_day": all_day, "start": None, "end": None, "d0": None, "d1": None}
    if CX.truthy(CX.col(row, "IsRecurring", "Recurring")):
        notes.append((RECURRING_NOTE, ref))
    if all_day:
        o["d0"] = _written_date(raw_s)
        d1 = _written_date(raw_e) if en is not None else None
        if d1 is None or d1 < o["d0"]:
            if d1 is not None:
                notes.append(("the all-day end is before its start, so it is read as one day", raw_e))
            d1 = o["d0"]
        elif d1 > o["d0"] and re.search(r"[T ]00:00", str(raw_e)):
            # an end at midnight, as written, is the start of the day after the last day
            d1 = d1 - timedelta(days=1)
        o["d1"] = d1 + timedelta(days=1)
    else:
        o["start"] = st
        if en is None:
            notes.append(("no end time given, so it is read at its start time only", ref))
        elif not en_time:
            raise Unread("the start has a time and the end is a date alone", raw_e)
        elif en < st:
            raise Unread("it ends before it starts", f"{raw_s} to {raw_e}")
        elif en > st:
            o["end"] = en
    o["hearing"] = classify(o)[0]
    return o


# ---------------------------------------------------------------- the checks

def in_window(o, lo, hi):
    if o["all_day"]:
        return o["d0"] < hi.date() and o["d1"] > lo.date()
    if o["end"] is None:
        return lo <= o["start"] < hi
    return o["start"] < hi and o["end"] > lo


def nsubj(s):
    s = CANCEL_PREFIX.sub("", s or "")
    return " ".join(re.sub(r"[^\w\s]", " ", s.lower()).split())


def nloc(s):
    return " ".join((s or "").lower().split())


def physical(o):
    loc = (o.get("location") or "").strip()
    return bool(loc) and not VIRTUAL.search(loc)


def day_of(o):
    return o["d0"] if o["all_day"] else o["start"].date()


def same_times(a, b):
    if a["all_day"] != b["all_day"]:
        return False
    if a["all_day"]:
        return (a["d0"], a["d1"]) == (b["d0"], b["d1"])
    return (a["start"], a["end"]) == (b["start"], b["end"])


def overlap(a, b):
    """Minutes the two share, 0 when one has no end and starts inside the
    other, None when they do not meet."""
    sa, ea, sb, eb = a["start"], a["end"], b["start"], b["end"]
    if ea is None and eb is None:
        return 0 if sa == sb else None
    if ea is None:
        return 0 if sb <= sa < eb else None
    if eb is None:
        return 0 if sa <= sb < ea else None
    lo, hi = max(sa, sb), min(ea, eb)
    return mins(hi - lo) if hi > lo else None


def dates_covered(o, lo, hi):
    if o["all_day"]:
        d, last = o["d0"], o["d1"] - timedelta(days=1)
    else:
        d = o["start"].date()
        last = ((o["end"] - timedelta(minutes=1)).date()
                if o["end"] and o["end"] > o["start"] else d)
    out = []
    while d <= last:
        if lo.date() <= d < hi.date():
            out.append(d)
        d += timedelta(days=1)
    return out


def analyse(occ, lo, hi, buffer, hbuffer):
    """occ: every occurrence in the window. Returns the sections."""
    # the same event on two calendars: matched on subject and Eastern date
    n = len(occ)
    parent = list(range(n))

    def root(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    groups = {}
    for i, o in enumerate(occ):
        groups.setdefault((nsubj(o["subject"]), day_of(o)), []).append(i)
    drift_pairs = []
    for (subj, _), idx in groups.items():
        if not subj:
            continue
        for x in range(len(idx)):
            for y in range(x + 1, len(idx)):
                a, b = occ[idx[x]], occ[idx[y]]
                if (a["src"], a["cal"]) == (b["src"], b["cal"]):
                    continue
                if a["cancelled"] and b["cancelled"]:
                    continue
                if same_times(a, b) and a["cancelled"] == b["cancelled"]:
                    parent[root(idx[y])] = root(idx[x])
                else:
                    drift_pairs.append((idx[x], idx[y]))

    # one entry per event, with every calendar it is on
    reps, rep_of = [], {}
    for i, o in enumerate(occ):
        r = root(i)
        if r not in rep_of:
            rep_of[r] = len(reps)
            reps.append(dict(o, cals=[]))
        cal = (o["cal"], o["src"])
        if o.get("matter") and not reps[rep_of[r]].get("matter"):
            reps[rep_of[r]]["matter"] = o["matter"]
        if cal not in reps[rep_of[r]]["cals"]:
            reps[rep_of[r]]["cals"].append(cal)
    rid = [rep_of[root(i)] for i in range(n)]
    both = [r for r in reps if len(r["cals"]) > 1]

    twins, drift = set(), []
    for i, j in drift_pairs:
        k = frozenset((rid[i], rid[j]))
        if k in twins:
            continue
        twins.add(k)
        drift.append((reps[rid[i]], reps[rid[j]]))

    live = [r for r in reps if not r["cancelled"]]
    timed = sorted([r for r in live if not r["all_day"]], key=lambda r: r["start"])
    tid = {id(r): i for i, r in enumerate(reps)}

    def twin(a, b):
        return frozenset((tid[id(a)], tid[id(b)])) in twins

    overlaps, tentative = [], []
    for x in range(len(timed)):
        for y in range(x + 1, len(timed)):
            a, b = timed[x], timed[y]
            if twin(a, b):
                continue
            ov = overlap(a, b)
            if ov is None:
                continue
            if a["show"] in BUSY and b["show"] in BUSY:
                overlaps.append((a, b, ov))
            elif {a["show"], b["show"]} <= BUSY | {"tentative"}:
                tentative.append((a, b, ov))

    hearings, seen = [], set()
    for h in [r for r in timed if r["hearing"] and r["show"] in BUSY | {"tentative"}]:
        near = []
        hs, he = h["start"], h["end"] or h["start"]
        for x in timed:
            if x is h or x["show"] not in BUSY or twin(h, x):
                continue
            pk = frozenset((id(h), id(x)))
            if pk in seen:
                continue
            ov = overlap(h, x)
            xs, xe = x["start"], x["end"] or x["start"]
            if ov is not None:
                rel, gap = "overlap", ov
            elif xe <= hs:
                rel, gap = "before", mins(hs - xe)
            elif xs >= he:
                rel, gap = "after", mins(xs - he)
            else:
                continue
            if rel != "overlap" and gap >= hbuffer:
                continue
            seen.add(pk)
            near.append((x, rel, gap))
        for x, rel, gap in near:
            hearings.append((h, x, rel, gap))

    place = []
    busy_timed = [r for r in timed if r["show"] in BUSY]
    for a in busy_timed:
        for b in busy_timed:
            if a is b or twin(a, b) or overlap(a, b) is not None:
                continue
            gap = mins(b["start"] - (a["end"] or a["start"]))
            if 0 <= gap < buffer and physical(a) and physical(b) \
                    and nloc(a["location"]) != nloc(b["location"]):
                place.append((a, b, gap))
    place.sort(key=lambda p: p[1]["start"])

    all_day_busy = []
    for r in live:
        if not r["all_day"] or r["show"] not in BUSY:
            continue
        ds = set(dates_covered(r, lo, hi))
        alongside = [x for x in busy_timed if x["start"].date() in ds]
        if alongside:
            all_day_busy.append((r, alongside))

    dates = {}
    for r in live:
        for d in dates_covered(r, lo, hi):
            if day_facts(d):
                dates.setdefault(d, []).append(r)
    for d in dates:
        dates[d].sort(key=lambda r: (not r["all_day"], r["start"] or datetime.min))

    return {"reps": reps, "overlaps": overlaps, "tentative": tentative, "hearings": hearings,
            "place": place, "drift": drift, "both": both, "all_day_busy": all_day_busy,
            "dates": sorted(dates.items())}


# ---------------------------------------------------------------- page

CSS = """
body{margin:0;background:#f4f5f7;font-family:-apple-system,BlinkMacSystemFont,
"Segoe UI",Arial,sans-serif;color:#1b2a4a}
.w{max-width:900px;margin:0 auto;padding:28px 20px 70px}
.card{background:#fff;border:1px solid #e3e8ef;border-radius:12px;padding:22px 26px;margin-bottom:16px}
.k{font-size:11px;font-weight:600;letter-spacing:1.6px;text-transform:uppercase;color:#ca25b7;padding-bottom:10px}
h1{margin:0 0 6px;font-size:27px;font-weight:600;color:#0b1f3a;letter-spacing:-.5px}
.sub{color:#6a7488;font-size:14px;margin:0 0 18px;line-height:1.55}
.tally{display:flex;gap:10px;flex-wrap:wrap;margin:0 0 22px}
.t{background:#fff;border:1px solid #e3e8ef;border-radius:10px;padding:10px 16px;min-width:120px}
.t b{display:block;font-size:24px;color:#000c65}
.t span{font-size:11px;letter-spacing:1.2px;text-transform:uppercase;color:#8a93a6;font-weight:600}
table{width:100%;border-collapse:collapse;font-size:13.5px}
th{text-align:left;font-size:10.5px;letter-spacing:1.2px;text-transform:uppercase;color:#8a93a6;
font-weight:600;padding:0 8px 8px 0;border-bottom:1px solid #e3e8ef}
td{padding:8px 8px 8px 0;border-bottom:1px solid #f0f2f6;vertical-align:top}
td.n,th.n{text-align:right}
.late{color:#b4483a;font-weight:600}
.src{color:#8a93a6;font-size:11.5px;font-family:ui-monospace,Menlo,monospace}
.row{font-size:13.5px;line-height:1.55;padding:6px 0;border-bottom:1px solid #f0f2f6}
.foot{color:#8a93a6;font-size:12.5px;line-height:1.65}
.tag{display:inline-block;font-size:10px;font-weight:700;letter-spacing:1px;text-transform:uppercase;
padding:2px 8px;border-radius:20px;background:#f6e4f3;color:#a3208f;margin-left:4px;vertical-align:1px}
.light{background:#fafbfc;border-style:dashed}
.light .k{color:#8a93a6}
.row,td,.sub{overflow-wrap:break-word}
td.d{white-space:nowrap}
@media(max-width:600px){.card{padding:18px 16px}.tbl{overflow-x:auto}.tbl table{min-width:600px}
td.d{white-space:normal;width:90px}}
"""


def when_text(o, with_day=False):
    if o["all_day"]:
        last = o["d1"] - timedelta(days=1)
        w = "all day" if last == o["d0"] else f"all day, {fmt_day(o['d0'])} to {fmt_day(last)}"
        if with_day and last == o["d0"]:
            w = f"{fmt_day(o['d0'])}, all day"
    else:
        s = fmt_time(o["start"].time())
        if o["end"] is None:
            w = f"{s}, no end time given"
        elif o["end"].date() != o["start"].date():
            w = f"{s} to {fmt_day(o['end'].date())}, {fmt_time(o['end'].time())}"
        else:
            w = f"{s} to {fmt_time(o['end'].time())}"
        if with_day:
            w = f"{fmt_day(o['start'].date())}, {w}"
    if o["show"] != "busy":
        w += f", {SHOW_LABEL[o['show']]}"
    if o["cancelled"]:
        w += ", cancelled"
    return w


def cal_html(o):
    cals = o.get("cals") or [(o["cal"], o["src"])]
    return ", ".join(f"{nt(c)} ({nt(s)})" for c, s in cals)


def ev_cell(o, with_day=False):
    tag = f"<span class='tag'>{e(o['hearing'])}</span>" if o.get("hearing") else ""
    subj = nt(o["subject"]) if o["subject"] else e("No subject")
    loc = f"<div class='src'>{nt(o['location'])}</div>" if o.get("location") else ""
    mat = f" &middot; matter {nt(o['matter'])}" if o.get("matter") else ""
    return (f"<b>{subj}</b> {tag}<div class='src'>{e(when_text(o, with_day))} &middot; "
            f"{cal_html(o)}{mat}</div>{loc}")


def table(head, rows, empty, cols):
    if not rows:
        rows = [f"<tr><td colspan={cols} class=src>{e(empty)}</td></tr>"]
    return f"<div class='tbl'><table><tr>{head}</tr>{''.join(rows)}</table></div>"


def gap_text(rel, gap, what="the hearing"):
    if rel == "overlap":
        return (f"Overlaps by {plural(gap, 'minute')}" if gap else
                "Starts inside it, with no end time given")
    if rel == "before":
        return f"Ends {plural(gap, 'minute')} before {what}" if gap else f"Ends as {what} starts"
    return f"Starts {plural(gap, 'minute')} after {what}" if gap else f"Starts as {what} ends"


def drift_text(a, b):
    out = []
    if a["cancelled"] != b["cancelled"]:
        out.append("Cancelled on one, not on the other.")
    if a["all_day"] != b["all_day"]:
        out.append("All day on one, timed on the other.")
    elif a["all_day"]:
        if a["d1"] != b["d1"]:
            out.append("Ends on a different day.")
    else:
        ds = abs(mins(b["start"] - a["start"]))
        if ds:
            out.append(f"Start differs by {plural(ds, 'minute')}.")
        if a["end"] and b["end"]:
            de = abs(mins(b["end"] - a["end"]))
            if de:
                out.append(f"End differs by {plural(de, 'minute')}.")
        elif (a["end"] is None) != (b["end"] is None):
            out.append("One has no end time.")
    return " ".join(out) or "Times differ."


def render(r, ctx):
    lo, last = ctx["lo"], ctx["last"]
    span = (f"{lo:%B} {lo.day} to {last:%B} {last.day}, {last.year}" if lo.year == last.year else
            f"{lo:%B} {lo.day}, {lo.year} to {last:%B} {last.day}, {last.year}")

    src_bits = []
    for info in ctx["sources"]:
        bit = nt(info["src"])
        if info.get("pulled"):
            bit += f", read {nt(info['pulled'])}"
        cals = [c for (s, c) in ctx["counts"] if s == info["src"]]
        bit += ", " + plural(len(cals), "calendar") + ": " + ", ".join(nt(c) for c in cals)
        src_bits.append(bit)

    ov_rows = [f"<tr><td class=d>{e(fmt_day(a['start'].date()))}</td><td>{ev_cell(a)}</td><td>{ev_cell(b)}</td>"
               f"<td class=n>{ov if ov else '0, no end time'}</td></tr>" for a, b, ov in r["overlaps"]]
    te_rows = [f"<tr><td class=d>{e(fmt_day(a['start'].date()))}</td><td>{ev_cell(a)}</td><td>{ev_cell(b)}</td>"
               f"<td class=n>{ov if ov else '0, no end time'}</td></tr>" for a, b, ov in r["tentative"]]
    he_rows = [f"<tr><td>{ev_cell(h, True)}</td><td>{ev_cell(x)}</td><td>{e(gap_text(rel, gap))}</td></tr>"
               for h, x, rel, gap in r["hearings"]]
    pl_rows = [f"<tr><td class=d>{e(fmt_day(b['start'].date()))}</td><td>{ev_cell(a)}</td><td>{ev_cell(b)}</td>"
               f"<td class=n>{gap}</td></tr>" for a, b, gap in r["place"]]
    dr_rows = [f"<tr><td class=d>{e(fmt_day(day_of(a)))}</td><td>{ev_cell(a)}</td><td>{ev_cell(b)}</td>"
               f"<td>{e(drift_text(a, b))}</td></tr>" for a, b in r["drift"]]
    both_rows = "".join(f"<div class='row'>{ev_cell(o, True)}</div>" for o in r["both"]) \
        or "<div class='foot'>None in the window.</div>"
    ad_rows = [f"<tr><td>{ev_cell(o, True)}</td><td>"
               + "".join(f"<div style='margin-bottom:6px'>{ev_cell(x, True)}</div>" for x in xs)
               + "</td></tr>" for o, xs in r["all_day_busy"]]
    da_rows = [f"<tr><td>{e(fmt_date_long(d))}</td><td>{e(' '.join(day_facts(d)))}</td><td>"
               + "".join(f"<div style='margin-bottom:6px'>{ev_cell(o)}</div>" for o in evs)
               + "</td></tr>" for d, evs in r["dates"]]

    c_rows, tot = [], [0] * 8
    for (s, c), v in ctx["counts"].items():
        vals = [v["entries"], v["unread"], v["outside"], v["win"], v["free"], v["tentative"],
                v["cancelled"], v["all_day"]]
        tot = [a + b for a, b in zip(tot, vals)]
        c_rows.append(f"<tr><td>{nt(c)}<div class='src'>{nt(s)}</div></td>"
                      + "".join(f"<td class=n>{x}</td>" for x in vals) + "</tr>")
    c_rows.append("<tr><td><b>Every source</b></td>"
                  + "".join(f"<td class=n><b>{x}</b></td>" for x in tot) + "</tr>")

    nr_rows = "".join(
        f"<div class='row'><b>{nt(s) if s else e('No subject')}</b> "
        f"<span class='src'>{nt(c)} ({nt(f)})</span><br>{e(why[:1].upper() + why[1:])}"
        f"{(': ' + nt(val)) if val else '.'}</div>"
        for f, c, s, (why, val) in ctx["unread"]) or "<div class='foot'>Every entry was read.</div>"
    note_rows = "".join(
        f"<div class='row'><b>{nt(s) if s else e('No subject')}</b> "
        f"<span class='src'>{nt(c)} ({nt(f)})</span><br>{e(why[:1].upper() + why[1:])}"
        f"{(': ' + nt(val)) if val else '.'}</div>"
        for f, c, s, (why, val) in ctx["notes"]) or "<div class='foot'>None.</div>"

    caret_card = ""
    cx = ctx.get("caret")
    if cx:
        tk = cx["taken"]
        age = cx["age"]
        if age < 0:
            age_txt = f"Taken {plural(-age, 'day')} after the as-of date."
        elif age == 0:
            age_txt = "Taken on the as-of date."
        else:
            age_txt = f"{plural(age, 'day')} old on the as-of date."
        stale = ""
        if age > CARET_STALE_DAYS:
            stale = (f"<p class='late' style='margin:8px 0 0'>The export is older than "
                     f"{plural(CARET_STALE_DAYS, 'day')}. A CARET entry made or changed after "
                     f"{e(fmt_date_long(tk.date()))} is not on this page.</p>")
        cal_line = (f"Calendar.csv read: {plural(ctx['counts'].get((cx['src'], CARET_CAL), {}).get('entries', 0), 'row')}."
                    if cx["has_calendar"] else
                    "Calendar.csv is not in the export, so no CARET entry is on this page.")
        caret_card = (f"<div class=\"card\"><div class=\"k\">CARET Export</div>"
                      f"<div class='row'><b>{nt(cx['name'])}</b><div class='src'>Taken "
                      f"{e(fmt_date_long(tk.date()))}, {e(fmt_time(tk.time()))}. {e(age_txt)}</div></div>"
                      f"<p class='foot' style='margin:8px 0 0'>{e(cal_line)} CARET is read through its "
                      f"firm export. Its times are converted from UTC to Eastern. A recurring CARET "
                      f"entry carries no repeat rule in the export, so only the occurrence it lists "
                      f"is read.</p>{stale}</div>")

    th = lambda *cols: "".join(f"<th{' class=n' if c.startswith('#') else ''}>{e(c.lstrip('#'))}</th>"
                               for c in cols)
    b, hb = ctx["buffer"], ctx["hbuffer"]

    return f"""<!DOCTYPE html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>Calendar Conflicts</title><style>{CSS}</style></head><body><div class="w">
<div class="k">Calendar Conflicts &middot; Item 13</div>
<h1>{e(span)}</h1>
<p class="sub">Read {plural(len(ctx['sources']), 'source')}: {'; '.join(src_bits)}. Every time is Eastern.
A change of place counts under {plural(b, 'minute')}. A hearing is checked {plural(hb, 'minute')}
before and after.</p>
{caret_card}<div class="tally">
<div class="t"><b>{len(r['overlaps'])}</b><span>Overlaps</span></div>
<div class="t"><b>{len(r['tentative'])}</b><span>Tentative</span></div>
<div class="t"><b>{len(r['hearings'])}</b><span>Hearing Collisions</span></div>
<div class="t"><b>{len(r['place'])}</b><span>Changes of Place</span></div>
<div class="t"><b>{len(r['drift'])}</b><span>Sync Drift</span></div>
<div class="t"><b>{len(r['dates'])}</b><span>Dates to See</span></div>
</div>
<div class="card"><div class="k">Overlaps</div>
{table(th('Day', 'One', 'The Other', '#Minutes'), ov_rows, 'No two busy events overlap in the window.', 4)}
<p class="foot" style="margin-top:10px">Two events marked busy or out of office whose times
intersect, on any calendars. Free and cancelled events are not checked here. They are
counted under What Was Read.</p></div>
<div class="card light"><div class="k">Tentative Overlaps</div>
{table(th('Day', 'One', 'The Other', '#Minutes'), te_rows, 'None in the window.', 4)}
<p class="foot" style="margin-top:10px">An event marked tentative whose time intersects a busy
or tentative event.</p></div>
<div class="card"><div class="k">Hearing Collisions</div>
{table(th('Hearing', 'Busy Nearby', 'Gap'), he_rows, 'Nothing busy within the buffer of a hearing.', 3)}
<p class="foot" style="margin-top:10px">Everything busy from {plural(hb, 'minute')} before a
hearing to {plural(hb, 'minute')} after it. A hearing is read by the same words, the Hearing
category, and the [no prep] tag that hearing prep uses.</p></div>
<div class="card"><div class="k">Tight Changes of Place</div>
{table(th('Day', 'From', 'To', '#Minutes Between'), pl_rows, 'None in the window.', 4)}
<p class="foot" style="margin-top:10px">Two busy events at two different physical locations
with less than {plural(b, 'minute')} between the end of one and the start of the next. A location
that reads as Zoom, Teams, Webex, a phone, a call, a conference line, or a link is not physical.
An event with no location is not counted here.</p></div>
<div class="card"><div class="k">Sync Drift</div>
{table(th('Day', 'One Calendar', 'The Other', 'Difference'), dr_rows, 'None in the window.', 4)}
<p class="foot" style="margin-top:10px">The same subject on the same day on two calendars or
sources, with different times or a different status.</p></div>
<div class="card"><div class="k">On Both Calendars</div>{both_rows}
<p class="foot" style="margin-top:10px">The same subject at the same times on more than one
calendar. Each is checked once above.</p></div>
<div class="card"><div class="k">Busy or Away All Day</div>
{table(th('All Day', 'Timed and Busy the Same Day'), ad_rows, 'None in the window.', 2)}</div>
<div class="card"><div class="k">Dates to See</div>
{table(th('Date', 'The Day', 'On the Calendar'), da_rows, 'Nothing falls on a weekend or a holiday in the window.', 3)}
<p class="foot" style="margin-top:10px">Weekends, federal holidays, and DC Emancipation Day,
computed for the year, with a Saturday holiday observed the Friday before and a Sunday holiday the
Monday after.</p></div>
<div class="card"><div class="k">What Was Read</div>
{table(th('Calendar', '#Entries', '#Not Read', '#Outside the Window', '#In the Window', '#Free', '#Tentative', '#Cancelled', '#All Day'), c_rows, '', 9)}
<p class="foot" style="margin-top:10px">Entries are the events in each file. In the window counts
occurrences, so a repeating event counts once for each time it falls in the window. Free includes
working elsewhere. A calendar listed with no events shows zero.</p></div>
<div class="card"><div class="k">Not Read</div>{nr_rows}</div>
<div class="card"><div class="k">Read With a Note</div>{note_rows}</div>
<div class="card"><p class="foot" style="margin:0">{FOOT.format(buffer=b, caret=CARET_AFTER if cx else CARET_NOT_SEEN)}</p></div>
</div></body></html>"""


def check_words(html):
    """The engine's own words never advise. Calendar text, marked nt, is skipped."""
    own = re.sub(r'<span class="nt">.*?</span>', " ", html, flags=re.S)
    low = " " + re.sub(r"<[^>]+>", " ", own).lower() + " "
    for w in WORDS_NEVER_PRINTED:
        if w in low:
            raise SystemExit(f"Refusing to write: the page contains '{w.strip()}'. "
                             f"The conflict check computes. It does not advise.")


def as_json(r, ctx):
    def ev(o):
        return {"subject": o["subject"], "all_day": o["all_day"],
                "start": (o["start"].isoformat(timespec="minutes") if o["start"] else o["d0"].isoformat()),
                "end": (o["end"].isoformat(timespec="minutes") if o["end"] else
                        (o["d1"].isoformat() if o["all_day"] else None)),
                "location": o.get("location", ""), "show_as": o["show"], "cancelled": o["cancelled"],
                "hearing": o.get("hearing"), "matter": o.get("matter") or None,
                "calendars": [{"calendar": c, "source": s} for c, s in (o.get("cals") or [(o["cal"], o["src"])])]}
    cx = ctx.get("caret")
    return {
        "caret_export": ({"file": cx["name"], "taken": cx["taken"].isoformat(timespec="minutes"),
                          "age_days": cx["age"], "older_than_7_days": cx["age"] > CARET_STALE_DAYS,
                          "has_calendar": cx["has_calendar"]} if cx else None),
        "as_of": ctx["lo"].date().isoformat(), "through": ctx["last"].isoformat(),
        "times": "Eastern", "buffer_minutes": ctx["buffer"], "hearing_buffer_minutes": ctx["hbuffer"],
        "overlaps": [{"one": ev(a), "other": ev(b), "minutes": m} for a, b, m in r["overlaps"]],
        "tentative": [{"one": ev(a), "other": ev(b), "minutes": m} for a, b, m in r["tentative"]],
        "hearing_collisions": [{"hearing": ev(h), "nearby": ev(x), "relation": rel, "minutes": g}
                               for h, x, rel, g in r["hearings"]],
        "changes_of_place": [{"from": ev(a), "to": ev(b), "minutes_between": g} for a, b, g in r["place"]],
        "sync_drift": [{"one": ev(a), "other": ev(b), "difference": drift_text(a, b)} for a, b in r["drift"]],
        "on_both_calendars": [ev(o) for o in r["both"]],
        "busy_all_day": [{"item": ev(o), "timed_same_day": [ev(x) for x in xs]} for o, xs in r["all_day_busy"]],
        "dates_to_see": [{"date": d.isoformat(), "facts": day_facts(d), "events": [ev(o) for o in evs]}
                         for d, evs in r["dates"]],
        "counts": [dict(v, source=s, calendar=c) for (s, c), v in ctx["counts"].items()],
        "not_read": [{"source": f, "calendar": c, "subject": s, "reason": why, "value": val}
                     for f, c, s, (why, val) in ctx["unread"]],
        "read_with_a_note": [{"source": f, "calendar": c, "subject": s, "note": why, "value": val}
                             for f, c, s, (why, val) in ctx["notes"]],
    }


# ---------------------------------------------------------------- the run

def run(events_files, ics_files, as_of, days, buffer, hbuffer, caret=None):
    lo = datetime.combine(as_of, time())
    last = as_of + timedelta(days=days)
    hi = datetime.combine(last + timedelta(days=1), time())

    sources, entries = [], []
    for p in events_files:
        info, ents = read_events_file(p)
        sources.append(info)
        entries += ents
    for p in ics_files:
        info, ents = read_ics_file(p, lo, hi)
        sources.append(info)
        entries += ents
    caret_src = None
    if caret is not None:
        caret_src, ents = read_caret_file(caret, as_of)
        sources.append(caret_src)
        entries += ents

    counts = {}

    def row(s, c):
        return counts.setdefault((s, c), {"entries": 0, "unread": 0, "outside": 0, "win": 0,
                                          "free": 0, "tentative": 0, "cancelled": 0, "all_day": 0})

    for info in sources:
        for c in info["calendars"]:
            row(info["src"], c)

    occ, unread, notes = [], [], []
    for ent in entries:
        v = row(ent["src"], ent["cal"])
        v["entries"] += 1
        if ent["unread"]:
            v["unread"] += 1
            unread.append((ent["src"], ent["cal"], ent["subject"], ent["unread"]))
            continue
        inw = [o for o in ent["occ"] if in_window(o, lo, hi)]
        if not inw:
            v["outside"] += 1
            continue
        for o in inw:
            v["win"] += 1
            if o["cancelled"]:
                v["cancelled"] += 1
            elif o["show"] in FREE:
                v["free"] += 1
            elif o["show"] == "tentative":
                v["tentative"] += 1
            if o["all_day"]:
                v["all_day"] += 1
        occ += inw
        for nt_ in ent["notes"]:
            notes.append((ent["src"], ent["cal"], ent["subject"], nt_))

    r = analyse(occ, lo, hi, buffer, hbuffer)
    ctx = {"lo": lo, "last": last, "hi": hi, "sources": sources, "counts": counts,
           "unread": unread, "notes": notes, "buffer": buffer, "hbuffer": hbuffer,
           "caret": caret_src}
    return r, ctx


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--events", action="append", default=[])
    ap.add_argument("--ics", action="append", default=[])
    ap.add_argument("--caret", nargs="?", const="", default=None,
                    help="the CARET FirmExport zip or folder; with no path, the newest in Downloads")
    ap.add_argument("--as-of")
    ap.add_argument("--days", type=int, default=14)
    ap.add_argument("--buffer", type=int, default=30)
    ap.add_argument("--hearing-buffer", type=int, default=60)
    ap.add_argument("--out", default="Calendar Conflicts.html")
    ap.add_argument("--json")
    a = ap.parse_args(argv)
    if not a.events and not a.ics and a.caret is None:
        raise SystemExit("Give at least one calendar: --events, --caret, or --ics.")
    caret = None
    if a.caret is not None:
        try:
            caret = CX.find_export(a.caret or None)
        except FileNotFoundError as x:
            raise SystemExit(str(x))
        if caret is None:
            raise SystemExit("No CARET export found. In CARET: Firm Settings, Your CARET Legal "
                             "Account, Export, Download Data. The FirmExport zip lands in Downloads.")
    for p in a.events + a.ics:
        if not Path(p).exists():
            raise SystemExit(f"Not found: {p}")
    as_of = date.fromisoformat(a.as_of) if a.as_of else date.today()

    r, ctx = run(a.events, a.ics, as_of, a.days, a.buffer, a.hearing_buffer, caret)
    html = render(r, ctx)
    check_words(html)
    Path(a.out).write_text(html, encoding="utf-8")
    if a.json:
        Path(a.json).write_text(json.dumps(as_json(r, ctx), indent=1), encoding="utf-8")

    tot = {k: sum(v[k] for v in ctx["counts"].values()) for k in ("entries", "unread", "win")}
    print(f"Written: {a.out}   {as_of} through {ctx['last']}, Eastern")
    cx = ctx["caret"]
    if cx:
        print(f"  CARET export {cx['name']}, taken {cx['taken']:%Y-%m-%d %H:%M}, {cx['age']} day(s) old"
              + (f", older than {CARET_STALE_DAYS} days" if cx["age"] > CARET_STALE_DAYS else "")
              + ("" if cx["has_calendar"] else ", no Calendar.csv in it"))
    print(f"  {tot['entries']} entr(ies) read from {len(ctx['sources'])} source(s), "
          f"{tot['win']} occurrence(s) in the window, {tot['unread']} not read")
    print(f"  {len(r['overlaps'])} overlap(s), {len(r['tentative'])} tentative, "
          f"{len(r['hearings'])} hearing collision(s), {len(r['place'])} change(s) of place, "
          f"{len(r['drift'])} drift, {len(r['both'])} on both calendars, "
          f"{len(r['dates'])} date(s) to see")
    for f, c, s, (why, val) in ctx["unread"]:
        print(f"  NOT READ {f} / {c}: {s or 'No subject'}: {why}" + (f": {val}" if val else ""))
    return r, ctx


if __name__ == "__main__":
    main()

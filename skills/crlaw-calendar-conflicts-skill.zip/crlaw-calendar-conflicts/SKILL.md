---
name: crlaw-calendar-conflicts
description: Multi-calendar sync with conflict detection for the Law Offices of Charles A. Ray, P.C. Use whenever Charles asks whether his calendar collides with itself, including "check my calendar for conflicts", "am I double booked", "any conflicts next week", "does my hearing clash with anything", "sync check", "is CARET in sync with Outlook", "anything on a holiday", or when a scheduled morning run asks for it. It reads every Outlook calendar and any .ics export it is given (a CARET export, a court feed, a personal calendar), puts every time in Eastern, and reports overlaps, hearing collisions, tight changes of place, sync drift between calendars, and dates that fall on a weekend or a holiday. It never moves or declines anything, and it never says what to do.
---

# Calendar Conflicts

Item 13. Charles keeps his calendar in Outlook. CARET, his practice management
system, has no API. His own notes say Outlook events sync to CARET on their
own, so Outlook is read as the master. This skill reads every calendar it is
given, converts every time to Eastern, and writes one page of what collides in
the next 14 days.

Three rules, and they are the firm's:

- **It computes. It never recommends.** The page refuses to write if the
  engine's own words advise. Subjects and locations are the calendar's words
  and pass.
- **Nothing is dropped.** Every event read is counted. Every event not read is
  listed by name with the reason: a repeat rule the engine cannot expand, a
  date it cannot read, a time zone it does not know.
- **Every line says where it came from**: the calendar and the file.

---

## Run It

**1. Read every Outlook calendar.** With the Outlook connector, list his
calendars first, so none is missed: the main calendar, a court dates calendar,
shared calendars, personal ones. Then read each one from today through 14 days
out. Write every event, unfiltered, to `events.json` in the shape in
`reference/inputs.md`: subject, start and end with their offsets, location,
the first lines of the notes, categories, the calendar's name, show as, all
day, cancelled, and the event id. Put the calendar names in `calendars`, so a
calendar with nothing in the window still shows on the page as read.

**2. Add any .ics exports.** A CARET export if one exists, a court calendar
feed, a personal calendar. Each is its own `--ics`.

**3. Run the engine.**

```
python3 scripts/conflicts.py --events events.json \
    --ics "C:/Users/<you>/Documents/Calendar Exports/CARET.ics" \
    --as-of 2026-10-13 --days 14 --buffer 30 --hearing-buffer 60 \
    --out "Calendar Conflicts.html" --json conflicts.json
```

- `--events` and `--ics` may each repeat. At least one source is needed.
- `--days` sets the window, from the as-of date through as-of plus that many
  days. It defaults to 14.
- `--buffer` sets the minutes between two physical places below which a
  change of place is listed. It defaults to 30.
- `--hearing-buffer` sets the minutes checked before and after a hearing. It
  defaults to 60.
- `--json` writes the same findings for another skill to read.

The run prints the tallies and every entry it did not read.

**4. Hand him the page.** Say how many overlaps, which hearings have something
close, and any drift between calendars. Do not add advice the page does not
carry.

---

## The Page

| Section | What it shows |
|---|---|
| Overlaps | Two busy or out-of-office events whose times intersect, on any calendars, with the minutes they share and both calendars. |
| Tentative Overlaps | A tentative event that intersects a busy or tentative one, in a lighter card. |
| Hearing Collisions | Anything busy from 60 minutes before a hearing to 60 minutes after it, with the gap in minutes. |
| Tight Changes of Place | Back-to-back busy events at two different physical places with less than 30 minutes between them. |
| Sync Drift | The same subject on the same day on two calendars, at different times or cancelled on one only. Both versions shown. |
| On Both Calendars | The same subject at the same times on more than one calendar. Listed once and checked once. |
| Busy or Away All Day | An all-day item marked busy or out of office, with every timed busy event on its days. |
| Dates to See | Every event on a Saturday, a Sunday, a federal holiday, or DC Emancipation Day, with the day named. |
| What Was Read | For each source and calendar: entries, not read, outside the window, in the window, free, tentative, cancelled, all day. |
| Not Read | Every entry the engine could not read, by name, with the reason. |
| Read With a Note | Every entry read on a stated assumption, such as no end time. |

Free and cancelled events are in no check. They are counted. The rule behind
each section, the words that make a location virtual, and the holidays are in
`reference/rules.md`.

---

## What CARET Means Here

- Outlook is read directly. If his CARET entries originate in Outlook, as his
  notes say, the Outlook read covers them.
- A CARET-only entry, one made in CARET and never in Outlook, is covered once
  CARET can export .ics or a scheduled report, passed as another source.
  Whether such entries exist is confirmed with him on October 13.
- With a CARET export given, an entry on both at the same times is listed once
  under On Both Calendars. One at different times, or cancelled on one only,
  is Sync Drift.
- A CARET entry that never reached any source given is not seen. The foot of
  the page says so on every run.

---

## What Reads as a Hearing

The same rules as hearing prep: CDP, collection due process, Tax Court,
calendar call, trial, Appeals, OAH, administrative hearing, hearing officer,
hearing, examination, exam, audit, revenue agent, revenue officer, settlement
conference. An Outlook category named **Hearing** always counts. **[no prep]**
in the subject never does. The list is `TRIGGERS` at the top of
`scripts/conflicts.py`, copied from hearing prep. A change to one goes into
both.

---

## Every Morning

Built to be scheduled. Weekdays at 6:50 a.m., a scheduled task:

> Run the calendar conflict check. List my Outlook calendars, read every one
> from today through 14 days out into events.json, add any .ics exports in my
> Calendar Exports folder, and run crlaw-calendar-conflicts. Send me the page
> if it shows an overlap, a hearing collision, a tight change of place, or sync
> drift.

Daylight time does not move the times. The engine converts every start to
Eastern itself, on the second Sunday of March and the first Sunday of
November, without a time zone database.

---

## What It Will Not Do

- Move, decline, accept, or reschedule anything.
- Write to any calendar. It reads Outlook and the exports, and writes only its
  page and its JSON.
- Read CARET directly. CARET has no API. A CARET entry reaches the page only
  through Outlook or an export.
- Give a legal consequence of a date. A holiday is named as a holiday. Whether
  a deadline moves is not stated.
- Check travel time beyond the buffer, or court rules.
- Put a client name in a file name. The page and the JSON are named for what
  they are.

# Inputs

## The Events File

`events.json`, written by Claude from the Outlook connector. Every event in
the window, from every calendar. Do not filter. One file may hold several
calendars. It is the shape hearing prep reads, with a few fields added.

```json
{
  "pulled": "2026-10-13 06:50",
  "window": "Oct 13 to Oct 27",
  "calendars": ["Calendar", "Court dates", "Personal"],
  "events": [
    {
      "id": "AAMkAG...",
      "subject": "CDP hearing, M-0142",
      "start": "2026-10-20T10:00:00-04:00",
      "end": "2026-10-20T11:00:00-04:00",
      "location": "Appeals, conference line",
      "body": "first lines of the notes",
      "organizer": "Settlement Officer",
      "categories": ["Hearing"],
      "calendar": "Court dates",
      "show_as": "busy",
      "is_all_day": false,
      "is_cancelled": false
    }
  ]
}
```

| Field | Rule |
|---|---|
| `calendars` | Every calendar the connector listed, read or empty. A listed calendar with nothing in the window shows on the page with zeros, so it reads as checked. |
| `start`, `end` | With the offset, or ending in `Z` for UTC. The engine converts to Eastern itself. The connector's own form, `{"dateTime": "...", "timeZone": "UTC"}`, is read too, for UTC and Eastern zone names. Any other zone is listed as not read. |
| `end` missing | Read at its start time only, and listed under Read With a Note. |
| `calendar` | The calendar's name as Outlook shows it. Missing, it reads "Calendar not named". |
| `show_as` | `busy`, `tentative`, `free`, `oof`, or `workingElsewhere`. Missing, it is busy. Any other value is read as busy and listed under Read With a Note. |
| `is_all_day` | True for an all-day item. The date is taken as written, with no time zone conversion. `end` is the day after the last day, the way Outlook gives it. A start that is a date alone, `2026-10-23`, is all day too. |
| `is_cancelled` | True for a cancelled event. A subject that opens with "Canceled:" reads as cancelled as well. |
| `id` | The Outlook event id. Shown in the JSON output only. |

A start or end that does not read as a date is listed on the page by name,
never dropped.

## The CARET Export

CARET Legal has no API. Its firm export is the way in. In CARET: Firm
Settings, Your CARET Legal Account, Export, Download Data. CARET saves
`FirmExport-<n>.zip` to Downloads, holding one CSV per record type: Calendar,
Matter, Task, Notes, Hours, the contacts, Invoice, and the checks. Nothing is
unzipped. The engine reads `Calendar.csv` straight out of the zip.

`--caret` with no path reads the newest FirmExport zip or folder in Downloads,
or in a Claude AI Reports folder under the home folder or OneDrive. With a
path, it reads that zip, or a folder holding the CSVs.

Headers are matched by meaning: case, spaces, and punctuation are set aside,
so `FromDate`, `From Date`, and `fromdate` read the same. CARET's own spelling
`Descrption` is read, and so is `Description`.

| Column | How It Is Read |
|---|---|
| `Subject` | The event's subject, HTML removed. |
| `FromDate`, `ToDate` | `2026-08-05T08:30:00+00:00` is UTC and converted to Eastern. A time with no offset is Eastern. `10/22/2026 2:00 PM` reads too. A date alone is all day. |
| `IsAllday` | TRUE is all day. The date is taken as written, with no time zone conversion. An end at midnight is the start of the day after the last day. An end on the same date, or a date alone, is the last day. |
| `Location` | As written, HTML removed. |
| `Descrption` | HTML removed, paragraphs kept as line breaks, the first 400 characters. Read for hearing words. |
| `MatterNumber` | `01391-Romain P...` is split to the number, `01391`, shown beside the event. Blank is no matter. |
| `IsRecurring` | TRUE with no repeat rule in the export. Only the listed occurrence is known. It is read as that one event and listed under Read With a Note: recurring in CARET, listed occurrence only. |
| `CategoryName` | `Hearing` counts as a hearing. `None` is no category. |
| `Owner`, `IsPrivate`, `MatterPermission`, `CreatedTime`, `ModifiedTime`, `Modifiedby` | Not used. |

Every CARET row is busy and not cancelled, since the export carries no show-as
or status. A subject that opens with "Canceled:" reads as cancelled, as it does
everywhere. A row that does not read is listed under Not Read by subject, with
its line in the file, `Calendar.csv row 11`.

The page names the export, when it was taken (the newest file time inside the
zip), and its age in days on the as-of date. Over 7 days old, the page says
so: a CARET entry made or changed after that date is not on the page. An
export with no `Calendar.csv` is named on the page, with no CARET entries.

## The .ics Files

Any other calendar file: a court calendar feed, a personal calendar. Each
file is one source. Its calendar is named by `X-WR-CALNAME`, or by the file
name when there is none.

Read from each `VEVENT`:

| Property | How It Is Read |
|---|---|
| `DTSTART`, `DTEND` | `TZID=America/New_York` (and other Eastern names) as written. A `Z` time as UTC, converted. A time with no zone as Eastern. `VALUE=DATE` as all day, with `DTEND` the day after the last day. Any other `TZID` is listed as not read. |
| `DURATION` | When there is no `DTEND`. Weeks, days, hours, minutes, seconds. |
| `SUMMARY`, `LOCATION`, `DESCRIPTION` | Folded lines joined. `\,` `\;` `\n` and `\\` read as the comma, semicolon, new line, and backslash they stand for. |
| `CATEGORIES` | For the Hearing category. |
| `STATUS:CANCELLED` | Cancelled. `STATUS:TENTATIVE` is tentative. |
| `TRANSP:TRANSPARENT` | Free. |
| `X-MICROSOFT-CDO-BUSYSTATUS` | Read first when Outlook wrote it: free, tentative, busy, out of office, working elsewhere. |
| `RRULE` | `FREQ=DAILY`, `WEEKLY`, or `MONTHLY`, with `INTERVAL`, `COUNT`, `UNTIL`, `WKST`, and `BYDAY` on a weekly rule. A monthly rule repeats on the start's day of the month and skips a month without that day. |
| `EXDATE` | Each excluded occurrence is left out. |
| `RECURRENCE-ID` | A changed occurrence replaces the one it names. |

Not expanded, and listed by name with the reason: any other repeat rule (a
yearly rule, `BYDAY` on a monthly rule such as the first Monday,
`BYMONTHDAY`, `BYSETPOS`), `RDATE`, `EXRULE`, and any date that does not read.
A series whose rule is not expanded and which provably falls outside the
window, by its start or its `UNTIL`, is counted as outside the window.

## The JSON Output

`--json conflicts.json` writes what the page shows, for another skill to read:
`overlaps`, `tentative`, `hearing_collisions`, `changes_of_place`,
`sync_drift`, `on_both_calendars`, `busy_all_day`, `dates_to_see`, `counts`,
`not_read`, `read_with_a_note`, and `caret_export` (the file, when it was
taken, its age in days, and whether it is older than 7 days). Every event
carries `matter`, the CARET matter number or null. Every time is Eastern, written
`2026-10-20T10:00`. Every event carries its calendars and sources. Nothing is
written, page or JSON, when the page refuses.

# Inputs

## The Events File

`events.json`, written by Claude from the Outlook connector. Every event in
the window, from every calendar. Do not filter. One file may hold several
calendars. It is the shape hearing prep reads, with a few fields added.

```json
{
  "pulled": "2026-10-13 06:50",
  "window": "Oct 13 to Oct 27",
  "calendars": ["Calendar", "Court dates", "Personal"],
  "events": [
    {
      "id": "AAMkAG...",
      "subject": "CDP hearing, M-0142",
      "start": "2026-10-20T10:00:00-04:00",
      "end": "2026-10-20T11:00:00-04:00",
      "location": "Appeals, conference line",
      "body": "first lines of the notes",
      "organizer": "Settlement Officer",
      "categories": ["Hearing"],
      "calendar": "Court dates",
      "show_as": "busy",
      "is_all_day": false,
      "is_cancelled": false
    }
  ]
}
```

| Field | Rule |
|---|---|
| `calendars` | Every calendar the connector listed, read or empty. A listed calendar with nothing in the window shows on the page with zeros, so it reads as checked. |
| `start`, `end` | With the offset, or ending in `Z` for UTC. The engine converts to Eastern itself. The connector's own form, `{"dateTime": "...", "timeZone": "UTC"}`, is read too, for UTC and Eastern zone names. Any other zone is listed as not read. |
| `end` missing | Read at its start time only, and listed under Read With a Note. |
| `calendar` | The calendar's name as Outlook shows it. Missing, it reads "Calendar not named". |
| `show_as` | `busy`, `tentative`, `free`, `oof`, or `workingElsewhere`. Missing, it is busy. Any other value is read as busy and listed under Read With a Note. |
| `is_all_day` | True for an all-day item. The date is taken as written, with no time zone conversion. `end` is the day after the last day, the way Outlook gives it. A start that is a date alone, `2026-10-23`, is all day too. |
| `is_cancelled` | True for a cancelled event. A subject that opens with "Canceled:" reads as cancelled as well. |
| `id` | The Outlook event id. Shown in the JSON output only. |

A start or end that does not read as a date is listed on the page by name,
never dropped.

## The .ics Files

Any export: a CARET export, a court calendar feed, a personal calendar. Each
file is one source. Its calendar is named by `X-WR-CALNAME`, or by the file
name when there is none.

Read from each `VEVENT`:

| Property | How it is read |
|---|---|
| `DTSTART`, `DTEND` | `TZID=America/New_York` (and other Eastern names) as written. A `Z` time as UTC, converted. A time with no zone as Eastern. `VALUE=DATE` as all day, with `DTEND` the day after the last day. Any other `TZID` is listed as not read. |
| `DURATION` | When there is no `DTEND`. Weeks, days, hours, minutes, seconds. |
| `SUMMARY`, `LOCATION`, `DESCRIPTION` | Folded lines joined. `\,` `\;` `\n` and `\\` read as the comma, semicolon, new line, and backslash they stand for. |
| `CATEGORIES` | For the Hearing category. |
| `STATUS:CANCELLED` | Cancelled. `STATUS:TENTATIVE` is tentative. |
| `TRANSP:TRANSPARENT` | Free. |
| `X-MICROSOFT-CDO-BUSYSTATUS` | Read first when Outlook wrote it: free, tentative, busy, out of office, working elsewhere. |
| `RRULE` | `FREQ=DAILY`, `WEEKLY`, or `MONTHLY`, with `INTERVAL`, `COUNT`, `UNTIL`, `WKST`, and `BYDAY` on a weekly rule. A monthly rule repeats on the start's day of the month and skips a month without that day. |
| `EXDATE` | Each excluded occurrence is left out. |
| `RECURRENCE-ID` | A changed occurrence replaces the one it names. |

Not expanded, and listed by name with the reason: any other repeat rule (a
yearly rule, `BYDAY` on a monthly rule such as the first Monday,
`BYMONTHDAY`, `BYSETPOS`), `RDATE`, `EXRULE`, and any date that does not read.
A series whose rule is not expanded and which provably falls outside the
window, by its start or its `UNTIL`, is counted as outside the window.

## The JSON Output

`--json conflicts.json` writes what the page shows, for another skill to read:
`overlaps`, `tentative`, `hearing_collisions`, `changes_of_place`,
`sync_drift`, `on_both_calendars`, `busy_all_day`, `dates_to_see`, `counts`,
`not_read`, and `read_with_a_note`. Every time is Eastern, written
`2026-10-20T10:00`. Every event carries its calendars and sources. Nothing is
written, page or JSON, when the page refuses.

# The Rules

Each section of the page, and exactly what puts an event in it. The engine
computes these. None of them says what to do.

## The Window

From the as-of date at midnight through the end of the last day, as-of plus
`--days`, Eastern. An event that runs into the window from the day before
counts. An event that ends at midnight on the first day does not.

## What Takes Part

| Shown As | Overlaps | Tentative | Hearings | Change of Place | Drift and Dates |
|---|---|---|---|---|---|
| Busy | Yes | Yes | Yes | Yes | Yes |
| Out of office | Yes | Yes | Yes | Yes | Yes |
| Tentative | No | Yes | A tentative hearing is checked | No | Yes |
| Free, working elsewhere | No | No | No | No | Yes |
| Cancelled | No | No | No | No | Drift only |

Free, working elsewhere, and cancelled events are counted under What Was Read
on every run.

## Overlaps

Two timed events, both busy or out of office, whose times intersect. The
minutes are the time they share. Two events on the same calendar count. The
two versions of one event on two calendars do not: those are Sync Drift or On
Both Calendars. An event with no end time overlaps when it starts inside the
other, shown as 0 minutes.

## Tentative Overlaps

A tentative event whose time intersects a busy, out-of-office, or tentative
event. Its own card, lighter.

## Hearing Collisions

A hearing, read by the same rules as hearing prep, with anything busy from
`--hearing-buffer` minutes before it to the same after it. The gap is the
minutes from the end of one to the start of the other, or the minutes they
overlap. A gap of exactly the buffer is outside it.

| Name on the Page | Matches, in the Subject, Location, or Notes |
|---|---|
| CDP hearing | CDP, collection due process |
| Tax Court | Tax Court, calendar call, trial |
| Appeals | Appeal, Appeals |
| Administrative hearing | OAH, administrative hearing, hearing officer |
| Hearing | hearing |
| Examination | examination, exam, audit, revenue agent |
| Revenue officer | revenue officer |
| Settlement conference | settlement conference |

An Outlook category, or a CARET CategoryName, named **Hearing** always counts. **[no prep]** in the
subject never does, so a prep block is not a hearing. It is still busy, and
still counts near a hearing.

## Tight Changes of Place

Two busy timed events, one ending and the next starting less than `--buffer`
minutes later, where both have a location, the locations differ after case
and spacing are set aside, and neither reads as virtual. A gap of exactly the
buffer is not tight. Every such pair is listed, not only the next event.

A location reads as virtual when it holds any of: Zoom, Teams, Webex, phone,
telephone, call (but not "calendar call"), conference line, dial-in, a link
(`http`, `www.`), virtual, Google Meet.

## Sync Drift and On Both Calendars

Two entries on different calendars or sources are the same event when their
subjects match and they fall on the same Eastern date. Subjects match after
case, punctuation, spacing, and a leading "Canceled:" are set aside.

- Same times and the same status: **On Both Calendars**, listed once and
  checked once.
- Different start, end, or all-day setting, or cancelled on one only:
  **Sync Drift**, with both versions shown.

An entry moved to another date reads as two events, not as drift.

## Busy or Away All Day

An all-day item marked busy or out of office, with each timed busy event on
any of its days. An all-day item with nothing timed on its days is counted and
not listed.

## Dates to See

Any event or all-day item, not cancelled, on a Saturday, a Sunday, a federal
holiday, or DC Emancipation Day. A free item counts: a deadline marked free
still shows. The day is named and nothing more.

| Holiday | Date |
|---|---|
| New Year's Day | January 1 |
| Martin Luther King Jr. Day | Third Monday of January |
| Washington's Birthday | Third Monday of February |
| DC Emancipation Day | April 16, a District of Columbia holiday |
| Memorial Day | Last Monday of May |
| Juneteenth | June 19 |
| Independence Day | July 4 |
| Labor Day | First Monday of September |
| Columbus Day | Second Monday of October |
| Veterans Day | November 11 |
| Thanksgiving Day | Fourth Thursday of November |
| Christmas Day | December 25 |

A fixed-date holiday on a Saturday is observed the Friday before. On a Sunday,
the Monday after. Both days are named: "Falls on the day Juneteenth is
observed, a federal holiday. Juneteenth itself is Saturday, June 19, 2027."
The dates are computed for any year in code.

The page states the fact only. It never says what a holiday means for a
filing, a deadline, or a hearing.

## Nothing Is Dropped

- Every entry in every source is counted under What Was Read: entries, not
  read, outside the window, and occurrences in the window.
- Every entry not read is listed by name under Not Read, with the reason and
  the value that could not be read.
- Every entry read on an assumption is listed under Read With a Note.

## Words Never Written

The page refuses to write, page and JSON both, when its own text contains
should, recommend, advisable, or we suggest. Subjects, locations, and calendar
names are the calendar's words, marked as quoted, and pass.

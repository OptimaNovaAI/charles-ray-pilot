---
name: charles-ray-poa
description: Complete a power of attorney for a client of the Law Offices of Charles A. Ray, P.C. Use this whenever Charles asks to complete, fill, prepare, or draft a POA or any of these forms by name - Form 2848, the 2848, IRS power of attorney, Form D-2848, the DC POA, Form 548, the Maryland POA, Form PAR 101, the Virginia POA, or PAR-101. Also use it when he says he needs a power of attorney for a new matter or a new client, needs to get on a client's account, or asks what form a matter needs. It fills his representative block, the taxpayer information, and the tax matters, and returns a completed fillable PDF plus the transmittal email to the client. It never signs anything.
---

# Power of Attorney

Charles's half of every POA never changes. It is already inside the four
masters in `forms/`. This skill fills the taxpayer half and the tax matters,
and hands back a completed form for signature.

## Which form

| He says | Use | File |
|---|---|---|
| 2848, IRS POA, federal | IRS | `MASTER_IRS_2848.pdf` |
| D-2848, DC POA, District | DC | `MASTER_DC_D-2848.pdf` |
| 548, Maryland POA, MD | MD | `MASTER_MD_548.pdf` |
| PAR 101, PAR-101, Virginia POA, VA | VA | `MASTER_VA_PAR-101.pdf` |

If he names the form, use it. If he describes a matter without naming a form,
ask which agency the matter is before: IRS, DC OTR, Comptroller of Maryland,
or Virginia Tax. A matter before two agencies needs two separate forms, so
produce both.

## What to collect

Ask for anything missing in one message, not one question at a time.

**Required**
- Client's name exactly as it appears on the return
- Street address, city, state, ZIP
- Tax matter: what kind of tax, which form number, which years or periods

**Fill if he has it, leave blank if he does not**
- SSN, ITIN, or FEIN
- Daytime phone
- Spouse name and SSN, when the matter involves a joint return

If he pastes a consultation note, an intake email, or a scored lead card,
pull the fields from it and show him what was found before filling anything.

## The client usually supplies the SSN

By the time Charles opens a POA he has had the consultation, so he has the
name, the address, and the years. The number he often does not have is the
SSN, and it is the one thing a client will not put in an email.

So do not stall waiting for it. Fill everything he has, leave the identifier
blank, and say plainly which fields the client still needs to complete. The
transmittal email below tells the client exactly what to enter.

## The one rule that gets forms rejected

**Line 3 on the 2848, Part III on the 548, Tax Matters on the D-2848, and
Section 3 on the PAR 101 must be specific.** Every one of these agencies
treats a general reference as an invalid document. "All years", "All taxes",
"Various", or a blank field means the form comes back.

`fill_poa` refuses to build a form with a general or empty matter and tells
you why. Do not work around it. Go back to Charles and get the years.

Virginia will not accept periods more than three years in the future.
Maryland wants fiscal years as YYYYMM.

## Running it

```bash
cd scripts
python3 -c "
from poa_autofill import fill_poa
fill_poa('IRS',
  {'name':'DANNER HAWKINS','address':'123 Main Street',
   'city':'Bowie','state':'MD','zip':'20715',
   'tin':'','phone':'301-555-0100'},
  [{'description':'Income','form':'1040','years':'2022, 2023'}],
  '/mnt/user-data/outputs/2848-hawkins.pdf')
"
```

The masters are in `../forms/`. Output stays fillable, so Charles can correct
anything before printing. Nothing is flattened and nothing is signed.

## If a PDF cannot be written

Some sessions cannot create files. Do not fail and do not apologize at length.
Open `reference/field-map.md`, find the form, and give him a fill sheet: each
field label with the value to type, in page order. Tell him which master to
open from `forms/`. He pastes it in and is done in about a minute, which is
still faster than what he does today.

## The transmittal email

Always offer it. It is half the value.

Draft it in his voice, short, and name only the fields the client still has to
complete. Use his standing instruction verbatim for the signature:

> Sign and date with an original signature, not an electronic one.

For the 2848, the client signs page 2, line 7. For the 548 and D-2848 the
taxpayer signature is on page 2. For the PAR 101 it is Section 5.

Charles signs his own declaration after the client returns it. Say so, so the
client knows the form is coming back.

Apply his standard email signature block if it is in memory. Do not invent one.

## Never

- Never sign for Charles or for the client. Every agency requires wet ink.
- Never guess an SSN, a CAF number, or a bar number. His are already in the
  masters. The client's identifier comes from the client.
- Never put a client's name in a file name, a document title, or PDF metadata.
  Name outputs by form and matter number: `2848-01406.pdf`.
- Never edit the masters. Fill a copy.
- Never tell him a form is filed. This produces a document. Filing is his.

# Power of Attorney skill
Law Offices of Charles A. Ray, P.C. · Prepared by OptimaNova AI

## Install, once

1. Unzip.
2. In Claude, go to Settings, then Capabilities, then Skills.
3. Upload the `charles-ray-poa` folder.

That is the whole setup. It stays available in every conversation.

## Use it

Say the form name:

- "Complete Form 2848 for Danner Hawkins, 1040, 2022 and 2023."
- "I need a 548 for the Stedman matter."
- "Prepare the PAR 101 for this client."

Or describe the matter and let it ask which form:

- "New client, Maryland income tax appeal, 2024. I need a POA."

You can also paste a consultation note or an intake email and say
"complete the 2848 from this." It pulls the fields and shows you what it
found before filling anything.

## What comes back

A completed PDF with your representative block, the client's information,
and the tax matters filled in. It stays editable, so you can correct
anything before printing. Two things are always left blank: both signature
lines and both date lines.

Ask for the transmittal email and it drafts that too, naming only the
fields the client still has to complete.

## What is already in every form

Your name, firm, and address. CAF number 2605-70664R. DC bar 419973,
Maryland bar 69367, Virginia agent A-0440967. Phone, fax, email. The
authorized-acts checkboxes and the "receive IRS transcripts" language.
The Part II declaration line. You never retype any of it.

## One thing it will refuse

It will not produce a form with a blank or general tax matter. "All years"
and an empty years field both get rejected, because every one of these
agencies treats a general reference as an invalid document and sends the
form back. It will ask you for the specific years instead.

## Notes

It never signs anything. Wet ink only, on both sides.
It produces a document. Filing is yours.
Client names never appear in file names or document properties.

# Manual fill sheet

Use this only when a PDF cannot be written in the session.

Open the master from `forms/`, then type these values into the listed
fields. Charles's half — name, firm, address, CAF number, bar numbers,
phone, fax, the authorized-acts checkboxes, and the Part II declaration —
is already filled in every master. Do not retype it.

---

## IRS Form 2848

`forms/MASTER_IRS_2848.pdf` · Charles's block pre-filled at 9pt for fax legibility

| Field on the form | What goes in it |
|---|---|
| Page 1, line 1 · Taxpayer name and address | Name, then street, city, state ZIP on the second line |
| Page 1, line 1 · Taxpayer identification number | SSN, ITIN, or FEIN |
| Page 1, line 1 · Daytime telephone number | Client's phone |
| Page 1, line 3 · Description of Matter | Income, Employment, Civil Penalty, etc. |
| Page 1, line 3 · Tax Form Number | 1040, 941, 720, etc. |
| Page 1, line 3 · Year(s) or Period(s) | Specific years. Never 'All years' |
| Page 2, line 7 · Print name | Client's name |


## DC Form D-2848

`forms/MASTER_DC_D-2848.pdf` · 78 fields · 8 already filled with Charles's information

| Field on the form | What goes in it |
|---|---|
| Page 1 · Your first name, M.I., Last name | Client's name as on the return |
| Page 1 · Your SSN, EIN or ITIN | Client's identifier |
| Page 1 · Home address | Street address |
| Page 1 · City / State / Zip code | Three separate boxes |
| Page 1 · Tax Matters, Type of Tax | Income, Withholding, Sales, etc. |
| Page 1 · Tax Matters, Type of Form | D-40, FR-900, etc. |
| Page 1 · Tax Matters, Years or Periods | Specific years |
| Page 2 · Taxpayer's Name | Client's name again |
| Page 2 · Taxpayer's SSN or FEIN | Client's identifier again |


## Maryland Form 548

`forms/MASTER_MD_548.pdf` · 51 fields · 10 already filled with Charles's information

| Field on the form | What goes in it |
|---|---|
| Page 1, Part I · Your first name, MI, last name | Client's name |
| Page 1, Part I · Spouse's name | Only for joint representation |
| Page 1, Part I · Your SSN | Client's identifier |
| Page 1, Part I · Spouse's SSN | Only for joint representation |
| Page 1, Part I · Daytime telephone number | Client's phone |
| Page 1, Part I · Home address | Street address |
| Page 1, Part I · City / State / ZIP+4 | Three separate boxes |
| Page 1, Part III · Type of Tax(es) | Income, Sales and Use, etc. |
| Page 1, Part III · Tax Form Number | 502, 505, etc. |
| Page 1, Part III · Years or Periods | Specific. Fiscal years as YYYYMM |
| Page 2 · Taxpayer's SSN or FEIN | Client's identifier again |
| Page 2 · Taxpayer's Name | Client's name again |


## Virginia Form PAR 101

`forms/MASTER_VA_PAR-101.pdf` · 81 fields · 16 already filled with Charles's information

| Field on the form | What goes in it |
|---|---|
| Section 1 · Taxpayer Name | Client's name |
| Section 1 · SSN, ITIN, or FEIN | Client's identifier |
| Section 1 · Address | Street address |
| Section 1 · City / State / ZIP Code | Three separate boxes |
| Section 1 · Daytime Telephone | Area code and number are separate boxes |
| Section 1 · Email Address | Client's email |
| Section 3 · Tax Type | Individual Income, Corporate, etc. |
| Section 3 · Taxable Years | Specific. No more than 3 years forward |
| Section 5 · Print Name | Client's name |


---

## Leave blank in every case

- Both signature lines. Wet ink only, no electronic signatures.
- Both date lines. They are dated at signing.
- The client's identifier if Charles does not have it. The transmittal
  email asks the client to supply it.

## Before it goes out

- The matter and the years are specific. A general reference is rejected.
- The form matches the agency. IRS, DC OTR, Maryland Comptroller, Virginia Tax.
- No client name in the file name or the document properties.
#!/usr/bin/env python3
"""
Hearing prep for the Law Offices of Charles A. Ray, P.C.

    python3 prep.py --events events.json --as-of 2026-10-13 --out prep.html
                    [--caret [FirmExport-123.zip or folder]]
                    [--matters matters.json] [--register register.csv]
                    [--scan] [--folders DIR] [--listing listing.json]
                    [--log prep_log.json] [--next-run 2026-10-14]
                    [--assemble "C:/Users/.../Desktop/Hearing Files"]

Item 14. Alerts at T-7, T-3, and T-1 for every hearing on the calendar and
every hearing deadline in the clock register, with the file pulled.

What it reads
    --events    the calendar for the coming days, as Claude reads it from
                Outlook. Shape in reference/inputs.md
    --caret     the CARET firm export: the FirmExport zip as CARET saves it,
                or the folder it was unzipped to. Given with no path, the
                newest FirmExport in Downloads. Its Calendar.csv joins the
                Outlook events, its Matter.csv is the matter list when no
                --matters is given, and its Task.csv and Notes.csv show on
                each alerted matter's page
    --matters   the matter list: number, client, aliases, folder, forum, years
    --register  the clock register from the blind-spot flags skill. Its
                CDP_WINDOW and PETITION_WINDOW dates are hearing deadlines and
                get the same T-7, T-3, T-1 treatment. Its CSED rows show on
                each matter's page, with their kind
    --scan      list each matter's folder directly, when the folders are on
                this machine
    --folders   where --scan looks for a matter with no folder of its own: a
                folder whose name starts with the matter number. Repeatable.
                Defaults to Downloads
    --listing   or a folder listing written elsewhere, same shape as --scan
    --log       which alerts already went out, so a run never repeats one and
                never loses one that a weekend or a late calendar entry skipped
    --assemble  copies the files found for each alerted matter into one
                folder per hearing, with this page beside them. That is the
                file pulled

Three rules, and they are the firm's.
    Nothing is dropped silently. Every event in the window is counted, and an
    event that did not read as a hearing is listed by name.
    Every statement says where it came from: the calendar entry, the register
    row, or the file name and its date.
    It reports what is in hand. It never says what to do. A file the listing
    does not show is "not found by name", never "missing", because the folder
    may name it differently.
"""

import argparse
import html as H
import json
import re
import shutil
import sys
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import register as REG  # noqa: E402
import caret_export as CX  # noqa: E402

STAGES = (7, 3, 1)

# What reads as a hearing. Charles strikes and adds in reference/triggers.md;
# the list here is the one that runs. Order matters: the first match names it.
TRIGGERS = [
    ("CDP hearing", r"\bCDP\b|collection due process"),
    ("Tax Court", r"tax court|calendar call|\btrial\b"),
    ("Appeals", r"\bappeals?\b"),
    ("Administrative hearing", r"\bOAH\b|administrative hearing|hearing officer"),
    ("Hearing", r"\bhearing\b"),
    ("Examination", r"\bexamination\b|\baudit\b|revenue agent|\bexam\b"),
    ("Revenue officer", r"revenue officer"),
    ("Settlement conference", r"settlement conference"),
]
# A calendar category of "Hearing" always counts. "[no prep]" in the subject
# never does.
OPT_IN_CATEGORY = "hearing"
OPT_OUT = re.compile(r"\[no prep\]", re.I)

# Register clocks that are hearing deadlines.
DEADLINE_CLOCKS = {"CDP_WINDOW": "Last day to request a CDP hearing",
                   "PETITION_WINDOW": "Last day to petition the Tax Court"}

# What the file inventory looks for, by name. A match is "found"; no match is
# "not found by name". The patterns are in reference/checklists.md.
INVENTORY = [
    ("poa", "Power of attorney",
     r"2848|d-?2848|\b548\b|par[ -]?101|power of attorney|\bpoa\b"),
    ("transcript", "Account transcript", r"transcript"),
    ("engines", "Compliance check, resolution path, or flags",
     r"compliance|resolution|flags|worksheet"),
    ("financials", "Collection information statement",
     r"433-?a|433-?f|433-?b|\b656\b|collection information"),
    ("notice", "The notice",
     r"\bcp ?\d{2,4}\b|\blt ?\d{2,4}\b|letter ?\d{3,4}|\bnotice\b|\bsnod\b"),
    ("position", "Position on paper",
     r"memo|position|protest|brief|statement of (facts|authority)"),
]
TRANSCRIPT_AGE_DAYS = 30

WORDS_NEVER_PRINTED = (" should ", "recommend", "advisable", "we suggest")

CARET_STALE_DAYS = 7
CARET_DOCS = ("Documents live in CARET. In CARET, open the matter, Documents tab, Bulk "
              "Download, Download Entire Matter, then rerun with --listing or --scan.")
RECURRING_NOTE = "recurring in CARET, listed occurrence only"
NOTES_SHOWN = 5
DONE_STATUS = re.compile(r"complete|done|closed|cancel", re.I)
COMPANY = re.compile(r"\b(inc|llc|l\.l\.c|corp|corporation|co|company|group|lp|llp|pllc|pc|p\.c|ltd|"
                     r"trust|estate|foundation|partners|associates|holdings)\b\.?", re.I)


# ---------------------------------------------------------------- time

def _nth_sunday(y, m, n):
    d0 = date(y, m, 1)
    first = d0 + timedelta(days=(6 - d0.weekday()) % 7)
    return first + timedelta(weeks=n - 1)


def eastern(dt):
    """US Eastern without a time zone database, so it runs the same on
    Charles's Windows machine as anywhere else. Daylight time runs from 2 a.m.
    on the second Sunday of March to 2 a.m. on the first Sunday of November."""
    if dt.tzinfo is None:
        return dt
    u = dt.astimezone(timezone.utc).replace(tzinfo=None)
    start = datetime.combine(_nth_sunday(u.year, 3, 2), datetime.min.time()) + timedelta(hours=7)
    end = datetime.combine(_nth_sunday(u.year, 11, 1), datetime.min.time()) + timedelta(hours=6)
    off = -4 if start <= u < end else -5
    return (u + timedelta(hours=off))


def parse_when(s):
    """An event start as the calendar gives it. Returns (date, time or None)."""
    if s in (None, ""):
        return None, None
    s = str(s).strip()
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", s):
        return date.fromisoformat(s), None
    s2 = s.replace("Z", "+00:00")
    dt = datetime.fromisoformat(s2[:32])
    loc = eastern(dt)
    return loc.date(), loc.time().replace(second=0, microsecond=0)


def next_weekday(d0):
    n = d0 + timedelta(days=1)
    while n.weekday() >= 5:
        n += timedelta(days=1)
    return n


def e(s):
    return H.escape(str(s), quote=False)


def nt(s):
    """Text quoted from a calendar, a CARET note, or a task. Marked so the word
    check skips it: those words are his, and the check is for the engine's."""
    return f'<span class="nt">{e(s)}</span>'


def nsubj(s):
    return " ".join(re.sub(r"[^\w\s]", " ", str(s or "").lower()).split())


def fmt_day(d0):
    return d0.strftime("%A, %B ") + str(d0.day)


def fmt_time(t):
    if t is None:
        return "all day"
    h = t.hour % 12 or 12
    return f"{h}:{t.minute:02d} {'AM' if t.hour < 12 else 'PM'}"


# ---------------------------------------------------------------- reading

def classify(ev):
    subj = ev.get("subject", "") or ""
    if OPT_OUT.search(subj):
        return None, "marked [no prep]"
    cats = [str(c).lower() for c in ev.get("categories", []) or []]
    hay = " ".join([subj, ev.get("location", "") or "", ev.get("body", "") or ""])
    for name, pat in TRIGGERS:
        if re.search(pat, hay, re.I):
            return name, None
    if OPT_IN_CATEGORY in cats:
        return "Hearing", None
    return None, "no hearing word in the subject, location, or notes"


def match_matter(text, matters):
    hits = []
    low = text.lower()
    for m in matters:
        keys = [m.get("matter", "")] + [m.get("client", "")] + list(m.get("aliases", []) or [])
        for k in keys:
            k = str(k).strip()
            if len(k) >= 3 and re.search(r"(?<!\w)" + re.escape(k.lower()) + r"(?!\w)", low):
                hits.append(m)
                break
    return hits


def scan_folder(folder):
    p = Path(folder)
    if not p.exists():
        return None
    files = []
    for f in sorted(p.rglob("*")):
        if f.is_file() and len(f.relative_to(p).parts) <= 3:
            files.append({"name": str(f.relative_to(p)),
                          "modified": date.fromtimestamp(f.stat().st_mtime).isoformat(),
                          "path": str(f)})
    return {"listed_on": date.today().isoformat(), "files": files}


def inventory(listing, as_of):
    if listing is None:
        return None
    out = {}
    files = listing.get("files", [])
    for key, label, pat in INVENTORY:
        hits = [f for f in files if re.search(pat, Path(f["name"]).name, re.I)]
        hits.sort(key=lambda f: f.get("modified", ""), reverse=True)
        out[key] = {"label": label, "hits": hits}
    t = out["transcript"]["hits"]
    if t and t[0].get("modified"):
        age = (as_of - date.fromisoformat(t[0]["modified"][:10])).days
        out["transcript"]["age"] = age
    return out


# ---------------------------------------------------------------- CARET export

def caret_info(exp, as_of):
    taken = CX.export_taken(exp)
    return {"name": Path(exp).name, "taken": taken, "age": (as_of - taken.date()).days,
            "tables": CX.list_tables(exp)}


def _written_date(raw):
    m = re.match(r"^\s*(\d{4}-\d{2}-\d{2})", str(raw or ""))
    if m:
        return date.fromisoformat(m.group(1))
    dt, _ = CX.parse_dt(raw)
    return dt.date() if dt else None


def caret_events(exp):
    """Calendar.csv rows as calendar events. Returns (events, unread). An
    all-day row, or a start that is a date alone, keeps the date as written."""
    evs, unread = [], []
    for row in CX.read_table(exp, "Calendar"):
        ref = f"Calendar.csv row {row['_row']}"
        subject = CX.clean_text(CX.col(row, "Subject", "Title")).replace("\n", " ")
        raw = CX.col(row, "FromDate", "StartDate", "Start*", "From*")
        dt, has_time = CX.parse_dt(raw)
        if dt is None:
            unread.append({"subject": subject, "start": raw, "where": ref})
            continue
        all_day = CX.truthy(CX.col(row, "IsAllday", "IsAllDay", "AllDay")) or not has_time
        number, mname = CX.split_matter(CX.col(row, "MatterNumber", "Matter Number", "MatterNo"),
                                        CX.col(row, "MatterName", "Matter Name"))
        cat = str(CX.col(row, "CategoryName", "Category")).strip()
        evs.append({
            "subject": subject,
            "start": raw,
            "day": _written_date(raw) if all_day else dt.date(),
            "time": None if all_day else dt.time().replace(second=0, microsecond=0),
            "location": CX.clean_text(CX.col(row, "Location")).replace("\n", ", "),
            "body": CX.clean_text(CX.col(row, "Descrption", "Description", "Notes"))[:400],
            "organizer": "",
            "categories": [cat] if cat and cat.lower() != "none" else [],
            "matter_number": number, "matter_name": mname,
            "recurring": CX.truthy(CX.col(row, "IsRecurring", "Recurring")),
            "where": ref,
        })
    return evs, unread


def _aliases(*names):
    out = []
    for n in names:
        n = " ".join(str(n or "").split())
        if not n:
            continue
        out.append(n)
        bare = re.sub(r"^the\s+", "", n, flags=re.I)
        bare = re.sub(r",?\s*\b(inc|llc|l\.l\.c|corp|ltd|pllc|p\.?c)\b\.?$", "", bare, flags=re.I).strip(" ,")
        if bare and bare != n:
            out.append(bare)
        words = bare.split()
        if not COMPANY.search(bare) and 2 <= len(words) <= 3 and all(re.fullmatch(r"[A-Za-z'.-]+", w) for w in words):
            last = words[-1].strip(".")
            if len(last) >= 4:
                out.append(last)
    seen, uniq = set(), []
    for a in out:
        if a.lower() not in seen:
            seen.add(a.lower())
            uniq.append(a)
    return uniq


def caret_matters(exp):
    """Matter.csv as the matter list. Columns are found by meaning. Returns
    (open matters, closed matters, the columns used)."""
    rows = CX.read_table(exp, "Matter")
    opened, closed = [], []
    for row in rows:
        raw_no = CX.col(row, "MatterNumber", "Matter Number", "MatterNo", "Matter No", "Number",
                        "MatterID", "Matter Id", "FileNumber", "File Number", "CaseNumber")
        name = CX.col(row, "MatterName", "Matter Name", "Name", "MatterTitle", "Title", "CaseName")
        client = CX.col(row, "Client", "ClientName", "Client Name", "Clients", "Contact",
                        "ContactName", "PrimaryContact", "PrimaryClient")
        number, _ = CX.split_matter(raw_no)
        after = str(raw_no or "").split("-", 1)[1].strip() if "-" in str(raw_no or "") else ""
        if not number:
            continue
        status = str(CX.col(row, "Status", "MatterStatus", "Matter Status", "State", "Stage")).strip()
        is_closed = "closed" in status.lower() or CX.truthy(CX.col(row, "IsClosed", "Closed"))
        m = {"matter": number, "client": " ".join(str(client or name or after).split()),
             "name": " ".join(str(name or "").split()), "status": status,
             "aliases": [a for a in _aliases(name, client, after) if a.lower() != number.lower()],
             "row": row["_row"], "from_caret": True, "closed": is_closed}
        (closed if is_closed else opened).append(m)
    return opened, closed


def caret_by_matter(exp, table):
    out = {}
    for row in CX.read_table(exp, table):
        number, _ = CX.split_matter(CX.col(row, "MatterNumber", "Matter Number", "MatterNo"))
        if number:
            out.setdefault(number, []).append(row)
    return out


def open_tasks(rows):
    out = []
    for row in rows:
        status = str(CX.col(row, "Status", "TaskStatus")).strip()
        if DONE_STATUS.search(status) or str(CX.col(row, "CompletedDate", "Completed*", "DateCompleted")).strip():
            continue
        due, _ = CX.parse_dt(CX.col(row, "DueDate", "Due Date", "Due*", "Deadline"))
        out.append({"subject": CX.clean_text(CX.col(row, "Subject", "Title", "Task", "Name")).replace("\n", " "),
                    "due": due.date() if due else None, "status": status, "row": row["_row"]})
    out.sort(key=lambda x: (x["due"] is None, x["due"] or date.max, x["row"]))
    return out


def latest_notes(rows, n=NOTES_SHOWN):
    out = []
    for row in rows:
        d, _ = CX.parse_dt(CX.col(row, "Date", "NoteDate", "Note Date", "CreatedDate", "Created*",
                                  "LastEditedDate"))
        out.append({"date": d.date() if d else None,
                    "subject": CX.clean_text(CX.col(row, "Subject", "Title")).replace("\n", " "),
                    "text": CX.clean_text(CX.col(row, "Description", "Descrption", "Note", "Notes", "Body")),
                    "row": row["_row"]})
    out.sort(key=lambda x: (x["date"] or date.min, x["row"]), reverse=True)
    return out[:n], len(out)


def folder_by_number(number, roots):
    """A folder whose name starts with the matter number, under any root."""
    pat = re.compile(r"^" + re.escape(str(number)) + r"(?![\w])", re.I)
    for r in roots:
        base = Path(r).expanduser()
        if not base.is_dir():
            continue
        for d in sorted(base.iterdir()):
            if d.is_dir() and pat.match(d.name):
                return d
    return None


# ---------------------------------------------------------------- the run

def stage_due(event_day, as_of, next_run, fired, catch_up):
    """
    The stage due on this run. A stage is due when its day falls on or after
    today and before the next run, so a Friday run carries a Saturday or Sunday
    stage. With the alert log, a stage whose day has passed and that the log
    does not show as sent is due now, marked late, so a weekend or a late
    calendar entry never loses one. Two stages due on one run collapse to the
    nearer one.
    """
    if (event_day - as_of).days < 0:
        return []
    due = []
    for s in STAGES:
        if s in fired:
            continue
        sd = event_day - timedelta(days=s)
        if as_of <= sd < next_run:
            due.append((s, False))
        elif catch_up and sd < as_of:
            due.append((s, True))
    if len(due) > 1:
        due = [min(due, key=lambda x: x[0])]
    return due


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--events")
    ap.add_argument("--caret", nargs="?", const="", default=None)
    ap.add_argument("--matters")
    ap.add_argument("--register")
    ap.add_argument("--scan", action="store_true")
    ap.add_argument("--folders", action="append", default=[])
    ap.add_argument("--listing")
    ap.add_argument("--log")
    ap.add_argument("--as-of")
    ap.add_argument("--next-run")
    ap.add_argument("--assemble")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    if not a.events and a.caret is None:
        raise SystemExit("Give the calendar: --events, --caret, or both.")

    ev_doc = json.loads(Path(a.events).read_text(encoding="utf-8")) if a.events else {}
    events = ev_doc.get("events", []) if isinstance(ev_doc, dict) else (ev_doc if isinstance(ev_doc, list) else [])
    as_of = date.fromisoformat(a.as_of) if a.as_of else date.today()
    next_run = date.fromisoformat(a.next_run) if a.next_run else next_weekday(as_of)
    horizon = as_of + timedelta(days=8)

    exp, cx = None, None
    if a.caret is not None:
        try:
            exp = CX.find_export(a.caret or None)
        except FileNotFoundError as x:
            raise SystemExit(str(x))
        if exp is None:
            raise SystemExit("No CARET export found. In CARET: Firm Settings, Your CARET Legal "
                             "Account, Export, Download Data. The FirmExport zip lands in Downloads.")
        cx = caret_info(exp, as_of)

    matters = json.loads(Path(a.matters).read_text(encoding="utf-8")) if a.matters else []
    if isinstance(matters, dict):
        matters = matters.get("matters", [])
    closed = []
    matter_src = "matters.json" if a.matters else None
    if not a.matters and exp is not None:
        matters, closed = caret_matters(exp)
        matter_src = "Matter.csv"
    listings = json.loads(Path(a.listing).read_text(encoding="utf-8")) if a.listing else {}
    tasks_by = caret_by_matter(exp, "Task") if exp is not None else {}
    notes_by = caret_by_matter(exp, "Notes") if exp is not None else {}
    roots = a.folders or (["~/Downloads"] if exp is not None else [])

    reg_rows = []
    if a.register:
        raw = REG.load(a.register)
        reg_rows, errs = REG.validate(raw, "register row")
        if errs:
            raise SystemExit("The register has rows it refuses. Fix them first:\n  "
                             + "\n  ".join(errs))

    log = {}
    if a.log and Path(a.log).exists():
        log = json.loads(Path(a.log).read_text(encoding="utf-8"))

    # every calendar entry, Outlook then CARET, one per event
    cal, unread = [], []
    for ev in events:
        try:
            day, tm = parse_when(ev.get("start"))
        except ValueError:
            day = None
        if day is None:
            unread.append({"subject": ev.get("subject", ""), "start": ev.get("start"), "where": "Outlook"})
            continue
        cal.append({"subject": ev.get("subject", ""), "start": ev.get("start"), "day": day, "time": tm,
                    "location": ev.get("location", ""), "body": ev.get("body", ""),
                    "organizer": ev.get("organizer", ""), "categories": ev.get("categories", []),
                    "keys": [ev.get("id") or f"{ev.get('subject', '')}|{ev.get('start', '')}"],
                    "sources": ["the Outlook calendar"], "numbers": [], "recurring": False})
    if exp is not None:
        c_evs, c_unread = caret_events(exp)
        unread += c_unread
        index = {(nsubj(c["subject"]), c["day"], c["time"]): c for c in cal}
        for ce in c_evs:
            k = (nsubj(ce["subject"]), ce["day"], ce["time"])
            src = f"CARET, {ce['where']}"
            nums = [ce["matter_number"]] if ce["matter_number"] else []
            if k in index and k[0]:
                c = index[k]
                c["sources"].append(src)
                c["numbers"] += [n for n in nums if n not in c["numbers"]]
                c["keys"].append(f"CARET|{k[0]}|{k[1]}|{k[2]}")
                c["recurring"] = c["recurring"] or ce["recurring"]
                for f in ("location", "body"):
                    if not c[f] and ce[f]:
                        c[f] = ce[f]
                continue
            c = dict(ce, keys=[f"CARET|{k[0]}|{k[1]}|{k[2]}"], sources=[src], numbers=nums)
            cal.append(c)
            index[k] = c

    def tie(numbers, text):
        """A CARET matter number ties directly, open or closed. Then the text
        is matched by number, client, and alias against open matters only."""
        out = []
        for n in numbers:
            hit = [m for m in matters + closed if str(m.get("matter")) == n]
            out += hit or [{"matter": n, "client": "", "from_caret": True, "stub": True}]
        for m in match_matter(text, [m for m in matters if not m.get("closed")]):
            if not any(str(x.get("matter")) == str(m.get("matter")) for x in out):
                out.append(m)
        return out

    items, others = [], []
    for c in cal:
        if not (as_of <= c["day"] <= horizon):
            continue
        kind, why = classify(c)
        if kind is None:
            others.append((c, c["day"], c["time"], why))
            continue
        text = " ".join([c["subject"], c["location"] or "", c["body"] or ""])
        items.append({"source": "calendar", "kind": kind, "day": c["day"], "time": c["time"],
                      "title": c["subject"], "location": c["location"],
                      "organizer": c["organizer"], "key": c["keys"][0], "keys": c["keys"],
                      "sources": c["sources"], "recurring": c["recurring"],
                      "matters": tie(c["numbers"], text), "ev": c})

    for r in reg_rows:
        if r["clock"] not in DEADLINE_CLOCKS:
            continue
        day = date.fromisoformat(r["date"])
        if not (as_of <= day <= horizon):
            continue
        m = [x for x in matters if str(x.get("matter")) == r["matter"]] or \
            [{"matter": r["matter"], "client": r.get("client", "")}]
        key = f"REG|{r['matter']}|{r['year']}|{r['clock']}|{r['date']}|{r['kind']}"
        items.append({"source": "register", "kind": DEADLINE_CLOCKS[r["clock"]],
                      "day": day, "time": None,
                      "title": f"{r['matter']}, tax year {r['year']}",
                      "location": "", "organizer": "", "key": key, "keys": [key],
                      "sources": ["the clock register"], "recurring": False,
                      "matters": m, "reg": r})

    items.sort(key=lambda i: (i["day"], i["time"] or datetime.min.time()))

    alerts = []
    for it in items:
        fired = set()
        if a.log:
            for k in it["keys"]:
                fired |= set(log.get(k, []))
        due = stage_due(it["day"], as_of, next_run, fired, catch_up=bool(a.log))
        it["due"] = due
        it["days_out"] = (it["day"] - as_of).days
        if due:
            alerts.append(it)

    # file inventory, clocks, and CARET tasks and notes for every matter on the page
    for it in items:
        it["inv"] = []
        for m in it["matters"]:
            num = str(m.get("matter"))
            lst, folder = None, None
            if a.scan:
                if m.get("folder") and Path(m["folder"]).exists():
                    folder = m["folder"]
                elif not m.get("folder") and roots:
                    folder = folder_by_number(num, roots)
                if folder:
                    lst = scan_folder(folder)
            if lst is None and num in listings:
                lst = listings[num]
            clocks = [r for r in reg_rows if r["matter"] == num
                      and r["clock"] in ("CSED", "CDP_WINDOW", "PETITION_WINDOW", "ASED")]
            notes, n_notes = latest_notes(notes_by.get(num, [])) if exp is not None else ([], 0)
            it["inv"].append({"m": m, "inv": inventory(lst, as_of),
                              "listed_on": (lst or {}).get("listed_on"),
                              "folder": str(folder) if folder else None,
                              "clocks": clocks,
                              "tasks": open_tasks(tasks_by.get(num, [])) if exp is not None else None,
                              "notes": notes, "n_notes": n_notes})

    ctx = {"caret": cx, "matter_src": matter_src, "n_open": len([m for m in matters if not m.get("closed")]),
           "n_closed": len(closed), "has_events": bool(a.events)}
    html = render(as_of, next_run, ev_doc, items, alerts, others, unread,
                  bool(a.log), bool(a.scan or a.listing), ctx)
    own = re.sub(r'<span class="nt">.*?</span>', " ", html, flags=re.S)
    low = " " + re.sub(r"<[^>]+>", " ", own).lower() + " "
    for w in WORDS_NEVER_PRINTED:
        if w in low:
            raise SystemExit(f"Refusing to write: the page contains '{w.strip()}'. "
                             f"Prep reports what is in hand. It does not advise.")
    Path(a.out).write_text(html, encoding="utf-8")

    if a.assemble:
        for it in alerts:
            for blk in it["inv"]:
                inv = blk["inv"]
                if not inv:
                    continue
                folder = Path(a.assemble) / f"{it['day'].isoformat()} {blk['m'].get('matter', 'matter')}"
                folder.mkdir(parents=True, exist_ok=True)
                for key, _, _ in INVENTORY:
                    for f in inv[key]["hits"][:1]:
                        src = f.get("path")
                        if src and Path(src).exists():
                            shutil.copy2(src, folder / Path(src).name)
                shutil.copy2(a.out, folder / "Hearing prep.html")

    if a.log:
        for it in alerts:
            done = set()
            for k in it["keys"]:
                done |= set(log.get(k, []))
            done.update(s for s, _ in it["due"])
            # a stage sent late also settles the stages before it
            if it["due"]:
                done.update(s for s in STAGES if s > min(s2 for s2, _ in it["due"]))
            for k in it["keys"]:
                log[k] = sorted(done, reverse=True)
        Path(a.log).write_text(json.dumps(log, indent=1), encoding="utf-8")

    print(f"Written: {a.out}   as of {as_of}, next run {next_run}")
    if cx:
        print(f"  CARET export {cx['name']}, taken {cx['taken']:%Y-%m-%d %H:%M}, {cx['age']} day(s) old"
              + (f", older than {CARET_STALE_DAYS} days" if cx["age"] > CARET_STALE_DAYS else ""))
    if matter_src == "Matter.csv":
        print(f"  matter list from Matter.csv: {ctx['n_open']} open, {ctx['n_closed']} closed kept out of matching")
    print(f"  {len(alerts)} alert(s), {len(items)} hearing item(s) in the next eight days, "
          f"{len(others)} other event(s) counted, {len(unread)} unreadable")
    for it in alerts:
        print(f"  T-{it['due'][0][0]}{' (late)' if it['due'][0][1] else ''}: "
              f"{it['day']} {it['kind']}: {it['title']}")


# ---------------------------------------------------------------- render

CSS = """
body{margin:0;background:#f4f5f7;font-family:-apple-system,BlinkMacSystemFont,
"Segoe UI",Arial,sans-serif;color:#1b2a4a}
.w{max-width:900px;margin:0 auto;padding:28px 20px 70px}
.card{background:#fff;border:1px solid #e3e8ef;border-radius:12px;padding:22px 26px;
margin-bottom:16px}
.k{font-size:11px;font-weight:600;letter-spacing:1.6px;text-transform:uppercase;
color:#ca25b7;padding-bottom:10px}
h1{margin:0 0 6px;font-size:27px;font-weight:600;color:#0b1f3a;letter-spacing:-.5px}
h2{font-size:18px;margin:2px 0 6px;color:#0b1f3a;font-weight:600}
.sub{color:#6a7488;font-size:14px;margin:0 0 18px;line-height:1.55}
.tally{display:flex;gap:10px;flex-wrap:wrap;margin:0 0 22px}
.t{background:#fff;border:1px solid #e3e8ef;border-radius:10px;padding:10px 16px;min-width:120px}
.t b{display:block;font-size:24px;color:#000c65}
.t span{font-size:11px;letter-spacing:1.2px;text-transform:uppercase;color:#8a93a6;font-weight:600}
.stage{display:inline-block;font-size:11px;font-weight:700;letter-spacing:1.2px;
text-transform:uppercase;padding:4px 10px;border-radius:20px;color:#fff;background:#2e75b6}
.stage.s3{background:#ca25b7}.stage.s1{background:#b4483a}
.stage.late{outline:2px dashed #d9a441;outline-offset:2px}
.meta{font-size:13.5px;color:#6a7488;line-height:1.6;margin:6px 0 10px}
.lbl{font-size:10.5px;letter-spacing:1.2px;text-transform:uppercase;color:#8a93a6;
font-weight:600;margin:14px 0 6px}
table{width:100%;border-collapse:collapse;font-size:13.5px}
td{padding:7px 8px 7px 0;border-bottom:1px solid #f0f2f6;vertical-align:top}
.ok{color:#0b7a55;font-weight:600}.no{color:#9a7220;font-weight:600}
.src{color:#8a93a6;font-size:11.5px;font-family:ui-monospace,Menlo,monospace}
.row{font-size:13.5px;line-height:1.55;padding:6px 0;border-bottom:1px solid #f0f2f6}
.foot{color:#8a93a6;font-size:12.5px;line-height:1.65}
.say{font-family:ui-monospace,Menlo,monospace;font-size:12.5px;background:#f6f8fb;
border-left:2px solid #2e75b6;padding:8px 12px;margin-top:8px}
.cr{color:#2e5b9a;font-weight:600}
.fact{font-size:13.5px;line-height:1.55;background:#f3f6fb;border-radius:8px;padding:10px 12px;margin:8px 0}
.late{color:#b4483a;font-weight:600}
.row,td,.meta,.sub,.fact,.say{overflow-wrap:anywhere}
@media(max-width:600px){.card{padding:18px 16px}}
"""

STAGE_NOTE = {7: "A week out", 3: "Three days out", 1: "The day before"}


def checklist(stage, it, blk, as_of, caret=False):
    """What is in hand for this stage, from the calendar, the register, and the
    file listing. Each row reports. None instructs."""
    inv = blk["inv"]
    rows = []

    names = {k: lab for k, lab, _ in INVENTORY}

    def file_row(key, label=None):
        if inv is None and caret:
            return (label or names[key], "caret", "Documents live in CARET.")
        if inv is None:
            return (label or names[key], "no", "No folder listing for this matter.")
        h = inv[key]["hits"]
        if not h:
            return (label or inv[key]["label"], "no", "Not found by name in the folder listing.")
        f = h[0]
        extra = ""
        if key == "transcript" and "age" in inv[key]:
            age = inv[key]["age"]
            extra = (f" {age} days old"
                     + (f", older than {TRANSCRIPT_AGE_DAYS} days" if age > TRANSCRIPT_AGE_DAYS else "")
                     + ".")
        more = f" ({len(h) - 1} more by name)" if len(h) > 1 else ""
        return (label or inv[key]["label"], "ok",
                f"<span class='src'>{nt(f['name'])}</span>, modified {e(f.get('modified', 'date not listed'))}."
                f"{extra}{more}")

    if stage == 7:
        when = f"{fmt_day(it['day'])}, {fmt_time(it['time'])}"
        rows.append(("The setting, as the source shows it", "ok",
                     f"{e(when)}" + (f". {nt(it['location'])}" if it["location"] else "")
                     + (f". Organizer {nt(it['organizer'])}" if it["organizer"] else "")
                     + ("." if it["source"] == "calendar" else
                        f". From the clock register, {e(REG.KIND_LABEL[it['reg']['kind']])}: "
                        f"{e(it['reg'].get('basis') or it['reg'].get('given_by') or '')}.")))
        rows.append(file_row("poa"))
        rows.append(file_row("transcript"))
        rows.append(file_row("engines"))
        rows.append(file_row("financials"))
        rows.append(file_row("notice"))
    elif stage == 3:
        rows.append(file_row("position"))
        rows.append(file_row("transcript"))
        rows.append(file_row("financials"))
        rows.append(file_row("poa"))
    else:
        when = f"{fmt_day(it['day'])}, {fmt_time(it['time'])}"
        rows.append(("Where and when", "ok",
                     e(when) + (f". {nt(it['location'])}" if it["location"] else
                                ". No location or dial-in on the calendar entry.")))
        rows.append(file_row("position"))
        rows.append(file_row("notice"))
        rows.append(file_row("engines"))
    return rows


def clocks_table(blk):
    if not blk["clocks"]:
        return "<p class='foot'>No clocks in the register for this matter.</p>"
    trs = "".join(
        f"<tr><td>{e(r['year'])}</td><td>{e(r['clock'])}</td><td><b>{e(r['date'])}</b></td>"
        f"<td>{e(REG.KIND_LABEL[r['kind']])}</td>"
        f"<td class='src'>{e(r.get('assessment_ref') or 'year')}</td></tr>"
        for r in sorted(blk["clocks"], key=lambda r: (r["year"], r["clock"], REG.RANK[r["kind"]])))
    return f"<table>{trs}</table>"


def fmt_date_long(d0):
    return d0.strftime("%A, %B ") + str(d0.day) + ", " + str(d0.year)


def caret_card(cx, ctx):
    if not cx:
        return ""
    tk, age = cx["taken"], cx["age"]
    if age < 0:
        age_txt = f"Taken {-age} day(s) after the as-of date."
    elif age == 0:
        age_txt = "Taken on the as-of date."
    else:
        age_txt = f"{age} day{'s' if age != 1 else ''} old on the as-of date."
    stale = ""
    if age > CARET_STALE_DAYS:
        stale = (f"<p class='late' style='margin:8px 0 0'>The export is older than {CARET_STALE_DAYS} "
                 f"days. A CARET entry, task, or note made or changed after "
                 f"{e(fmt_date_long(tk.date()))} is not on this page.</p>")
    read = [n for n in ("Calendar", "Matter", "Task", "Notes") if n in cx["tables"]]
    gone = [n for n in ("Calendar", "Matter", "Task", "Notes") if n not in cx["tables"]]
    mline = ""
    if ctx["matter_src"] == "Matter.csv":
        mline = (f" The matter list is Matter.csv: {ctx['n_open']} open, {ctx['n_closed']} closed and "
                 f"kept out of matching.")
    elif ctx["matter_src"]:
        mline = " The matter list is matters.json. Matter.csv is not used for matching."
    return (f"<div class=\"card\"><div class=\"k\">CARET Export</div>"
            f"<div class='row'><b>{nt(cx['name'])}</b><div class='src'>Taken "
            f"{e(fmt_date_long(tk.date()))}, {e(fmt_time(tk.time()))}. {e(age_txt)}</div></div>"
            f"<p class='foot' style='margin:8px 0 0'>Read from it: "
            f"{e(', '.join(n + '.csv' for n in read) or 'nothing')}."
            f"{(' Not in it: ' + e(', '.join(n + '.csv' for n in gone)) + '.') if gone else ''}"
            f"{e(mline)} CARET times are converted from UTC to Eastern. A recurring CARET entry "
            f"carries no repeat rule in the export, so only the occurrence it lists is read.</p>{stale}</div>")


def caret_blocks(blk, as_of):
    out = []
    tasks = blk.get("tasks")
    if tasks is not None:
        if tasks:
            rows = []
            for tk in tasks:
                if tk["due"] is None:
                    due = "No due date."
                else:
                    d = (tk["due"] - as_of).days
                    rel = ("due today" if d == 0 else f"{abs(d)} day(s) {'after' if d > 0 else 'before'} this run")
                    due = f"Due {fmt_day(tk['due'])}, {tk['due'].year}, {rel}."
                rows.append(f"<div class='row'><b>{nt(tk['subject'])}</b> "
                            f"{(nt(tk['status']) + '. ') if tk['status'] else ''}{e(due)} "
                            f"<span class='src'>Task.csv row {tk['row']}</span></div>")
            body = "".join(rows)
        else:
            body = "<p class='foot'>No open task in Task.csv for this matter.</p>"
        out.append(f"<div class='lbl'>From CARET Tasks</div>{body}")
    if blk.get("tasks") is not None:
        notes = blk.get("notes") or []
        if notes:
            rows = "".join(
                f"<div class='row'><b>{e(fmt_day(nn['date']) + ', ' + str(nn['date'].year)) if nn['date'] else 'No date'}"
                f"</b>{(' &middot; ' + nt(nn['subject'])) if nn['subject'] else ''}"
                f"<div>{nt(nn['text'][:300] + ('...' if len(nn['text']) > 300 else ''))}</div>"
                f"<span class='src'>Notes.csv row {nn['row']}</span></div>" for nn in notes)
            more = (f"<p class='foot'>The latest {len(notes)} of {blk['n_notes']} notes for this matter.</p>"
                    if blk["n_notes"] > len(notes) else "")
        else:
            rows, more = "<p class='foot'>No note in Notes.csv for this matter.</p>", ""
        out.append(f"<div class='lbl'>From CARET Notes</div>{rows}{more}")
    return "".join(out)


def render(as_of, next_run, ev_doc, items, alerts, others, unread, has_log, has_files, ctx=None):
    ctx = ctx or {"caret": None, "matter_src": None, "has_events": True}
    cx = ctx.get("caret")
    cards = []
    for it in alerts:
        s, late = it["due"][0]
        if not it["matters"]:
            mblock = ("<div class='lbl'>Matter</div><p class='meta'>Not identified from the "
                      "calendar entry. No matter number, client name, or alias in it matched "
                      "the matter list.</p>")
        else:
            parts = []
            if len(it["matters"]) > 1:
                parts.append("<p class='meta'>More than one matter matched the entry. "
                             "Each is shown.</p>")
            for blk in it["inv"]:
                m = blk["m"]
                lab = {"ok": "In hand", "no": "Open", "caret": "In CARET"}
                rows = "".join(
                    f"<tr><td style='width:34%'>{e(lb)}</td>"
                    f"<td><span class='{'cr' if st == 'caret' else st}'>{lab[st]}</span> {txt}</td></tr>"
                    for lb, st, txt in checklist(s, it, blk, as_of, caret=bool(cx)))
                if blk["listed_on"]:
                    listed = f"Folder listed {e(blk['listed_on'])}."
                    if blk.get("folder"):
                        listed = f"Folder {nt(Path(blk['folder']).name)} listed {e(blk['listed_on'])}."
                    fact = ""
                elif cx:
                    listed, fact = "", f"<div class='fact'>{e(CARET_DOCS)}</div>"
                else:
                    listed, fact = "No folder listing.", ""
                status = []
                if m.get("closed"):
                    status.append("Closed in CARET")
                if m.get("stub"):
                    status.append("Matter number from CARET, not in the matter list")
                head = " &middot; ".join(
                    [nt(m.get('matter', ''))]
                    + ([nt(m['client'])] if m.get('client') else [])
                    + ([nt(m['forum'])] if m.get('forum') else [])
                    + ([e(', '.join(str(y) for y in m['years']))] if m.get('years') else [])
                    + [e(x) for x in status])
                parts.append(f"""<div class="lbl">{head}</div>
<table>{rows}</table>{fact}{f'<p class="foot">{listed}</p>' if listed else ''}
<div class="lbl">Clocks in the Register</div>{clocks_table(blk)}
{caret_blocks(blk, as_of)}
<div class="say">Pull the file for {nt(m.get('matter', 'this matter'))} into a folder on my desktop named for {e(it['day'].isoformat())}, with this prep page.</div>""")
            mblock = "".join(parts)
        srcs = " and ".join(it.get("sources") or [])
        rec = f" {e(RECURRING_NOTE[:1].upper() + RECURRING_NOTE[1:])}." if it.get("recurring") else ""
        cards.append(f"""<div class="card">
<span class="stage s{s}{' late' if late else ''}">T-{s}{' &middot; late' if late else ''}</span>
<h2>{e(it['kind'])}: {nt(it['title'])}</h2>
<p class="meta">{e(STAGE_NOTE[s])}. {e(fmt_day(it['day']))}, {e(fmt_time(it['time']))},
{it['days_out']} day(s) from {as_of}. Source: {e(srcs)}.{rec}
{' This stage day passed before the run that could carry it, so it goes out now.' if late else ''}</p>
{mblock}</div>""")

    coming = "".join(
        f"<div class='row'><b>{e(fmt_day(it['day']))}, {e(fmt_time(it['time']))}.</b> "
        f"{e(it['kind'])}: {nt(it['title'])} "
        f"<span class='src'>({it['days_out']} day(s) out; "
        f"{'alert today' if it['due'] else 'no stage due today'}; {e(' and '.join(it.get('sources') or []))})</span></div>"
        for it in items) or "<div class='foot'>No hearings or hearing deadlines in the next eight days.</div>"
    other_rows = "".join(
        f"<div class='row'>{e(fmt_day(d0))}, {e(fmt_time(t))}. {nt(ev.get('subject', ''))} "
        f"<span class='src'>({e(why)}; {e(' and '.join(ev.get('sources') or []))})</span></div>"
        for ev, d0, t, why in others) or "<div class='foot'>None.</div>"
    unread_rows = "".join(
        f"<div class='row'>{nt(ev.get('subject', ''))} <span class='src'>(start '{nt(ev.get('start'))}' "
        f"does not read as a date; {e(ev.get('where') or 'Outlook')})</span></div>" for ev in unread)

    window = ev_doc.get("window") if isinstance(ev_doc, dict) else None
    pulled = ev_doc.get("pulled") if isinstance(ev_doc, dict) else None
    if ctx.get("has_events", True):
        src_line = (f"Outlook calendar read {e(pulled)}" if pulled else "Outlook calendar read time not stated") + \
                   (f", window {e(window)}." if window else ", window not stated.")
    else:
        src_line = "No Outlook calendar given."
    if cx:
        src_line += f" CARET calendar from {nt(cx['name'])}."

    return f"""<!DOCTYPE html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>Hearing Prep</title><style>{CSS}</style></head><body><div class="w">
<div class="k">Hearing Prep &middot; T-7, T-3, T-1</div>
<h1>{e(fmt_day(as_of))}</h1>
<p class="sub">{src_line} This run carries every stage that falls from today up to the
next run on {e(fmt_day(next_run))}.{'' if has_log else ' No alert log was supplied, so a stage day that passed before today is not caught up.'}
{'' if has_files or cx else ' No folder listing was supplied, so the file inventory is not checked.'}</p>
{caret_card(cx, ctx)}
<div class="tally">
<div class="t"><b>{len(alerts)}</b><span>Alerts Today</span></div>
<div class="t"><b>{len(items)}</b><span>Next Eight Days</span></div>
<div class="t"><b>{len(others)}</b><span>Other Events</span></div>
</div>
{''.join(cards) or "<div class='card'><p class='foot'>No stage falls due on this run.</p></div>"}
<div class="card"><div class="k">The Next Eight Days</div>{coming}</div>
<div class="card"><div class="k">Other Events in the Window, Not Read as Hearings</div>{other_rows}{unread_rows}</div>
<div class="card"><p class="foot">
In hand means a file in the matter folder matched by name, with its date. Open means
no file matched by name. The folder may name it differently, so open is a prompt to
look, not a finding that it is missing.{' In CARET means the matter has no folder on this machine and its documents are held in CARET.' if cx else ''}<br><br>
Not checked by this page: exhibits, the client's own preparation, and the forum's
procedural rules. State forums follow their own rules, which belong to the state tax
skill.{' Not on this page: anything made or changed in CARET after the export was taken.' if cx else ''}<br><br>
This page reports what is in hand. The preparation is the attorney's.
</p></div>
</div></body></html>"""


if __name__ == "__main__":
    main()

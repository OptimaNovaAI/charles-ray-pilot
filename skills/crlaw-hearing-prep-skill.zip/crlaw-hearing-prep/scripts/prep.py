#!/usr/bin/env python3
"""
Hearing prep for the Law Offices of Charles A. Ray, P.C.

    python3 prep.py --events events.json --as-of 2026-10-13 --out prep.html
                    [--matters matters.json] [--register register.csv]
                    [--scan] [--listing listing.json]
                    [--log prep_log.json] [--next-run 2026-10-14]
                    [--assemble "C:/Users/.../Desktop/Hearing Files"]

Item 14. Alerts at T-7, T-3, and T-1 for every hearing on the calendar and
every hearing deadline in the clock register, with the file pulled.

What it reads
    --events    the calendar for the coming days, as Claude reads it from
                Outlook. Shape in reference/inputs.md
    --matters   the matter list: number, client, aliases, folder, forum, years
    --register  the clock register from the blind-spot flags skill. Its
                CDP_WINDOW and PETITION_WINDOW dates are hearing deadlines and
                get the same T-7, T-3, T-1 treatment. Its CSED rows show on
                each matter's page, with their kind
    --scan      list each matter's folder directly, when the folders are on
                this machine
    --listing   or a folder listing written elsewhere, same shape as --scan
    --log       which alerts already went out, so a run never repeats one and
                never loses one that a weekend or a late calendar entry skipped
    --assemble  copies the files found for each alerted matter into one
                folder per hearing, with this page beside them. That is the
                file pulled

Three rules, and they are the firm's.
    Nothing is dropped silently. Every event in the window is counted, and an
    event that did not read as a hearing is listed by name.
    Every statement says where it came from: the calendar entry, the register
    row, or the file name and its date.
    It reports what is in hand. It never says what to do. A file the listing
    does not show is "not found by name", never "missing", because the folder
    may name it differently.
"""

import argparse
import html as H
import json
import re
import shutil
import sys
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import register as REG  # noqa: E402

STAGES = (7, 3, 1)

# What reads as a hearing. Charles strikes and adds in reference/triggers.md;
# the list here is the one that runs. Order matters: the first match names it.
TRIGGERS = [
    ("CDP hearing", r"\bCDP\b|collection due process"),
    ("Tax Court", r"tax court|calendar call|\btrial\b"),
    ("Appeals", r"\bappeals?\b"),
    ("Administrative hearing", r"\bOAH\b|administrative hearing|hearing officer"),
    ("Hearing", r"\bhearing\b"),
    ("Examination", r"\bexamination\b|\baudit\b|revenue agent|\bexam\b"),
    ("Revenue officer", r"revenue officer"),
    ("Settlement conference", r"settlement conference"),
]
# A calendar category of "Hearing" always counts. "[no prep]" in the subject
# never does.
OPT_IN_CATEGORY = "hearing"
OPT_OUT = re.compile(r"\[no prep\]", re.I)

# Register clocks that are hearing deadlines.
DEADLINE_CLOCKS = {"CDP_WINDOW": "Last day to request a CDP hearing",
                   "PETITION_WINDOW": "Last day to petition the Tax Court"}

# What the file inventory looks for, by name. A match is "found"; no match is
# "not found by name". The patterns are in reference/checklists.md.
INVENTORY = [
    ("poa", "Power of attorney",
     r"2848|d-?2848|\b548\b|par[ -]?101|power of attorney|\bpoa\b"),
    ("transcript", "Account transcript", r"transcript"),
    ("engines", "Compliance check, resolution path, or flags",
     r"compliance|resolution|flags|worksheet"),
    ("financials", "Collection information statement",
     r"433-?a|433-?f|433-?b|\b656\b|collection information"),
    ("notice", "The notice",
     r"\bcp ?\d{2,4}\b|\blt ?\d{2,4}\b|letter ?\d{3,4}|\bnotice\b|\bsnod\b"),
    ("position", "Position on paper",
     r"memo|position|protest|brief|statement of (facts|authority)"),
]
TRANSCRIPT_AGE_DAYS = 30

WORDS_NEVER_PRINTED = (" should ", "recommend", "advisable", "we suggest")


# ---------------------------------------------------------------- time

def _nth_sunday(y, m, n):
    d0 = date(y, m, 1)
    first = d0 + timedelta(days=(6 - d0.weekday()) % 7)
    return first + timedelta(weeks=n - 1)


def eastern(dt):
    """US Eastern without a time zone database, so it runs the same on
    Charles's Windows machine as anywhere else. Daylight time runs from 2 a.m.
    on the second Sunday of March to 2 a.m. on the first Sunday of November."""
    if dt.tzinfo is None:
        return dt
    u = dt.astimezone(timezone.utc).replace(tzinfo=None)
    start = datetime.combine(_nth_sunday(u.year, 3, 2), datetime.min.time()) + timedelta(hours=7)
    end = datetime.combine(_nth_sunday(u.year, 11, 1), datetime.min.time()) + timedelta(hours=6)
    off = -4 if start <= u < end else -5
    return (u + timedelta(hours=off))


def parse_when(s):
    """An event start as the calendar gives it. Returns (date, time or None)."""
    if s in (None, ""):
        return None, None
    s = str(s).strip()
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", s):
        return date.fromisoformat(s), None
    s2 = s.replace("Z", "+00:00")
    dt = datetime.fromisoformat(s2[:32])
    loc = eastern(dt)
    return loc.date(), loc.time().replace(second=0, microsecond=0)


def next_weekday(d0):
    n = d0 + timedelta(days=1)
    while n.weekday() >= 5:
        n += timedelta(days=1)
    return n


def e(s):
    return H.escape(str(s), quote=False)


def fmt_day(d0):
    return d0.strftime("%A, %B ") + str(d0.day)


def fmt_time(t):
    if t is None:
        return "all day"
    h = t.hour % 12 or 12
    return f"{h}:{t.minute:02d} {'AM' if t.hour < 12 else 'PM'}"


# ---------------------------------------------------------------- reading

def classify(ev):
    subj = ev.get("subject", "") or ""
    if OPT_OUT.search(subj):
        return None, "marked [no prep]"
    cats = [str(c).lower() for c in ev.get("categories", []) or []]
    hay = " ".join([subj, ev.get("location", "") or "", ev.get("body", "") or ""])
    for name, pat in TRIGGERS:
        if re.search(pat, hay, re.I):
            return name, None
    if OPT_IN_CATEGORY in cats:
        return "Hearing", None
    return None, "no hearing word in the subject, location, or notes"


def match_matter(text, matters):
    hits = []
    low = text.lower()
    for m in matters:
        keys = [m.get("matter", "")] + [m.get("client", "")] + list(m.get("aliases", []) or [])
        for k in keys:
            k = str(k).strip()
            if len(k) >= 3 and re.search(r"(?<!\w)" + re.escape(k.lower()) + r"(?!\w)", low):
                hits.append(m)
                break
    return hits


def scan_folder(folder):
    p = Path(folder)
    if not p.exists():
        return None
    files = []
    for f in sorted(p.rglob("*")):
        if f.is_file() and len(f.relative_to(p).parts) <= 3:
            files.append({"name": str(f.relative_to(p)),
                          "modified": date.fromtimestamp(f.stat().st_mtime).isoformat(),
                          "path": str(f)})
    return {"listed_on": date.today().isoformat(), "files": files}


def inventory(listing, as_of):
    if listing is None:
        return None
    out = {}
    files = listing.get("files", [])
    for key, label, pat in INVENTORY:
        hits = [f for f in files if re.search(pat, Path(f["name"]).name, re.I)]
        hits.sort(key=lambda f: f.get("modified", ""), reverse=True)
        out[key] = {"label": label, "hits": hits}
    t = out["transcript"]["hits"]
    if t and t[0].get("modified"):
        age = (as_of - date.fromisoformat(t[0]["modified"][:10])).days
        out["transcript"]["age"] = age
    return out


# ---------------------------------------------------------------- the run

def stage_due(event_day, as_of, next_run, fired, catch_up):
    """
    The stage due on this run. A stage is due when its day falls on or after
    today and before the next run, so a Friday run carries a Saturday or Sunday
    stage. With the alert log, a stage whose day has passed and that the log
    does not show as sent is due now, marked late, so a weekend or a late
    calendar entry never loses one. Two stages due on one run collapse to the
    nearer one.
    """
    if (event_day - as_of).days < 0:
        return []
    due = []
    for s in STAGES:
        if s in fired:
            continue
        sd = event_day - timedelta(days=s)
        if as_of <= sd < next_run:
            due.append((s, False))
        elif catch_up and sd < as_of:
            due.append((s, True))
    if len(due) > 1:
        due = [min(due, key=lambda x: x[0])]
    return due


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--events", required=True)
    ap.add_argument("--matters")
    ap.add_argument("--register")
    ap.add_argument("--scan", action="store_true")
    ap.add_argument("--listing")
    ap.add_argument("--log")
    ap.add_argument("--as-of")
    ap.add_argument("--next-run")
    ap.add_argument("--assemble")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    ev_doc = json.loads(Path(a.events).read_text(encoding="utf-8"))
    events = ev_doc.get("events", ev_doc if isinstance(ev_doc, list) else [])
    as_of = date.fromisoformat(a.as_of) if a.as_of else date.today()
    next_run = date.fromisoformat(a.next_run) if a.next_run else next_weekday(as_of)
    horizon = as_of + timedelta(days=8)

    matters = json.loads(Path(a.matters).read_text(encoding="utf-8")) if a.matters else []
    if isinstance(matters, dict):
        matters = matters.get("matters", [])
    listings = json.loads(Path(a.listing).read_text(encoding="utf-8")) if a.listing else {}

    reg_rows = []
    if a.register:
        raw = REG.load(a.register)
        reg_rows, errs = REG.validate(raw, "register row")
        if errs:
            raise SystemExit("The register has rows it refuses. Fix them first:\n  "
                             + "\n  ".join(errs))

    log = {}
    if a.log and Path(a.log).exists():
        log = json.loads(Path(a.log).read_text(encoding="utf-8"))

    items, others, unread = [], [], []
    for ev in events:
        try:
            day, tm = parse_when(ev.get("start"))
        except ValueError:
            unread.append(ev)
            continue
        if day is None:
            unread.append(ev)
            continue
        if not (as_of <= day <= horizon):
            continue
        kind, why = classify(ev)
        if kind is None:
            others.append((ev, day, tm, why))
            continue
        text = " ".join([ev.get("subject", ""), ev.get("location", ""), ev.get("body", "")])
        items.append({"source": "calendar", "kind": kind, "day": day, "time": tm,
                      "title": ev.get("subject", ""), "location": ev.get("location", ""),
                      "organizer": ev.get("organizer", ""),
                      "key": ev.get("id") or f"{ev.get('subject','')}|{ev.get('start','')}",
                      "matters": match_matter(text, matters), "ev": ev})

    for r in reg_rows:
        if r["clock"] not in DEADLINE_CLOCKS:
            continue
        day = date.fromisoformat(r["date"])
        if not (as_of <= day <= horizon):
            continue
        m = [x for x in matters if str(x.get("matter")) == r["matter"]] or \
            [{"matter": r["matter"], "client": r.get("client", "")}]
        items.append({"source": "register", "kind": DEADLINE_CLOCKS[r["clock"]],
                      "day": day, "time": None,
                      "title": f"{r['matter']}, tax year {r['year']}",
                      "location": "", "organizer": "",
                      "key": f"REG|{r['matter']}|{r['year']}|{r['clock']}|{r['date']}|{r['kind']}",
                      "matters": m, "reg": r})

    items.sort(key=lambda i: (i["day"], i["time"] or datetime.min.time()))

    alerts = []
    for it in items:
        fired = set(log.get(it["key"], [])) if a.log else set()
        due = stage_due(it["day"], as_of, next_run, fired, catch_up=bool(a.log))
        it["due"] = due
        it["days_out"] = (it["day"] - as_of).days
        if due:
            alerts.append(it)

    # file inventory and clocks for every matter on the page
    for it in items:
        it["inv"] = []
        for m in it["matters"]:
            lst = None
            if a.scan and m.get("folder"):
                lst = scan_folder(m["folder"])
            if lst is None and str(m.get("matter")) in listings:
                lst = listings[str(m.get("matter"))]
            clocks = [r for r in reg_rows if r["matter"] == str(m.get("matter"))
                      and r["clock"] in ("CSED", "CDP_WINDOW", "PETITION_WINDOW", "ASED")]
            it["inv"].append({"m": m, "inv": inventory(lst, as_of),
                              "listed_on": (lst or {}).get("listed_on"),
                              "clocks": clocks})

    html = render(as_of, next_run, ev_doc, items, alerts, others, unread,
                  bool(a.log), bool(a.scan or a.listing))
    low = re.sub(r"<[^>]+>", " ", html).lower()
    for w in WORDS_NEVER_PRINTED:
        if w in low:
            raise SystemExit(f"Refusing to write: the page contains '{w.strip()}'. "
                             f"Prep reports what is in hand. It does not advise.")
    Path(a.out).write_text(html, encoding="utf-8")

    if a.assemble:
        for it in alerts:
            for blk in it["inv"]:
                inv = blk["inv"]
                if not inv:
                    continue
                folder = Path(a.assemble) / f"{it['day'].isoformat()} {blk['m'].get('matter', 'matter')}"
                folder.mkdir(parents=True, exist_ok=True)
                for key, _, _ in INVENTORY:
                    for f in inv[key]["hits"][:1]:
                        src = f.get("path")
                        if src and Path(src).exists():
                            shutil.copy2(src, folder / Path(src).name)
                shutil.copy2(a.out, folder / "Hearing prep.html")

    if a.log:
        for it in alerts:
            done = set(log.get(it["key"], []))
            done.update(s for s, _ in it["due"])
            # a stage sent late also settles the stages before it
            if it["due"]:
                done.update(s for s in STAGES if s > min(s2 for s2, _ in it["due"]))
            log[it["key"]] = sorted(done, reverse=True)
        Path(a.log).write_text(json.dumps(log, indent=1), encoding="utf-8")

    print(f"Written: {a.out}   as of {as_of}, next run {next_run}")
    print(f"  {len(alerts)} alert(s), {len(items)} hearing item(s) in the next eight days, "
          f"{len(others)} other event(s) counted, {len(unread)} unreadable")
    for it in alerts:
        print(f"  T-{it['due'][0][0]}{' (late)' if it['due'][0][1] else ''}: "
              f"{it['day']} {it['kind']}: {it['title']}")


# ---------------------------------------------------------------- render

CSS = """
body{margin:0;background:#f4f5f7;font-family:-apple-system,BlinkMacSystemFont,
"Segoe UI",Arial,sans-serif;color:#1b2a4a}
.w{max-width:900px;margin:0 auto;padding:28px 20px 70px}
.card{background:#fff;border:1px solid #e3e8ef;border-radius:12px;padding:22px 26px;
margin-bottom:16px}
.k{font-size:11px;font-weight:600;letter-spacing:1.6px;text-transform:uppercase;
color:#ca25b7;padding-bottom:10px}
h1{margin:0 0 6px;font-size:27px;font-weight:600;color:#0b1f3a;letter-spacing:-.5px}
h2{font-size:18px;margin:2px 0 6px;color:#0b1f3a;font-weight:600}
.sub{color:#6a7488;font-size:14px;margin:0 0 18px;line-height:1.55}
.tally{display:flex;gap:10px;flex-wrap:wrap;margin:0 0 22px}
.t{background:#fff;border:1px solid #e3e8ef;border-radius:10px;padding:10px 16px;min-width:120px}
.t b{display:block;font-size:24px;color:#000c65}
.t span{font-size:11px;letter-spacing:1.2px;text-transform:uppercase;color:#8a93a6;font-weight:600}
.stage{display:inline-block;font-size:11px;font-weight:700;letter-spacing:1.2px;
text-transform:uppercase;padding:4px 10px;border-radius:20px;color:#fff;background:#2e75b6}
.stage.s3{background:#ca25b7}.stage.s1{background:#b4483a}
.stage.late{outline:2px dashed #d9a441;outline-offset:2px}
.meta{font-size:13.5px;color:#6a7488;line-height:1.6;margin:6px 0 10px}
.lbl{font-size:10.5px;letter-spacing:1.2px;text-transform:uppercase;color:#8a93a6;
font-weight:600;margin:14px 0 6px}
table{width:100%;border-collapse:collapse;font-size:13.5px}
td{padding:7px 8px 7px 0;border-bottom:1px solid #f0f2f6;vertical-align:top}
.ok{color:#0b7a55;font-weight:600}.no{color:#9a7220;font-weight:600}
.src{color:#8a93a6;font-size:11.5px;font-family:ui-monospace,Menlo,monospace}
.row{font-size:13.5px;line-height:1.55;padding:6px 0;border-bottom:1px solid #f0f2f6}
.foot{color:#8a93a6;font-size:12.5px;line-height:1.65}
.say{font-family:ui-monospace,Menlo,monospace;font-size:12.5px;background:#f6f8fb;
border-left:2px solid #2e75b6;padding:8px 12px;margin-top:8px}
@media(max-width:600px){.card{padding:18px 16px}}
"""

STAGE_NOTE = {7: "A week out", 3: "Three days out", 1: "The day before"}


def checklist(stage, it, blk, as_of):
    """What is in hand for this stage, from the calendar, the register, and the
    file listing. Each row reports. None instructs."""
    inv = blk["inv"]
    rows = []

    names = {k: lab for k, lab, _ in INVENTORY}

    def file_row(key, label=None):
        if inv is None:
            return (label or names[key], "no", "No folder listing for this matter.")
        h = inv[key]["hits"]
        if not h:
            return (label or inv[key]["label"], "no", "Not found by name in the folder listing.")
        f = h[0]
        extra = ""
        if key == "transcript" and "age" in inv[key]:
            age = inv[key]["age"]
            extra = (f" {age} days old"
                     + (f", older than {TRANSCRIPT_AGE_DAYS} days" if age > TRANSCRIPT_AGE_DAYS else "")
                     + ".")
        more = f" ({len(h) - 1} more by name)" if len(h) > 1 else ""
        return (label or inv[key]["label"], "ok",
                f"<span class='src'>{e(f['name'])}</span>, modified {e(f.get('modified', 'date not listed'))}."
                f"{extra}{more}")

    if stage == 7:
        when = f"{fmt_day(it['day'])}, {fmt_time(it['time'])}"
        rows.append(("The setting, as the source shows it", "ok",
                     f"{e(when)}" + (f". {e(it['location'])}" if it["location"] else "")
                     + (f". Organizer {e(it['organizer'])}" if it["organizer"] else "")
                     + ("." if it["source"] == "calendar" else
                        f". From the clock register, {e(REG.KIND_LABEL[it['reg']['kind']])}: "
                        f"{e(it['reg'].get('basis') or it['reg'].get('given_by') or '')}.")))
        rows.append(file_row("poa"))
        rows.append(file_row("transcript"))
        rows.append(file_row("engines"))
        rows.append(file_row("financials"))
        rows.append(file_row("notice"))
    elif stage == 3:
        rows.append(file_row("position"))
        rows.append(file_row("transcript"))
        rows.append(file_row("financials"))
        rows.append(file_row("poa"))
    else:
        when = f"{fmt_day(it['day'])}, {fmt_time(it['time'])}"
        rows.append(("Where and when", "ok",
                     e(when) + (f". {e(it['location'])}" if it["location"] else
                                ". No location or dial-in on the calendar entry.")))
        rows.append(file_row("position"))
        rows.append(file_row("notice"))
        rows.append(file_row("engines"))
    return rows


def clocks_table(blk):
    if not blk["clocks"]:
        return "<p class='foot'>No clocks in the register for this matter.</p>"
    trs = "".join(
        f"<tr><td>{e(r['year'])}</td><td>{e(r['clock'])}</td><td><b>{e(r['date'])}</b></td>"
        f"<td>{e(REG.KIND_LABEL[r['kind']])}</td>"
        f"<td class='src'>{e(r.get('assessment_ref') or 'year')}</td></tr>"
        for r in sorted(blk["clocks"], key=lambda r: (r["year"], r["clock"], REG.RANK[r["kind"]])))
    return f"<table>{trs}</table>"


def render(as_of, next_run, ev_doc, items, alerts, others, unread, has_log, has_files):
    cards = []
    for it in alerts:
        s, late = it["due"][0]
        if not it["matters"]:
            mblock = ("<div class='lbl'>Matter</div><p class='meta'>Not identified from the "
                      "calendar entry. No matter number, client name, or alias in it matched "
                      "the matter list.</p>")
        else:
            parts = []
            if len(it["matters"]) > 1:
                parts.append("<p class='meta'>More than one matter matched the entry. "
                             "Each is shown.</p>")
            for blk in it["inv"]:
                m = blk["m"]
                rows = "".join(
                    f"<tr><td style='width:34%'>{e(lab)}</td>"
                    f"<td><span class='{st}'>{'In hand' if st == 'ok' else 'Open'}</span> {txt}</td></tr>"
                    for lab, st, txt in checklist(s, it, blk, as_of))
                listed = (f"Folder listed {e(blk['listed_on'])}." if blk["listed_on"]
                          else "No folder listing.")
                parts.append(f"""<div class="lbl">{e(m.get('matter', ''))} &middot; {e(m.get('client', ''))}
{(' &middot; ' + e(m['forum'])) if m.get('forum') else ''}
{(' &middot; ' + e(', '.join(str(y) for y in m['years']))) if m.get('years') else ''}</div>
<table>{rows}</table><p class="foot">{listed}</p>
<div class="lbl">Clocks in the register</div>{clocks_table(blk)}
<div class="say">Pull the file for {e(m.get('matter', 'this matter'))} into a folder on my desktop named for {e(it['day'].isoformat())}, with this prep page.</div>""")
            mblock = "".join(parts)
        cards.append(f"""<div class="card">
<span class="stage s{s}{' late' if late else ''}">T-{s}{' &middot; late' if late else ''}</span>
<h2>{e(it['kind'])}: {e(it['title'])}</h2>
<p class="meta">{e(STAGE_NOTE[s])}. {e(fmt_day(it['day']))}, {e(fmt_time(it['time']))},
{it['days_out']} day(s) from {as_of}. Source: {'the Outlook calendar' if it['source'] == 'calendar' else 'the clock register'}.
{' This stage day passed before the run that could carry it, so it goes out now.' if late else ''}</p>
{mblock}</div>""")

    coming = "".join(
        f"<div class='row'><b>{e(fmt_day(it['day']))}, {e(fmt_time(it['time']))}.</b> "
        f"{e(it['kind'])}: {e(it['title'])} "
        f"<span class='src'>({it['days_out']} day(s) out; "
        f"{'alert today' if it['due'] else 'no stage due today'})</span></div>"
        for it in items) or "<div class='foot'>No hearings or hearing deadlines in the next eight days.</div>"
    other_rows = "".join(
        f"<div class='row'>{e(fmt_day(d0))}, {e(fmt_time(t))}. {e(ev.get('subject', ''))} "
        f"<span class='src'>({e(why)})</span></div>"
        for ev, d0, t, why in others) or "<div class='foot'>None.</div>"
    unread_rows = "".join(
        f"<div class='row'>{e(ev.get('subject', ''))} <span class='src'>(start '{e(ev.get('start'))}' "
        f"does not read as a date)</span></div>" for ev in unread)

    window = ev_doc.get("window") if isinstance(ev_doc, dict) else None
    pulled = ev_doc.get("pulled") if isinstance(ev_doc, dict) else None
    src_line = (f"Calendar read {e(pulled)}" if pulled else "Calendar read time not stated") + \
               (f", window {e(window)}." if window else ", window not stated.")

    return f"""<!DOCTYPE html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>Hearing Prep</title><style>{CSS}</style></head><body><div class="w">
<div class="k">Hearing Prep &middot; T-7, T-3, T-1</div>
<h1>{e(fmt_day(as_of))}</h1>
<p class="sub">{src_line} This run carries every stage that falls from today up to the
next run on {e(fmt_day(next_run))}.{'' if has_log else ' No alert log was supplied, so a stage day that passed before today is not caught up.'}
{'' if has_files else ' No folder listing was supplied, so the file inventory is not checked.'}</p>
<div class="tally">
<div class="t"><b>{len(alerts)}</b><span>Alerts today</span></div>
<div class="t"><b>{len(items)}</b><span>Next eight days</span></div>
<div class="t"><b>{len(others)}</b><span>Other events</span></div>
</div>
{''.join(cards) or "<div class='card'><p class='foot'>No stage falls due on this run.</p></div>"}
<div class="card"><div class="k">The next eight days</div>{coming}</div>
<div class="card"><div class="k">Other events in the window, not read as hearings</div>{other_rows}{unread_rows}</div>
<div class="card"><p class="foot">
In hand means a file in the matter folder matched by name, with its date. Open means
no file matched by name. The folder may name it differently, so open is a prompt to
look, not a finding that it is missing.<br><br>
Not checked by this page: exhibits, the client's own preparation, and the forum's
procedural rules. State forums follow their own rules, which belong to the state tax
skill.<br><br>
This page reports what is in hand. The preparation is the attorney's.
</p></div>
</div></body></html>"""


if __name__ == "__main__":
    main()

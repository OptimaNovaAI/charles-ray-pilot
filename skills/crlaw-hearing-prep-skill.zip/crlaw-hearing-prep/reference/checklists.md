# The Stage Checklists

Charles's to strike and add to. Each row reports what is in hand. None
instructs.

## What Each Stage Shows

| Stage | Rows |
|---|---|
| T-7, a week out | The setting · Power of attorney · Account transcript and its age · Compliance check, resolution path, or flags · Collection information statement · The notice |
| T-3, three days out | Position on paper · Account transcript · Collection information statement · Power of attorney |
| T-1, the day before | Where and when · Position on paper · The notice · Compliance check, resolution path, or flags |

Every stage also shows the matter's clocks from the register: CSED, ASED, the
CDP window, and the petition window, each with its kind.

## How a File Is Found

By its file name, in the matter folder and two levels below it. The newest
match is shown with its date. More matches are counted.

| Row | A File Name Matching |
|---|---|
| Power of attorney | 2848, D-2848, 548, PAR 101, power of attorney, POA |
| Account transcript | transcript |
| Compliance check, resolution path, or flags | compliance, resolution, flags, worksheet |
| Collection information statement | 433-A, 433-F, 433-B, 656, collection information |
| The notice | CP and a number, LT and a number, Letter and a number, notice, SNOD |
| Position on paper | memo, position, protest, brief, statement of facts, statement of authority |

The account transcript also shows its age in days. Past thirty days, the page
says so. The page does not say what to do about it.

## In Hand and Open

- **In hand**: a file matched by name. The file and its date are shown.
- **Open**: nothing matched by name. The folder may name it differently, so
  open is a prompt to look. It is never written as missing.

## Not Checked

Exhibits, the client's own preparation, and the forum's procedural rules. The
page says so at the foot of every run.

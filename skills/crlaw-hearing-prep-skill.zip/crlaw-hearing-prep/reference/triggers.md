# What Reads as a Hearing

This list is Charles's to strike and add to. A change here goes into
`TRIGGERS` at the top of `scripts/prep.py`, so the list that runs and the list
on this page stay the same.

The engine reads the subject and the location first, and the notes only when
those name nothing, because a forwarded email in the notes names every kind of
thing. The first match, in this order, names the event. Case is ignored except
for the officer abbreviations, which count only in capitals as whole words, so
"ra" or "so" inside a sentence never does.

| Name on the Page | Matches |
|---|---|
| CDP hearing | CDP, collection due process |
| Tax Court | Tax Court, calendar call, trial |
| IDR deadline | IDR (capitals), information document request |
| Appeals | Appeal, Appeals, appeals officer, settlement officer, AO, SO (capitals) |
| Administrative hearing | OAH, administrative hearing, hearing officer |
| Hearing | hearing |
| Examination | examination, exam, audit, revenue agent, examiner, RA (capitals) |
| Revenue officer | revenue officer, RO (capitals) |
| Settlement conference | settlement conference |

An examiner's name alone ("Meeting with Delgado") is not caught; the title or
abbreviation beside it is ("Meeting with RA Delgado"). A name that comes up
often can be added here as its own line.

## By Name

An IRS employee listed in IRS Contacts.txt (Claude AI Reports), named by
surname in the subject or location, reads as a meeting with that person.
Day notes fills the list from his notes; he can edit it.

## Set Aside

These name an officer or an appeal without being a hearing or an agency
deadline. Each is listed under Other Events with its reason. A Hearing
category overrides both.

| Reason on the Page | Matches in the Subject |
|---|---|
| Reads as a reminder | reminder |
| Reads as documents the client owes | client documents (docs, records, statements, information) ... due |

## Always and Never

- An Outlook category, or a CARET CategoryName, named **Hearing** always counts, whatever the subject
  says.
- **[no prep]** in the subject never counts. Use it on prep blocks, internal
  reviews, and anything else that names a hearing without being one.

## Hearing Deadlines From the Register

| Clock | On the Page |
|---|---|
| `CDP_WINDOW` | Last day to request a CDP hearing |
| `PETITION_WINDOW` | Last day to petition the Tax Court |

Each carries its kind from the register: derived, IRS-printed, or controlling.

## Nothing Is Dropped

Every event in the window is counted. An event that did not read as a hearing is
listed by name with the reason, so a hearing named in a way the list does not
catch is seen on the page and the word gets added here.

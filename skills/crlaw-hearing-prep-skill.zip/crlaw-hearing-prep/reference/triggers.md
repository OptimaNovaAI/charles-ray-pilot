# What Reads as a Hearing

This list is Charles's to strike and add to. A change here goes into
`TRIGGERS` at the top of `scripts/prep.py`, so the list that runs and the list
on this page stay the same.

The engine reads the subject, the location, and the notes. The first match
names the event.

| Name on the Page | Matches |
|---|---|
| CDP hearing | CDP, collection due process |
| Tax Court | Tax Court, calendar call, trial |
| Appeals | Appeal, Appeals |
| Administrative hearing | OAH, administrative hearing, hearing officer |
| Hearing | hearing |
| Examination | examination, exam, audit, revenue agent |
| Revenue officer | revenue officer |
| Settlement conference | settlement conference |

## Always and Never

- An Outlook category, or a CARET CategoryName, named **Hearing** always counts, whatever the subject
  says.
- **[no prep]** in the subject never counts. Use it on prep blocks, internal
  reviews, and anything else that names a hearing without being one.

## Hearing Deadlines From the Register

| Clock | On the Page |
|---|---|
| `CDP_WINDOW` | Last day to request a CDP hearing |
| `PETITION_WINDOW` | Last day to petition the Tax Court |

Each carries its kind from the register: derived, IRS-printed, or controlling.

## Nothing Is Dropped

Every event in the window is counted. An event that did not read as a hearing is
listed by name with the reason, so a hearing named in a way the list does not
catch is seen on the page and the word gets added here.

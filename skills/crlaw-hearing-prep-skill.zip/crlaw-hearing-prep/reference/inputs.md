# Inputs

## The CARET Export

CARET Legal has no API. Its firm export is the way in. In CARET: Firm
Settings, Your CARET Legal Account, Export, Download Data. CARET saves
`FirmExport-<n>.zip` to Downloads. Nothing is unzipped. The engine reads the
CSVs straight out of the zip. `--caret` with no path reads the newest
FirmExport zip or folder in Downloads or a Claude AI Reports folder; with a
path, that zip, or a folder holding the CSVs.

Headers are matched by meaning: case, spaces, and punctuation are set aside,
so `MatterNumber`, `Matter Number`, and `matternumber` read the same. Where
the real header was not seen, several names are tried, in the order below.

### Calendar.csv

| Column | How it is read |
|---|---|
| `Subject` | The event's subject. |
| `FromDate` | CARET writes `2026-08-05T08:30:00+00:00`, labeled UTC, but the times are not UTC. The time is read as written and moved by the offset measured against Outlook on items in both (kept in `CARET Time Calibration.json` in Claude AI Reports). A date alone is all day. Only rows in the run's window are read further. |
| `IsAllday` | TRUE is all day, on the date as written. |
| `Location`, `Descrption` | HTML removed. Read for hearing words, as Outlook's location and notes are. |
| `MatterNumber` | `01901-Avery Lane` is split to `01901`, which ties the event to that matter directly. |
| `IsRecurring` | TRUE carries no repeat rule in the export. The listed occurrence is read, and its alert says: recurring in CARET, listed occurrence only. |
| `CategoryName` | `Hearing` counts as a hearing. `None` is no category. |

An Outlook event and a CARET row are one event when they fall on the same
day, their subjects match with case, punctuation, and small words set aside,
and they start within 90 minutes of each other, or either is all day. One CARET
item filed under two matters is one event naming both rows. The page names
every source. The alert log records the stage under each, so a stage is never
sent twice when the event later shows in only one of them. A row whose start
does not read is listed on the page with its line, `Calendar.csv row 11`.

### Matter.csv

The matter list when no `--matters` file is given.

| Field | Columns tried |
|---|---|
| Matter number | `MatterNumber`, `Matter No`, `Number`, `MatterID`, `FileNumber`, `CaseNumber`. The client CARET writes after the number is split off. |
| Matter name | `MatterName`, `Name`, `MatterTitle`, `Title`, `CaseName` |
| Client | `Client`, `ClientName`, `Clients`, `Contact`, `ContactName`, `PrimaryContact`, `PrimaryClient` |
| Status | `Status`, `MatterStatus`, `State`, `Stage`. Any value holding "closed", or `IsClosed` TRUE, is closed. |

Aliases come from the name: the matter name, the client, the client after the
number, the name without "The" or a company ending such as "Inc.", and for a
person's name of two or three words, the surname of four letters or more.
Closed matters are kept out of matching and counted on the page. A CARET
calendar row that names a closed matter's number still ties to it, marked
Closed in CARET. A number not in the list shows as the number alone.

### Task.csv

Open tasks for each alerted matter, by `MatterNumber`: every row whose
`Status` does not read complete, done, closed, or cancelled and whose
`CompletedDate` is blank. Shown with `Subject`, `Status`, `DueDate`, and the
days from this run, under From CARET Tasks.

### Notes.csv

The latest 5 notes for each alerted matter, by `MatterNumber`, newest first by
`Date` (or `NoteDate`, `CreatedDate`, `LastEditedDate`). Shown with the date,
`Subject`, and `Description` with HTML removed, the first 300 characters,
under From CARET Notes. The page counts any older ones.

### Documents

His matter documents live inside CARET, and the export does not hold them. A
matter with no folder on this machine reads In CARET on every file row, with
this fact on the page: "Documents live in CARET. In CARET, open the matter,
Documents tab, Bulk Download, Download Entire Matter, then rerun with
--listing or --scan." Once the documents are in a folder named for the matter
number, such as `01901-Avery Lane`, in Downloads or a `--folders` path,
`--scan` lists it.

## events.json

Every event in the window, as the Outlook calendar gives it. Do not filter.

```json
{
  "pulled": "2026-10-13 06:45",
  "window": "Oct 13 to Oct 21",
  "events": [
    {
      "id": "AAMkAG...",
      "subject": "CDP hearing, M-0142",
      "start": "2026-10-20T10:00:00-04:00",
      "location": "Appeals, conference line",
      "body": "first lines of the notes",
      "organizer": "Settlement Officer",
      "categories": ["Hearing"]
    }
  ]
}
```

- `start` carries its offset, or ends in `Z` for UTC. An all-day event is the
  date alone, `2026-10-14`. The engine converts to Eastern itself.
- `id` keeps the alert log exact. Without it the log keys on subject and start.
- A start that does not read as a date is listed on the page, never dropped.

## matters.json

Optional with `--caret`, where Matter.csv is the list. Given, it is the list.
Kept on his machine. It holds client names.

```json
[
  {
    "matter": "M-0142",
    "client": "Client name",
    "aliases": ["the name the calendar uses"],
    "folder": "C:/Users/<you>/Documents/Matters/M-0142",
    "forum": "IRS Appeals",
    "years": [2016, 2017]
  }
]
```

A calendar entry is matched to a matter by the matter number, the client's
name, or an alias, anywhere in the subject, location, or notes. More than one
match shows every match. No match says so.

## listing.json

Only where the folders are not on the machine running the engine. Same shape
`--scan` writes:

```json
{
  "M-0142": {
    "listed_on": "2026-10-13",
    "files": [{"name": "2848 signed.pdf", "modified": "2026-07-20"}]
  }
}
```

## The Clock Register

The same file the blind-spot flags skill keeps. See that skill's
`reference/register.md`. Read from `Clock Register.xlsx` in OneDrive, Claude AI
Reports, when `--register` is not given. Empty or absent until the blind-spot
flags skill fills it; the page says so in one line.

## The Alert Log

`Hearing Prep Log.json` in OneDrive, Claude AI Reports, written by the engine
on every run: which stages went out for which event. It lives there because a
skill's own folder does not persist between sessions. The first run creates
it and is the baseline: nothing is marked late, and stage days already past
are recorded as settled. `--log` names another file.

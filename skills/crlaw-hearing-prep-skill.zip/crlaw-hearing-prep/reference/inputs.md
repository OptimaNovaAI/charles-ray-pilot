# Inputs

## events.json

Every event in the window, as the Outlook calendar gives it. Do not filter.

```json
{
  "pulled": "2026-10-13 06:45",
  "window": "Oct 13 to Oct 21",
  "events": [
    {
      "id": "AAMkAG...",
      "subject": "CDP hearing, M-0142",
      "start": "2026-10-20T10:00:00-04:00",
      "location": "Appeals, conference line",
      "body": "first lines of the notes",
      "organizer": "Settlement Officer",
      "categories": ["Hearing"]
    }
  ]
}
```

- `start` carries its offset, or ends in `Z` for UTC. An all-day event is the
  date alone, `2026-10-14`. The engine converts to Eastern itself.
- `id` keeps the alert log exact. Without it the log keys on subject and start.
- A start that does not read as a date is listed on the page, never dropped.

## matters.json

Kept on his machine. It holds client names.

```json
[
  {
    "matter": "M-0142",
    "client": "Client name",
    "aliases": ["the name the calendar uses"],
    "folder": "C:/Users/<you>/Documents/Matters/M-0142",
    "forum": "IRS Appeals",
    "years": [2016, 2017]
  }
]
```

A calendar entry is matched to a matter by the matter number, the client's
name, or an alias, anywhere in the subject, location, or notes. More than one
match shows every match. No match says so.

## listing.json

Only where the folders are not on the machine running the engine. Same shape
`--scan` writes:

```json
{
  "M-0142": {
    "listed_on": "2026-10-13",
    "files": [{"name": "2848 signed.pdf", "modified": "2026-07-20"}]
  }
}
```

## The clock register

The same file the blind-spot flags skill keeps. See that skill's
`reference/register.md`.

## prep_log.json

Written by the engine. Which stages went out for which event. Keep it beside
the matter list.

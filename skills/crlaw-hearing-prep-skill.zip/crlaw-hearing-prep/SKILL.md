---
name: crlaw-hearing-prep
description: Hearing prep alerts at T-7, T-3, and T-1 for the Law Offices of Charles A. Ray, P.C., with the file pulled. Use whenever Charles asks about hearings coming up or wants to prepare for one, including "run hearing prep", "what hearings do I have this week", "prep me for the CDP hearing", "pull the file for Tuesday's hearing", "anything on the calendar that needs prep", "what's at T-7", or when a scheduled morning run asks for it. Also use when a hearing deadline is close, such as the last day to request a CDP hearing or to petition the Tax Court. It reads the Outlook calendar, the CARET firm export (calendar, matters, tasks, and notes from the FirmExport zip), and the clock register, and reports what is in hand. It never says what to do.
---

# Hearing Prep

Item 14. Every hearing on the calendar and every hearing deadline in the clock
register gets three alerts: a week out, three days out, and the day before. Each
alert shows the setting, what the matter folder has in hand, the clocks for the
matter, the open CARET tasks and latest CARET notes, and the file pulled into
one folder.

CARET Legal, his practice system, has no API. CARET is now covered by its firm
export: the FirmExport zip CARET saves to Downloads. Its Calendar.csv joins the
Outlook calendar, its Matter.csv is the matter list, and its Task.csv and
Notes.csv show on each alerted matter's page. His matter documents live inside
CARET, so a matter with no folder on this machine says so as a fact, with the
steps to bring the documents down.

It reports what is in hand. It never says what to do. A file the folder does
not show is **not found by name**, never "missing", because the folder may name
it differently.

---

## Run It

**1. Export from CARET.** In CARET: Firm Settings, Your CARET Legal Account,
Export, Download Data. CARET saves `FirmExport-<n>.zip` to Downloads. Leave it
there and leave it zipped. Nothing is unzipped or moved.

**2. Read the Outlook calendar.** With the Outlook connector, read his calendar
from today through eight days out. Write every event, not only the ones that
look like hearings, to `events.json` in the shape in `reference/inputs.md`:
subject, start with its time zone offset, location, the first lines of the
notes, categories, and the event id. Record when the calendar was read and the
window. Nothing is filtered at this step. The engine counts every event and
lists the ones it did not read as hearings, so a missed hearing shows up on the
page.

**3. Run with `--caret`.**

```
python3 scripts/prep.py --events events.json --caret \
    --register "C:/Users/<you>/OneDrive/Clock Register.xlsx" \
    --scan --log prep_log.json --out "Hearing Prep.html" \
    --assemble "C:/Users/<you>/Desktop/Hearing Files"
```

- `--caret` with no path reads the newest FirmExport zip in Downloads (or in
  a Claude AI Reports folder). Give a path to read a particular zip, or the
  folder an export was unzipped to. With `--caret`, `--events` is optional.
- The matter list is Matter.csv, unless `--matters matters.json` is given, in
  which case matters.json is the list. Shape of both in `reference/inputs.md`.
  Both hold client names, so both stay on his machine.

- `--register` is the clock register the blind-spot flags skill keeps. Its
  `CDP_WINDOW` and `PETITION_WINDOW` dates get the same three alerts. Its
  CSED rows show on each matter, with their kind: derived, IRS-printed, or
  controlling.
- `--scan` lists each matter folder directly. It needs the folders on this
  machine, which is where Dispatch runs. A CARET matter has no folder of its
  own, so `--scan` looks in Downloads, or in each `--folders` path, for a
  folder whose name starts with the matter number, such as
  `01901-Avery Lane`. Without it, pass `--listing`.
- `--log` remembers which alerts went out. With it, no alert repeats, and a
  stage that a weekend or a late calendar entry skipped goes out on the next
  run, marked late.
- `--assemble` copies what was found for each alerted matter into one folder
  per hearing, named by date and matter number, with the prep page beside
  them. That is the file pulled.

**4. Hand him the page.** Open it, or send it to him. Say how many alerts, which
hearings, and which items are open. Do not add advice the page does not carry.

---

## What CARET Adds

| On the Page | From the Export |
|---|---|
| CARET Export card | The export's file name, when it was taken, and its age in days. Over 7 days old, the page says so as a fact. It also names which of Calendar.csv, Matter.csv, Task.csv, and Notes.csv were in it. |
| Hearings | Calendar.csv rows join the Outlook events. The same subject at the same Eastern start is one event, with both sources named: "the Outlook calendar and CARET, Calendar.csv row 2". A recurring CARET row is the occurrence it lists, noted on its alert. |
| The matter | A CARET row's MatterNumber ties the event to its matter directly. Outlook entries are matched by matter number, client, or alias, as before. Closed matters are kept out of matching and counted on the page. |
| From CARET Tasks | Open tasks for the matter, with due dates and the days from this run, each with its Task.csv row. |
| From CARET Notes | The latest 5 notes for the matter, newest first, HTML removed, each with its date and Notes.csv row. |
| The file | With no folder for the matter on this machine, each file row reads In CARET, and the page says: "Documents live in CARET. In CARET, open the matter, Documents tab, Bulk Download, Download Entire Matter, then rerun with --listing or --scan." That is a fact about where the documents are. It is never written as missing. |

Notes and task names are his words. They are quoted on the page and pass the
word check, the way calendar subjects do.

---

## The Stages

| Stage | When | What the Page Shows |
|---|---|---|
| T-7 | A week out | The setting, the power of attorney, the account transcript and its age, the engine outputs, the collection information statement, the notice |
| T-3 | Three days out | The position on paper, the transcript, the financials, the power of attorney |
| T-1 | The day before | Where and when, the position on paper, the notice, the engine outputs |

Every stage also shows the matter's clocks from the register. The checklists
and the file patterns are in `reference/checklists.md`, for Charles to strike
and add to.

A run carries every stage day from today until the next weekday run, so a
Friday run carries a Monday hearing's T-1. Two stages due on one run collapse to
the nearer one.

---

## What Reads as a Hearing

The trigger words, the opt-in category, and the opt-out tag are in
`reference/triggers.md`. In short: CDP, collection due process, Tax Court,
calendar call, trial, Appeals, OAH, administrative hearing, hearing officer,
hearing, examination, audit, revenue agent, revenue officer, settlement
conference. An Outlook category, or a CARET CategoryName, named **Hearing** always counts. **[no prep]**
in the subject never does, which keeps his own prep blocks off the list.

---

## Every Morning

The run is built to be scheduled. Weekdays at 6:45 a.m., a scheduled task:

> Run hearing prep. Read my Outlook calendar from today through eight days out
> into events.json, then run crlaw-hearing-prep with --caret (the newest CARET
> export in my Downloads), my clock register, the alert log, folder scan, and
> assembly to Desktop\Hearing Files. Send me the page only if there is at least
> one alert.

The CARET part of the page is only as fresh as the last Download Data. The
page states the export's age on every run.

Daylight time does not move the dates. The engine converts every start to
Eastern itself, on the second Sunday of March and the first Sunday of
November, without a time zone database.

---

## What It Will Not Do

- Say what to prepare. Open means not found by name. The preparation is his.
- Read a state forum's rules. Those belong to the state tax skill.
- Check exhibits or the client's own preparation. The page lists both as not
  checked.
- Log in to CARET or download its documents. CARET has no API. The export and
  a Bulk Download are his to take.
- Put a client name in a file name. The hearing folder is named by date and
  matter number.

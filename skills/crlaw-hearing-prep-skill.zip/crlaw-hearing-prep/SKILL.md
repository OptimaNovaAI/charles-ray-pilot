---
name: crlaw-hearing-prep
description: Hearing prep alerts at T-7, T-3, and T-1 for the Law Offices of Charles A. Ray, P.C., with the file pulled. Use whenever Charles asks about hearings coming up or wants to prepare for one, including "run hearing prep", "what hearings do I have this week", "prep me for the CDP hearing", "pull the file for Tuesday's hearing", "anything on the calendar that needs prep", "what's at T-7", or when a scheduled morning run asks for it. Also use when a hearing deadline is close, such as the last day to request a CDP hearing or to petition the Tax Court. It reads the Outlook calendar, the CARET firm export (calendar, matters, tasks, and notes from the FirmExport zip), and the clock register, and reports what is in hand. It never says what to do.
---

# Hearing Prep

Item 14. Every hearing on the calendar and every hearing deadline in the clock
register gets three alerts: a week out, three days out, and the day before. Each
alert shows the setting, what the matter folder has in hand, the clocks for the
matter, the open CARET tasks and latest CARET notes, and the file pulled into
one folder.

CARET Legal, his practice system, has no API. CARET is now covered by its firm
export: the FirmExport zip CARET saves to Downloads. Its Calendar.csv joins the
Outlook calendar, its Matter.csv is the matter list, and its Task.csv and
Notes.csv show on each alerted matter's page. His matter documents live inside
CARET, so a matter with no folder on this machine says so as a fact, with the
steps to bring the documents down.

It reports what is in hand. It never says what to do. A file the folder does
not show is **not found by name**, never "missing", because the folder may name
it differently.

---

## Run It

Commands below say `python3`. On Windows, where `python3` is not found, use
`python` (or `py -3`). Run from this skill's own folder; the scripts are in
`scripts/`.

Two lines the run may print go to Charles as written, before anything else:
"No CARET export found" (the run read Outlook only; tell him how to export)
and any line saying the Claude AI Reports folder is not on OneDrive or not
connected (what the run saved will not be there next session; ask him to
connect his OneDrive folder Claude AI Reports to the chat).


**1. Export from CARET.** In CARET: Firm Settings, Your CARET Legal Account,
Export, Download Data. CARET saves `FirmExport-<n>.zip` to Downloads. Leave it
there and leave it zipped. Nothing is unzipped or moved.

**2. Read the Outlook calendar.** With the Outlook connector, read his calendar
from today through eight days out. Write every event, not only the ones that
look like hearings, to `events.json` in the shape in `reference/inputs.md`:
subject, start with its time zone offset, location, the first lines of the
notes, categories, and the event id. Record when the calendar was read and the
window. Nothing is filtered at this step. The engine counts every event and
lists the ones it did not read as hearings, so a missed hearing shows up on the
page.

**3. Run the engine.** The engine is inside this skill: `scripts/prep.py`.
Run it from the skill folder. Nothing has to be on his computer beforehand
except the CARET export and the Outlook events file from steps 1 and 2.

```
python3 scripts/prep.py --events events.json --caret --out "Hearing Prep.html"
```

That is the whole run. Everything else has a default:

- `--caret` with no path reads the newest FirmExport zip in Downloads (or in
  the Claude AI Reports folder). Give a path to read a particular zip.
- **The matter list is Matter.csv from the export.** No other file is needed.
  `--matters matters.json` is optional, for a hand-kept list.
- **The alert log** is `Hearing Prep Log.json` in OneDrive, Claude AI
  Reports. It lives there because this skill's folder does not persist between
  sessions, so a log kept beside the script is gone by the next run. The log
  is how a stage is never sent twice and how a stage a weekend skipped goes
  out on the next run, marked late. The first run creates it and is the
  baseline: nothing on the first run is marked late. `--log` names another
  file.
- **The clock register** is read from `Clock Register.xlsx` in the same Claude
  AI Reports folder when `--register` is not given. Its `CDP_WINDOW` and
  `PETITION_WINDOW` dates get the same three alerts, and its CSED rows show on
  each matter. The register is empty until the blind-spot flags skill runs on
  a matter and fills it. Until then the page says so in one line. That is
  expected, not an error.
- `--scan` and `--assemble "C:/Users/<you>/Desktop/Hearing Files"` pull the
  file when matter folders exist on this computer: a folder whose name starts
  with the matter number, such as `01901-Avery Lane`, in Downloads or any
  `--folders` path. His matter documents live in CARET, so usually there is
  none. Then the run still completes and the page says in one line that the
  file pull was skipped, with the CARET Bulk Download steps. Nothing errors.
- `--now 14:30` sets the run time. Without it, a run for today uses the clock.
  A hearing that already started before the run gets no alert; it is listed
  once under Already Held.

**4. Hand him the page.** Open it, or send it to him. Say how many alerts, which
hearings, and which items are open. Do not add advice the page does not carry.

---

## What CARET Adds

| On the Page | From the Export |
|---|---|
| CARET Export card | The export's file name, when it was taken, and its age in days. Over 7 days old, the page says so as a fact. It also names which of Calendar.csv, Matter.csv, Task.csv, and Notes.csv were in it. |
| Hearings | Calendar.csv rows in the eight-day window join the Outlook events. Rows outside the window are skipped before their text is read, so a large calendar reads in seconds. One CARET item filed under two matters is one event naming both. An Outlook event and a CARET row are one event when they fall on the same day, their subjects match with case, punctuation, and small words set aside, and they start within 90 minutes of each other (or either is all day). Both sources are named: "the Outlook calendar and CARET, Calendar.csv row 2". A recurring CARET row is the occurrence it lists, noted on its alert. |
| CARET times | CARET labels its times UTC, but they are not. Each CARET time is read as written and moved by the offset measured on items that are in both CARET and Outlook, kept in `CARET Time Calibration.json` in Claude AI Reports for runs with no Outlook. Every CARET time on the page says how it was read. An all-day item keeps its date as written. |
| How the export read | Each CSV's rows read, rows put back together where CARET's email text broke the file's columns, and any row set aside, by line number. Nothing is dropped silently. |
| The matter | A CARET row's MatterNumber ties the event to its matter directly. Outlook entries are matched by matter number, client, or alias, as before. Closed matters are kept out of matching and counted on the page. |
| From CARET Tasks | Open tasks for the matter, with due dates and the days from this run, each with its Task.csv row. |
| From CARET Notes | The latest 5 notes for the matter, newest first, HTML removed, each with its date and Notes.csv row. |
| The file | With no folder for the matter on this machine, each file row reads In CARET, and the page says: "Documents live in CARET. In CARET, open the matter, Documents tab, Bulk Download, Download Entire Matter, then rerun with --listing or --scan." That is a fact about where the documents are. It is never written as missing. |

Notes and task names are his words. They are quoted on the page and pass the
word check, the way calendar subjects do.

---

## The Stages

| Stage | When | What the Page Shows |
|---|---|---|
| T-7 | A week out | The setting, the power of attorney, the account transcript and its age, the engine outputs, the collection information statement, the notice |
| T-3 | Three days out | The position on paper, the transcript, the financials, the power of attorney |
| T-1 | The day before | Where and when, the position on paper, the notice, the engine outputs |

Every stage also shows the matter's clocks from the register. The checklists
and the file patterns are in `reference/checklists.md`, for Charles to strike
and add to.

A run carries every stage day from today until the next weekday run, so a
Friday run carries a Monday hearing's T-1. Two stages due on one run collapse to
the nearer one.

---

## What Reads as a Hearing

The trigger words, the opt-in category, the opt-out tag, and the entries set
aside are in `reference/triggers.md`. In short: CDP, collection due process,
Tax Court, calendar call, trial, IDR, Appeals, appeals officer, settlement
officer, OAH, administrative hearing, hearing officer, hearing, examination,
exam, audit, revenue agent, examiner, revenue officer, settlement conference,
and the officer abbreviations RA, RO, SO, and AO in capitals. The subject and
location are read first; the notes only when they name nothing, because a
forwarded email in the notes names every kind of thing. A reminder, or
documents the client owes, is listed under Other Events with the reason. An Outlook category, or a CARET CategoryName, named **Hearing** always counts. **[no prep]**
in the subject never does, which keeps his own prep blocks off the list.

---

## IRS Contacts

A meeting that names an IRS employee by surname alone, "Meeting with
Delgado", reads only if that person is in IRS Contacts.txt in Claude AI
Reports. Day notes adds each official his notes name with a title in two or
more notes ("RA Delgado", "Settlement Officer Park"), so the list grows on its
own. A surname that is also a client's never counts. He
can add or strike a line in the file at any time: one person per line, as
written, with the title when he knows it ("RA Delgado"). The title sets the
kind: RA or examiner is an examination, RO is collection, SO or AO is appeals.

## Every Morning

The run is built to be scheduled. Weekdays at 6:45 a.m., a scheduled task:

> Run hearing prep. Read my Outlook calendar from today through eight days out
> into events.json, then run crlaw-hearing-prep with --caret (the newest CARET
> export in my Downloads), with folder scan and assembly to Desktop\Hearing
> Files. Send me the page only if there is at least one alert.

The CARET part of the page is only as fresh as the last Download Data. The
page states the export's age on every run.

Daylight time does not move the dates. The engine converts every Outlook
start to Eastern itself, on the second Sunday of March and the first Sunday of
November, without a time zone database. CARET's times are measured against
Outlook separately for daylight and standard time.

---

## What It Will Not Do

- Say what to prepare. Open means not found by name. The preparation is his.
- Read a state forum's rules. Those belong to the state tax skill.
- Check exhibits or the client's own preparation. The page lists both as not
  checked.
- Log in to CARET or download its documents. CARET has no API. The export and
  a Bulk Download are his to take.
- Put a client name in a file name. The hearing folder is named by date and
  matter number.

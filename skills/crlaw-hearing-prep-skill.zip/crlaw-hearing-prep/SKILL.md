---
name: crlaw-hearing-prep
description: Hearing prep alerts at T-7, T-3, and T-1 for the Law Offices of Charles A. Ray, P.C., with the file pulled. Use whenever Charles asks about hearings coming up or wants to prepare for one, including "run hearing prep", "what hearings do I have this week", "prep me for the CDP hearing", "pull the file for Tuesday's hearing", "anything on the calendar that needs prep", "what's at T-7", or when a scheduled morning run asks for it. Also use when a hearing deadline is close, such as the last day to request a CDP hearing or to petition the Tax Court. It reads the Outlook calendar and the clock register, and reports what is in hand. It never says what to do.
---

# Hearing prep

Item 14. Every hearing on the calendar and every hearing deadline in the clock
register gets three alerts: a week out, three days out, and the day before. Each
alert shows the setting, what the matter folder has in hand, the clocks for the
matter, and the file pulled into one folder.

It reports what is in hand. It never says what to do. A file the folder does
not show is **not found by name**, never "missing", because the folder may name
it differently.

---

## Run it

**1. Read the calendar.** With the Outlook connector, read Charles's calendar
from today through eight days out. Write every event, not only the ones that
look like hearings, to `events.json` in the shape in `reference/inputs.md`:
subject, start with its time zone offset, location, the first lines of the
notes, categories, and the event id. Record when the calendar was read and the
window. Nothing is filtered at this step. The engine counts every event and
lists the ones it did not read as hearings, so a missed hearing shows up on the
page.

**2. The matter list.** `matters.json` on his machine: matter number, client,
aliases the calendar uses, the matter folder, the forum, the years. Shape in
`reference/inputs.md`. It holds client names, so it stays on his machine.

**3. Run the engine.**

```
python3 scripts/prep.py --events events.json --matters matters.json \
    --register "C:/Users/<you>/OneDrive/Clock Register.xlsx" \
    --scan --log prep_log.json --out "Hearing Prep.html" \
    --assemble "C:/Users/<you>/Desktop/Hearing Files"
```

- `--register` is the clock register the blind-spot flags skill keeps. Its
  `CDP_WINDOW` and `PETITION_WINDOW` dates get the same three alerts. Its
  CSED rows show on each matter, with their kind: derived, IRS-printed, or
  controlling.
- `--scan` lists each matter folder directly. It needs the folders on this
  machine, which is where Dispatch runs. Without it, pass `--listing`.
- `--log` remembers which alerts went out. With it, no alert repeats, and a
  stage that a weekend or a late calendar entry skipped goes out on the next
  run, marked late.
- `--assemble` copies what was found for each alerted matter into one folder
  per hearing, named by date and matter number, with the prep page beside
  them. That is the file pulled.

**4. Hand him the page.** Open it, or send it to him. Say how many alerts, which
hearings, and which items are open. Do not add advice the page does not carry.

---

## The stages

| Stage | When | What the page shows |
|---|---|---|
| T-7 | A week out | The setting, the power of attorney, the account transcript and its age, the engine outputs, the collection information statement, the notice |
| T-3 | Three days out | The position on paper, the transcript, the financials, the power of attorney |
| T-1 | The day before | Where and when, the position on paper, the notice, the engine outputs |

Every stage also shows the matter's clocks from the register. The checklists
and the file patterns are in `reference/checklists.md`, for Charles to strike
and add to.

A run carries every stage day from today until the next weekday run, so a
Friday run carries a Monday hearing's T-1. Two stages due on one run collapse to
the nearer one.

---

## What reads as a hearing

The trigger words, the opt-in category, and the opt-out tag are in
`reference/triggers.md`. In short: CDP, collection due process, Tax Court,
calendar call, trial, Appeals, OAH, administrative hearing, hearing officer,
hearing, examination, audit, revenue agent, revenue officer, settlement
conference. An Outlook category named **Hearing** always counts. **[no prep]**
in the subject never does, which keeps his own prep blocks off the list.

---

## Every morning

The run is built to be scheduled. Weekdays at 6:45 a.m., a scheduled task:

> Run hearing prep. Read my Outlook calendar from today through eight days out
> into events.json, then run crlaw-hearing-prep with my matter list, my clock
> register, the alert log, folder scan, and assembly to Desktop\Hearing Files.
> Send me the page only if there is at least one alert.

Daylight time does not move the dates. The engine converts every start to
Eastern itself, on the second Sunday of March and the first Sunday of
November, without a time zone database.

---

## What it will not do

- Say what to prepare. Open means not found by name. The preparation is his.
- Read a state forum's rules. Those belong to the state tax skill.
- Check exhibits or the client's own preparation. The page lists both as not
  checked.
- Put a client name in a file name. The hearing folder is named by date and
  matter number.

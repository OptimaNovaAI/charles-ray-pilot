#!/usr/bin/env python3
"""
POA submission tracking for the Law Offices of Charles A. Ray, P.C.

    python3 poa_track.py --register "POA Register.xlsx" --events events.json \
                         [--agencies agencies.json] [--as-of 2026-10-13] \
                         --out "POA Tracker.html"

Item 9. Every power of attorney the POA skill prepares moves through the same
stages: prepared, sent to the client, signed by the client, signed by Charles,
submitted, confirmed, recorded. Claude reads Outlook (the transmittal in Sent
Items, the signed copy coming back, the eFax confirmation, the CAF letter) and
writes each stage as an event. This file applies the events to the register,
ties each fax confirmation to the POA it belongs to, and writes the page.

Three rules, and they are the firm's.
    Every event cites where it was read and carries a quote from it. An event
    without both is refused and listed.
    Nothing is dropped. Every event is listed on the page, applied or not,
    with the reason. A fax confirmation that cannot be tied to exactly one POA
    is listed with its candidates, never guessed.
    It reports. Days are counted. What to do about a POA that has waited is
    the attorney's call.

The register is rebuilt from the events on every run, so a run repeated
changes nothing. The your_note column is Charles's and is carried over. A row
in the register with no event behind it is kept and flagged. The register holds
matter numbers, never client names, and stays on his machine.
"""

import argparse
import csv
import html as H
import json
import re
from datetime import date
from pathlib import Path

# ------------------------------------------------------------------ agencies
# Where each form goes. Read from the sources named, for Charles to confirm.
# follow_up_days is his number. Until he sets it, the page counts days and
# marks nothing as past a window.
AGENCIES = {
    "IRS-Memphis": {
        "form": "2848", "name": "IRS CAF Unit, Memphis",
        "fax": "855-214-7519",
        "mail": "Internal Revenue Service, 5333 Getwell Road, Stop 8423, Memphis, TN 38118",
        "online": "IRS.gov/Submit2848",
        "covers": "Taxpayers in DC, Maryland, Virginia, and 25 other states on the IRS chart",
        "signature": "Electronic signatures only through IRS.gov/Submit2848. By fax or mail, handwritten.",
        "source": "IRS Instructions for Form 2848, Where To File Chart",
        "follow_up_days": None, "confirmed": False},
    "IRS-Ogden": {
        "form": "2848", "name": "IRS CAF Unit, Ogden",
        "fax": "855-214-7522",
        "mail": "Internal Revenue Service, 1973 Rulon White Blvd., MS 6737, Ogden, UT 84201",
        "online": "IRS.gov/Submit2848",
        "covers": "Taxpayers in the western states on the IRS chart",
        "signature": "Electronic signatures only through IRS.gov/Submit2848. By fax or mail, handwritten.",
        "source": "IRS Instructions for Form 2848, Where To File Chart",
        "follow_up_days": None, "confirmed": False},
    "MD": {
        "form": "548", "name": "Comptroller of Maryland, Revenue Administration Division, Attn: POA",
        "fax": "410-260-6213",
        "mail": "P.O. Box 1829, Annapolis, MD 21404-1829",
        "online": "Scanned to RADPOA@marylandtaxes.gov",
        "covers": "Maryland",
        "signature": "Not stated in the instructions read.",
        "source": "Form 548 instructions, Comptroller of Maryland",
        "follow_up_days": None, "confirmed": False},
    "VA": {
        "form": "PAR 101", "name": "Virginia Tax",
        "fax": "804-254-6115",
        "mail": "P.O. Box 1114, Richmond, VA 23218-1114",
        "online": "Secure Message through iFile or iReg",
        "covers": "Virginia",
        "signature": "Not stated on the form.",
        "source": "Printed on his master Form PAR 101",
        "follow_up_days": None, "confirmed": False},
    "DC": {
        "form": "D-2848", "name": "DC Office of Tax and Revenue",
        "fax": "",
        "mail": "1101 4th Street, SW, Suite 270 West, Washington, DC 20024, by mail or in person",
        "online": "MyTax.DC.gov, More, Registration Details, Add Power of Attorney",
        "covers": "District of Columbia",
        "signature": "Not stated on the page read.",
        "source": "OTR Power of Attorney page. Its general fax, 202-442-6890, is not named for POAs.",
        "follow_up_days": None, "confirmed": False},
}
DEFAULT_AGENCY = {"2848": "IRS-Memphis", "548": "MD", "PAR 101": "VA", "D-2848": "DC"}
FORM_ALIASES = {"2848": "2848", "f2848": "2848", "irs 2848": "2848", "form 2848": "2848",
                "548": "548", "md 548": "548", "form 548": "548", "md548": "548",
                "par 101": "PAR 101", "par101": "PAR 101", "par-101": "PAR 101", "va par 101": "PAR 101",
                "d-2848": "D-2848", "d2848": "D-2848", "dc 2848": "D-2848", "dc d-2848": "D-2848"}

STAGES = ["prepared", "sent", "signed", "rep_signed", "submitted", "confirmed", "recorded"]
STAGE_LABEL = {"prepared": "Prepared", "sent": "Sent to client", "signed": "Signed by client",
               "rep_signed": "Signed by you", "submitted": "Submitted", "confirmed": "Confirmed",
               "recorded": "Recorded", "rejected": "Rejected", "fax_failed": "Fax failed"}
EVENT_STAGES = set(STAGES) | {"rejected", "fax_result"}
METHODS = {"fax", "online", "mail", "email", "in person", "portal"}
COLUMNS = ["key", "matter", "form", "agency", "periods", "prepared", "sent", "signed", "rep_signed",
           "submitted", "method", "fax_to", "signature", "confirmed", "pages", "confirm_ref",
           "recorded", "rejected", "status", "last_event", "refs", "note", "your_note"]
WORDS_NEVER_PRINTED = (" should ", "recommend", "advisable", "we suggest")


def e(s):
    return H.escape(str(s if s is not None else ""), quote=False)


def q(s):
    return f'<span class="nt">{e(s)}</span>'


def digits(s):
    d = re.sub(r"\D", "", str(s or ""))
    return d[1:] if len(d) == 11 and d.startswith("1") else d


def form_of(s):
    return FORM_ALIASES.get(" ".join(str(s or "").lower().replace("form ", "form ").split()))


def day(s):
    try:
        return date.fromisoformat(str(s)[:10])
    except ValueError:
        return None


# ------------------------------------------------------------------ register io

def load_register(path):
    p = Path(path)
    if not p.exists():
        return {}
    if p.suffix.lower() == ".xlsx":
        from openpyxl import load_workbook
        ws = load_workbook(p, read_only=True, data_only=True).active
        rows = list(ws.iter_rows(values_only=True))
        head = [str(h or "") for h in rows[0]] if rows else []
        recs = [{h: ("" if v is None else str(v)) for h, v in zip(head, r)} for r in rows[1:]]
    else:
        with p.open(newline="", encoding="utf-8-sig") as fh:
            recs = list(csv.DictReader(fh))
    return {r["key"]: r for r in recs if r.get("key")}


def save_register(path, rows):
    p = Path(path)
    ordered = sorted(rows.values(), key=lambda r: (r.get("prepared") or r.get("last_event") or "", r["key"]))
    if p.suffix.lower() == ".xlsx":
        from openpyxl import Workbook
        from openpyxl.styles import Font
        wb = Workbook()
        ws = wb.active
        ws.title = "POA Register"
        ws.append(list(COLUMNS))
        for c in ws[1]:
            c.font = Font(bold=True)
        for r in ordered:
            ws.append([r.get(c, "") for c in COLUMNS])
        ws.freeze_panes = "B2"
        wb.save(p)
        return
    with p.open("w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=COLUMNS, extrasaction="ignore")
        w.writeheader()
        for r in ordered:
            w.writerow({c: r.get(c, "") for c in COLUMNS})


# ------------------------------------------------------------------ applying

def status_of(r):
    if r.get("rejected") and r["rejected"] >= max([r.get(s) or "" for s in STAGES]):
        return "rejected"
    if (r.get("note") or "").startswith("fax failed") and not r.get("confirmed"):
        return "fax_failed"
    done = [s for s in STAGES if r.get(s)]
    return done[-1] if done else ""


def validate(ev, agencies):
    probs = []
    if ev.get("stage") not in EVENT_STAGES:
        probs.append(f"stage '{ev.get('stage')}' is not one of {', '.join(sorted(EVENT_STAGES))}")
    if not day(ev.get("date")):
        probs.append(f"date '{ev.get('date')}' is not a date")
    if not str(ev.get("source") or "").strip():
        probs.append("no source")
    if not str(ev.get("quote") or "").strip():
        probs.append("no quote")
    if ev.get("stage") == "fax_result":
        if ev.get("result") not in ("delivered", "failed"):
            probs.append("a fax result is delivered or failed")
        if not digits(ev.get("to")) and not ev.get("matter"):
            probs.append("a fax result needs the number dialed or the matter")
    elif ev.get("stage") in EVENT_STAGES:
        if not ev.get("matter"):
            probs.append("no matter")
        if not form_of(ev.get("form")):
            probs.append(f"form '{ev.get('form')}' is not 2848, 548, PAR 101, or D-2848")
    if ev.get("method") and ev["method"] not in METHODS:
        probs.append(f"method '{ev['method']}' is not one of {', '.join(sorted(METHODS))}")
    if ev.get("agency") and ev["agency"] not in agencies:
        probs.append(f"agency '{ev['agency']}' is not in the agency table")
    return probs


def key_of(ev):
    return f"{ev['matter']} {form_of(ev['form'])}"


def apply_events(rows, events, agencies):
    log, flags = [], []
    order = sorted(enumerate(events, 1), key=lambda x: (str(x[1].get("date")), STAGES.index(x[1]["stage"])
                                                       if x[1].get("stage") in STAGES else 9))
    for i, ev in order:
        probs = validate(ev, agencies)
        if probs:
            log.append((i, ev, "refused", "; ".join(probs)))
            continue
        d = str(ev["date"])[:10]
        ref = f"{d} {ev['stage']}"

        if ev["stage"] == "fax_result":
            if ev.get("matter") and ev.get("form"):
                k = key_of(ev)
                cands = [rows[k]] if k in rows else []
            else:
                to = digits(ev.get("to"))
                cands = [r for r in rows.values()
                         if r.get("method") == "fax" and digits(r.get("fax_to")) == to
                         and r.get("submitted") and not r.get("confirmed")
                         and 0 <= (day(d) - day(r["submitted"])).days <= 1]
            if len(cands) != 1:
                why = ("no POA submitted by fax to that number that day or the day before"
                       if not cands else "more than one POA could be this fax: " + ", ".join(r["key"] for r in cands))
                log.append((i, ev, "unmatched", why))
                continue
            r = cands[0]
            if ev["result"] == "delivered":
                r["confirmed"] = d
                r["pages"] = str(ev.get("pages") or "")
                r["confirm_ref"] = str(ev.get("ref") or "")
                if (r.get("note") or "").startswith("fax failed"):
                    r["note"] = ""
            else:
                r["note"] = f"fax failed {d}" + (f", {ev['detail']}" if ev.get("detail") else "")
            _touch(r, d, ref)
            log.append((i, ev, "applied", f"{r['key']}, fax {ev['result']}"))
            continue

        k = key_of(ev)
        r = rows.get(k)
        if r is None:
            r = {c: "" for c in COLUMNS}
            form = form_of(ev["form"])
            r.update(key=k, matter=ev["matter"], form=form,
                     agency=ev.get("agency") or DEFAULT_AGENCY[form])
            rows[k] = r
        elif ev["stage"] == "prepared" and r.get("rejected"):
            r["note"] = f"earlier round rejected {r['rejected']}"
            for s in STAGES + ["rejected", "confirmed", "pages", "confirm_ref", "method", "fax_to", "signature"]:
                r[s] = ""
        if ev.get("agency"):
            r["agency"] = ev["agency"]
        if ev.get("periods"):
            r["periods"] = ev["periods"]
        st = ev["stage"]
        if st in STAGES:
            if r.get(st) and r[st] != d:
                flags.append((r["key"], f"{STAGE_LABEL[st].lower()} recorded twice: {r[st]} and {d}. Kept {max(r[st], d)}."))
                d_keep = max(r[st], d)
            else:
                d_keep = d
            r[st] = d_keep
            if st == "submitted":
                r["method"] = ev.get("method") or r.get("method") or ""
                if r["method"] == "fax":
                    r["fax_to"] = ev.get("to") or agencies[r["agency"]]["fax"]
                    ag = agencies[r["agency"]]
                    if ag["fax"] and digits(r["fax_to"]) != digits(ag["fax"]):
                        flags.append((r["key"], f"faxed to {r['fax_to']}. The table has {ag['fax']} for {ag['name']}."))
                    if not ag["fax"]:
                        flags.append((r["key"], f"faxed to {r['fax_to']}. The table has no fax for {ag['name']}."))
            if ev.get("signature"):
                r["signature"] = ev["signature"]
            if (st in ("submitted", "signed") and r.get("signature") == "electronic"
                    and r["form"] == "2848" and r.get("method") in ("fax", "mail")):
                flags.append((r["key"], "electronic signature on a 2848 sent by "
                              f"{r['method']}. The IRS instructions take an electronic signature only "
                              "through IRS.gov/Submit2848."))
        elif st == "rejected":
            r["rejected"] = d
            if ev.get("detail"):
                r["note"] = f"rejected: {ev['detail']}"
        _touch(r, d, ref)
        log.append((i, ev, "applied", f"{r['key']}, {STAGE_LABEL.get(st, st).lower()}"))
    for r in rows.values():
        r["status"] = status_of(r)
        flags.extend((r["key"], m) for m in consistency(r))
    log.sort(key=lambda x: x[0])
    seen, uniq = set(), []
    for f in flags:
        if f not in seen:
            seen.add(f)
            uniq.append(f)
    return log, uniq


def consistency(r):
    """What the dates in one row say about each other."""
    out = []
    have = [(s, r[s]) for s in STAGES if r.get(s)]
    for i, (s1, d1) in enumerate(have):
        for s2, d2 in have[i + 1:]:
            if d1 > d2:
                out.append(f"{STAGE_LABEL[s2].lower()} {d2} is dated before {STAGE_LABEL[s1].lower()} {d1}")
    if r.get("submitted") and not r.get("signed"):
        out.append(f"submitted {r['submitted']} with no client signature in the record")
    if r.get("submitted") and not r.get("rep_signed"):
        out.append(f"submitted {r['submitted']} with no signature of yours in the record")
    return out


def _touch(r, d, ref):
    if d >= (r.get("last_event") or ""):
        r["last_event"] = d
    refs = [x for x in (r.get("refs") or "").split("; ") if x]
    if ref not in refs:
        refs.append(ref)
    r["refs"] = "; ".join(refs[-8:])


# ------------------------------------------------------------------ page

CSS = """
body{margin:0;background:#f4f5f7;font-family:-apple-system,BlinkMacSystemFont,
"Segoe UI",Arial,sans-serif;color:#1b2a4a}
.w{max-width:960px;margin:0 auto;padding:28px 20px 70px}
.card{background:#fff;border:1px solid #e3e8ef;border-radius:12px;padding:22px 26px;margin-bottom:16px}
.k{font-size:11px;font-weight:600;letter-spacing:1.6px;text-transform:uppercase;color:#ca25b7;padding-bottom:10px}
h1{margin:0 0 6px;font-size:27px;font-weight:600;color:#0b1f3a;letter-spacing:-.5px}
.sub{color:#6a7488;font-size:14px;margin:0 0 18px;line-height:1.55}
.tally{display:flex;gap:10px;flex-wrap:wrap;margin:0 0 22px}
.t{background:#fff;border:1px solid #e3e8ef;border-radius:10px;padding:10px 16px;min-width:120px}
.t b{display:block;font-size:24px;color:#000c65}
.t span{font-size:11px;letter-spacing:1.2px;text-transform:uppercase;color:#8a93a6;font-weight:600}
table{width:100%;border-collapse:collapse;font-size:13.5px}
th{text-align:left;font-size:10.5px;letter-spacing:1.2px;text-transform:uppercase;color:#8a93a6;
font-weight:600;padding:0 8px 8px 0;border-bottom:1px solid #e3e8ef}
td{padding:8px 8px 8px 0;border-bottom:1px solid #f0f2f6;vertical-align:top}
td.n,th.n{text-align:right}
td.d,.nw{white-space:nowrap}
.late{color:#b4483a;font-weight:600}
.src{color:#8a93a6;font-size:11.5px;font-family:ui-monospace,Menlo,monospace}
.row{font-size:13.5px;line-height:1.55;padding:6px 0;border-bottom:1px solid #f0f2f6}
.foot{color:#8a93a6;font-size:12.5px;line-height:1.65;margin:0}
.tag{display:inline-block;font-size:10.5px;font-weight:600;letter-spacing:.8px;text-transform:uppercase;
border:1px solid #e3e8ef;border-radius:999px;padding:1px 8px;color:#6a7488}
@media(max-width:640px){.card{padding:18px 16px}.tbl{overflow-x:auto}}
"""


def render(rows, log, flags, agencies, as_of, out):
    def age(s):
        return (as_of - day(s)).days if day(s) else ""

    def table(head, body, empty, cols):
        if not body:
            body = f"<tr><td colspan={cols} class=src>{empty}</td></tr>"
        return f"<div class='tbl'><table><tr>{head}</tr>{body}</table></div>"

    live = [r for r in rows.values() if r["status"] not in ("recorded",)]
    w_client = sorted([r for r in live if r["status"] == "sent"], key=lambda r: r["sent"])
    w_you = sorted([r for r in live if r["status"] in ("prepared", "signed", "rep_signed")],
                   key=lambda r: r.get(r["status"]) or "")
    at_agency = sorted([r for r in live if r["status"] in ("submitted", "confirmed")], key=lambda r: r["submitted"])
    failed = [r for r in rows.values() if r["status"] in ("fax_failed", "rejected")]
    unmatched = [x for x in log if x[2] == "unmatched"]
    refused = [x for x in log if x[2] == "refused"]
    look = len(failed) + len(unmatched) + len(refused) + len(flags)

    next_step = {"prepared": "Sent to the client", "signed": "Your signature",
                 "rep_signed": "Submission"}
    rows_client = "".join(
        f"<tr><td>{e(r['key'])}</td><td>{e(r.get('periods'))}</td><td>{e(r['sent'])}</td>"
        f"<td class=n>{age(r['sent'])}</td></tr>" for r in w_client)
    rows_you = "".join(
        f"<tr><td>{e(r['key'])}</td><td>{e(STAGE_LABEL[r['status']])} {e(r.get(r['status']))}</td>"
        f"<td>{e(next_step[r['status']])}</td><td class=n>{age(r.get(r['status']))}</td></tr>"
        for r in w_you)

    def agency_row(r):
        ag = agencies.get(r["agency"], {})
        win = ag.get("follow_up_days")
        days = age(r["submitted"])
        past = win is not None and days != "" and days > win
        conf = (f"Delivered {e(r['confirmed'])}" + (f", {e(r['pages'])} pages" if r.get("pages") else "")
                + (f"<div class=src>{e(r['confirm_ref'])}</div>" if r.get("confirm_ref") else "")) \
            if r.get("confirmed") else ("no confirmation in the record" if r.get("method") == "fax"
                                        else f"by {e(r.get('method') or 'a method not recorded')}")
        return (f"<tr><td>{e(r['key'])}</td><td>{e(ag.get('name', r['agency']))}</td>"
                f"<td>{e(r['submitted'])}</td><td>{conf}</td>"
                f"<td class='n{' late' if past else ''}'>{days}{' past your window' if past else ''}</td></tr>")
    rows_agency = "".join(agency_row(r) for r in at_agency)

    look_rows = "".join(
        f"<div class='row'><b>{e(r['key'])}.</b> "
        + (f"Rejected {e(r['rejected'])}. {e(r.get('note'))}" if r["status"] == "rejected"
           else e((r.get("note") or "fax failed").capitalize()) + ".")
        + "</div>" for r in failed)
    look_rows += "".join(f"<div class='row'><b>Fax {e(ev.get('date'))} to {e(ev.get('to'))}.</b> "
                         f"Not tied: {e(why)}. <span class='src'>{e(ev.get('source'))}</span></div>"
                         for _, ev, _, why in unmatched)
    look_rows += "".join(f"<div class='row'><b>{e(k)}.</b> {e(msg)}</div>" for k, msg in flags)
    look_rows += "".join(f"<div class='row'><b>Event {i} refused.</b> {e(why)}. "
                         f"<span class='src'>{e(ev.get('source'))}</span></div>" for i, ev, _, why in refused)
    look_rows = look_rows or "<div class='foot'>Nothing.</div>"

    reg = "".join(
        f"<tr><td>{e(r['key'])}</td><td><span class=tag>{e(STAGE_LABEL.get(r['status'], r['status']))}</span></td>"
        + "".join(f"<td class=d>{e(r.get(s) or '')}</td>" for s in ("prepared", "sent", "signed", "rep_signed",
                                                             "submitted", "confirmed", "recorded"))
        + "</tr>" for r in sorted(rows.values(), key=lambda r: r["key"]))

    ag_rows = "".join(
        f"<tr><td><b>{e(a['form'])}</b><div class=src>{e(k)}</div></td><td>{e(a['name'])}<div class=src>{e(a['covers'])}</div></td>"
        f"<td class=d>{e(a['fax'] or 'none listed')}</td><td>{e(a['mail'])}<div class=src>{e(a['online'])}</div></td>"
        f"<td>{e(a['signature'])}</td>"
        f"<td>{e(a['follow_up_days'] if a['follow_up_days'] is not None else 'not set')}</td>"
        f"<td>{'yes' if a['confirmed'] else 'not yet'}<div class=src>{e(a['source'])}</div></td></tr>"
        for k, a in agencies.items())

    ev_rows = "".join(
        f"<tr><td class=n>{i}</td><td class=d>{e(ev.get('date'))}</td><td>{e(ev.get('stage'))}</td>"
        f"<td>{e(what)}</td><td>{e(how)}<div class=src>{e(ev.get('source'))}</div>"
        f"<div class=src>{q((ev.get('quote') or '')[:140])}</div></td></tr>"
        for i, ev, how, what in log)

    unset = [a["name"] for a in agencies.values() if a["follow_up_days"] is None]
    html = f"""<!DOCTYPE html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>POA Tracker</title><style>{CSS}</style></head><body><div class="w">
<div class="k">POA Submission Tracking &middot; Item 9</div>
<h1>As of {e(as_of.strftime('%B ') + str(as_of.day) + ', ' + str(as_of.year))}</h1>
<p class="sub">{len(rows)} power(s) of attorney in the register, {len(log)} event(s) read. Every
event cites where it was read. Days are counted to today.</p>
<div class="tally">
<div class="t"><b>{len(w_client)}</b><span>With the client</span></div>
<div class="t"><b>{len(w_you)}</b><span>With you</span></div>
<div class="t"><b>{len(at_agency)}</b><span>At the agency</span></div>
<div class="t"><b>{look}</b><span>Needs a look</span></div>
</div>
<div class="card"><div class="k">Needs a look</div>{look_rows}</div>
<div class="card"><div class="k">With the client, sent and not signed</div>
{table('<th>POA</th><th>Periods</th><th>Sent</th><th class=n>Days</th>', rows_client, 'Nothing with a client.', 4)}</div>
<div class="card"><div class="k">With you</div>
{table('<th>POA</th><th>Last step</th><th>Not yet in the record</th><th class=n>Days</th>', rows_you, 'Nothing waiting on you.', 4)}</div>
<div class="card"><div class="k">At the agency, submitted and not recorded</div>
{table('<th>POA</th><th>Agency</th><th>Submitted</th><th>Confirmation</th><th class=n>Days</th>', rows_agency, 'Nothing at an agency.', 5)}
<p class="foot" style="margin-top:10px">Recorded means the record shows the agency has it on file: a
CAF letter, transcript access, or the agency saying so.{(' No follow-up window is set for ' + e(', '.join(unset)) + ', so days are counted and nothing is marked past a window.') if unset else ''}</p></div>
<div class="card"><div class="k">Every POA</div>
{table('<th>POA</th><th>Status</th><th>Prepared</th><th>Sent</th><th>Signed</th><th>You</th><th>Submitted</th><th>Confirmed</th><th>Recorded</th>', reg, 'The register is empty.', 9)}</div>
<div class="card"><div class="k">Where each form goes</div>
{table('<th>Form</th><th>Agency</th><th>Fax</th><th>Mail and online</th><th>Signature</th><th>Window</th><th>Confirmed</th>', ag_rows, '', 7)}
<p class="foot" style="margin-top:10px">Read from the sources named, for you to confirm. A fax
confirmation is tied to a POA by the number dialed and the day: one POA faxed to that number that
day or the day before. Anything else is listed above, never guessed.</p></div>
<div class="card"><div class="k">Every event read</div>
{table('<th class=n>#</th><th>Date</th><th>Stage</th><th>POA</th><th>Result and source</th>', ev_rows, 'No events.', 5)}</div>
<div class="card"><p class="foot">The register holds matter numbers and stays on this machine. This
page reports what the record shows. The judgment is the attorney's.</p></div>
</div></body></html>"""
    own = re.sub(r'<span class="nt">.*?</span>', " ", html, flags=re.S)
    low = " " + re.sub(r"<[^>]+>", " ", own).lower() + " "
    for w in WORDS_NEVER_PRINTED:
        if w in low:
            raise SystemExit(f"Refusing to write: the page contains '{w.strip()}'.")
    Path(out).write_text(html, encoding="utf-8")
    return w_client, w_you, at_agency, look


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--register", required=True)
    ap.add_argument("--events", required=True)
    ap.add_argument("--agencies")
    ap.add_argument("--as-of")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    agencies = json.loads(json.dumps(AGENCIES))
    if a.agencies and Path(a.agencies).exists():
        for k, v in json.loads(Path(a.agencies).read_text(encoding="utf-8")).items():
            agencies.setdefault(k, {}).update(v)
    evs = json.loads(Path(a.events).read_text(encoding="utf-8"))
    events = evs.get("events", evs if isinstance(evs, list) else [])
    as_of = date.fromisoformat(a.as_of) if a.as_of else date.today()

    existing = load_register(a.register)
    rows = {}
    log, flags = apply_events(rows, events, agencies)
    for k, old in existing.items():
        if k in rows:
            rows[k]["your_note"] = old.get("your_note", "")
        else:
            rows[k] = {c: old.get(c, "") for c in COLUMNS}
            rows[k]["status"] = status_of(rows[k])
            flags.append((k, "in the register with no event behind it. Kept as it was."))
    before = json.dumps({k: {c: str(v.get(c, "")) for c in COLUMNS} for k, v in existing.items()}, sort_keys=True)
    after = json.dumps({k: {c: str(v.get(c, "")) for c in COLUMNS} for k, v in rows.items()}, sort_keys=True)
    save_register(a.register, rows)
    w_client, w_you, at_agency, look = render(rows, log, flags, agencies, as_of, a.out)

    applied = sum(1 for x in log if x[2] == "applied")
    print(f"Written: {a.out}   as of {as_of}")
    print(f"  {len(events)} event(s): {applied} applied, "
          f"{sum(1 for x in log if x[2] == 'unmatched')} unmatched, {sum(1 for x in log if x[2] == 'refused')} refused")
    print(f"  register {a.register}: {len(rows)} POA(s)"
          + ("" if after != before else "; no changes"))
    print(f"  with the client {len(w_client)}, with you {len(w_you)}, at the agency {len(at_agency)}, "
          f"needs a look {look}")
    for i, ev, how, why in log:
        if how != "applied":
            print(f"  {how.upper()} event {i}: {why}")
    for k, msg in flags:
        print(f"  FLAG {k}: {msg}")


if __name__ == "__main__":
    main()

# Writing events

`events.json` is a list of events, one per stage the record shows.

```json
{"events": [
  {"date": "2026-10-02", "matter": "M-0917", "form": "2848", "stage": "submitted",
   "method": "fax", "to": "855-214-7519",
   "source": "Day notes, Oct 2 para 4", "quote": "faxed 2848 to CAF"},
  {"date": "2026-10-02", "stage": "fax_result", "to": "1 (855) 214-7519",
   "result": "delivered", "pages": 4, "ref": "Job 88231",
   "source": "Inbox, eFax confirmation, Oct 2 11:02 AM",
   "quote": "Your fax was successfully sent"}
]}
```

## Every event

| Field | Rule |
|---|---|
| `date` | The day it happened, `YYYY-MM-DD`. |
| `stage` | prepared, sent, signed, rep_signed, submitted, fax_result, recorded, rejected. |
| `source` | Where it was read: the folder, the subject, the date and time. |
| `quote` | Copied from the source. A short phrase is enough. |
| `matter` | The matter number. Never the client's name. |
| `form` | 2848, 548, PAR 101, or D-2848. Aliases such as MD 548 and par101 are read. |

## By stage

| Stage | Also |
|---|---|
| `prepared` | `periods`: the tax matters as the form lists them, "1040, 2017 to 2019". `agency` for a 2848 filed with Ogden: `IRS-Ogden`. Memphis is the default, and covers DC, Maryland, and Virginia. |
| `sent`, `signed` | `signature`: `electronic` when the client signed through Adobe Sign or another e-signature service, `handwritten` when the scan shows ink. Leave it out when the record does not say. |
| `submitted` | `method`: fax, online, mail, email, in person, or portal. `to`: the number dialed when it was a fax. Left out, the table's number for that agency is used. |
| `fax_result` | `to`: the number dialed, as the confirmation shows it. `result`: delivered or failed. `pages`, `ref`, and `detail` (the failure reason) when the confirmation gives them. `matter` and `form` only when the confirmation names them. |
| `rejected` | `detail`: the reason as the letter gives it. A later `prepared` event starts a new round, and the note keeps the earlier rejection. |
| `recorded` | The source that shows the agency has it on file. |

## Words never written

An event is a record. The engine refuses to write the page when its own text
contains should, recommend, advisable, or we suggest. Words quoted from the
source are the source's and pass.

# The Two Signature Routes

Charles picks the route. Both are ready, and the tracker reads either one.

## Route A: Ink and Fax

His standing instruction today, and the only route the state forms' sources
support.

| Stage | What happens | The event |
|---|---|---|
| Prepared | The POA skill fills the form | `prepared` |
| Sent | The transmittal goes to the client: "Sign and date with an original signature, not an electronic one." | `sent`, `signature` left out |
| Signed | The client returns a scan of the inked form | `signed`, `signature: handwritten` when the scan shows ink |
| Signed by you | He signs the declaration in ink | `rep_signed` |
| Submitted | Faxed to the agency's number in the table | `submitted`, `method: fax` |
| Confirmed | The eFax confirmation | `fax_result`, tied by number and day |
| Recorded | A CAF letter, transcript access, or the agency saying it is on file | `recorded` |

## Route B: E-Sign and Upload, Form 2848 Only

The IRS takes an electronically signed 2848 only through its online
submission, IRS.gov/Submit2848, which needs his Secure Access account.

| Stage | What happens | The event |
|---|---|---|
| Prepared | The POA skill fills the form | `prepared` |
| Sent | He sends the filled form for signature through Adobe Sign | `sent`, `method: email` |
| Signed | Adobe Sign's completion email arrives | `signed`, `signature: electronic`, quote from the completion email |
| Signed by you | He signs the declaration in Adobe Sign or in ink | `rep_signed` |
| Submitted | He uploads the signed form at IRS.gov/Submit2848 | `submitted`, `method: online` |
| Confirmed | The submission confirmation the upload shows or sends | `confirmed`, quote from the confirmation |
| Recorded | A CAF letter, transcript access, or the IRS saying it is on file | `recorded` |

The transmittal line for Route B, for him to approve before it is used:

> You will receive a signature request from Adobe Sign. Please sign where
> indicated and return it through Adobe Sign.

## What the Tracker Flags

- An electronic signature on a 2848 that went by fax or mail.
- An electronic signature on a 548, PAR 101, or D-2848, since those sources do
  not say the agency takes one.
- A 2848 sent online with no signature recorded is shown as it stands; nothing
  is assumed.

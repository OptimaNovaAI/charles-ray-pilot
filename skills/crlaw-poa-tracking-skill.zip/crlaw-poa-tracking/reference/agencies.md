# Where each form goes

Read from the sources named, for Charles to confirm. The table that runs is
`AGENCIES` at the top of `scripts/poa_track.py`. His changes go in
`agencies.json`, so the script stays as delivered.

| Form | Agency | Fax | Mail and online | Source |
|---|---|---|---|---|
| 2848 | IRS CAF Unit, Memphis. Taxpayers in DC, Maryland, Virginia, and the other eastern states on the IRS chart | 855-214-7519 | 5333 Getwell Road, Stop 8423, Memphis, TN 38118. IRS.gov/Submit2848 | IRS Instructions for Form 2848, Where To File Chart |
| 2848 | IRS CAF Unit, Ogden. The western states on the IRS chart | 855-214-7522 | 1973 Rulon White Blvd., MS 6737, Ogden, UT 84201. IRS.gov/Submit2848 | Same |
| 548 | Comptroller of Maryland, Revenue Administration Division, Attn: POA | 410-260-6213 | P.O. Box 1829, Annapolis, MD 21404-1829. Scanned to RADPOA@marylandtaxes.gov | Form 548 instructions |
| PAR 101 | Virginia Tax | 804-254-6115 | P.O. Box 1114, Richmond, VA 23218-1114. Secure Message through iFile or iReg | Printed on his master Form PAR 101 |
| D-2848 | DC Office of Tax and Revenue | None listed for POAs | 1101 4th Street, SW, Suite 270 West, Washington, DC 20024, by mail or in person. MyTax.DC.gov: More, Registration Details, Add Power of Attorney | OTR Power of Attorney page |

## Signatures

- **2848.** The IRS instructions take an electronic signature only through
  IRS.gov/Submit2848, which needs a Secure Access account. By fax or mail the
  signature is handwritten.
- **548, PAR 101, D-2848.** The sources read do not say. Charles confirms.

## His changes

```json
{
  "IRS-Memphis": {"follow_up_days": 10, "confirmed": true},
  "DC": {"fax": "the number he uses", "confirmed": true}
}
```

`follow_up_days` is his number for each agency. Until he sets one, the page
counts days and marks nothing as past a window.

---
name: crlaw-poa-tracking
description: POA submission tracking for the Law Offices of Charles A. Ray, P.C. Use whenever Charles asks where a power of attorney stands, including "where are my POAs", "did the 2848 go through", "which POAs are still with clients", "did the fax to the CAF unit confirm", "what's waiting on my signature", "track the POA for M-0917", "update the POA register", or when a scheduled morning run asks for it. Covers Form 2848, Maryland 548, Virginia PAR 101, and DC D-2848. It reads Outlook for the transmittal, the signed copy, the eFax confirmation, and the agency's answer, keeps the POA register, and reports each POA's stage with days counted. It never says what to do.
---

# POA tracking

Item 9. Every power of attorney the POA skill prepares moves through seven
stages: prepared, sent to the client, signed by the client, signed by Charles,
submitted, confirmed, recorded. This skill reads where each stage shows up,
writes it as an event, ties every eFax confirmation to the POA it belongs to,
and keeps the register.

Three rules, and they are the firm's:

- **Every event cites where it was read** and carries a quote from it. An event
  without both is refused and listed.
- **Nothing is dropped.** Every event is on the page, applied or not, with the
  reason. A fax confirmation that cannot be tied to exactly one POA is listed
  with its candidates, never guessed.
- **It reports.** Days are counted. What to do about a POA that has waited is
  the attorney's call.

---

## Run it

**1. Read the record.** With the Outlook connector, read the last 60 days:

| Where | Stage |
|---|---|
| A POA skill run, or the completed form saved to the matter folder | prepared |
| Sent Items: the transmittal with the form attached | sent |
| Inbox: the signed copy back from the client | signed |
| Day notes or a saved file showing his declaration signed | rep_signed |
| Day notes, a sent fax, a mailing, or a portal submission | submitted |
| Inbox: the eFax confirmation or failure | fax_result |
| A CAF letter, transcript access, or the agency saying it is on file | recorded |
| A letter or call saying it was not accepted | rejected |

Add an event to `events.json` for each, following `reference/events.md`. Keep
`events.json` beside the register. It grows run by run.

**2. Run the engine.**

```
python3 scripts/poa_track.py --register "C:/Users/<you>/OneDrive/POA Register.xlsx" \
    --events events.json --agencies agencies.json --as-of 2026-10-13 \
    --out "POA Tracker.html"
```

- The register is rebuilt from the events every run, so a run repeated changes
  nothing. The `your_note` column is his and carries over. A row he adds by hand
  is kept and flagged as having no event behind it.
- `--agencies` holds his changes to the agency table: a confirmed fax number,
  and the follow-up window for each agency. See `reference/agencies.md`.

**3. Hand him the page.** Say what needs a look first, then what is with
clients, with him, and at the agencies. Do not add advice the page does not
carry.

---

## The page

| Section | What it shows |
|---|---|
| Needs a look | A failed fax, a rejection, a fax confirmation not tied to one POA, dates out of order, a submission with no signature in the record, a fax sent to a number the table does not have, an electronic signature on a 2848 sent by fax or mail, and any refused event. |
| With the client | Sent and not signed, with days since sent. |
| With you | Prepared and not sent, or signed by the client and not yet submitted, with days. |
| At the agency | Submitted and not recorded: the agency, the date, the fax confirmation and pages, and days since. Past his window is marked once he sets one. |
| Every POA | Each stage's date. |
| Where each form goes | The agency table, with its source and whether he has confirmed it. |
| Every event read | All of them, with the source and the quote. |

---

## How a fax confirmation is tied

By the number dialed and the day. One POA submitted by fax to that number, that
day or the day before, with no confirmation yet: it is tied. None, or more than
one: it is listed with the candidates. A confirmation that names the matter is
tied to that matter directly.

---

## Signatures

The IRS instructions for Form 2848 take an electronic signature only through
IRS.gov/Submit2848. By fax or mail, the signature is handwritten. His standing
instruction to clients, "Sign and date with an original signature, not an
electronic one," fits the fax route. The engine flags an electronic signature
on a 2848 that went by fax or mail, and any electronic signature on a state
form, since those sources do not say. Both routes are written out in
`reference/routes.md`, so the route he picks runs the day he picks it.

---

## Every morning

Built to be scheduled. Weekdays at 7:15 a.m., a scheduled task:

> Run POA tracking. Read my Outlook from the last 60 days for POA transmittals,
> signed copies, eFax confirmations, and agency letters, add events for anything
> new, and run crlaw-poa-tracking with my POA register. Send me the page if
> anything needs a look.

---

## What it will not do

- Fax, mail, or submit anything. It reads what happened.
- Sign for anyone. Every signature is the client's or his.
- Decide a POA is lost or follow up with an agency. It counts the days.
- Put a client name in the register or on the page. It keys on matter number
  and form.

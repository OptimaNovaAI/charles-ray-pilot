# Change log

## October 24, 2026

Approved by Charles A. Ray, Jr. Prepared in a Claude session for install.

### Masters

**MASTER_IRS_2848.pdf**
- Representative name, CAF, telephone, fax, and line 5a "Other acts" text
  raised from 8 or 9 point to 9.5 point.
- Part II designation, jurisdiction, and bar number raised from 8 to 10 point.
- Jurisdiction corrected from "D.C; MD" to "D.C.; MD".
- Representative address left at 9 point. Its first line fills the box at 9.

**MASTER_DC_D-2848.pdf**
- Representative name-and-address block reduced from 9 to 8.5 point. At 9 the
  fifth line, "Washington, DC 20036," was cut off at the bottom of the box.

**MASTER_MD_548.pdf**
- Fax field reduced from 10 to 8 point. At 10 it was cut off at
  "202-824-0640 or 202-217-".

**MASTER_VA_PAR-101.pdf**
- No change. All fields render cleanly at 10 point.

### scripts/poa_autofill.py

- `_fits` recalibrated against rendered forms. One-line fields may use at
  most 80 percent of the box height (10 point clipped in a 12-point box;
  9.5 is clean). Multi-line fields allow 1.15 times the font size per line
  with no extra padding (two lines at 10 point fit a 24-point box; the old
  test forced them down to 8).
- `_bump_fonts` may now go below the master's own size when that size
  itself clips, down to `MIN_SIZE` (7 point). Before, a field whose master
  size clipped stayed clipped.
- New `preview()` renders a filled form to PNG for a visual check.
- Unchanged: field maps, the line 3 guardrail, and the never-touch rule for
  the representative half at fill time.

### SKILL.md

- New section: look at the rendered form before delivering.
- New section: font sizes, and that master changes are reserved to Charles.
- Example output name changed from a client surname to a matter number, to
  match the skill's own file-naming rule.

### Tested

Filled all four forms with sample data and rendered every page. No clipping
on any filled or pre-filled field. The line 3 guardrail still blocks
"All years" and an empty matter.

# Power of Attorney skill
Law Offices of Charles A. Ray, P.C. · Prepared by OptimaNova AI

## Install, once

1. Unzip.
2. In Claude, go to Settings, then Capabilities, then Skills.
3. Upload the `charles-ray-poa` folder.

That is the whole setup. It stays available in every conversation.

## Use it

Say the form name:

- "Complete Form 2848 for Danner Hawkins, 1040, 2022 and 2023."
- "I need a 548 for the Stedman matter."
- "Prepare the PAR 101 for this client."

Or describe the matter and let it ask which form:

- "New client, Maryland income tax appeal, 2024. I need a POA."

You can also paste a consultation note or an intake email and say
"complete the 2848 from this." It pulls the fields and shows you what it
found before filling anything.

## What comes back

A completed PDF with your representative block, the client's information,
and the tax matters filled in. It stays editable, so you can correct
anything before printing. Two things are always left blank: both signature
lines and both date lines.

Ask for the transmittal email and it drafts that too, naming only the
fields the client still has to complete.

## What is already in every form

Your name, firm, and address. CAF number 2605-70664R. DC bar 419973,
Maryland bar 69367, Virginia agent A-0440967. Phone, fax, email. The
authorized-acts checkboxes and the "receive IRS transcripts" language.
The Part II declaration line. You never retype any of it.

## One thing it will refuse

It will not produce a form with a blank or general tax matter. "All years"
and an empty years field both get rejected, because every one of these
agencies treats a general reference as an invalid document and sends the
form back. It will ask you for the specific years instead.

## Version 5, October 24, 2026

Your October 24 package, loaded as sent. Full detail is in `CHANGELOG.md`.

- Masters: your representative block and Part II on the IRS 2848 print in
  larger type, and the jurisdiction reads "D.C.; MD". The DC D-2848 address
  block and the Maryland 548 fax field no longer clip. The Virginia PAR 101
  is unchanged.
- `poa_autofill.py`: the fit check is calibrated against the rendered forms,
  so two-line fields keep 10 point where it fits and one-line fields no
  longer clip. A field whose master size clips may step down, to 7 point at
  the lowest. New `preview()` renders every page of a filled form for a
  visual check before it goes out.
- `SKILL.md`: check the rendered form before delivery. Changes to the
  masters are yours to approve.

## Version 4, October 2026

Your October 10 script, loaded as sent:

- Client fields print up to two points larger, and step back down
  wherever the larger size would clip. Set by `FONT_BUMP = 2`.
- Maryland 548 tax matters land in Part III, all three rows.
- DC D-2848 puts the name on the name line and the phone in the phone box,
  and fills the third tax-matter row.

The IRS 2848 and Virginia PAR 101 mappings are unchanged.

## Notes

It never signs anything. Wet ink only, on both sides.
It produces a document. Filing is yours.
Client names never appear in file names or document properties.

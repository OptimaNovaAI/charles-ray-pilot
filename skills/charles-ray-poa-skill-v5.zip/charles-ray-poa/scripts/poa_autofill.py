#!/usr/bin/env python3
"""
POA autofill.

Takes a taxpayer record and a jurisdiction, fills the taxpayer half of the
right master, and returns a completed PDF. The representative half is already
in the master and is never touched.

Output stays fillable so Charles can correct anything before printing.
Only the ink signature is left for a human.

    fill_poa("IRS", taxpayer, matters, "/tmp/out.pdf")
"""

from pypdf import PdfReader, PdfWriter
from pathlib import Path

MASTERS = Path(__file__).resolve().parent.parent / "forms"

FORMS = {
    "IRS": "MASTER_IRS_2848.pdf",
    "DC":  "MASTER_DC_D-2848.pdf",
    "MD":  "MASTER_MD_548.pdf",
    "VA":  "MASTER_VA_PAR-101.pdf",
}


class IncompleteMatter(Exception):
    """Line 3 / Part III is required. A general reference invalidates the form."""


def _validate(matters):
    """Every jurisdiction rejects a general reference. Catch it here, not at the agency."""
    banned = {"all", "all years", "all periods", "all taxes", "various", "n/a", ""}
    if not matters:
        raise IncompleteMatter(
            "At least one tax matter is required. A POA with no matter listed "
            "will be returned."
        )
    for m in matters:
        for key in ("description", "years"):
            val = str(m.get(key, "")).strip().lower()
            if val in banned:
                raise IncompleteMatter(
                    f"'{key}' is '{m.get(key)}'. Agencies treat a general reference "
                    f"as an invalid document. State the specific matter and years."
                )


# Points added to the font size of every text field we fill. Fields the
# master sets to auto-size (0 Tf) are left alone. Change it here only.
FONT_BUMP = 2


def _qualified_name(obj):
    """Full field name, e.g. topmostSubform[0].Page1[0].TaxpayerName[0]."""
    parts = []
    while obj is not None:
        if "/T" in obj:
            parts.append(str(obj["/T"]))
        obj = obj["/Parent"].get_object() if "/Parent" in obj else None
    return ".".join(reversed(parts))


def _fits(text, font, size, width, height):
    """
    True if every line of text fits the box at this size.

    Calibrated against rendered 2848s, Oct 2026:
    - One-line box: the font may use at most 80 percent of the box height.
      10 pt in a 12 pt box clips the descenders; 9.5 pt renders clean.
    - Multi-line box: allow 1.15 times the font size per line, no padding.
      Two lines at 10 pt fit a 24 pt box cleanly.
    """
    from reportlab.pdfbase.pdfmetrics import stringWidth
    f = font.lower()
    face = ("Courier" if "courier" in f else "Helvetica") + ("-Bold" if "bold" in f else "")
    lines = str(text).split("\n")
    if len(lines) == 1:
        if size > height * 0.8:
            return False
    elif len(lines) * size * 1.15 > height:
        return False
    return all(stringWidth(l, face, size) <= width - 4 for l in lines)


# Smallest size we will step down to when the master's own size clips.
MIN_SIZE = 7


def _bump_fonts(writer, values, bump=FONT_BUMP):
    """
    Enlarge the font on each text field being filled by up to `bump` points,
    stepping back down where the larger size would clip the text. Stays at or
    above the master's own size unless that size itself clips, in which case
    it steps down until the text fits, but never below MIN_SIZE.
    """
    import re
    from pypdf.generic import NameObject, TextStringObject
    pat = re.compile(r"(/\S+)\s+([\d.]+)\s+Tf")
    for page in writer.pages:
        for ref in page.get("/Annots") or []:
            widget = ref.get_object()
            name = _qualified_name(widget)
            if name not in values:
                continue
            x1, y1, x2, y2 = [float(c) for c in widget["/Rect"]]
            w, h = abs(x2 - x1), abs(y2 - y1)
            # /DA can sit on the widget, its parent field, or both
            node = widget
            while node is not None:
                da = node.get("/DA")
                if da is not None:
                    m = pat.search(str(da))
                    if m and float(m.group(2)) > 0:
                        base = float(m.group(2))
                        size = base + bump
                        floor = MIN_SIZE if not _fits(values[name], m.group(1), base, w, h) else base
                        while size > floor and not _fits(values[name], m.group(1), size, w, h):
                            size -= 0.5
                        node[NameObject("/DA")] = TextStringObject(
                            pat.sub(f"{m.group(1)} {size:g} Tf", str(da), count=1))
                node = node["/Parent"].get_object() if "/Parent" in node else None


def _write(src, dest, values):
    reader = PdfReader(src)
    writer = PdfWriter(clone_from=reader)
    writer.set_need_appearances_writer(True)
    _bump_fonts(writer, values)
    for page in writer.pages:
        writer.update_page_form_field_values(page, values, auto_regenerate=False)
    with open(dest, "wb") as fh:
        writer.write(fh)
    return dest


def preview(pdf, out_prefix=None, dpi=100):
    """
    Render every page of a filled form to PNG so it can be looked at before
    it goes to Charles. Returns the list of image paths. Requires pdftoppm.
    The fit check is arithmetic; only the rendered page proves nothing clips.
    """
    import subprocess, glob
    pdf = str(pdf)
    prefix = out_prefix or pdf[:-4] + "-preview"
    subprocess.run(["pdftoppm", "-r", str(dpi), "-png", pdf, prefix], check=True)
    return sorted(glob.glob(prefix + "*.png"))


def fill_poa(jurisdiction, taxpayer, matters, dest):
    """
    jurisdiction : "IRS" | "DC" | "MD" | "VA"
    taxpayer     : {name, address, city, state, zip, tin, phone,
                    spouse_name?, spouse_tin?}
    matters      : [{description, form, years}]  e.g.
                   [{"description": "Income", "form": "1040",
                     "years": "2022, 2023"}]
    """
    j = jurisdiction.upper()
    if j not in FORMS:
        raise ValueError(f"Unknown jurisdiction {jurisdiction!r}. Use IRS, DC, MD, or VA.")
    _validate(matters)

    t = taxpayer
    m1 = matters[0]
    m2 = matters[1] if len(matters) > 1 else {}
    m3 = matters[2] if len(matters) > 2 else {}
    full_addr = f'{t["address"]}\n{t["city"]}, {t["state"]}  {t["zip"]}'

    if j == "IRS":
        p = "topmostSubform[0].Page1[0]."
        p2 = "topmostSubform[0].Page2[0]."
        tbl = f"{p}Table_Line3[0]."
        v = {
            f"{p}TaxpayerName[0]":      t["name"],
            f"{p}TaxpayerAddress[0]":   full_addr,
            f"{p}TaxpayerIDSSN[0]":     t.get("tin", ""),
            f"{p}TaxpayerTelephone[0]": t.get("phone", ""),
            f"{tbl}BodyRow1[0].Description1[0]": m1.get("description", ""),
            f"{tbl}BodyRow1[0].TaxForm1[0]":     m1.get("form", ""),
            f"{tbl}BodyRow1[0].Years1[0]":       m1.get("years", ""),
            f"{tbl}BodyRow2[0].Description2[0]": m2.get("description", ""),
            f"{tbl}BodyRow2[0].TaxForm2[0]":     m2.get("form", ""),
            f"{tbl}BodyRow2[0].Years2[0]":       m2.get("years", ""),
            f"{p2}PrintName[0]":                 t["name"],
        }

    elif j == "DC":
        v = {
            # Name 1 is the taxpayer name line; Text1 is the daytime phone box.
            "Name 1":    t["name"],
            "Text1":     t.get("phone", ""),
            "TIN":       t.get("tin", ""),
            "Address 1": t["address"],
            "City":      t["city"],
            "state":     t["state"],
            "zip":       t["zip"],
            "Type 1":    m1.get("description", ""),
            "Form 1":    m1.get("form", ""),
            "Period 1":  m1.get("years", ""),
            "Type 2":    m2.get("description", ""),
            "Form 2":    m2.get("form", ""),
            "Period 2":  m2.get("years", ""),
            "Type 3":    m3.get("description", ""),
            "Form 3":    m3.get("form", ""),
            "Period 3":  m3.get("years", ""),
            "Spouse Name": t.get("spouse_name", ""),
            "S TIN":       t.get("spouse_tin", ""),
        }

    elif j == "MD":
        v = {
            "Text Field 2":  t["name"],
            "Text Field 1":  t.get("spouse_name", ""),
            "Text Field 3":  t.get("tin", ""),
            "Text Field 5":  t.get("spouse_tin", ""),
            "Text Field 6":  t.get("phone", ""),
            "Text Field 7":  t["address"],
            "Text Field 9":  t["city"],
            "Text Field 10": t["state"],
            "Text Field 11": t["zip"],
            # Part III, Tax Matters: three rows of type / form / years.
            # (Fields 20-26 are the second representative's block.)
            "Text Field 27": m1.get("description", ""),
            "Text Field 28": m1.get("form", ""),
            "Text Field 29": m1.get("years", ""),
            "Text Field 30": m2.get("description", ""),
            "Text Field 31": m2.get("form", ""),
            "Text Field 32": m2.get("years", ""),
            "Text Field 33": m3.get("description", ""),
            "Text Field 34": m3.get("form", ""),
            "Text Field 35": m3.get("years", ""),
            "Text Field 39": t.get("tin", ""),
            "Text Field 40": t["name"],
        }

    else:  # VA
        phone = t.get("phone", "")
        ac, _, local = phone.partition("-") if "-" in phone else ("", "", phone)
        v = {
            "Taxpayer Name Individual Business or Fiduciary": t["name"],
            "SSN ITIN or FEIN":        t.get("tin", ""),
            "Address":                 t["address"],
            "City":                    t["city"],
            "State":                   t["state"],
            "ZIP Code":                t["zip"],
            "Daytime Area Code":       ac,
            "Daytime Telephone Number": local,
            "Taxpayer Email Address":  t.get("email", ""),
            "Spouse Name For joint representation only See instructions": t.get("spouse_name", ""),
            "Spouse SSN or ITIN":      t.get("spouse_tin", ""),
            "Tax TypeRow1":            m1.get("description", ""),
            "Taxable Years Do Not Enter All Years  Must be SpecificRow1": m1.get("years", ""),
            "Tax TypeRow2":            m2.get("description", ""),
            "Taxable Years Do Not Enter All Years  Must be SpecificRow2": m2.get("years", ""),
            "Print Name":              t["name"],
        }

    return _write(MASTERS / FORMS[j], dest, {k: val for k, val in v.items() if val})


# ---------------------------------------------------------------
if __name__ == "__main__":
    taxpayer = {
        "name":    "JANE Q SAMPLE",
        "address": "1400 Test Street NW",
        "city":    "Washington",
        "state":   "DC",
        "zip":     "20005",
        "tin":     "000-00-0000",
        "phone":   "202-555-0147",
        "email":   "sample@example.com",
    }
    matters = [{"description": "Income", "form": "1040", "years": "2022, 2023"}]

    out = Path("/mnt/user-data/outputs/poa-test")
    out.mkdir(parents=True, exist_ok=True)

    print("Test fill, all four jurisdictions\n")
    for j in ("IRS", "DC", "MD", "VA"):
        f = fill_poa(j, taxpayer, matters, out / f"TEST_{j}.pdf")
        fields = PdfReader(f).get_fields()
        n = sum(1 for x in fields.values() if x.get("/V") not in (None, "", "/Off"))
        print(f"  {j:4} -> {f.name:16} {n:2} fields populated, form still live")

    print("\nGuardrail check")
    for bad in ("All years", ""):
        try:
            fill_poa("IRS", taxpayer,
                     [{"description": "Income", "form": "1040", "years": bad}],
                     out / "should_not_exist.pdf")
            print(f"  FAIL: '{bad}' was accepted")
        except IncompleteMatter as e:
            print(f"  blocked '{bad}': {str(e)[:66]}...")

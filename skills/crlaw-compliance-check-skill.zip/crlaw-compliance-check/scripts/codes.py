#!/usr/bin/env python3
"""
IRS account transcript transaction codes.

This table is the engine's working vocabulary. It is not authority. Charles
should read it once and correct anything that does not match what he sees on
real transcripts, because a wrong meaning here produces a confident wrong
answer downstream rather than an error.

EFFECT is how the code moves the module balance:
    assess   the Service added to what is owed
    credit   a payment or credit reduced it
    abate    an earlier assessment was reduced or removed
    refund   money left the account to the taxpayer
    neutral  no balance effect, but it may still matter
    status   no balance effect, and it changes the posture of the account

A code absent from this table is never dropped. It is reported as unrecognized
with its line, so the attorney sees it and the table can grow.
"""

CODES = {
    # --- the return itself -------------------------------------------------
    "150": ("Return filed and tax assessed", "assess"),
    "140": ("Inquiry issued for non-filing of return", "neutral"),
    "460": ("Extension of time to file granted", "neutral"),
    "570": ("Additional account action pending, refund held", "status"),
    "571": ("Release of prior 570 hold", "status"),
    "576": ("Unallowable tax, hold", "status"),
    "599": ("Return secured by the Service", "neutral"),
    "976": ("Duplicate return filed", "neutral"),
    "977": ("Amended return filed", "neutral"),

    # --- additional assessments -------------------------------------------
    "290": ("Additional tax assessed", "assess"),
    "300": ("Additional tax assessed by examination", "assess"),
    "310": ("Penalty for fraud", "assess"),
    "320": ("Fraud penalty", "assess"),
    "350": ("Negligence penalty", "assess"),

    # --- penalties and interest -------------------------------------------
    "160": ("Failure to file penalty, manually assessed", "assess"),
    "166": ("Failure to file penalty", "assess"),
    "170": ("Estimated tax penalty, manually assessed", "assess"),
    "176": ("Estimated tax penalty", "assess"),
    "196": ("Interest assessed", "assess"),
    "234": ("Failure to pay penalty, manually assessed", "assess"),
    "238": ("Failure to pay penalty", "assess"),
    "270": ("Failure to pay penalty, manually assessed", "assess"),
    "276": ("Failure to pay penalty", "assess"),

    # --- abatements and reversals -----------------------------------------
    "161": ("Abatement of failure to file penalty", "abate"),
    "167": ("Abatement of failure to file penalty", "abate"),
    "171": ("Abatement of estimated tax penalty", "abate"),
    "177": ("Abatement of estimated tax penalty", "abate"),
    "197": ("Abatement of interest", "abate"),
    "235": ("Abatement of failure to pay penalty", "abate"),
    "239": ("Abatement of failure to pay penalty", "abate"),
    "271": ("Abatement of failure to pay penalty", "abate"),
    "277": ("Abatement of failure to pay penalty", "abate"),
    "291": ("Abatement of prior tax assessment", "abate"),
    "295": ("Abatement of prior tax assessment", "abate"),
    "299": ("Abatement of prior tax assessment", "abate"),
    "301": ("Abatement of prior examination assessment", "abate"),
    "305": ("Abatement of prior examination assessment", "abate"),
    "311": ("Abatement of fraud penalty", "abate"),
    "321": ("Abatement of fraud penalty", "abate"),
    "351": ("Abatement of negligence penalty", "abate"),

    # --- payments and credits ---------------------------------------------
    "610": ("Payment with return", "credit"),
    "611": ("Payment with return, dishonored", "assess"),
    "640": ("Advance payment of determined deficiency", "credit"),
    "650": ("Federal tax deposit", "credit"),
    "660": ("Estimated tax payment", "credit"),
    "670": ("Subsequent payment", "credit"),
    "671": ("Subsequent payment, dishonored", "assess"),
    "700": ("Credit applied", "credit"),
    "706": ("Credit applied from another period", "credit"),
    "710": ("Overpayment credit applied", "credit"),
    "716": ("Overpayment credit applied", "credit"),
    "730": ("Overpayment interest applied", "credit"),
    "736": ("Overpayment interest applied", "credit"),
    "756": ("Interest credit", "credit"),
    "764": ("Earned income credit", "credit"),
    "765": ("Reversal of earned income credit", "assess"),
    "766": ("Credit to the account", "credit"),
    "767": ("Reversal of credit to the account", "assess"),
    "768": ("Earned income credit", "credit"),
    "806": ("Withholding and excess FICA credit", "credit"),
    "807": ("Reversal of withholding credit", "assess"),

    # --- money leaving the account ----------------------------------------
    "826": ("Credit transferred out to another period", "assess"),
    "846": ("Refund issued", "refund"),
    "776": ("Interest paid on refund", "refund"),
    "841": ("Refund cancelled", "credit"),

    # --- posture of the account -------------------------------------------
    "420": ("Examination indicator", "status"),
    "421": ("Examination closed", "status"),
    "424": ("Examination request indicator", "status"),
    "425": ("Reversed examination indicator", "status"),
    "480": ("Offer in compromise pending", "status"),
    "481": ("Offer in compromise withdrawn", "status"),
    "482": ("Offer in compromise rejected", "status"),
    "483": ("Offer in compromise returned", "status"),
    "488": ("Installment or manual billing", "status"),
    "494": ("Notice of deficiency issued", "status"),
    "495": ("Notice of deficiency closed", "status"),
    "500": ("Military deferment", "status"),
    "520": ("Bankruptcy or litigation, collection suspended", "status"),
    "521": ("Reversal of bankruptcy or litigation hold", "status"),
    "530": ("Currently not collectible", "status"),
    "531": ("Reversal of currently not collectible", "status"),
    "550": ("Collection statute date extended by agreement", "status"),
    "582": ("Lien filed", "status"),
    "583": ("Lien released", "status"),
    "780": ("Offer in compromise accepted", "status"),
    "788": ("All collateral conditions of the offer met", "status"),
    "960": ("Appointed representative, power of attorney on file", "status"),
    "961": ("Power of attorney revoked or replaced", "status"),
    "971": ("Miscellaneous transaction, read the action code", "status"),
    "972": ("Reversal of a miscellaneous transaction", "status"),
}

# Codes that bear on the collection statute. The engine flags these and does
# not compute with them. A suspension has a start and an end, the end is often
# on a different line or a different year, and the arithmetic is the attorney's
# with the register in front of him.
STATUTE_FLAGS = {
    "480": "Offer pending. Collection is generally suspended while it is.",
    "481": "Offer withdrawn. A suspension that began at 480 may end here.",
    "482": "Offer rejected. A suspension that began at 480 may end here.",
    "483": "Offer returned. A suspension that began at 480 may end here.",
    "500": "Military deferment. Collection is generally suspended.",
    "520": "Bankruptcy or litigation. Collection is generally suspended.",
    "521": "Reversal of the 520 hold. A suspension may end here.",
    "550": "The statute date was extended by agreement. Read the new date "
           "off the line and treat it as controlling.",
    "780": "Offer accepted. The liability may be settled rather than running.",
}

# Codes that say the account is not in ordinary collection status.
POSTURE_FLAGS = {
    "420": "Under examination.",
    "424": "Flagged for examination.",
    "494": "A notice of deficiency was issued. Check the address it went to "
           "and the ninety day window.",
    "530": "Currently not collectible.",
    "582": "A lien is filed.",
    "488": "Installment or manual billing.",
    "570": "Refund or account action is held.",
    "971": "Miscellaneous transaction. The meaning sits in the action code on "
           "the line beneath it, for example a CP notice number.",
}

ASSESSING = {"assess"}
REDUCING = {"credit", "abate"}


def look_up(code):
    """Return (description, effect, recognized)."""
    code = str(code).strip()
    if code in CODES:
        desc, eff = CODES[code]
        return desc, eff, True
    return "Unrecognized transaction code", "unknown", False

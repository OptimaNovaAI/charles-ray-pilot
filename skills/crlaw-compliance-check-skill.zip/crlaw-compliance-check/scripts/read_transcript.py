#!/usr/bin/env python3
"""
Reader for IRS account transcripts.

    python3 read_transcript.py transcript.html  periods.json  "label"
    python3 read_transcript.py transcript.pdf   periods.json  "label"
    python3 read_transcript.py transcript.txt   periods.json  "label"

Turns a transcript into the structure evaluate.py reads. The contract between
the two is in reference/contract.md and this file satisfies it.

It reads the download from e-Services, a PDF carrying a text layer, or plain
text. It does not read a page whose characters were saved as drawings. It says
so and stops, because guessing at a page it cannot see is the failure this
engine exists to prevent.

Every transaction carries the raw line it came from. Nothing is tidied up on
the way through.
"""

import json
import re
import sys
from pathlib import Path

# ---------------------------------------------------------------- patterns

# A transaction line opens with a three digit code at the left margin.
TXN = re.compile(r"^\s{0,6}(?P<code>\d{3})\s+(?P<rest>\S.*?)\s*$")

DATE = re.compile(r"(?<!\d)(\d{2})-(\d{2})-(\d{4})(?!\d)")
CYCLE = re.compile(r"(?<!\d)(\d{8})(?!\d)")
AMOUNT = re.compile(r"(-?)\$([\d,]+\.\d{2})")
DLN = re.compile(r"^\d{5}-\d{3}-\d{5}-\d$")
NOTICE = re.compile(r"^(CP|LT|LP)\s*\d+", re.I)

SUMMARY = {
    "stated_balance": re.compile(r"^\s*Account balance:\s*\$?(-?[\d,]+\.\d{2})",
                                 re.I | re.M),
    "accrued_interest": re.compile(r"^\s*Accrued interest:\s*\$?(-?[\d,]+\.\d{2})",
                                   re.I | re.M),
    "accrued_penalty": re.compile(r"^\s*Accrued penalty:\s*\$?(-?[\d,]+\.\d{2})",
                                  re.I | re.M),
}
PERIOD = re.compile(r"Report for Tax Period Ending:\s*(\d{2})-(\d{2})-(\d{4})", re.I)
FORMNO = re.compile(r"^\s*Form Number:\s*(\d+)", re.I | re.M)


def money(sign, digits):
    v = float(digits.replace(",", ""))
    return -v if sign == "-" else v


def iso(m):
    mm, dd, yyyy = m.groups()
    return f"{yyyy}-{mm}-{dd}"


# ---------------------------------------------------------------- extraction

def from_html(path):
    """The e-Services download. Tags out, text and line breaks preserved."""
    import html as H
    raw = Path(path).read_text(encoding="utf-8", errors="ignore")
    raw = re.sub(r"(?is)<(script|style).*?</\1>", " ", raw)
    raw = re.sub(r"(?i)<br\s*/?>", "\n", raw)
    raw = re.sub(r"(?i)</(p|div|tr|h\d|pre|li)>", "\n", raw)
    raw = re.sub(r"(?i)</t[dh]>", "  ", raw)
    raw = re.sub(r"<[^>]+>", "", raw)
    raw = H.unescape(raw)
    return "\n".join(l.rstrip() for l in raw.splitlines())


def from_pdf(path):
    """
    A PDF, page by page, layout preserved.

    A page carrying no text is reported rather than skipped. On the
    print-to-PDF route the transactions page is frequently saved as outlines of
    its letters, which looks right on paper and holds nothing a parser can read.
    """
    import subprocess
    from pypdf import PdfReader
    n = len(PdfReader(str(path)).pages)
    pages, empty = [], []
    for i in range(1, n + 1):
        r = subprocess.run(
            ["pdftotext", "-layout", "-f", str(i), "-l", str(i), str(path), "-"],
            capture_output=True, text=True)
        if len(r.stdout.strip()) < 20:
            empty.append(i)
        pages.append(r.stdout)
    return "\n".join(pages), empty


def load(path):
    p = Path(path)
    ext = p.suffix.lower()
    if ext in (".html", ".htm"):
        return from_html(p), []
    if ext == ".pdf":
        return from_pdf(p)
    return p.read_text(encoding="utf-8", errors="ignore"), []


# ---------------------------------------------------------------- parsing

def parse_transactions(text):
    """
    Read the TRANSACTIONS table.

    A line opening with a three digit code starts a transaction. A line that
    does not is a continuation of the one above it, and what it carries depends
    on the code it sits under: a document locator number under a 150, a notice
    under a 971, a date under a penalty code.

    A continuation is attached to its parent, typed, and kept in the parent's
    line. It is never dropped and never read as a transaction of its own.
    """
    out = []
    started = False

    for line in text.splitlines():
        if not started:
            if re.search(r"CODE\s+EXPLANATION OF TRANSACTION", line, re.I):
                started = True
            continue
        if re.search(r"This Product Contains Sensitive", line, re.I):
            break
        if not line.strip():
            continue

        m = TXN.match(line)
        if m:
            rest = m.group("rest")
            cyc = CYCLE.search(rest)
            dt = DATE.search(rest)
            amt = AMOUNT.search(rest)
            desc = rest
            for pat in (CYCLE, DATE, AMOUNT):
                desc = pat.sub("", desc)
            out.append({
                "code": m.group("code"),
                "description": " ".join(desc.split()),
                "date": iso(dt) if dt else None,
                "amount": money(*amt.groups()) if amt else None,
                "cycle": cyc.group(1) if cyc else None,
                "line": line.strip(),
                "continuations": [],
            })
            continue

        if out:
            frag = line.strip()
            kind, value = "unclassified", frag
            if DLN.match(frag):
                kind = "document_locator_number"
            elif DATE.fullmatch(frag):
                kind = "date"
                value = iso(DATE.match(frag))
            elif NOTICE.match(frag):
                kind = "notice"
            elif re.fullmatch(r"\d{1,4}", frag):
                kind = "indicator"
            out[-1]["continuations"].append(
                {"kind": kind, "value": value, "line": frag})
            out[-1]["line"] += "  |  " + frag

    return out


def parse(text, empty_pages, label):
    period = PERIOD.search(text)
    form = FORMNO.search(text)

    sums = {}
    for k, pat in SUMMARY.items():
        m = pat.search(text)
        if m:
            sums[k] = float(m.group(1).replace(",", ""))

    p = {
        "year": int(period.group(3)) if period else None,
        "form": form.group(1) if form else "1040",
        "transactions": parse_transactions(text),
    }
    if "stated_balance" in sums:
        p["stated_balance"] = sums["stated_balance"]

    return {
        "taxpayer_label": label,
        "source": {"kind": "account_transcript",
                   "text_layer": not empty_pages,
                   "pages_without_text": empty_pages},
        "periods": [p],
    }


# ---------------------------------------------------------------- main

def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)

    src, out = sys.argv[1], sys.argv[2]
    label = sys.argv[3] if len(sys.argv) > 3 else "Account transcript"

    text, empty = load(src)
    data = parse(text, empty, label)
    p = data["periods"][0]

    if empty:
        sys.stderr.write(
            f"\nPage(s) {', '.join(str(x) for x in empty)} carry no text.\n"
            "On the print-to-PDF route the transactions page is often saved as\n"
            "drawings of its letters. It looks right on paper and holds nothing\n"
            "a parser can read. Use the download from e-Services instead, which\n"
            "comes as HTML and carries real text throughout.\n\n")

    if not p["transactions"]:
        raise SystemExit(
            "No transactions found. Either the TRANSACTIONS heading is absent, "
            "or the page it sits on carries no text. Nothing written.")

    Path(out).write_text(json.dumps(data, indent=2))

    # Reconcile here as well as in the engine, so a bad read is caught where it
    # happened rather than three steps later.
    sys.path.insert(0, str(Path(__file__).parent))
    from codes import look_up, ASSESSING, REDUCING

    assessed = reduced = 0.0
    unknown = []
    for t in p["transactions"]:
        _, eff, known = look_up(t["code"])
        if not known:
            unknown.append(t["code"])
        if t["amount"] is None:
            continue
        if eff in ASSESSING:
            assessed += abs(t["amount"])
        elif eff in REDUCING:
            reduced += abs(t["amount"])
        elif eff == "refund":
            assessed += abs(t["amount"])
    computed = assessed - reduced
    if abs(computed) < 0.005:
        computed = 0.0

    cont = sum(len(t["continuations"]) for t in p["transactions"])
    print(f"Written: {out}")
    print(f"  year {p['year']}   {len(p['transactions'])} transaction(s)")
    print(f"  {cont} continuation line(s), attached and kept")
    print(f"  computed ${computed:,.2f}", end="")
    if "stated_balance" in p:
        diff = computed - p["stated_balance"]
        print(f"   stated ${p['stated_balance']:,.2f}", end="")
        print("   RECONCILES" if abs(diff) < 0.005
              else f"   DISCREPANCY ${abs(diff):,.2f}")
    else:
        print("   (transcript states no balance)")
    if unknown:
        print(f"  unrecognized: {', '.join(sorted(set(unknown)))} "
              f"— reported, not dropped")


if __name__ == "__main__":
    main()

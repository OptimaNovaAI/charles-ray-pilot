#!/usr/bin/env python3
"""
Compliance check for the Law Offices of Charles A. Ray, P.C.

    python3 evaluate.py periods.json out.html

Reads structured transcript data and reports filing and payment status for each
year, with the transcript line that establishes every claim.

It does not read a transcript. That is scripts/read_transcript.py, which is not
written yet because the format has not been confirmed against a real file. The
contract between the two is in reference/contract.md and is fixed, so the
reader can be written without touching anything here.

Three rules run through this, and they are Charles's, not mine.

    Nothing is dropped silently. An unrecognized code is reported as
    unrecognized, with its line. It is never discarded to keep the output tidy.

    Every claim cites the line that establishes it.

    Derived is not controlling. A figure this engine computed is labelled as
    computed. A figure the Service stated is labelled as stated. Where the two
    disagree, both are shown and the disagreement is the finding.
"""

import json
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from codes import (look_up, STATUTE_FLAGS, POSTURE_FLAGS,  # noqa: E402
                   ASSESSING, REDUCING)

MONEY = "${:,.2f}"


def fmt(v):
    if isinstance(v, (int, float)):
        # a computed total can land on -0.0; it is zero and prints as zero
        if abs(v) < 0.005:
            v = 0.0
        return MONEY.format(v)
    return str(v)


def d(s):
    if not s:
        return None
    return datetime.strptime(str(s)[:10], "%Y-%m-%d").date()


# ------------------------------------------------------------------ one year

def evaluate_period(p):
    """Filing and payment posture for a single tax period."""
    year = p.get("year")
    txns = p.get("transactions", [])

    seen = []
    unrecognized = []
    assessed = 0.0
    reduced = 0.0
    refunded = 0.0

    filing = None          # the TC 150, if there is one
    amended = []
    statute_flags = []
    posture_flags = []

    for t in txns:
        code = str(t.get("code", "")).strip()
        amount = t.get("amount")
        amount = float(amount) if amount not in (None, "") else None
        line = t.get("line", "")
        when = d(t.get("date"))

        desc, effect, known = look_up(code)
        row = {"code": code, "date": when, "amount": amount, "line": line,
               "desc": desc, "effect": effect, "known": known,
               "continuations": t.get("continuations", [])}
        seen.append(row)

        if not known:
            unrecognized.append(row)
            continue

        if amount is not None:
            mag = abs(amount)
            if effect in ASSESSING:
                assessed += mag
            elif effect in REDUCING:
                reduced += mag
            elif effect == "refund":
                refunded += mag

        if code == "150":
            filing = row
        if code in ("976", "977"):
            amended.append(row)
        if code in STATUTE_FLAGS:
            statute_flags.append({**row, "why": STATUTE_FLAGS[code]})
        if code in POSTURE_FLAGS:
            posture_flags.append({**row, "why": POSTURE_FLAGS[code]})

    computed = assessed - reduced + refunded
    stated = p.get("stated_balance")
    stated = float(stated) if stated not in (None, "") else None

    # A disagreement between what we computed and what the Service printed is
    # itself a finding. Neither figure wins silently.
    discrepancy = None
    if stated is not None and abs(computed - stated) >= 0.01:
        discrepancy = computed - stated

    # Filing status. A missing 150 is not proof of non-filing, only absence of
    # evidence of filing, and the two are said differently.
    if filing is None:
        filing_status = "No return posting on this transcript"
        filing_basis = ("No TC 150 appears. That is the absence of a filing "
                        "record, which is not the same as proof that nothing "
                        "was filed.")
    else:
        sfr = (filing["amount"] in (0, 0.0, None)
               and ("sfr" in filing["line"].lower()
                    or "substitute" in filing["line"].lower()))
        if sfr:
            filing_status = "Return posted, possible substitute for return"
            filing_basis = ("The TC 150 posts at zero and the line reads as a "
                            "substitute. Confirm before relying on it.")
        else:
            filing_status = "Return posted"
            filing_basis = f"TC 150 dated {filing['date']}."

    if computed <= 0.009:
        payment_status = "No balance"
    else:
        payment_status = "Balance due"

    return {
        "year": year, "form": p.get("form", ""),
        "transactions": seen, "unrecognized": unrecognized,
        "assessed": assessed, "reduced": reduced, "refunded": refunded,
        "computed": computed, "stated": stated, "discrepancy": discrepancy,
        "filing_status": filing_status, "filing_basis": filing_basis,
        "filing_row": filing, "amended": amended,
        "payment_status": payment_status,
        "statute_flags": statute_flags, "posture_flags": posture_flags,
    }


# ------------------------------------------------------------------ findings

def findings(results, meta):
    out = []

    if meta.get("text_layer") is False:
        out.append(("caution",
                    "This transcript had no text layer and was read by "
                    "character recognition. Every figure below should be read "
                    "against the page before it is relied on."))

    unfiled = [r["year"] for r in results if r["filing_row"] is None]
    if unfiled:
        out.append(("open",
                    f"No return posting for {', '.join(str(y) for y in unfiled)}. "
                    f"Filing compliance is a condition of most collection "
                    f"alternatives, so this is a sequence question."))

    owing = [r for r in results if r["computed"] > 0.009]
    if owing:
        total = sum(r["computed"] for r in owing)
        yrs = ", ".join(str(r["year"]) for r in owing)
        out.append(("note",
                    f"Balance computed for {yrs}, totalling {fmt(total)}."))

    for r in results:
        if r["discrepancy"] is not None:
            out.append(("caution",
                        f"{r['year']}: this engine computes {fmt(r['computed'])} "
                        f"from the lines and the transcript states "
                        f"{fmt(r['stated'])}, a difference of "
                        f"{fmt(abs(r['discrepancy']))}. Neither figure is taken "
                        f"as correct here."))

    for r in results:
        for f in r["statute_flags"]:
            out.append(("statute",
                        f"{r['year']}, TC {f['code']} dated {f['date']}. "
                        f"{f['why']}"))

    for r in results:
        for f in r["posture_flags"]:
            extra = ""
            for c in f.get("continuations", []):
                if c["kind"] == "notice":
                    extra = f" The notice is {c['value']}."
            out.append(("posture",
                        f"{r['year']}, TC {f['code']} dated {f['date']}. "
                        f"{f['why']}{extra}"))

    # A continuation date exactly ten years from its assessment has the shape
    # of a collection statute date. It is flagged for confirmation and never
    # treated as established.
    for res in results:
        for t in res["transactions"]:
            for c in t.get("continuations", []):
                if c["kind"] != "date" or not t["date"]:
                    continue
                try:
                    cy = int(str(c["value"])[:4])
                except ValueError:
                    continue
                if (cy - t["date"].year == 10
                        and str(c["value"])[5:] == t["date"].isoformat()[5:]):
                    out.append(("statute",
                                f"{res['year']}, TC {t['code']} carries "
                                f"{c['value']} on the line beneath it, exactly "
                                f"ten years from the {t['date']} assessment. "
                                f"That has the shape of a collection statute "
                                f"date stated by the Service. Confirm it before "
                                f"treating it as controlling."))

    total_unrec = sum(len(r["unrecognized"]) for r in results)
    if total_unrec:
        out.append(("caution",
                    f"{total_unrec} transaction line(s) carry a code this "
                    f"engine does not recognize. Each one is listed under its "
                    f"year with its line. None were dropped."))

    for r in results:
        if r["amended"]:
            out.append(("note",
                        f"{r['year']}: an amended or duplicate return posts "
                        f"(TC {r['amended'][0]['code']}). The assessment "
                        f"history may not read in date order."))

    return out


# ------------------------------------------------------------------ render

CSS = """
body{margin:0;background:#f4f5f7;font-family:-apple-system,BlinkMacSystemFont,
"Segoe UI",Arial,sans-serif;color:#1b2a4a}
.w{max-width:900px;margin:0 auto;padding:28px 20px 70px}
.card{background:#fff;border:1px solid #e3e8ef;border-radius:12px;
padding:22px 26px;margin-bottom:16px}
.k{font-size:11px;font-weight:600;letter-spacing:1.6px;text-transform:uppercase;
color:#ca25b7;padding-bottom:10px}
h1{margin:0 0 6px;font-size:27px;font-weight:600;color:#0b1f3a;letter-spacing:-.5px}
.sub{color:#6a7488;font-size:14px;margin:0 0 22px}
.yr{font-size:19px;font-weight:600;color:#000c65}
.pill{display:inline-block;font-size:10.5px;letter-spacing:1.1px;
text-transform:uppercase;font-weight:600;padding:3px 9px;border-radius:20px;
margin-left:8px;vertical-align:2px}
.p-ok{background:#e8f5ef;color:#0b7a55}.p-due{background:#fdecea;color:#b4483a}
.p-none{background:#fdf4e3;color:#9a7220}
table{width:100%;border-collapse:collapse;font-size:13.5px;margin-top:12px}
th{text-align:left;font-size:10.5px;letter-spacing:1.2px;text-transform:uppercase;
color:#8a93a6;font-weight:600;padding:0 8px 8px 0;border-bottom:1px solid #e3e8ef}
td{padding:8px 8px 8px 0;border-bottom:1px solid #f0f2f6;vertical-align:top}
td.n,th.n{text-align:right}
.src{color:#8a93a6;font-size:11.5px;font-family:ui-monospace,Menlo,monospace}
.unk{background:#fdf4e3}
.basis{font-size:13.5px;color:#6a7488;padding-top:6px;line-height:1.55}
.f{border-left:3px solid #d5dae3;padding:2px 0 2px 14px;margin-bottom:14px;
font-size:14.5px;line-height:1.6}
.f.open{border-color:#0b7a55}.f.caution{border-color:#d9a441}
.f.statute{border-color:#ca25b7}.f.posture{border-color:#2e75b6}
.f.note{border-color:#8a93a6}
.tag{font-size:10px;letter-spacing:1.3px;text-transform:uppercase;
font-weight:600;display:block;padding-bottom:3px}
.open .tag{color:#0b7a55}.caution .tag{color:#d9a441}
.statute .tag{color:#ca25b7}.posture .tag{color:#2e75b6}.note .tag{color:#8a93a6}
.foot{color:#8a93a6;font-size:12.5px;line-height:1.65}
"""

TAGS = {"open": "Compliance", "caution": "Verification",
        "statute": "Statute", "posture": "Account posture", "note": "For reference"}


def render(results, meta, out_path):
    blocks = []
    for r in results:
        cls = "p-due" if r["computed"] > 0.009 else "p-ok"
        if r["filing_row"] is None:
            cls = "p-none"

        rows = "".join(
            f"<tr class='{'unk' if not t['known'] else ''}'>"
            f"<td><b>{t['code']}</b></td>"
            f"<td>{t['date'] or '&mdash;'}</td>"
            f"<td>{t['desc']}</td>"
            f"<td class='n'>{fmt(t['amount']) if t['amount'] is not None else '&mdash;'}</td>"
            f"<td class='src'>{t['line']}</td></tr>"
            for t in r["transactions"])

        stated = (f"<tr><td colspan='3'>Stated on the transcript</td>"
                  f"<td class='n'>{fmt(r['stated'])}</td><td></td></tr>"
                  if r["stated"] is not None else "")

        blocks.append(f"""<div class="card">
<div><span class="yr">{r['year']}</span>
<span class="pill {cls}">{r['payment_status']}</span>
<span class="pill {'p-ok' if r['filing_row'] else 'p-none'}">{r['filing_status']}</span></div>
<div class="basis">{r['filing_basis']}</div>
<table><tr><th>TC</th><th>Date</th><th>Meaning</th><th class="n">Amount</th>
<th>Line</th></tr>
{rows}
<tr><td colspan="3"><b>Computed by this engine</b></td>
<td class="n"><b>{fmt(r['computed'])}</b></td><td></td></tr>
{stated}
</table></div>""")

    f_html = "".join(
        f"<div class='f {k}'><span class='tag'>{TAGS[k]}</span>{t}</div>"
        for k, t in findings(results, meta)) or \
        "<div class='foot'>No findings.</div>"

    html = f"""<!DOCTYPE html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>Compliance check</title><style>{CSS}</style></head><body><div class="w">

<div class="k">Compliance check &middot; account transcript</div>
<h1>{meta.get('label','Account')}</h1>
<p class="sub">Transcript pulled {meta.get('pulled','date not stated')}.
Read {'as text' if meta.get('text_layer') else 'by character recognition'}.
Every claim below cites the line that establishes it.</p>

<div class="card"><div class="k">What the transcript shows</div>{f_html}</div>

{''.join(blocks)}

<div class="card"><p class="foot">
Every figure traces to a transcript line printed beside it. A figure this
engine computed is labelled computed. Where the transcript states a balance,
both appear and any difference is reported rather than reconciled.
<br><br>
Lines carrying a code this engine does not recognize are shaded and listed in
place. None are dropped.
<br><br>
This is a reading of the transcript. It is not advice on what to do about what
it shows.
</p></div>

</div></body></html>"""
    Path(out_path).write_text(html, encoding="utf-8")


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    data = json.loads(Path(sys.argv[1]).read_text())
    meta = {"label": data.get("taxpayer_label", "Account"),
            **data.get("source", {})}
    results = [evaluate_period(p) for p in data.get("periods", [])]
    render(results, meta, sys.argv[2])

    print(f"Written: {sys.argv[2]}")
    for r in results:
        unrec = f", {len(r['unrecognized'])} unrecognized" if r["unrecognized"] else ""
        disc = f", DISCREPANCY {fmt(abs(r['discrepancy']))}" if r["discrepancy"] else ""
        print(f"  {r['year']}  {r['filing_status']:38}  "
              f"{fmt(r['computed']):>12}{unrec}{disc}")


if __name__ == "__main__":
    main()

---
name: crlaw-compliance-check
description: Read an IRS account transcript and report filing and payment status for each year, citing the transcript line behind every claim. Use whenever the question is what the Service's own record shows — "run the compliance check", "is he filed", "what does the transcript say", "which years are unfiled", "what is the balance by year", "check filing compliance before we file the offer", "decode this transcript", "what are these transaction codes", or when transcripts arrive and need to mean something. Produces the filing and payment picture that the resolution path skill takes as input.
---

# Compliance check

Reads an account transcript. Reports, for every year, whether a return posted,
what the balance is, and what the Service has done to the account. Every claim
carries the transcript line that establishes it.

---

## Run it

```
python3 scripts/read_transcript.py transcript.html periods.json "label"
python3 scripts/evaluate.py       periods.json     report.html
```

```
scripts/read_transcript.py  reads the transcript
scripts/codes.py            the transaction code vocabulary
scripts/evaluate.py         the engine
reference/contract.md       what passes between them
```

**Use the download, not the print.** In e-Services the download comes as HTML
and carries real text throughout. The print-to-PDF route saves the
TRANSACTIONS page as drawings of its letters, which looks right on paper and
holds nothing a parser can read. The reader detects that, names the page, and
stops rather than guessing.

---

## The continuation line

A line that does not open with a three digit code belongs to the transaction
above it, and what it carries depends on that code.

| Under | It carries |
|---|---|
| 150 | the document locator number |
| 610, 660, 670 | an indicator |
| 166, 170 and other penalty codes | a date |
| 971 | the notice, for example CP 0014 |

Each one is typed, attached to its parent, and printed in the parent's line. A
continuation is never read as a transaction of its own and never dropped.

**The date is the one to watch.** Where it falls exactly ten years from the
assessment it sits under, the report flags it as having the shape of a
collection statute date stated by the Service, and says to confirm it before
treating it as controlling. The engine never computes with it.

---

## Three rules, and they are the firm's

**Nothing is dropped silently.** A transaction code the table does not know is
shaded, named unrecognized, and printed with its line. It is never discarded to
make the output read cleanly. The table grows when a meaning is confirmed, not
when a parser guesses one.

**Every claim cites its line.** The raw transcript text sits beside every
figure. A number without its line cannot be checked, and a number that cannot
be checked does not belong in the file.

**Computed is not stated.** Where the transcript prints a balance, the engine
computes its own from the lines and shows both. A difference is reported as a
finding and neither figure wins. That gap is often the whole matter.

---

## What it will not say

A missing TC 150 is reported as **no return posting on this transcript**, not
as a return that was never filed. Those are different claims and the transcript
only supports the first.

Statute-affecting codes are flagged and never computed with. A suspension has a
start and an end, the end is frequently on another line or in another year, and
the arithmetic belongs to the attorney with the register in front of him.

TC 971 is reported as present with a note that the action code carries the
meaning and is not on that line.

The report reads the transcript. It does not advise on what to do about what it
shows.

# The contract

The engine is written. The reader is not. This file fixes what passes between
them, so the reader can be written in one sitting once the transcript format is
confirmed, and nothing in `evaluate.py` has to move.

## What the reader must produce

```json
{
  "taxpayer_label": "never a client name in a shared file",
  "source": {
    "kind": "account_transcript",
    "pulled": "2026-09-17",
    "text_layer": true
  },
  "periods": [
    {
      "year": 2018,
      "form": "1040",
      "stated_balance": 14820.55,
      "transactions": [
        {
          "code": "150",
          "date": "2019-05-20",
          "amount": 21440.00,
          "line": "150  Tax return filed  05-20-2019  $21,440.00"
        }
      ]
    }
  ]
}
```

## Field by field

**`line` is not optional and is not decoration.** It is the raw transcript text
the transaction was read from, and it is printed beside every claim in the
report. A transaction without its line cannot be cited, and an uncited figure
does not belong in this firm's work. The reader preserves the line verbatim,
including spacing, and never cleans it up.

**`amount` carries the sign the transcript shows.** Credits are negative on the
page and stay negative here. The engine takes magnitudes and classifies by
transaction code, so a sign error will not corrupt the total, but it will make
the printed line disagree with the figure beside it and that is worse.

**`amount` is `null` when the line carries no figure.** A TC 530 has no amount.
Null and zero are different claims, and zero would be a fabricated one.

**`stated_balance` is the balance the transcript itself prints**, where it
prints one. Omit it when the transcript does not. Do not compute it. The engine
computes independently and reports any disagreement, and that comparison is
the point.

**`text_layer` is `false` when the page was read by character recognition.**
The report then carries a standing caution on every figure. This flag is not
cosmetic. Setting it true on an OCR read would put unearned confidence on the
page.

## What the reader must never do

**Never skip a line it cannot parse.** An unreadable line is reported with
whatever was recovered and an unrecognized code, so it reaches the attorney.
A transcript line that vanishes between the page and the report is the failure
this whole engine exists to prevent.

**Never infer a transaction that is not printed.** If a payment seems to be
missing, that is a finding for the attorney and not a line for the reader to
add.

**Never normalize a code it does not recognize.** TC 889 stays 889. The engine
shades it, names it unrecognized, and prints its line. The table in `codes.py`
grows when Charles confirms a meaning, not when a parser guesses one.

## Still to confirm against a real file

1. Whether the e-Services print-to-PDF carries a text layer or is a raster.
   The audit PDF received September 14 was a raster with no embedded fonts, and
   if transcripts are saved the same way the reader is an OCR problem rather
   than a parsing one.
2. Column positions, and whether they hold across years.
3. Whether the transcript prints a balance, and where.
4. How TC 971 action codes appear, since the code alone carries no meaning.
5. Whether the pull is per year or multi-year in one file.

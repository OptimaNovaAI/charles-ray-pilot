# Transcripts the Reader Takes

| Source | File | How it is read |
|---|---|---|
| Word Transcribe | .docx after Add all to document | A label line with the time and the speaker, in either order, then the words. A paragraph under a label keeps that speaker. |
| Teams | .vtt | Each cue's start time, the `<v Speaker>` voice tag or "Speaker: words", and the words. A speaker's back to back cues join. |
| Azure speech to text, batch | .json with `recognizedPhrases` | `offsetInTicks` or `offset`, `speaker`, and the first `nBest` display text. |
| Azure fast transcription | .json with `phrases` | `offsetMilliseconds`, `speaker`, and `text`. |
| Plain text | .txt or .md | "Speaker: words", "Speaker (0:45): words", "[0:45] Speaker: words", or plain lines, each its own segment. |

A file the reader cannot split reads as zero segments and says so. Nothing is
filled in.

## Today and Later

- **Today.** Elevate emails the MP3. Word's Transcribe turns it into a .docx in
  a few minutes, inside his Microsoft 365. 300 minutes of uploaded audio a
  month, hold time included.
- **Later.** Washington Works routes the recordings to the automation inbox,
  and the transcription service he picks writes the transcript to the matter
  folder on its own. The reader takes it as it comes.

## What Is Spotted

| Spotted | Pattern |
|---|---|
| ID number | Digits after badge, ID, identification, or employee, and any ten digit number |
| Reference | Digits after reference, confirmation, case, ticket, or tracking |
| Phone | 3, 3, and 4 digit groups, and toll free numbers |
| Amount | A dollar sign, or a number followed by dollars |
| Notice | CP and LT numbers, Letter and Form numbers, 433-A and 433-F, 668 |
| Date | Month and day with or without a year, the 13th of October, 10/13, 2026-10-13 |
| Tax year | 1990 to 2039 standing alone |

A number spoken as words ("one zero zero zero") is not spotted. Word usually
writes digits, and the recording settles any doubt.

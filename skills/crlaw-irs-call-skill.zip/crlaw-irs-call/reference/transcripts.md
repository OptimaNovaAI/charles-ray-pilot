# Transcripts the Reader Takes

| Source | File | How it is read |
|---|---|---|
| Word Transcribe | .docx after Add all to document | A label line with the time and the speaker, in either order, then the words. A paragraph under a label keeps that speaker. |
| Teams | .vtt | Each cue's start time, the `<v Speaker>` voice tag or "Speaker: words", and the words. A speaker's back to back cues join. |
| Azure speech to text, batch | .json with `recognizedPhrases` | `offsetInTicks` or `offset`, `speaker` (and `channel` on a stereo file), and the first `nBest` display text. Phrases that failed recognition are skipped. |
| Azure fast transcription | .json with `phrases` | `offsetMilliseconds`, `speaker`, and `text`. |
| Plain text | .txt or .md | "Speaker: words", "Speaker (0:45): words", "[0:45] Speaker: words", or plain lines, each its own segment. |

A file the reader cannot split reads as zero segments and says so. Nothing is
filled in.

## Where Transcripts Come From

- **Automatic.** Elevate records his extension, his assistant's, and the main
  number and emails each MP3 to svc-automation@. Washington Works' Logic App
  sends it to Azure speech to text in the firm's own Azure, and the transcript
  comes back to svc-automation@. The intake flow files it in OneDrive, Claude
  AI Reports, Call Transcripts:

  | File | What it is |
  |---|---|
  | `<date> <time> <caller's number>.json` | Azure's transcript, as delivered. The reader prefers it. |
  | `<date> <time> <caller's number>.txt` | The plain-text copy, when sent. |
  | `<date> <time> <caller's number> call.txt` | The call details from the email: caller, line called, start, duration. |

  Audio and working files in Azure are deleted after 30 days. The transcript
  stays where it was filed.
- **By hand.** Word's Transcribe turns the Elevate MP3 into a .docx in a few
  minutes, inside his Microsoft 365. 300 minutes of uploaded audio a month,
  hold time included. Use it when a call is not in the folder.

## Who Is Who

Transcripts number the speakers. Azure labels them `Speaker 1`, `Speaker 2`,
and a stereo file adds the channel: `Channel 0 Speaker 1`. The reader keeps
every label as given and proposes a role for each from what that speaker says:

| Role | What marks it |
|---|---|
| IRS employee | Gives an ID or badge number, says they are with the IRS, takes the call |
| Charles's side | Gives a CAF number, speaks to the power of attorney, names the firm or Charles Ray, speaks for the client |
| Automated recording | Menu prompts, wait times, recorded greetings |

The role with the most marks wins, and a person's marks outrank the
recording's on the same label: on a stereo file the IRS side of the line
carries the menu before the employee picks up. A tie, or nothing said, reads
unclear.
Every role is inferred, cites its segments, and shows on the note that way.

## What Is Spotted

| Spotted | Pattern |
|---|---|
| ID number | Digits after badge, ID, identification, or employee, and any ten digit number |
| Reference | Digits after reference, confirmation, case, ticket, or tracking |
| Phone | 3, 3, and 4 digit groups, and toll free numbers |
| Amount | A dollar sign, or a number followed by dollars |
| Notice | CP and LT numbers, Letter and Form numbers, 433-A and 433-F, 668 |
| Date | Month and day with or without a year, the 13th of October, 10/13, 2026-10-13 |
| Tax year | 1990 to 2039 standing alone |

A number spoken as words ("one zero zero zero") is not spotted. Word usually
writes digits, and the recording settles any doubt.

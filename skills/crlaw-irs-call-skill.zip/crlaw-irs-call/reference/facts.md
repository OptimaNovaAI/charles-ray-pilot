# Writing the Facts

`facts.json` holds the call block and the facts. One fact per thing said. A
segment that holds two facts, a balance and a year, is two facts citing the same
segment.

```json
{
  "call": {"date": "2026-10-13", "matter": "M-0917", "line": "Practitioner Priority Service",
           "date_source": "Elevate recording email, Oct 13 2:14 PM"},
  "facts": [
    {"kind": "employee_id", "value": "1000234567", "seg": [2], "quote": "my ID number is 1000234567"},
    {"kind": "commitment", "value": "Fax the 433-F to ACS", "who": "Charles", "due": "2026-11-13",
     "seg": [7], "quote": "fax the 433-F to 855-555-0142 by November 13"}
  ]
}
```

## The Call Block

| Field | Rule |
|---|---|
| `date` | The day of the call, `YYYY-MM-DD`. From the Elevate email or the file name, and say which in `date_source`. |
| `matter` | The matter number. Never the client's name. |
| `line` | The IRS line called, when known before the transcript says it. |

## Every Fact

| Field | Rule |
|---|---|
| `kind` | One of the kinds below. |
| `value` | The fact in a few words, in the call's terms. |
| `seg` | The segment number or numbers from `transcript.json`. |
| `quote` | Copied from the cited segment, word for word. A short phrase is enough. Any number in `value` must appear in the quote. |

## Kinds

| Kind | Use for |
|---|---|
| `line` | The IRS line or program: PPS, ACS, a revenue officer, Appeals, a state agency |
| `irs_employee` | The name the employee gave, as the transcript has it |
| `employee_id` | The ID or badge number, digits as said |
| `unit` | The unit or office: ACS, a campus, a field office |
| `account_status` | What the IRS said about the account: balances, status, holds, liens, levies, filing gaps |
| `request` | What Charles asked for |
| `action` | What the IRS did on the call |
| `commitment` | Who will do what. Add `who` (Charles, the IRS, the client) and `due` (`YYYY-MM-DD`) when a date was said |
| `date` | A date said on the call. `value` is `YYYY-MM-DD`, `as_said` is the words, which must be in the quote |
| `amount` | A dollar amount, as said |
| `notice` | A notice, letter, or form named on the call |
| `years` | The tax years discussed |
| `reference` | A reference or confirmation number |
| `callback` | A callback or fax number given |
| `other` | Anything else worth the file. Still cited |

## Commitments

`status` is `open` until a later call or record shows it done; then `done`.
"By the 13th" is the 13th of the month the call names. "In 30 days" is a
`due` only when the IRS states the date; otherwise keep the words in `value`
and leave `due` out.

## Heard and Not Recorded

The reader spots every ID number, date, amount, notice, tax year, phone
number, and reference number. Each one that no fact accounts for is listed on
the note. Most belong in a fact. One that does not, such as the IRS reading back
a number Charles gave, stays listed so the choice is visible.

## Words Never Written

The engine refuses to write the note if its own text contains should,
recommend, advisable, or we suggest. Words quoted from the call are the call's
and pass.

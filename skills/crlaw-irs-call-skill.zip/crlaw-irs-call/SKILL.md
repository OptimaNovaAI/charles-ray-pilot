---
name: crlaw-irs-call
description: IRS call companion and client summary for the Law Offices of Charles A. Ray, P.C. Use whenever Charles has finished a call with the IRS or a state taxing agency and wants it in the file, including "write up my IRS call", "I just got off with PPS", "file note for the ACS call", "who did I talk to at the IRS", "what was the badge number", "log this call", "summarize the call for the client", "draft the client update from today's call", or when a transcript or an Elevate recording of a call lands, including "what calls came in today", "find my 2:15 call", or "write up the call transcript that just came in". It reads the transcript, records who he spoke with, the employee ID, what the IRS said and did, who owes what by when, and every date, amount, and reference number, each tied to the line of the transcript it came from. It keeps the matter's call log and drafts the client email for his review. It never sends anything.
---

# IRS call companion

Items 10 and 11. After every call with the IRS, the file needs the same things:
who he spoke with and their ID number, the unit, what the Service said about
the account, what was done, what each side owes and by when, and the reference
number. This skill takes them off the transcript, checks each one against the
line it came from, writes the call note, adds the call to the log, and drafts
the client update for Charles to review.

Three rules, and they are the firm's:

- **Every fact cites its transcript segment** and carries a quote from it. The
  engine checks the quote word for word, and a number in a fact must be in its
  quote. A fact that fails is refused and listed.
- **Nothing heard is dropped.** Every ID number, date, amount, notice, tax year,
  phone number, and reference number in the transcript is either in a fact or
  listed as heard and not recorded.
- **It reports.** The note says what was said. The client draft says what
  happened and what comes next. Advice is his to add.

---

## Run It

**1. Find the transcript.** Every recorded call on the firm's lines is
transcribed on its own in the firm's Azure, and the intake flow files it in
OneDrive, Claude AI Reports, **Call Transcripts**, named by the call's date,
time, and the caller's number, with the call details beside it.

```
python3 scripts/find_calls.py --date 2026-10-22
```

It lists the day's calls, newest first: when each started, who called, the line
called, the duration, the transcript file, and how often IRS words came up.
Pick the call he means by its time or number. If he names none, show him the
list and ask which. A call with no IRS words is still a call; a note is
written only for the call he picks. `--latest` gives the newest call alone.

If the call is not in the folder yet, or the automatic path is not running, the
transcript comes from Word, which is part of his Microsoft 365:

1. Open a new Word document. Home, then Dictate, then **Transcribe**.
2. **Upload audio** and pick the MP3 from the Elevate email.
3. When it finishes, **Add all to document**, with speakers and timestamps.
4. Save it in the matter folder as `<date> <matter> <line>.docx`, for example
   `2026-10-13 M-0917 PPS.docx`. No client name in the file name.

Word transcribes 300 minutes of uploaded audio a month on Microsoft 365, hold
time included. A Teams transcript (.vtt), an Azure transcript (.json), or a
plain text transcript reads the same way. See `reference/transcripts.md`.

**2. Read it.**

```
python3 scripts/read_transcript.py "<transcript file>" transcript.json
```

It numbers every segment with its speaker and time and spots every number,
date, amount, and notice. It interprets nothing. It also proposes who each
numbered speaker is (the IRS employee, Charles's side, an automated recording)
from what they say, with the segments that show it, and marks each role
inferred. When the call details sit beside the transcript, it picks them up:
start time, caller's number, line called, duration.

Check the roles before writing facts. If a role reads unclear or wrong, say so
when you hand him the note; never relabel a speaker in the transcript.

**3. Write the facts.** Read `transcript.json` and write `facts.json` following
`reference/facts.md`: the call block (date and matter), then one fact per thing
said, each with its segment and a quote.

**4. Run the engine.**

```
python3 scripts/call_note.py --transcript transcript.json --facts facts.json \
    --log "C:/Users/<you>/OneDrive/IRS Call Log.csv" \
    --out "2026-10-13 M-0917 Call Note.html" --summary summary_facts.json
```

It prints how many facts were kept and refused and what was heard and not
recorded. Fix every refused fact and record or deliberately leave each item
heard, then run it again. Save the note in the matter folder. The log holds one
row per call, keyed on date, matter, and transcript, so a rerun replaces the row.

**5. Draft the client update (item 11).** Only when Charles asks for it. Write
the email from `summary_facts.json` alone:

- What the call was, the date, and what the IRS said about the account.
- What was done on the call.
- What happens next and who owes it, with the dates said.
- Plain words, short, no advice, no IRS employee ID unless he asks for it.

Save the body as `draft.txt` and check it:

```
python3 scripts/check_summary.py --facts summary_facts.json --draft draft.txt
```

Every date, dollar amount, tax year, and long number in the draft must be in the
verified note, and the advice words are flagged. Fix and check again until it
passes. Then create the draft in Outlook with the Microsoft 365 connector, to
the client's address from his matter list, and end it with his firm signature
block exactly as his standing instruction gives it. If he will insert his
Outlook signature himself, leave the block off. Never send. He reviews it, adds
his advice, and sends it himself.

**6. Hand him the note.** Say who he spoke with, what was done, what he owes and
by when, and anything heard and not recorded.

---

## The Note

| Section | What it shows |
|---|---|
| The call | Date, matter, IRS line, employee, employee ID, unit, each with its segment, and the call details from the email when filed |
| Who was on the call | Each numbered speaker and the role read from what they said, marked inferred |
| What the IRS said | The account as the Service described it |
| What was done | What he asked for and what the IRS did |
| Who owes what | Each commitment, who owes it, and the date said. Past due is marked |
| Dates, amounts, and notices | Each with the words as said |
| References | Reference and callback numbers |
| Heard, not recorded | Every spotted number, date, amount, or notice no fact accounts for |
| Facts refused | Every fact that failed the check, with the reason |

A transcript is machine made. A name or a number misheard by the transcription
is misheard in the note too, so the recording stays the record. The note says
so at the foot.

---

## What It Will Not Do

- Send the client email. It drafts. He sends.
- Add advice to the client draft. That is his.
- Fill in a name, an ID, or a date the transcript does not carry.
- Put a client name in a file name or in the call log. Both key on the matter
  number.

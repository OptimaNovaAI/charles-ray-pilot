#!/usr/bin/env python3
"""
IRS call transcript reader for the Law Offices of Charles A. Ray, P.C.

    python3 read_transcript.py "2026-10-13 M-0917 PPS.docx" transcript.json

Items 10 and 11. Reads a call transcript and splits it into numbered segments,
each with its speaker and time where the transcript gives them. It needs
nothing installed. It reads:

    .docx   Word's Transcribe, after "Add all to document", or any Word file
    .vtt    a Teams transcript
    .json   Azure speech to text, batch or fast transcription
    .txt    one line per turn, "Speaker: words", or plain lines

It interprets nothing. It also spots, word for word, every ID number, date,
dollar amount, notice, tax year, and phone number in the transcript, so the
call note can show which were recorded and which were heard and not recorded.
Nothing heard is dropped.
"""

import json
import re
import sys
import zipfile
from datetime import datetime
from pathlib import Path

W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
TS = r"(?:\d{1,2}:)?\d{1,2}:\d{2}(?:[.,]\d{1,3})?"
SPEAKER = r"[A-Z][\w.'\-]*(?: [A-Z0-9][\w.'\-]*){0,3}"
LABEL_LINE = [
    re.compile(rf"^(?P<sp>{SPEAKER})\s+(?P<t>{TS})$"),
    re.compile(rf"^(?P<t>{TS})\s+(?P<sp>{SPEAKER})$"),
    re.compile(rf"^(?P<t>{TS})$"),
]
INLINE = [
    re.compile(rf"^(?P<sp>{SPEAKER})\s*\((?P<t>{TS})\)\s*:\s*(?P<x>.+)$"),
    re.compile(rf"^\[?(?P<t>{TS})\]?\s+(?P<sp>{SPEAKER})\s*:\s*(?P<x>.+)$"),
    re.compile(rf"^(?P<sp>{SPEAKER})\s*:\s*(?P<x>.+)$"),
]
MONTHS = ("january february march april may june july august september "
          "october november december").split()
MON = r"(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\.?"


def seconds(t):
    if not t:
        return None
    t = t.replace(",", ".")
    parts = [float(p) for p in t.split(":")]
    s = 0.0
    for p in parts:
        s = s * 60 + p
    return round(s, 2)


def clock(s):
    if s is None:
        return ""
    s = int(s)
    return f"{s // 3600}:{s % 3600 // 60:02d}:{s % 60:02d}" if s >= 3600 else f"{s // 60}:{s % 60:02d}"


# ------------------------------------------------------------------ readers

def lines_docx(path):
    import xml.etree.ElementTree as ET
    with zipfile.ZipFile(path) as z:
        root = ET.fromstring(z.read("word/document.xml"))
    out = []
    for p in root.iter(W + "p"):
        parts = []
        for node in p.iter():
            if node.tag == W + "t" and node.text:
                parts.append(node.text)
            elif node.tag == W + "tab":
                parts.append(" ")
            elif node.tag in (W + "br", W + "cr"):
                parts.append("\n")
        for ln in "".join(parts).split("\n"):
            out.append(ln)
    return out


def from_lines(lines):
    """Word Transcribe, plain text, or any label-then-words layout.

    A label line (a speaker and a time, or a time alone) starts a segment and
    the words under it fill it. "Speaker: words" is a segment on one line. A
    plain line with no label is its own segment, under the speaker of the label
    above it when there is one."""
    segs, cur = [], None
    for raw in lines:
        ln = " ".join(raw.split())
        if not ln:
            continue
        hit = next((m for m in (rx.match(ln) for rx in LABEL_LINE) if m), None)
        if hit:
            cur = {"t": seconds(hit.groupdict().get("t")), "speaker": (hit.groupdict().get("sp") or "").strip(),
                   "text": "", "label": True}
            segs.append(cur)
            continue
        hit = next((m for m in (rx.match(ln) for rx in INLINE) if m), None)
        if hit and hit.group("sp") not in ("Re", "Note", "Subject", "Date", "Time", "Matter", "Client"):
            cur = {"t": seconds(hit.groupdict().get("t")), "speaker": hit.group("sp").strip(),
                   "text": hit.group("x").strip(), "label": False}
            segs.append(cur)
            continue
        if cur is not None and cur["label"] and not cur["text"]:
            cur["text"] = ln
            continue
        cur = {"t": None, "speaker": cur["speaker"] if cur is not None and cur["label"] else "",
               "text": ln, "label": cur["label"] if cur is not None else False}
        segs.append(cur)
    for x in segs:
        x.pop("label", None)
    return [x for x in segs if x["text"]]


def from_vtt(text):
    segs, cur_t = [], None
    for block in re.split(r"\n\s*\n", text.replace("\r", "")):
        lines = [l for l in block.split("\n") if l.strip()]
        if not lines or lines[0].startswith("WEBVTT") or lines[0].startswith("NOTE"):
            continue
        timing = next((l for l in lines if "-->" in l), None)
        if not timing:
            continue
        cur_t = seconds(timing.split("-->")[0].strip())
        body = " ".join(lines[lines.index(timing) + 1:])
        sp = ""
        m = re.match(r"^<v\s+([^>]+)>(.*?)(?:</v>)?$", body)
        if m:
            sp, body = m.group(1).strip(), m.group(2)
        else:
            m = re.match(rf"^({SPEAKER})\s*:\s*(.+)$", body)
            if m:
                sp, body = m.group(1), m.group(2)
        body = re.sub(r"<[^>]+>", "", body).strip()
        if not body:
            continue
        if segs and segs[-1]["speaker"] == sp and sp:
            segs[-1]["text"] += " " + body
        else:
            segs.append({"t": cur_t, "speaker": sp, "text": body})
    return segs


def iso_seconds(v):
    if isinstance(v, (int, float)):
        return float(v)
    m = re.match(r"^PT(?:(\d+)H)?(?:(\d+)M)?(?:([\d.]+)S)?$", str(v or ""))
    if not m:
        return None
    h, mi, s = m.groups()
    return int(h or 0) * 3600 + int(mi or 0) * 60 + float(s or 0)


def from_azure(doc):
    segs = []
    if "recognizedPhrases" in doc:
        for p in doc["recognizedPhrases"]:
            best = (p.get("nBest") or [{}])[0]
            text = best.get("display") or best.get("lexical") or ""
            t = (p["offsetInTicks"] / 1e7) if "offsetInTicks" in p else iso_seconds(p.get("offset"))
            segs.append({"t": round(t, 2) if t is not None else None,
                         "speaker": f"Speaker {p['speaker']}" if "speaker" in p else "", "text": text})
    elif "phrases" in doc:
        for p in doc["phrases"]:
            t = p.get("offsetMilliseconds")
            segs.append({"t": round(t / 1000, 2) if t is not None else None,
                         "speaker": f"Speaker {p['speaker']}" if "speaker" in p else "", "text": p.get("text", "")})
    else:
        raise SystemExit("This JSON is not an Azure transcript: no recognizedPhrases or phrases.")
    segs.sort(key=lambda s: (s["t"] is None, s["t"] or 0))
    merged = []
    for s in segs:
        if merged and s["speaker"] and merged[-1]["speaker"] == s["speaker"]:
            merged[-1]["text"] += " " + s["text"]
        else:
            merged.append(s)
    return [s for s in merged if s["text"].strip()]


# ------------------------------------------------------------------ spotting

SPOT = {
    "id": [re.compile(r"(?:badge|i\.?d\.?|identification|employee|id number|number is)\D{0,25}?((?:\d[\s\-]?){5,11}\d)", re.I),
           re.compile(r"(?<![\d$,.])(\d{10})(?![\d,])")],
    "reference": [re.compile(r"(?:reference|confirmation|case|ticket|tracking)\s+(?:number|no\.?|#)?\D{0,30}?([A-Z0-9]*\d[A-Z0-9\-]{3,})", re.I)],
    "phone": [re.compile(r"(?<![\d$])(\(?\d{3}\)?[\s.\-]\d{3}[\s.\-]\d{4})(?!\d)"),
              re.compile(r"(?<![\d$])(1[\s.\-]?8\d{2}[\s.\-]\d{3}[\s.\-]\d{4})(?!\d)")],
    "amount": [re.compile(r"(\$\s?\d[\d,]*(?:\.\d{2})?)"),
               re.compile(r"(\d[\d,]*(?:\.\d{2})?\s+dollars)", re.I)],
    "notice": [re.compile(r"\b(CP\s?\d{2,4}[A-Z]?|LT\s?\d{1,4}[A-Z]?|Letter\s\d{3,4}[A-Z]?|Form\s\d{3,4}(?:-[A-Z]+)?|"
                          r"\d{3}-[A-F]\b|668\s?\(?[A-Z]\)?)", re.I)],
    "date": [re.compile(rf"\b({MON}\s+\d{{1,2}}(?:st|nd|rd|th)?(?:,?\s+\d{{4}})?)\b", re.I),
             re.compile(rf"\b(\d{{1,2}}(?:st|nd|rd|th)?\s+of\s+{MON}(?:,?\s+\d{{4}})?)\b", re.I),
             re.compile(r"(?<![\d/])(\d{1,2}/\d{1,2}(?:/\d{2,4})?)(?![\d/])"),
             re.compile(r"\b(\d{4}-\d{2}-\d{2})\b")],
    "year": [re.compile(r"(?<![\d$,.\-/])((?:19[9]\d|20[0-3]\d))(?![\d,])")],
}


def spot(segs):
    found = {k: [] for k in SPOT}
    for s in segs:
        taken = []
        for kind in ("reference", "phone", "id", "amount", "notice", "date", "year"):
            for rx in SPOT[kind]:
                for m in rx.finditer(s["text"]):
                    a, b = m.span(1)
                    if any(a < y and b > x for x, y in taken):
                        continue
                    if kind == "date" and not re.search(r"[a-z]", m.group(1), re.I):
                        mo, dy = m.group(1).split("/")[:2]
                        if not (1 <= int(mo) <= 12 and 1 <= int(dy) <= 31):
                            continue
                    taken.append((a, b))
                    found[kind].append({"seg": s["n"], "text": m.group(1).strip()})
    return found


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    src, out = Path(sys.argv[1]), Path(sys.argv[2])
    ext = src.suffix.lower()
    if ext == ".docx":
        segs, fmt = from_lines(lines_docx(src)), "Word"
    elif ext == ".vtt":
        segs, fmt = from_vtt(src.read_text(encoding="utf-8-sig")), "Teams (VTT)"
    elif ext == ".json":
        segs, fmt = from_azure(json.loads(src.read_text(encoding="utf-8-sig"))), "Azure speech to text"
    else:
        segs, fmt = from_lines(src.read_text(encoding="utf-8-sig").splitlines()), "Text"
    for i, s in enumerate(segs, 1):
        s.pop("open", None)
        s["n"] = i
        s["at"] = clock(s["t"])
    doc = {"transcript_file": src.name, "format": fmt, "read_on": datetime.now().strftime("%Y-%m-%d %H:%M"),
           "segments": segs, "spotted": spot(segs),
           "counts": {"segments": len(segs), "speakers": len({s["speaker"] for s in segs if s["speaker"]}),
                      "words": sum(len(s["text"].split()) for s in segs)}}
    out.write_text(json.dumps(doc, indent=1, ensure_ascii=False), encoding="utf-8")
    sp = doc["spotted"]
    print(f"Read {src.name} ({fmt}): {len(segs)} segment(s), {doc['counts']['speakers']} speaker(s), "
          f"{doc['counts']['words']} words")
    print("  spotted: " + ", ".join(f"{len(v)} {k}" for k, v in sp.items()))
    if not segs:
        print("  Note: no segments read. The file may be empty or in a layout this reader does not know.")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
Client summary check for the Law Offices of Charles A. Ray, P.C.

    python3 check_summary.py --facts summary_facts.json --draft draft.txt

Item 11. Claude drafts the client email from the verified call note only. This
file reads the draft and checks it before Charles sees it:

    Every date, dollar amount, tax year, and long number in the draft must be
    in the verified facts or be the call date. Anything else is listed.
    The draft carries what happened on the call and what comes next. Advice is
    Charles's to add, so should, recommend, advisable, and we suggest are
    listed.
    The IRS employee ID is listed if it appears, so Charles decides whether a
    client sees it.

It exits 0 when the draft is clean and 1 when anything is listed. The draft is
fixed and checked again until it passes. The signature block is not checked:
it is his, word for word.
"""

import argparse
import json
import re
import sys
from datetime import date
from pathlib import Path

MONTHS = {m: i for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}
ADVICE = ("should", "recommend", "advisable", "we suggest")
SIG_START = re.compile(r"^\s*(?:Charles A\. Ray, Jr\.|Law Offices of Charles A\. Ray)", re.M)


def digits(s):
    return re.sub(r"\D", "", str(s or ""))


def norm_amt(s):
    v = str(s).replace("$", "").replace(",", "").strip()
    return v.rstrip("0").rstrip(".") if "." in v else v


def strip_html(s):
    s = re.sub(r"<(br|/p|/div|/li)[^>]*>", "\n", s, flags=re.I)
    return re.sub(r"<[^>]+>", " ", s).replace("&nbsp;", " ").replace("&amp;", "&")


def body_only(text):
    m = SIG_START.search(text)
    return text[:m.start()] if m else text


def allowed_from(doc):
    call_d = date.fromisoformat(doc["call"]["date"])
    dates, amounts, years, numbers = {(call_d.month, call_d.day, call_d.year)}, set(), {call_d.year}, set()
    blob = []
    for f in doc["facts"]:
        v, q = str(f.get("value") or ""), str(f.get("quote") or "")
        blob += [v, q, str(f.get("as_said") or ""), str(f.get("due") or "")]
        for iso in (v if f.get("kind") == "date" else "", f.get("due") or ""):
            try:
                d0 = date.fromisoformat(str(iso))
                dates.add((d0.month, d0.day, d0.year))
                years.add(d0.year)
            except ValueError:
                pass
    text = " ".join(blob)
    for m in re.finditer(r"\$?\s?(\d[\d,]*(?:\.\d{2})?)", text):
        amounts.add(norm_amt(m.group(1)))
    for m in re.finditer(r"\b(19\d{2}|20\d{2})\b", text):
        years.add(int(m.group(1)))
    for m in re.finditer(r"\d[\d\s\-().]{4,}\d", text):
        numbers.add(digits(m.group(0)))
    numbers |= {digits(f.get("value")) for f in doc["facts"] if len(digits(f.get("value"))) >= 5}
    return dates, amounts, years, numbers


def found_in_draft(body):
    items = []
    spans = []
    for m in re.finditer(r"\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+(\d{1,2})(?:st|nd|rd|th)?(?:,?\s+(\d{4}))?",
                         body, re.I):
        items.append(("date", m.group(0), (MONTHS[m.group(1)[:3].lower()], int(m.group(2)),
                                           int(m.group(3)) if m.group(3) else None)))
        spans.append(m.span())
    for m in re.finditer(r"(?<![\d/])(\d{1,2})/(\d{1,2})(?:/(\d{2,4}))?(?![\d/])", body):
        y = m.group(3)
        y = (int(y) + 2000 if len(y) == 2 else int(y)) if y else None
        items.append(("date", m.group(0), (int(m.group(1)), int(m.group(2)), y)))
        spans.append(m.span())

    def free(a, b):
        return not any(a < y and b > x for x, y in spans)

    for m in re.finditer(r"\$\s?(\d[\d,]*(?:\.\d{2})?)", body):
        if free(*m.span()):
            items.append(("amount", m.group(0), m.group(1)))
            spans.append(m.span())
    for m in re.finditer(r"\d[\d\s\-().]{4,}\d", body):
        if free(*m.span()) and len(digits(m.group(0))) >= 5:
            items.append(("number", m.group(0).strip(), digits(m.group(0))))
            spans.append(m.span())
    for m in re.finditer(r"\b(19\d{2}|20\d{2})\b", body):
        if free(*m.span()):
            items.append(("year", m.group(0), int(m.group(1))))
    return items


def check(doc, draft):
    body = body_only(strip_html(draft) if "<" in draft else draft)
    dates, amounts, years, numbers = allowed_from(doc)
    problems = []
    for kind, shown, val in found_in_draft(body):
        ok = True
        if kind == "date":
            mo, dy, yr = val
            ok = any(mo == a and dy == b and (yr is None or yr == c) for a, b, c in dates)
        elif kind == "amount":
            ok = norm_amt(val) in amounts
        elif kind == "number":
            ok = any(val in n or n in val for n in numbers if len(n) >= 5)
        elif kind == "year":
            ok = val in years
        if not ok:
            problems.append(f"{kind} '{shown}' is not in the verified call note")
    low = " " + " ".join(body.lower().split()) + " "
    for w in ADVICE:
        if re.search(rf"\b{re.escape(w)}\b", low):
            problems.append(f"'{w}' is in the draft. Advice is Charles's to add")
    emp_ids = [digits(f["value"]) for f in doc["facts"] if f.get("kind") == "employee_id"]
    for d in emp_ids:
        if d and d in digits(body):
            problems.append("the IRS employee ID is in the draft. Charles decides whether a client sees it")
    return problems


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--facts", required=True)
    ap.add_argument("--draft", required=True)
    a = ap.parse_args()
    doc = json.loads(Path(a.facts).read_text(encoding="utf-8"))
    problems = check(doc, Path(a.draft).read_text(encoding="utf-8"))
    if problems:
        print(f"Not ready: {len(problems)} item(s)")
        for p in problems:
            print("  " + p)
        sys.exit(1)
    print("Ready for Charles: every date, amount, year, and number is in the verified call note.")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
Call transcript finder for the Law Offices of Charles A. Ray, P.C.

    python3 find_calls.py                      the calls in the folder, newest first
    python3 find_calls.py --date 2026-10-22    one day's calls
    python3 find_calls.py --latest             the newest call only
    python3 find_calls.py --folder "<path>"    a folder other than Call Transcripts
    python3 find_calls.py --json calls.json    the same list, for the next step

Items 10 and 11. Once the automatic transcription is live, every recorded call
on the firm's lines arrives as a transcript in svc-automation@, and the intake
flow files it in a Call Transcripts folder in his OneDrive, beside the clock
register:

    <date> <time> <caller's number>.json        Azure's transcript, as delivered
    <date> <time> <caller's number>.txt         the plain-text copy, when sent
    <date> <time> <caller's number> call.txt    the call details from the email

This lists them: when the call started, the caller's number, the line called,
the duration, the transcript to read, and how many times IRS words came up, so
an IRS call stands out from the rest of the day's calls. It reads; it changes
nothing. A call with no IRS words is still listed. Whether it gets a note is
his call.
"""

import argparse
import json
import os
import re
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from read_transcript import from_azure, from_lines, from_vtt, lines_docx, read_details  # noqa: E402

SEARCH_DIRS = [
    "~/OneDrive/Claude AI Reports/Call Transcripts",
    "~/OneDrive/ClaudeAIReports/Call Transcripts",
    "~/Claude AI Reports/Call Transcripts",
    "~/Documents/Claude AI Reports/Call Transcripts",
]
TRANSCRIPT_EXT = (".json", ".vtt", ".txt", ".docx", ".md")
PREFER = {".json": 0, ".vtt": 1, ".docx": 2, ".txt": 3, ".md": 4}
STEM_TIME = re.compile(r"^(\d{4}-\d{2}-\d{2})(?:[ _T](\d{1,2})[:.]?(\d{2}))?")
IRS_WORDS = re.compile(r"\binternal revenue\b|\bIRS\b|\bI\.R\.S\b|\bbadge\b|\bpractitioner priority\b|"
                       r"\bACS\b|\brevenue (?:officer|agent)\b|\bemployee ID\b|\bCAF\b|\bpower of attorney\b",
                       re.I)


def folders(given=None):
    if given:
        p = Path(os.path.expanduser(given))
        if not p.is_dir():
            raise SystemExit(f"No folder at {p}")
        return [p]
    out = [Path(os.path.expanduser(d)) for d in SEARCH_DIRS]
    home = Path(os.path.expanduser("~"))
    for od in home.glob("OneDrive*"):
        for sub in od.glob("*Claude*"):
            out.append(sub / "Call Transcripts")
    seen, real = set(), []
    for p in out:
        if p.is_dir() and p.resolve() not in seen:
            seen.add(p.resolve())
            real.append(p)
    return real


def is_details(p):
    n = p.name.lower()
    return n.endswith(" call.txt") or n.endswith(".call.txt") or n.endswith(".call.json") or n.endswith(" call.json")


def stem_of(p):
    n = p.name
    for tail in (" call.txt", ".call.txt", ".call.json", " call.json"):
        if n.lower().endswith(tail):
            return n[: -len(tail)]
    return p.stem


def segments(path):
    ext = path.suffix.lower()
    try:
        if ext == ".json":
            return from_azure(json.loads(path.read_text(encoding="utf-8-sig")))
        if ext == ".vtt":
            return from_vtt(path.read_text(encoding="utf-8-sig"))
        if ext == ".docx":
            return from_lines(lines_docx(path))
        return from_lines(path.read_text(encoding="utf-8-sig").splitlines())
    except (SystemExit, ValueError, KeyError, OSError):
        return None


def when(stem, details):
    m = STEM_TIME.match(stem)
    if m:
        d, h, mi = m.groups()
        return f"{d} {int(h):02d}:{mi}" if h else d
    return (details or {}).get("start") or ""


def calls_in(folder_list):
    groups = {}
    for f in folder_list:
        for p in f.iterdir():
            if not p.is_file():
                continue
            if is_details(p):
                groups.setdefault((f, stem_of(p)), {})["details"] = p
            elif p.suffix.lower() in TRANSCRIPT_EXT:
                groups.setdefault((f, p.stem), {}).setdefault("transcripts", []).append(p)
    out = []
    for (f, stem), g in groups.items():
        ts = sorted(g.get("transcripts", []), key=lambda q: PREFER.get(q.suffix.lower(), 9))
        details = read_details(g.get("details")) if g.get("details") else None
        best = ts[0] if ts else None
        segs = segments(best) if best else None
        text = " ".join(s["text"] for s in segs or [])
        out.append({
            "started": when(stem, details),
            "caller": (details or {}).get("caller", ""),
            "called": (details or {}).get("called", ""),
            "duration": (details or {}).get("duration", ""),
            "transcript": str(best) if best else "",
            "other_copies": [str(q) for q in ts[1:]],
            "details_file": str(g["details"]) if g.get("details") else "",
            "segments": len(segs) if segs is not None else None,
            "irs_words": len(IRS_WORDS.findall(text)),
            "folder": str(f),
            "modified": datetime.fromtimestamp(max(q.stat().st_mtime for q in ts or [g["details"]])).strftime(
                "%Y-%m-%d %H:%M"),
        })
    out.sort(key=lambda c: (c["started"] or c["modified"]), reverse=True)
    return out


def main():
    ap = argparse.ArgumentParser(description="List call transcripts, newest first.")
    ap.add_argument("--folder")
    ap.add_argument("--date", help="YYYY-MM-DD")
    ap.add_argument("--latest", action="store_true")
    ap.add_argument("--json")
    a = ap.parse_args()

    fl = folders(a.folder)
    if not fl:
        print("No Call Transcripts folder found. The intake flow files transcripts in OneDrive, "
              "Claude AI Reports, Call Transcripts. Give another with --folder.")
        sys.exit(1)
    calls = calls_in(fl)
    if a.date:
        calls = [c for c in calls if (c["started"] or c["modified"]).startswith(a.date)]
    if a.latest:
        calls = calls[:1]
    if a.json:
        Path(a.json).write_text(json.dumps(calls, indent=1), encoding="utf-8")
    if not calls:
        print("No calls found" + (f" for {a.date}" if a.date else "") + f" in {', '.join(map(str, fl))}.")
        return
    print(f"{len(calls)} call(s), newest first:")
    for c in calls:
        bits = [c["started"] or f"filed {c['modified']}"]
        bits += [x for x in (c["caller"] and f"from {c['caller']}", c["called"] and f"to {c['called']}",
                             c["duration"] and f"{c['duration']}") if x]
        if not c["transcript"]:
            bits.append("no transcript yet, details only")
        elif c["segments"] is None:
            bits.append("transcript could not be read")
        else:
            bits.append(f"{c['segments']} segments, IRS words {c['irs_words']}")
        print("  " + " | ".join(bits))
        if c["transcript"]:
            print(f"    {c['transcript']}")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
IRS call note for the Law Offices of Charles A. Ray, P.C.

    python3 call_note.py --transcript transcript.json --facts facts.json \
                         --log "IRS Call Log.csv" --out "IRS Call Note.html" \
                         --summary summary_facts.json

Item 10. read_transcript.py splits the transcript into numbered segments.
Claude reads them and writes facts.json: who Charles spoke with, the employee
ID, the unit, what the IRS said about the account, what was done, who owes
what by when, and every date, amount, notice, and reference number. This file
checks every fact against the segment it cites, writes the call note, adds the
call to the matter's call log, and hands the verified facts to item 11.

Three rules, and they are the firm's.
    Every fact cites its segment, and its quote must be found in that segment,
    word for word. A number in a fact must be in its quote. A fact that fails
    is refused and listed.
    Nothing heard is dropped. Every ID number, date, amount, notice, tax year,
    and phone number the reader spotted is either in a kept fact or listed as
    heard and not recorded.
    It reports. The note says what was said on the call. The judgment is the
    attorney's.

The log keys on matter number and holds no client name.
"""

import argparse
import csv
import html as H
import json
import re
from datetime import date
from pathlib import Path

KINDS = {
    "irs_employee": "IRS employee", "employee_id": "Employee ID", "unit": "Unit or office",
    "line": "IRS line", "account_status": "What the IRS said", "action": "What was done",
    "request": "What you asked for", "commitment": "Who owes what", "date": "Date",
    "amount": "Amount", "notice": "Notice or form", "years": "Tax years", "reference": "Reference number",
    "callback": "Callback number", "other": "Other",
}
NUMERIC = {"employee_id", "amount", "reference", "callback", "years"}
SECTIONS = [
    ("What the IRS Said", ("account_status",)),
    ("What Was Done", ("action", "request")),
    ("Who Owes What", ("commitment",)),
    ("Dates, Amounts, and Notices", ("date", "amount", "notice", "years")),
    ("References", ("reference", "callback")),
    ("Other", ("other",)),
]
LOG_COLUMNS = ["date", "matter", "line", "employee", "employee_id", "unit", "actions",
               "owed_open", "transcript", "note", "facts_kept", "facts_refused"]
WORDS_NEVER_PRINTED = (" should ", "recommend", "advisable", "we suggest")


def e(s):
    return H.escape(str(s if s is not None else ""), quote=False)


def nt(s):
    """Words from the call. Marked so the word check reads only the engine's."""
    return f'<span class="nt">{e(s)}</span>'


def squash(s):
    return " ".join(re.sub(r"[‘’]", "'", str(s or "")).lower().split())


def digits(s):
    return re.sub(r"\D", "", str(s or ""))


def refs(f):
    r = f.get("seg") or []
    return [int(x) for x in (r if isinstance(r, list) else [r])]


def check_facts(transcript, facts):
    segs = {s["n"]: s for s in transcript["segments"]}
    kept, refused = [], []
    for i, f in enumerate(facts, 1):
        probs = []
        if f.get("kind") not in KINDS:
            probs.append(f"kind '{f.get('kind')}' is not one of {', '.join(KINDS)}")
        if not str(f.get("value") or "").strip():
            probs.append("no value")
        rs = refs(f)
        if not rs:
            probs.append("no segment cited")
        texts = []
        for n in rs:
            if n not in segs:
                probs.append(f"no segment {n}")
            else:
                texts.append(segs[n]["text"])
        q = squash(f.get("quote"))
        if not q:
            probs.append("no quote")
        elif texts and q not in squash(" ".join(texts)):
            probs.append(f"the quote is not in segment(s) {', '.join(map(str, rs))}")
        if f.get("kind") in NUMERIC and q and digits(f.get("value")):
            if digits(f.get("value")) not in digits(f.get("quote")):
                probs.append(f"the number in '{f.get('value')}' is not in the quote")
        if f.get("kind") == "date":
            try:
                date.fromisoformat(str(f.get("value")))
            except ValueError:
                probs.append(f"date '{f.get('value')}' is not YYYY-MM-DD")
            if f.get("as_said") and squash(f["as_said"]) not in q:
                probs.append("the date as said is not in the quote")
        if f.get("due"):
            try:
                date.fromisoformat(str(f["due"]))
            except ValueError:
                probs.append(f"due '{f['due']}' is not YYYY-MM-DD")
        (refused if probs else kept).append((i, f, probs) if probs else f)
    return kept, refused


def covered(spotted, kept):
    """Which spotted items no kept fact accounts for."""
    out = []
    for kind, items in spotted.items():
        for it in items:
            d = digits(it["text"])
            hit = False
            for f in kept:
                if it["seg"] not in refs(f):
                    continue
                if squash(it["text"]) in squash(f.get("quote")) or squash(it["text"]) in squash(f.get("value")):
                    hit = True
                if d and len(d) >= 3 and (d in digits(f.get("value")) or d in digits(f.get("quote"))):
                    hit = True
                if hit:
                    break
            if not hit:
                out.append((kind, it))
    return out


CSS = """
body{margin:0;background:#f4f5f7;font-family:-apple-system,BlinkMacSystemFont,
"Segoe UI",Arial,sans-serif;color:#1b2a4a}
.w{max-width:900px;margin:0 auto;padding:28px 20px 70px}
.card{background:#fff;border:1px solid #e3e8ef;border-radius:12px;padding:22px 26px;margin-bottom:16px}
.k{font-size:11px;font-weight:600;letter-spacing:1.6px;text-transform:uppercase;color:#ca25b7;padding-bottom:10px}
h1{margin:0 0 6px;font-size:27px;font-weight:600;color:#0b1f3a;letter-spacing:-.5px}
.sub{color:#6a7488;font-size:14px;margin:0 0 18px;line-height:1.55}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:10px}
.cell{border:1px solid #e3e8ef;border-radius:10px;padding:10px 14px}
.cell b{display:block;font-size:15px;color:#000c65;word-break:break-word}
.cell>span{font-size:10.5px;letter-spacing:1.2px;text-transform:uppercase;color:#8a93a6;font-weight:600}
.row{font-size:14px;line-height:1.55;padding:8px 0;border-bottom:1px solid #f0f2f6}
.src{color:#8a93a6;font-size:11.5px;font-family:ui-monospace,Menlo,monospace}
.q{color:#4a5568;font-style:italic}
.tag{display:inline-block;font-size:10.5px;font-weight:600;letter-spacing:.8px;text-transform:uppercase;
border:1px solid #e3e8ef;border-radius:999px;padding:1px 8px;color:#6a7488;margin-right:6px}
.late{color:#b4483a;font-weight:600}
.foot{color:#8a93a6;font-size:12.5px;line-height:1.65;margin:0}
@media(max-width:600px){.card{padding:18px 16px}}
"""


def seg_ref(transcript, f):
    segs = {s["n"]: s for s in transcript["segments"]}
    parts = []
    for n in refs(f):
        s = segs.get(n, {})
        parts.append(f"seg {n}" + (f" at {s['at']}" if s.get("at") else "") +
                     (f", {s['speaker']}" if s.get("speaker") else ""))
    return "; ".join(parts)


def first(kept, kind):
    return next((f for f in kept if f["kind"] == kind), None)


def render(transcript, call, kept, refused, unheard, as_of, out):
    def cell(label, f, fallback="not in the transcript"):
        if f is None:
            return f"<div class='cell'><span>{e(label)}</span><b class='src'>{e(fallback)}</b></div>"
        return (f"<div class='cell'><span>{e(label)}</span><b>{nt(f['value'])}</b>"
                f"<div class='src'>{e(seg_ref(transcript, f))}</div></div>")

    head = (f"<div class='cell'><span>Call date</span><b>{e(call.get('date'))}</b>"
            f"<div class='src'>{e(call.get('date_source', 'from the record'))}</div></div>"
            f"<div class='cell'><span>Matter</span><b>{e(call.get('matter'))}</b></div>"
            + cell("IRS line", first(kept, "line"), call.get("line") or "not in the transcript")
            + cell("IRS employee", first(kept, "irs_employee"))
            + cell("Employee ID", first(kept, "employee_id"))
            + cell("Unit or office", first(kept, "unit")))

    def fact_row(f, tag=True):
        extra = ""
        if f["kind"] == "commitment":
            who = f.get("who") or "not stated"
            due = f.get("due")
            late = due and date.fromisoformat(due) < as_of and (f.get("status") or "open") == "open"
            extra = (f" <span class='tag'>{e(who)}</span>"
                     + (f"<span class='{'late' if late else ''}'>due {e(due)}{' (past due)' if late else ''}</span>"
                        if due else "<span class='src'>no date said</span>"))
        if f["kind"] == "date" and f.get("as_said"):
            extra = f" <span class='src'>said as {nt(f['as_said'])}</span>"
        return (f"<div class='row'>{('<span class=tag>' + e(KINDS[f['kind']]) + '</span>') if tag else ''}{nt(f['value'])}{extra}"
                f"<div class='q'>&ldquo;{nt(f.get('quote'))}&rdquo; "
                f"<span class='src'>{e(seg_ref(transcript, f))}</span></div></div>")

    body = ""
    for title, kinds in SECTIONS:
        rows = [f for f in kept if f["kind"] in kinds]
        if not rows and title == "Other":
            continue
        body += (f"<div class='card'><div class='k'>{e(title)}</div>"
                 + ("".join(fact_row(f, len(kinds) > 1) for f in rows) or "<div class='foot'>Nothing recorded.</div>")
                 + "</div>")

    unheard_rows = "".join(
        f"<div class='row'><span class='tag'>{e(kind)}</span>{nt(it['text'])} "
        f"<span class='src'>seg {it['seg']}</span></div>" for kind, it in unheard) \
        or "<div class='foot'>Every number, date, amount, and notice spotted is in a fact above.</div>"
    ref_rows = "".join(f"<div class='row'><b>Fact {i}.</b> {e('; '.join(pr))}. "
                       f"<span class='src'>{nt((f.get('quote') or '')[:120])}</span></div>"
                       for i, f, pr in refused) or "<div class='foot'>None refused.</div>"
    c = transcript["counts"]
    html = f"""<!DOCTYPE html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>IRS Call Note</title><style>{CSS}</style></head><body><div class="w">
<div class="k">IRS Call Note &middot; Item 10</div>
<h1>{e(call.get('matter'))} &middot; {e(call.get('date'))}</h1>
<p class="sub">From {e(transcript['transcript_file'])} ({e(transcript['format'])}), {c['segments']} segments,
{c['words']} words. Every fact below cites its segment, and its quote was found there word for word.</p>
<div class="card"><div class="k">The Call</div><div class="grid">{head}</div></div>
{body}
<div class="card"><div class="k">Heard, Not Recorded</div>{unheard_rows}</div>
<div class="card"><div class="k">Facts Refused</div>{ref_rows}</div>
<div class="card"><p class="foot">A transcript is machine made. A name or a number misheard by
the transcription is misheard here too, so the recording stays the record. This note reports what
was said on the call. The judgment is the attorney's.</p></div>
</div></body></html>"""
    own = re.sub(r'<span class="nt">.*?</span>', " ", html, flags=re.S)
    low = " " + re.sub(r"<[^>]+>", " ", own).lower() + " "
    for w in WORDS_NEVER_PRINTED:
        if w in low:
            raise SystemExit(f"Refusing to write: the note contains '{w.strip()}'.")
    Path(out).write_text(html, encoding="utf-8")


def update_log(path, call, kept, refused, transcript, note_name):
    p = Path(path)
    rows = []
    if p.exists():
        with p.open(newline="", encoding="utf-8-sig") as fh:
            rows = list(csv.DictReader(fh))
    key = (call.get("date"), call.get("matter"), transcript["transcript_file"])
    rows = [r for r in rows if (r.get("date"), r.get("matter"), r.get("transcript")) != key]
    f_emp, f_id, f_unit, f_line = (first(kept, k) for k in ("irs_employee", "employee_id", "unit", "line"))
    rows.append({
        "date": call.get("date"), "matter": call.get("matter"),
        "line": (f_line or {}).get("value") or call.get("line", ""),
        "employee": (f_emp or {}).get("value", ""), "employee_id": (f_id or {}).get("value", ""),
        "unit": (f_unit or {}).get("value", ""),
        "actions": "; ".join(f["value"] for f in kept if f["kind"] == "action")[:300],
        "owed_open": str(sum(1 for f in kept if f["kind"] == "commitment" and (f.get("status") or "open") == "open")),
        "transcript": transcript["transcript_file"], "note": note_name,
        "facts_kept": str(len(kept)), "facts_refused": str(len(refused))})
    rows.sort(key=lambda r: (r.get("date") or "", r.get("matter") or ""))
    with p.open("w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=LOG_COLUMNS, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)
    return len(rows)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--transcript", required=True)
    ap.add_argument("--facts", required=True)
    ap.add_argument("--log")
    ap.add_argument("--out", required=True)
    ap.add_argument("--summary")
    ap.add_argument("--as-of")
    a = ap.parse_args()

    transcript = json.loads(Path(a.transcript).read_text(encoding="utf-8"))
    doc = json.loads(Path(a.facts).read_text(encoding="utf-8"))
    call, facts = doc.get("call", {}), doc.get("facts", [])
    for need in ("date", "matter"):
        if not call.get(need):
            raise SystemExit(f"facts.json needs call.{need}.")
    date.fromisoformat(call["date"])
    as_of = date.fromisoformat(a.as_of) if a.as_of else date.today()

    kept, refused = check_facts(transcript, facts)
    unheard = covered(transcript.get("spotted", {}), kept)
    render(transcript, call, kept, refused, unheard, as_of, a.out)
    print(f"Written: {a.out}")
    print(f"  {len(kept)} fact(s) kept, {len(refused)} refused, {len(unheard)} item(s) heard and not recorded")
    if a.log:
        n = update_log(a.log, call, kept, refused, transcript, Path(a.out).name)
        print(f"  call log {a.log}: {n} call(s)")
    if a.summary:
        Path(a.summary).write_text(json.dumps({"call": call, "facts": kept,
                                               "transcript_file": transcript["transcript_file"]},
                                              indent=1, ensure_ascii=False), encoding="utf-8")
        print(f"  verified facts for the client summary: {a.summary}")
    for i, f, pr in refused:
        print(f"  REFUSED fact {i}: {'; '.join(pr)}")
    for kind, it in unheard:
        print(f"  HEARD, NOT RECORDED: {kind} '{it['text']}' in seg {it['seg']}")


if __name__ == "__main__":
    main()
